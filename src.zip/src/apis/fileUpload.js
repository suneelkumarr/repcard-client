/**
 *
 * Description. Common Utility function for file upload
 *
 * @link   URL
 * @file   This function is used for any file upload capability like profile pic
 * @since  1.0.0
 */
import axios from 'axios';
import sessionErrorHandle from './sessionErrorHandle';
import app from '../helpers/appGlobal';

const baseApiURL = `${app.config.API_URL}/api`;

const fileUpload = (file, cancelToken, onProgress, cb, extraParams) => {
  const data = new FormData();
  data.append('file', file);
  data.append('userId', extraParams.userId);

  const config = {
    headers: {
      'content-type': 'multipart/form-data',
    },
  };
  if (app.user.token) {
    config.headers.Authorization = `${app.user.token}`;
  }
  if (cancelToken) {
    config.cancelToken = cancelToken;
  }
  if (onProgress) {
    config.onUploadProgress = onProgress;
  }

  axios
    .post(`${baseApiURL}/uploadDocs`, data, config)
    .then((response) => {
      if (sessionErrorHandle(response.data)) {
        cb(response.data);
      }
    })
    .catch((error) => {
      console.log(error);
    });
};

export default fileUpload;
