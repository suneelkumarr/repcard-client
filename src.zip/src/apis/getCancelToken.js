/**
 *
 * Description. Axios cancel token
 *
 * @link   URL
 * @file   Get cancel token from axios (used for cancelling the API)
 * @since  1.0.0
 */
import axios from 'axios';

const getCancelToken = () => {
  const { CancelToken } = axios;
  const source = CancelToken.source();
  return source;
};

export default getCancelToken;
