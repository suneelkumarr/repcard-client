// Global variables for Publish subscribe functionality
const PUB_SUB = {
  MOUSEDOWN: 'mousedownEvent',
  MOUSESCROLL: 'mousescrollEvent',
  RESIZE: 'resizeEvent',
  PAGE_VISIBILITY: 'visibilityChangeEvent',
};

export default PUB_SUB;
