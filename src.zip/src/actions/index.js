/* eslint import/prefer-default-export: 0 */
import * as actionType from './ActionType';

export function actionGetUserDashboard(payload) {
  return {
    type: actionType.GET_USER_DETAILS,
    payload,
  };
}
