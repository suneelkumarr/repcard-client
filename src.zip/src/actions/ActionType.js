/* eslint import/prefer-default-export: 0 */
export const GET_USER_DETAILS = 'get_user';
