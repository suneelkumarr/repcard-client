/**
 * Description. validation Wrapper.
 *
 * @link   URL
 * @file   Validation functions for email, firstname, lastname, phone etc...
 * @since  1.0.0
 */
import isURL from 'validator/lib/isURL';
import isEmpty from 'lodash/isEmpty';
import isEmail from 'validator/lib/isEmail';
import isValidateMobile from '../../utils/isValidateMobile';

const {
  wbValidateAlphaNumeric,
  wbValidatePassword,
} = require('../commonvalidation');

const requiredField = 'This field is mandatory';

const invalidPassword =
  'Your password must be between 8 and 15 characters, one uppercase letter, one lowercase letter, and one number and one special character.';

const validateObj = {
  email: (value) => {
    if (!value || isEmpty(value.trim())) {
      return requiredField;
    }
    if (value.length > 50) {
      return 'Maximum 50 characters allowed';
    }
    if (!isEmail(value)) {
      return 'Invalid Email';
    }
    return '';
  },
  cardName: (value) => {
    if (!value || isEmpty(value.trim())) {
      return requiredField;
    }
    if (value.length > 50) {
      return 'Maximum 50 Characters Allowed';
    }
    return '';
  },
  firstName: (value) => {
    if (!value || isEmpty(value.trim())) {
      return requiredField;
    }
    if (value.length < 3) {
      return 'Minimum 3 Characters';
    }
    if (value.length > 50) {
      return 'Maximum 50 Characters Allowed';
    }
    if (!wbValidateAlphaNumeric(value)) {
      return 'only alphanumeric characters';
    }
    return '';
  },
  lastName: (value) => {
    if (!value || isEmpty(value.trim())) {
      return requiredField;
    }
    if (value.length < 3) {
      return 'Minimum 3 Characters';
    }
    if (value.length > 50) {
      return 'Maximum 50 Characters Allowed';
    }
    if (!wbValidateAlphaNumeric(value)) {
      return 'only alphanumeric characters';
    }
    return '';
  },

  profileurl: (value) => {
    if (!value || isEmpty(value.trim())) {
      return requiredField;
    }
    if (value.length < 5) {
      return 'Minimum 5 Characters';
    }
    if (value.length > 50) {
      return 'Maximum 50 Characters Allowed';
    }
    if (!wbValidateAlphaNumeric(value)) {
      return 'only alphanumeric characters';
    }

    return '';
  },

  phone: (value) => isValidateMobile(value),
  customerServicePhone: (value) => isValidateMobile(value),
  title: (value, id) => {
    if (!value || isEmpty(value.trim())) {
      return requiredField;
    }

    if (!id) {
      return 'Please choose value from drop down';
    }
    return '';
  },
  designation: (value) => {
    if (!value || isEmpty(value.trim())) {
      return requiredField;
    }
    return '';
  },
  website: (value) => {
    if (!value || isEmpty(value.trim())) {
      return requiredField;
    }
    const options = {
      require_protocol: false,
    };
    if (!isURL(value, options)) {
      return 'Please enter valid url';
    }
    return '';
  },
  fromDate: (value) => {
    if (!value || isEmpty(value.trim())) {
      return requiredField;
    }
    return '';
  },
  toDate: (toDate, fromDate) => {
    if (!toDate || isEmpty(toDate.trim())) {
      return requiredField;
    }

    if (toDate < fromDate) {
      return 'ToDate must be greater or equal to front date';
    }
    return '';
  },
  backupRep: (value) => {
    if (!value) {
      return requiredField;
    }
    return '';
  },
  companyName: (value, companyId) => {
    if (!value || isEmpty(value.trim())) {
      return requiredField;
    }

    if (!companyId) {
      return 'Please choose value from drop down';
    }
    return '';
  },
  productcategoryName: (value, id) => {
    if (!value || isEmpty(value.trim())) {
      return requiredField;
    }

    if (!id) {
      return 'Please choose value from drop down';
    }
    return '';
  },
  hospital: (value, id) => {
    if (!value || isEmpty(value.trim())) {
      return requiredField;
    }

    if (!id) {
      return 'Please choose value from drop down';
    }
    return '';
  },
  company: (value, id) => {
    if (!value || isEmpty(value.trim())) {
      return requiredField;
    }

    if (!id) {
      return 'Please choose value from drop down';
    }
    return '';
  },
  specialty: (value, id) => {
    if (!value || isEmpty(value.trim())) {
      return requiredField;
    }

    if (!id) {
      return 'Please choose value from drop down';
    }
    return '';
  },
  password: (value) => {
    if (!value || isEmpty(value.trim())) {
      return requiredField;
    }
    if (value.length > 15) {
      return 'Maximum 15 characters allowed';
    }
    if (!wbValidatePassword(value)) {
      return invalidPassword;
    }
    return '';
  },
  confirmpass: (value, password) => {
    if (!value || isEmpty(value.trim())) {
      return requiredField;
    }
    if (value.length > 15) {
      return 'Maximum 15 characters allowed';
    }
    if (value !== password) {
      return "Password doesn't match, please re-enter";
    }
    return '';
  },
  loginPassword: (value) => {
    if (!value || isEmpty(value.trim())) {
      return requiredField;
    }
    if (value.length > 15) {
      return 'Maximum 15 characters allowed';
    }
    return '';
  },
};

export default validateObj;
