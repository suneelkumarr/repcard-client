/**
 * Description. validation Wrapper.
 *
 * @link   URL
 * @file   All the common validation utilities (Regex)
 * @since  1.0.0
 */

import wbValidateWithRegex from '../utils/validateWithRegex';

const wbValidateAlphaNumeric = (val) =>
  wbValidateWithRegex(val, /^[A-Za-z0-9\s]+$/);

const wbValidateName = (val) => wbValidateWithRegex(val, /^[A-Za-z\-\s]+$/);

const wbValidateNumber = (val) => wbValidateWithRegex(val, /^[0-9]+$/);

const wbValidateSSN = (val) =>
  wbValidateWithRegex(val, /^(?:\d{3}-\d{2}-\d{4})$/);

const wbValidateUSAzip = (val) => wbValidateWithRegex(val, /^\d{5}(-\d{4})?$/);

const wbValidatePhoneNumber = (val) =>
  wbValidateWithRegex(
    val,
    /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/
  );
/*
  return wbValidateWithRegex(
    val,
    /^\(?([2-9]{1}[0-9]{2})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/
  ); //this is for US phone number will not allovw 0 and 1 in first char
  */

const wbValidatePassword = (val) =>
  /* ^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$
  This regex will enforce these rules:

  At least one upper case English letter, (?=.*?[A-Z])
  At least one lower case English letter, (?=.*?[a-z])
  At least one digit, (?=.*?[0-9])
  At least one special character, (?=.*?[#?!@$%^&*-])
  Minimum eight in length .{8,} (with the anchors) */
  wbValidateWithRegex(
    val,
    // /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9#?!@$%^&*-]).{8,}$/
    /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,15}$/
  );

export {
  wbValidateName,
  wbValidateSSN,
  wbValidatePhoneNumber,
  wbValidatePassword,
  wbValidateNumber,
  wbValidateUSAzip,
  wbValidateAlphaNumeric,
};
