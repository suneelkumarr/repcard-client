/**
 *
 * Description. Autocomplete Utility (react-autocomplete package)
 *
 * @link   URL
 * @file   Display Autocomplete List as per the users's custom search.
           Also display automcomplete list through an api call if the list very
           large or dynamic list needs to be fetched.
 * @since  1.0.0
 */
import React, { Component } from 'react';
import Autocomplete from 'react-autocomplete';
import isEmpty from 'lodash/isEmpty';
import { matchStateToTermCustom, sortItemsCustom } from './autoCompleteUtils';
import { axiosApi } from '../apis/axiosApiCall';
import scrollCheck from './scrollCheck';

class RepAutocomplete extends Component {
  constructor(props) {
    super(props);
    const { items, minChar } = this.props;
    this.state = {
      autocompleteArr: items || [],
      apiId: 0,
      offset: 0,
      apiOnScroll: false,
      limit: 100,
      autocompleteValue: '',
      minChar: minChar === 0 ? 0 : minChar || 3,
    };

    this.onScroll = this.onScroll.bind(this);
    this.onChange = this.onChange.bind(this);
    this.onSelect = this.onSelect.bind(this);
    this.requestTimer = null;
  }

  componentDidMount() {}

  /**
   * Summary. On scroll event
   *
   * Description. Load more autocomplete data on scroll
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param  {Object}   e      event object
   */
  onScroll = (e) => {
    const { offset, apiOnScroll, autocompleteValue } = this.state;
    if (scrollCheck(e, offset, apiOnScroll)) {
      this.setState({
        apiOnScroll: true,
      });
      this.makeAPIrequest(autocompleteValue, offset);
    }
  };

  checkIsArrEmpty = (arr, name) => {
    if (!isEmpty(arr) && !isEmpty(arr[name])) {
      return arr[name];
    }
    if (!isEmpty(arr) && Array.isArray(arr)) {
      return arr;
    }
    return false;
  };

  setAutocompleteData(arr, name, offset) {
    const { limit } = this.state;
    const data = this.checkIsArrEmpty(arr, name);

    if (data) {
      let offset1 = 0;
      if (arr.isMore) {
        offset1 = offset + limit;
      }
      this.setState({
        autocompleteArr: data,
        isAutoCompleteData: true,
        offset: offset1,
      });
    } else {
      this.setState({ autocompleteArr: [], isAutoCompleteData: false });
    }
  }

  setAutocompleteDataOnScroll(arr, name, offset) {
    const { limit } = this.state;
    let offset1 = 0;
    const data = this.checkIsArrEmpty(arr, name);
    if (data) {
      if (arr.isMore) {
        offset1 = offset + limit;
      }
      this.setState((prevState) => ({
        autocompleteArr: [...prevState.autocompleteArr, ...data],
        offset: offset1,
      }));
    } else {
      this.setState({
        offset: offset1,
      });
    }
  }

  setData(id, offset, items, name) {
    const { apiId } = this.state;

    if (id >= apiId) {
      if (offset === 0) {
        this.setAutocompleteData(items, name, offset);
      } else {
        this.setAutocompleteDataOnScroll(items, name, offset);
      }
    }
  }

  /**
   * Summary. AutoComplete API
   *
   * Description. To retrive autocomplete list using api call with limit and offset
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   value     autocomplete value
   * @param {Integer}  offset    offset for fetching the list
   */
  makeAPIrequest(value, offset) {
    const { limit, apiId } = this.state;
    const { apiurl } = this.props;
    const apiId1 = apiId + 1;
    this.setState(
      {
        apiId: apiId1,
      },
      () => {
        const apiURLParam = `${apiurl}?text=${value}&offset=${offset}&limit=${limit}`;
        axiosApi(
          apiURLParam,
          'GET',
          '',
          (items, id) => {
            this.setData(id, offset, items.data, 'items');
            this.setState({
              apiOnScroll: false,
            });
          },
          '',
          '',
          apiId1
        );
      }
    );
  }

  callAutocomplete(value) {
    const { minChar } = this.state;
    if (value.length >= minChar) {
      const { isAutoCompleteData, autocompleteValue } = this.state;
      if (
        isAutoCompleteData === false &&
        value.length > autocompleteValue.length
      ) {
        return;
      }
      this.setState({ autocompleteArr: [] });
      clearTimeout(this.requestTimer);
      this.requestTimer = setTimeout(() => {
        this.makeAPIrequest(value, 0);
      }, 250);
    } else {
      this.setState({ isAutoCompleteData: '' });
    }
  }

  componentWillUnmount() {
    clearTimeout(this.requestTimer);
  }

  /**
   * Summary. OnChange event
   *
   * Description. Input Change method for all input
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   event           Input element event object
   * @param {String}   value           Input value
   *
   */
  onChange(event, value) {
    const { apiurl, onChange } = this.props;
    this.setState({
      autocompleteValue: value,
    });
    if (apiurl) {
      this.callAutocomplete(value);
    }
    onChange(event, value);
  }

  /*
   *
   * Call AutoComplete API on input focus event only if Api url is passed
   */
  onFocus = () => {
    const { autocompleteValue } = this.state;
    const { apiurl } = this.props;
    if (apiurl && !autocompleteValue) {
      const { offset } = this.state;
      if (offset === 0) {
        this.callAutocomplete('');
      }
    }
  };

  onSelect(value, item) {
    const { onSelect } = this.props;
    this.setState({
      autocompleteValue: value,
    });
    onSelect(value, item);
  }

  render() {
    const { autocompleteValue, autocompleteArr } = this.state;
    const {
      containerClass,
      items,
      apiurl,
      inputClass,
      inputName,
      placeholder,
      onFocus,
      onBlur,
      getItemValue,
      shouldItemRender,
      sortItems,
      renderInput,
      renderItem,
      error,
      value,
      removeWrapperClass,
      selectOnBlur,
      autoHighlight,
    } = this.props;

    let containerClassNames = '';
    if (!removeWrapperClass) {
      containerClassNames += `md-form ${containerClass || ''}`;
    }

    let autoArr = items || [];
    if (apiurl) {
      autoArr = autocompleteArr;
    }

    return (
      <div className="react-autocomplete">
        <Autocomplete
          ref={(el) => {
            this.input = el;
          }}
          inputProps={{
            className: `form-control ${inputClass}`,
            name: inputName,
            type: 'search',
            placeholder: placeholder || '',
            onFocus: (e) => {
              this.onFocus();
              if (onFocus) {
                onFocus(e);
              }
            },
            onBlur: (e) => {
              if (onBlur) {
                onBlur(e);
              }
            },
          }}
          wrapperProps={{
            className: `${containerClassNames}`,
          }}
          wrapperStyle={{}}
          getItemValue={(item) => {
            if (getItemValue) {
              return getItemValue(item);
            }
            return item.name;
          }}
          items={autoArr}
          shouldItemRender={(state, value1) => {
            if (shouldItemRender) {
              return shouldItemRender(state, value1);
            }
            return matchStateToTermCustom(state.name, value1);
          }}
          sortItems={(a, b, value1) => {
            if (sortItems) {
              return sortItems(a, b, value1);
            }
            return sortItemsCustom(a.name, b.name, value1);
          }}
          renderInput={(props) => {
            if (renderInput) {
              return renderInput(props);
            }
            return [
              <input key="1" {...props} />,
              <label data-error={error} key="2" />,
            ];
          }}
          renderMenu={(items1) => (
            <ul onScroll={this.onScroll} className="mdb-autocomplete-wrap">
              {items1}
            </ul>
          )}
          renderItem={(item, isHighlighted) => {
            if (renderItem) {
              return renderItem(item, isHighlighted);
            }
            return (
              <li
                style={{ background: isHighlighted ? '#eeeeee' : '' }}
                key={item.abbr}
              >
                {item.name}
              </li>
            );
          }}
          value={value || autocompleteValue}
          onChange={this.onChange}
          onSelect={this.onSelect}
          selectOnBlur={selectOnBlur || false}
          autoHighlight={autoHighlight !== false}
        />
        <div
          role="presentation"
          className="arrow-list-autocomplete"
          onClick={() => {
            this.input.focus();
          }}
        />
      </div>
    );
  }
}

export default RepAutocomplete;
