/**
 *
 * Description. URLSearchParams
 *
 * @link   URL
 * @file   Get values from url seacrh(query) parameters
 * @since  1.0.0
 */
import app from '../helpers/appGlobal';

const { decrypt } = require('../config/encrypt-decrypt');

/**
 * Summary. Get parameters from URL query
 *
 * Description. ?email=a@b.com => This function gets the email parameter as per
 *              this url, here no decryption required
 *
 * @since      1.0.0
 * @deprecated No //x.x.x Use new_function_name() instead.
 * @access     export public
 *
 * @param {object}   location       window.location.
 * @param {string}   name           name of the param.
 * @param {boolean}  isNoDecrypt    is decrytion required or not
 *
 */
const getAndSetIdFromQuery = (location, name, isNoDecrypt) => {
  if (location) {
    const { search } = location;
    if (search) {
      const urlParams = new URLSearchParams(search);
      const email = urlParams.get(name);
      if (email) {
        if (isNoDecrypt) {
          return email;
        }
        return decrypt(email, app.config.AES_ENCRYPTION_KEY);
      }
    }
  }
  return '';
};

export default getAndSetIdFromQuery;
