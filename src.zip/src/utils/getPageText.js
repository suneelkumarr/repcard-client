import { axiosSimple } from '../apis/axiosApiCall';

/**
 *
 * Description. Get Text For Page
 *
 * @link   URL
 * @file   Get the pieces of text needed for the page by passing the page prefix
 * @since  1.0.0
 */
// returns an object where the properties are text_id and values are text_value
// eg pageText.login_profile_heading
const getTextForPage = async (textIdPrefix) => {
  const path = `/siteText/${textIdPrefix}`;
  const res = await axiosSimple('GET', path);
  return res.data.data.reduce((acc, d) => {
    acc[d.text_id] = d.text_value;
    return acc;
  }, {});
};

const getTextValueByTextId = (pageText, textId) => {
  return pageText[textId] ? pageText[textId] : '';
};

export { getTextForPage, getTextValueByTextId };
