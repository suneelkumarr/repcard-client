/**
 *
 * Description. Enter key utility
 *
 * @link   URL
 * @file   Detects user has pressed enter key or not
 * @since  1.0.0
 */
const isEnterKeyPressed = (e) => {
  const code = e.keyCode ? e.keyCode : e.which;
  if (code === 13) {
    return true;
  }
  return false;
};

export default isEnterKeyPressed;
