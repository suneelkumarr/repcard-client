/**
 *
 * Description. Sorting Utility
 *
 * @link   URL
 * @file   Sort items for react-autocomplete library
 * @since  1.0.0
 */
export function sortItemsCustom(aName, bName, value) {
  const aLower = aName.toLowerCase();
  const bLower = bName.toLowerCase();
  const valueLower = value.toLowerCase();
  const queryPosA = aLower.indexOf(valueLower);
  const queryPosB = bLower.indexOf(valueLower);
  if (queryPosA !== queryPosB) {
    return queryPosA - queryPosB;
  }
  return aLower < bLower ? -1 : 1;
}

// Find only those values which is matching to custom input
export function matchStateToTermCustom(name, value) {
  return name.toLowerCase().indexOf(value.toLowerCase()) !== -1;
}
