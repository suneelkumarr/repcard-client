/**
 *
 * Description. Premium plan details
 *
 * @link   URL
 * @file   All the functions related to premium plans like plan details,
           to get customer id and subscription id.
           Whether premium plan is active or not.
           Premium plan unsubscribe information
 * @since  1.0.0
 */
import moment from 'moment';
import app from '../helpers/appGlobal';

// Get subscription details
export const getSubscription = () => {
  return app.user.subscription;
};

// Get subscription plan details if available
export const getPlanDetails = () => {
  const subscription = getSubscription();
  if (subscription) {
    return subscription.plan;
  }
  return '';
};

// Check whether user is in basic/premium plan
export const getBasicPlan = (planDetails) => {
  if (planDetails && planDetails.id) {
    return false;
  }
  return true;
};

// Check whether user is in basic/premium plan
export const getBasicPlanNew = () => {
  const planDetails = getPlanDetails();
  if (planDetails && planDetails.id) {
    return false;
  }
  return true;
};

// Get subscription end date of current plan
export const getPlanCancel = () => {
  const subscription = getSubscription();
  if (subscription) {
    return subscription.cancel_at_period_end;
  }
  return false;
};

// Get subscription Id
export const getSubscriptionId = () => {
  const subscription = getSubscription();
  if (subscription) {
    return subscription.id;
  }
  return '';
};

// Get end date in proper format like 1st jun, 2020
export const getEndDate = () => {
  const subscription = getSubscription();
  if (subscription) {
    const endDateTime = subscription.current_period_end;
    return moment.unix(endDateTime).format('MMMM Do, YYYY');
  }
  return '';
};

// Get Customer Id
export const getCustomerId = () => {
  const subscription = getSubscription();
  if (subscription) {
    return subscription.customer;
  }
  return '';
};
