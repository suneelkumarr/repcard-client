/**
 * Summary. On scroll check
 *
 * Description. Load more search results on scroll
 *
 * @since      1.0
 * @deprecated No //x.x.x Use new_function_name() instead.
 * @access     export public
 *
 * @param  {Object}    e            event object
 * @param  {integer}   offset       check if no data available
 * @param  {boolean}   apiOnScroll  check if api is already called on scroll
 */
const scrollCheck = (e, offset, apiOnScroll) => {
  const el = e.target;
  // Check if already API is called or not. Also check if API is needed or not.
  if (offset !== 0 && !apiOnScroll) {
    // Check if the scroll is at bottom
    if (el.scrollTop + el.getBoundingClientRect().height >= el.scrollHeight) {
      return true;
    }
  }
  return false;
};

export default scrollCheck;
