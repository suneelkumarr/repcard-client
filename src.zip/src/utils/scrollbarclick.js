/**
 *
 * Description. Scrollbar event check
 *
 * @link   URL
 * @file   Check if the browser scrollbar was clicked
 * @since  1.0.0
 */
const clickedScrollbar = (evt) =>
  document.documentElement.clientWidth <= evt.clientX ||
  document.documentElement.clientHeight <= evt.clientY;

export default clickedScrollbar;
