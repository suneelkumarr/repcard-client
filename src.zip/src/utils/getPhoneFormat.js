/**
 *
 * Description. Phone Format
 *
 * @link   URL
 * @file   Return the Phone number as per US format e.g. (111.111.1111)
 * @since  1.0.0
 */
const phoneFormat = (num) => {
  if (num) {
    num = num.replace(/-/g, ''); // eslint-disable-line
    if (num.length === 10) {
      return `${num.slice(0, 3)}.${num.slice(3, 6)}.${num.slice(6, 10)}`;
    }
  }
  return num;
};

export default phoneFormat;
