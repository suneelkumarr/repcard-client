/**
 *
 * Description. NumberFormat (NumberFormat package)
 *
 * @link   URL
 * @file   Converts phone numbers to the US format and display it.
           Also user can only enter digits while entering phone number.
 * @since  1.0.0
 */
import React, { Component } from 'react';
import NumberFormat from 'react-number-format';
import phoneFormat from './getPhoneFormat';

class RepNumberFormat extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  componentDidMount() {}

  // Input onChange event
  onDateChange = (values) => {
    const { onChange, name } = this.props;
    if (onChange) {
      // values.formattedValue is like "###.###.####"
      const apiValue = this.convertDateFormat(values.formattedValue);
      onChange(values, name, apiValue);
    }
  };

  // convert display number values to API param value
  // Like 111.111.1111 to 1111111111
  convertDateFormat = (value) => {
    const { format } = this.props;
    if (value) {
      if (format === 'XXX.XXX.XXXX') {
        return value.replace(/\./g, '');
      }
    }
    return '';
  };

  // convert API numberValue to US phone number
  // Like 1111111111 to 111.111.1111
  convertOriginalDateFormat = (value) => {
    const { format } = this.props;
    if (value) {
      if (format === 'XXX.XXX.XXXX') {
        return phoneFormat(value);
      }
    }
    return '';
  };

  /**
   * Summary. OnBlur event
   *
   * Description. Blur method for all input
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   e           Input element event object
   *
   */
  onBlur = (e) => {
    const { onBlur } = this.props;
    if (onBlur) {
      onBlur(e);
    }
  };

  render() {
    const {
      format,
      value,
      placeholder,
      className,
      name,
      disabled,
      onKeyUp,
    } = this.props;
    // Convert to display number as per US format e.g. 111.111.1111
    const dateValue = this.convertOriginalDateFormat(value);
    if (format === 'XXX.XXX.XXXX') {
      return (
        <NumberFormat
          format="###.###.####"
          placeholder={placeholder === ' ' ? '' : format}
          mask={['X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X']}
          type="text"
          value={dateValue}
          onValueChange={this.onDateChange}
          className={className}
          name={name}
          onBlur={this.onBlur}
          disabled={disabled}
          onKeyUp={onKeyUp || (() => true)}
        />
      );
    }
    return '';
  }
}

export default RepNumberFormat;
