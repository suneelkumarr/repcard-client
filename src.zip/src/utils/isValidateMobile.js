/**
 *
 * Description. Phone number validation
 *
 * @link   URL
 * @file   Check phone nummber is not empty and valid or not.
 * @since  1.0.0
 */
import isEmpty from 'lodash/isEmpty';

const { wbValidateNumber } = require('../validations/commonvalidation');

const requiredField = 'This field is mandatory';

const isValidateMobile = (value, isOptional) => {
  if (!isEmpty(value)) {
    if (!wbValidateNumber(value)) {
      return 'Only Digits Allowed';
    }
    if (value.length !== 10) {
      return 'Invalid US Phone number';
    }
  } else if (!isOptional) {
    return requiredField;
  }
  return '';
};

export default isValidateMobile;
