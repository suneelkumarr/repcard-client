/**
 *
 * Description. ProductCategory API Call
 *
 * @link   URL
 * @file   Get Rep's productcategories using an api call and returns the sorted data
 * @since  1.0.0
 */
import isEmpty from 'lodash/isEmpty';
import { axiosApi } from '../apis/axiosApiCall';

export const sortProductCategory = (productcategoryArr) => {
  productcategoryArr.sort((a, b) => {
    const nameA = a.productcategoryName.toLowerCase();
    const nameB = b.productcategoryName.toLowerCase();
    if (nameA < nameB) {
      return -1; // sort string ascending
    }
    if (nameA > nameB) {
      return 1;
    }
    return 0; // default return value (no sorting)
  });
  return productcategoryArr;
};

/**
 * Summary. ProductCategory API
 *
 * Description. To retrive Rep's ProductCategories information
 *
 * @since      1.0
 * @deprecated No //x.x.x Use new_function_name() instead.
 * @access     export public
 *
 * @param {string}   id       Rep's User Id
 * @param {function} cb       Callback function
 *
 */
export const getProductCategoryApi = (id, cb) => {
  axiosApi(`/repProfile/getRepProductCategories/${id}`, 'GET', '', (res) => {
    let newResults = [];
    if (res.error) {
      console.log(res);
    } else {
      const { results } = res.data;
      if (!isEmpty(results)) {
        newResults = sortProductCategory(results);
      }
    }
    cb(newResults);
  });
};
