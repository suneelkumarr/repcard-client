/**
 *
 * Description. Validation
 *
 * @link   URL
 * @file   Phone number validation using regex
 * @since  1.0.0
 */
import wbValidateWithRegex from './validateWithRegex';

const validateNumber = (val) => wbValidateWithRegex(val, /^[0-9]+$/);

export default validateNumber;
