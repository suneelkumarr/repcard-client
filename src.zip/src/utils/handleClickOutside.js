/**
 *
 * Description. Outside click check
 *
 * @link   URL
 * @file   This is used for checking if user has clicked outside or within the elements
           return true if outside click event occur
 * @since  1.0.0
 */
import clickedScrollbar from './scrollbarclick';

const handleClickOutside = (isOpen, refEle, eventObj, refEle1) => {
  if (isOpen) {
    if (!clickedScrollbar(eventObj.event)) {
      if (refEle && !refEle.current.contains(eventObj.event.target)) {
        if (refEle1) {
          if (!refEle1.current.contains(eventObj.event.target)) {
            return true;
          }
        } else {
          return true;
        }
      }
    }
  }
  return false;
};

export default handleClickOutside;
