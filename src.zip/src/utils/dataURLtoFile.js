/* eslint no-plusplus: 0 */
/**
 *  Convert base64 URL to file object
 */
const dataURLtoFile = (dataurl, filename) => {
  const arr = dataurl.split(',');
  const mime = arr[0].match(/:(.*?);/)[1];
  const bstr = atob(arr[1]);
  let n = bstr.length;
  const u8arr = new Uint8Array(n);
  while (n--) {
    u8arr[n] = bstr.charCodeAt(n);
  }
  if (navigator.msSaveBlob) {
    // detect if Edge browser
    const fileObj = new Blob([u8arr], { type: mime });
    fileObj.lastModifiedDate = new Date();
    fileObj.lastModified = new Date().getTime();
    fileObj.name = filename;
    return fileObj;
  }
  return new File([u8arr], filename, { type: mime });
};

export default dataURLtoFile;
