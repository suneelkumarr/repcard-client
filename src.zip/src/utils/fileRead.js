/**
 *  Read file using file reader
 */
const fileRead = (file, cb) => {
  const fileReader = new FileReader();
  fileReader.onloadend = () => {
    cb(fileReader.result);
  };
  fileReader.readAsDataURL(file);
};

export default fileRead;
