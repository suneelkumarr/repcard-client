/**
 *
 * Description. Load masterData
 *
 * @link   URL
 * @file   Master Data for productcategories, states, Hospitals
 * @since  1.0.0
 */
import isEmpty from 'lodash/isEmpty';
import app from '../helpers/appGlobal';
import { axiosApi } from '../apis/axiosApiCall';

/**
 *
 * Description. productcategories
 *
 * @link   URL
 * @file   Load ProductCategories master data from an API call
 * @since  1.0.0
 */
export const getMasterProductCategoryData = (cb) => {
  if (isEmpty(app.user.productcategories)) {
    axiosApi(`/masterData/getProductCategories`, 'GET', '', (res) => {
      if (res.error) {
        console.warn('error fetching productcategories:', res);
        cb(false);
      } else {
        app.user.productcategories = res.data;
        cb(true);
      }
    });
  } else {
    cb(true);
  }
};

/**
 *
 * Description. States MasterData
 *
 * @link   URL
 * @file   Get All the states information from an API call
 * @since  1.0.0
 */
export const getMasterStatesData = (cb) => {
  if (isEmpty(app.statesArr)) {
    axiosApi(`/masterData/getStates`, 'GET', '', (res) => {
      if (res.error) {
        console.warn('error fetching states:', res);
        cb(false);
      } else {
        app.statesArr = res.data;
        cb(app.statesArr);
      }
    });
  } else {
    cb(app.statesArr);
  }
};

/**
 *
 * Description. States MasterData with Cities
 *
 * @link   URL
 * @file   Get All the states information from an API call, with cities attached
 * @since  1.0.0
 */
export const getMasterStatesDataWithCities = (cb) => {
  if (isEmpty(app.statesArrWithCities)) {
    axiosApi(`/masterData/getStatesWithCities`, 'GET', '', (res) => {
      if (res.error) {
        console.warn('error fetching states with cities:', res);
        cb(false);
      } else {
        app.statesArrWithCities = res.data;
        cb(app.statesArrWithCities);
      }
    });
  } else {
    cb(app.statesArrWithCities);
  }
};

/**
 *
 * Description. Hospitals
 *
 * @link   URL
 * @file   Get All the hospitals related to state from an API call
 * @since  1.0.0
 */
export const getMasterHospitalsData = (id, cb) => {
  const statesName = `hospitals${id}`;
  if (isEmpty(app[statesName])) {
    axiosApi(`/hospitals/${id}`, 'GET', '', (res) => {
      if (res.error) {
        console.warn('error fetching hospitals by state:', res);
        cb(false);
      } else {
        app[statesName] = res.data;
        cb(res.data);
      }
    });
  } else {
    cb(app[statesName]);
  }
};
