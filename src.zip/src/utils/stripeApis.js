/**
 *
 * Description. Stripe Apis
 *
 * @link   URL
 * @file   All stripe related APIs
 * @since  1.0.0
 */
import isEmpty from 'lodash/isEmpty';
import app from '../helpers/appGlobal';
import { axiosApi } from '../apis/axiosApiCall';

/**
 *
 * Description. Fetch Customer
 *
 * @link   URL
 * @file   Load customer data using customer id
 * @since  1.0.0
 */
export const getCustomerAPI = (customerId, cb) => {
  const reqObj = {
    customerId,
  };
  axiosApi('/payment/customer', 'POST', reqObj, (res) => {
    if (res.error) {
      console.log(res.error);
      cb('', res.error);
    } else {
      const { data } = res.data.subscriptions;
      cb(data[0].plan);
    }
  });
};

/**
 *
 * Description. Fetch Payment Method
 *
 * @link   URL
 * @file   Load credit carg and billing details information
 * @since  1.0.0
 */
export const getCustomerPaymentAPI = (customerId, cb) => {
  const reqObj = {
    customerId,
  };
  axiosApi('/payment/customerPaymentMethods', 'POST', reqObj, (res) => {
    if (res.error) {
      cb('', res.error);
    } else {
      app.user.paymentMethod = res.data.data[0]; // eslint-disable-line
      cb(app.user.paymentMethod);
    }
  });
};

/**
 *
 * Description. Fetch Subscription
 *
 * @link   URL
 * @file   Load user's subscription plan details using subscription id
 * @since  1.0.0
 */
export const getSubscriptionApi = (subscriptionId, cb) => {
  if (
    isEmpty(app.user.subscription) ||
    app.user.subscription.id !== subscriptionId
  ) {
    const reqObj = {
      subscriptionId,
    };
    axiosApi('/payment/subscription', 'POST', reqObj, (res) => {
      if (res.error) {
        app.user.subscription = {};
        cb('', res.error);
      } else {
        app.user.subscription = res.data;
        cb(res.data.plan);
      }
    });
  } else {
    cb(app.user.subscription.plan);
  }
};

/**
 *
 * Description. Unsubscribe
 *
 * @link   URL
 * @file   Unsubscribe the current plan by making an api call
 * @since  1.0.0
 */
export const getUnsubscribeApi = (subscriptionId, cb) => {
  const reqObj = {
    subscriptionId,
  };
  axiosApi('/payment/unsubscribe', 'POST', reqObj, (res) => {
    if (res.error) {
      console.log(res);
      cb('', res.error);
    } else {
      app.user.subscription = res.data;
      cb('success', '');
    }
  });
};
