/**
 *
 * Description. Regex utility
 *
 * @link   URL
 * @file   Regex test function
 * @since  1.0.0
 */
const wbValidateWithRegex = (val, regex) => {
  const returnVal = val ? regex.test(val) : true;
  return returnVal;
};

export default wbValidateWithRegex;
