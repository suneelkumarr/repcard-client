/**
 *
 * Description. Rep Header
 *
 * @link   URL
 * @file   Header section for All Rep pages such as Dashboard, RepDashboard,
           My Account
 * @since  1.0.0
 */
import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import IdleTimer from 'react-idle-timer';
import AvatarProfile from '../AvatarProfile';
import ProfilePhoto from '../../Common/ProfilePhoto';
import app from '../../../helpers/appGlobal';
import { axiosApi } from '../../../apis/axiosApiCall';
import { getBasicPlan } from '../../../utils/getPlanInfo';
import { getSubscriptionApi } from '../../../utils/stripeApis';
import '../header.scss';
import {
  getCookieData,
  removeOnLogout,
} from '../../../utils/editUpdateStorage';
import InvitePopup from '../../Common/InvitePopup';

class Header extends Component {
  constructor(props) {
    super(props);
    this.state = {
      mobileMenuOpen: false,
      repData: {},
      invitePopupOpen: false,
    };
  }

  /**
   * Summary. Get Personal Rep Information
   *
   * Description. Call API for Rep's to get Personal info
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  getMyAccountApi = (repId) => {
    axiosApi(
      `/repProfile/getMyAccountRepProfile/${repId}`,
      'GET',
      '',
      (res) => {
        if (res.data) {
          this.setState({
            repData: res.data,
          });
          this.getPaymentInfoAPI(res.data.subscriptionId);
        } else {
          this.getPaymentInfoAPI('');
        }
      }
    );
  };

  /**
   * Summary. Payment API
   *
   * Description. To retrive all the payment related info (plan details)
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   subscriptionId        Plan subscription id
   *
   */
  getPaymentInfoAPI = (subscriptionId) => {
    if (subscriptionId) {
      this.setState({
        // isCustomerAPI: true, unused...
      });
      getSubscriptionApi(subscriptionId, (plan) => {
        if (plan) {
          this.setState({
            // planDetails: plan, unused...
          });
        }
        this.setState({
          // isCustomerAPI: false, unused...
        });
      });
    } else {
      this.setState({
        // isCustomerAPI: false, unused...:
      });
    }
  };

  componentDidMount() {
    if (getCookieData()) {
      this.getMyAccountApi(app.user.id);
      this.getRepProducts();
    } else {
      removeOnLogout();
    }
  }

  /**
   *  Toggle mobile menu popup
   */
  openMenu = () => {
    this.setState((prevState) => ({
      mobileMenuOpen: !prevState.mobileMenuOpen,
    }));
  };

  onClick = (e) => {
    e.preventDefault();
  };

  getRepProducts = () => {
    const { updateProducts } = this.props;
    const urlname = `/repProfile/getProductsForRep?repId=${app.user.id}`;
    const reqBody = {
      filters: { company: [] },
    };

    axiosApi(urlname, 'POST', reqBody, (res) => {
      app.user.products = [];
      if (res.data) {
        app.user.products = res.data;
      }
      // eslint-disable-next-line no-unused-expressions
      updateProducts && updateProducts();
    });
  };

  toggleInvitePopupOpen = () => {
    this.setState((prevState) => ({
      invitePopupOpen: !prevState.invitePopupOpen,
    }));
  };

  render() {
    const { mobileMenuOpen, repData } = this.state;
    const {
      profileRes,
      isHome,
      isMyAccount,
      isMyProducts,
      isMyColleagues,
      isAPINotNeeded,
      showClaimBtn,
    } = this.props;
    const { invitePopupOpen } = this.state;
    const newFirstName = isAPINotNeeded
      ? profileRes.firstName
      : repData.firstName;
    const newLastName = isAPINotNeeded ? profileRes.lastName : repData.lastName;
    const newphotoUrl = isAPINotNeeded ? profileRes.photoUrl : repData.photoUrl;

    const isBasicPlan = getBasicPlan(app.user.subscription);
    return (
      <>
        <IdleTimer timeout={1000 * 60 * 15} onIdle={removeOnLogout} />
        <header className={mobileMenuOpen ? 'mobilemenu' : null}>
          <div
            className="mobilemenuoverlay"
            role="presentation"
            onClick={this.openMenu}
          />
          <div
            className="closeMobileMenu"
            role="presentation"
            onClick={this.openMenu}
          />
          <div className="mobile_enable">
            <ProfilePhoto
              addProfile="mobile-avatar"
              rounded="border-radius"
              photoUrl={newphotoUrl}
            />
            <AvatarProfile
              photoUrl={newphotoUrl}
              firstName={newFirstName}
              lastName={newLastName}
            />
          </div>
          <ul className="nav-list p-0">
            <li>
              <Link to="/RepDashboard">
                <span className="logo" />
                REPCARDz&#8482;
              </Link>
            </li>
            <li>
              <Link className={isHome ? 'active' : ''} to="/RepDashboard">
                Home
              </Link>
            </li>
            {!isBasicPlan && (
              <li>
                <Link
                  className={isMyProducts ? 'active' : ''}
                  to="/RepMyProducts"
                >
                  My <br className="d-none d-md-block" />
                  Products ({app.user.products?.length})
                </Link>
              </li>
            )}
            <li>
              <Link className={isMyAccount ? 'active' : ''} to="/RepMyAccount">
                My <br className="d-none d-md-block" />
                Accounts
              </Link>
            </li>
            <li>
              <Link
                className={isMyColleagues ? 'active' : ''}
                to="/RepMyColleagues"
              >
                My <br className="d-none d-md-block" />
                Colleagues
              </Link>
            </li>
            <li>
              <Link to="/" onClick={this.onClick} className="i_tooltip_hover">
                Provider <br className="d-none d-md-block" />
                Requests
                <div className="info-tooltip bottom">Coming Soon</div>
              </Link>
            </li>
            <li>
              {mobileMenuOpen ? null : (
                <div className="d-flex">
                  <div className="chat-icon">
                    <div className="info-tooltip bottom">
                      Live chat coming soon!
                    </div>
                  </div>{' '}
                  <AvatarProfile
                    photoUrl={newphotoUrl}
                    firstName={newFirstName}
                    lastName={newLastName}
                  />
                  {showClaimBtn && (
                    <div className="header_claim_btn text-center">
                      <div
                        className="claim_btn d-inline-block"
                        onClick={this.toggleInvitePopupOpen}
                      >
                        Give a Month, Get a Month
                      </div>
                    </div>
                  )}
                </div>
              )}
            </li>
          </ul>
        </header>
        <div className="mobile_header">
          <Link to="/RepDashboard">
            <span className="logo" />
            <span className="mobile_logo_txt">REPCARDz&#8482;</span>
          </Link>
          <div
            className="menu-line"
            role="presentation"
            onClick={this.openMenu}
          >
            <span />
            <span />
            <span />
          </div>
        </div>
        <InvitePopup
          open={invitePopupOpen}
          toggle={this.toggleInvitePopupOpen}
        />
      </>
    );
  }
}

export default Header;
