/**
 *
 * Description. Profile Photo with options
 *
 * @link   URL
 * @file   Display user's profile pic with firstName and lastName.
           Also two options are available which is logout and My Profile(Dashboard page)
 * @since  1.0.0
 */
import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import ProfilePhoto from '../Common/ProfilePhoto';
import { removeOnLogout } from '../../utils/editUpdateStorage';

class AvatarProfile extends Component {
  constructor(props) {
    super(props);
    this.state = {
      open: false,
    };
  }

  componentDidMount() {}

  /**
   *  Reload Dashboard page if user is in same page and click occurs
   */
  onClick = () => {
    const { pathname } = window.location;
    if (pathname === '/Dashboard') {
      window.location.reload();
    }
  };

  /**
   *  Toggle profile menu
   */
  openProfile = (event) => {
    event.preventDefault();
    this.setState({ open: true }, () => {
      document.addEventListener('click', this.closeMenu);
    });
  };

  closeMenu = () => {
    this.setState({ open: false }, () => {
      document.removeEventListener('click', this.closeMenu);
    });
  };

  /**
   * Summary. Logout click
   *
   * Description. Remove localstorage session data and redirect to login page
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Object}   e      event object
   *
   */
  onLogout = (e) => {
    e.preventDefault();
    removeOnLogout();
  };

  render() {
    const { open } = this.state;
    const { photoUrl, firstName, lastName } = this.props;
    return (
      <div className="avatar-profile-panel">
        <div
          className="avatar-profile"
          role="presentation"
          onClick={this.openProfile}
          data-repcard-test="openprofile"
        >
          <ProfilePhoto
            addProfile=""
            rounded="rounded-circle"
            photoUrl={photoUrl}
          />
          <span className="avatar-name">
            {firstName} {lastName}
          </span>
          <span className="down-arrow" />
        </div>
        <div
          className={`avatar-prfl-details avatar-collapse ${
            open ? ' in' : ' '
          }`}
        >
          <ul className="avatar-prft-list">
            <li>
              <Link onClick={this.onClick} to="/Dashboard">
                My Profile
              </Link>
            </li>
            <li>
              <Link to="/" onClick={this.onLogout}>
                Log Out
              </Link>
            </li>
          </ul>
        </div>
      </div>
    );
  }
}

export default AvatarProfile;
