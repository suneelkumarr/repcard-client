/**
 *
 * Description. PreLogin Header
 *
 * @link   URL
 * @file   Header section for preLogin pages such as Login, Signup,
           Forgot Password and Reset Password
 * @since  1.0.0
 */
import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import { MDBContainer, MDBRow, MDBCol } from 'mdbreact';
import { ABOUT_US_URL, CONTACT_US_URL } from '../../../config';
import '../header.scss';

class Header extends Component {
  constructor(props) {
    super(props);
    this.state = {
      mobileMenuOpen: false,
    };
  }

  componentDidMount() {}

  /**
   *  Toggle mobile menu popup
   */
  openMenu = () => {
    this.setState((prevState) => ({
      mobileMenuOpen: !prevState.mobileMenuOpen,
    }));
  };

  render() {
    const { mobileMenuOpen } = this.state;
    const { isLoginPage, isOTPPage, isVerified } = this.props;
    return (
      <>
        <header
          className={`prelogin_header clearfix ${
            mobileMenuOpen ? 'mobilemenu' : null
          }`}
        >
          <div
            className="mobilemenuoverlay"
            role="presentation"
            onClick={this.openMenu}
          />
          <div
            className="closeMobileMenu"
            role="presentation"
            onClick={this.openMenu}
          />
          <MDBContainer>
            <MDBRow>
              <MDBCol lg="12">
                <div className="float-left">
                  {isOTPPage && !isVerified ? (
                    <div className="repcardz_logo">
                      <span className="logo" />
                      <span className="logo_txt">REPCARDz&#8482;</span>
                    </div>
                  ) : (
                    <Link to="/Login" className="repcardz_logo">
                      <span className="logo" />
                      <span className="logo_txt">REPCARDz&#8482;</span>
                    </Link>
                  )}
                </div>
                <div className="float-right">
                  <ul className="prenav_list">
                    <li>
                      <a
                        href={ABOUT_US_URL}
                        rel="noopener noreferrer"
                        target="_blank"
                      >
                        About Us
                      </a>
                    </li>
                    <li>
                      <a
                        href={CONTACT_US_URL}
                        rel="noopener noreferrer"
                        target="_blank"
                      >
                        Contact
                      </a>
                    </li>

                    {isOTPPage ? (
                      ''
                    ) : (
                      <li>
                        {isLoginPage ? (
                          ''
                        ) : (
                          <Link to="/Login" className="login_btn">
                            Log In
                          </Link>
                        )}
                      </li>
                    )}
                  </ul>
                </div>
              </MDBCol>
            </MDBRow>
          </MDBContainer>
        </header>
        <div className="mobile_header">
          <Link to="/RepDashboard">
            <span className="logo" />
            <span className="mobile_logo_txt">REPCARDz&#8482;</span>
          </Link>
          <div
            className="menu-line"
            role="presentation"
            onClick={this.openMenu}
          >
            <span />
            <span />
            <span />
          </div>
        </div>
      </>
    );
  }
}

export default Header;
