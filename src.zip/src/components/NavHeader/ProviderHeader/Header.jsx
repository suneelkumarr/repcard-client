/**
 *
 * Description. Provider Header
 *
 * @link   URL
 * @file   Header section for All provider pages such as Dashboard and SearchRep
 * @since  1.0.0
 */
import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import app from '../../../helpers/appGlobal';
import AvatarProfile from '../AvatarProfile';
import ProfilePhoto from '../../Common/ProfilePhoto';
import { axiosApi } from '../../../apis/axiosApiCall';
import '../header.scss';
import InvitePopup from '../../Common/InvitePopup';

class Header extends Component {
  constructor(props) {
    super(props);
    this.state = {
      mobileMenuOpen: false,
      providerData: {},
      invitePopupOpen: false,
    };
  }

  /**
   * Summary. Get Personal Rep Information
   *
   * Description. Call API for Provider's to get Personal info
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  getMyAccountApi = (id) => {
    axiosApi(`/providerProfile/getMyAccountProfile/${id}`, 'GET', '', (res) => {
      if (res.data) {
        this.setState({
          providerData: res.data,
        });
      }
    });
  };

  componentDidMount() {
    const { isAPINotNeeded } = this.props;
    if (!isAPINotNeeded) {
      this.getMyAccountApi(app.user.id);
    }
  }

  /**
   *  Toggle mobile menu popup
   */
  openMenu = () => {
    this.setState((prevState) => ({
      mobileMenuOpen: !prevState.mobileMenuOpen,
    }));
  };

  onClick = (e) => {
    e.preventDefault();
  };

  toggleInvitePopupOpen = () => {
    this.setState((prevState) => ({
      invitePopupOpen: !prevState.invitePopupOpen,
    }));
  };

  render() {
    const { mobileMenuOpen, providerData, invitePopupOpen } = this.state;
    const {
      profileRes,
      isSearch,
      isAPINotNeeded,
      showClaimBtn,
      backFromRepGrid,
    } = this.props;

    const newFirstName = isAPINotNeeded
      ? profileRes.firstName
      : providerData.firstName;
    const newLastName = isAPINotNeeded
      ? profileRes.lastName
      : providerData.lastName;
    const newphotoUrl = isAPINotNeeded
      ? profileRes.photoUrl
      : providerData.photoUrl;
    return (
      <>
        <header className={mobileMenuOpen ? 'mobilemenu' : null}>
          <div
            className="mobilemenuoverlay"
            role="presentation"
            onClick={this.openMenu}
          />
          <div
            className="closeMobileMenu"
            role="presentation"
            onClick={this.openMenu}
          />
          <div className="mobile_enable">
            <ProfilePhoto
              addProfile="mobile-avatar"
              rounded="border-radius"
              photoUrl={newphotoUrl}
            />
            <AvatarProfile
              photoUrl={newphotoUrl}
              firstName={newFirstName}
              lastName={newLastName}
            />
          </div>
          <ul className="nav-list provider-header p-0">
            <li>
              <Link to="/SearchRep">
                <span className="logo" />
                REPCARDz&#8482;
              </Link>
            </li>
            <li>
              <Link
                onClick={backFromRepGrid}
                className={isSearch ? 'active' : ''}
                to="/SearchRep"
              >
                Search
              </Link>
            </li>
            <li>
              <Link to="/" onClick={this.onClick}>
                Schedule A Rep <br className="d-none d-lg-block d-md-block" />{' '}
                (Coming Soon)
              </Link>
            </li>
            <li>
              {mobileMenuOpen ? null : (
                <div className="d-flex">
                  <div className="chat-icon">
                    <div className="info-tooltip bottom">
                      Live chat coming soon!
                    </div>
                  </div>{' '}
                  <AvatarProfile
                    photoUrl={newphotoUrl}
                    firstName={newFirstName}
                    lastName={newLastName}
                  />
                  {showClaimBtn && (
                    <div className="header_claim_btn text-center">
                      <div
                        className="claim_btn d-inline-block"
                        onClick={this.toggleInvitePopupOpen}
                      >
                        Give a Month, Get a Month
                      </div>
                    </div>
                  )}
                </div>
              )}
            </li>
          </ul>
        </header>
        <div className="mobile_header">
          <Link to="/SearchRep">
            <span className="logo" />
            <span className="mobile_logo_txt">REPCARDz&#8482;</span>
          </Link>
          <div
            className="menu-line"
            role="presentation"
            onClick={this.openMenu}
          >
            <span />
            <span />
            <span />
          </div>
        </div>
        <InvitePopup
          open={invitePopupOpen}
          toggle={this.toggleInvitePopupOpen}
        />
      </>
    );
  }
}

export default Header;
