/**
 *
 * Description. Sign up (Step 1)
 *
 * @link   URL
 * @file   Choose any one of the given two options (personal email option is
           disabled for now)
 * @since  1.0.0
 */
import React, { Component } from 'react';
import { MDBRow, MDBCol, MDBInput } from 'mdbreact';
import { TERMS_CONDITION_URL, PRIVACY_POLICY_URL } from '../../config';

class StepOne extends Component {
  constructor(props) {
    super(props);
    const { emailType } = this.props;
    this.state = {
      emailType,
      isChecked: false,
    };
  }

  componentDidMount() {}

  /**
   * Summary. Radio button on click event
   *
   * Description. set emailType (personal or manufacturer email)
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param  {string}      nr       emailType
   */
  onClick = (nr) => {
    this.setState({
      emailType: nr,
    });
  };

  /**
   *  Next button click event
   */
  onBtnClick = () => {
    const { emailType } = this.state;
    const { onClick } = this.props;
    onClick(emailType);
  };

  /**
   * Summary. Agree checkbox change
   *
   * Description. set checked flag of agree checkbox
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param  {object}      e      event object
   */
  onChangeCheckbox = (e) => {
    const { checked } = e.target;
    this.setState({
      isChecked: checked,
    });
  };

  render() {
    const { emailType, isChecked } = this.state;
    const { registrationType } = this.props;
    return (
      <MDBRow>
        <MDBCol lg="12">
          <div className="signup_info">
            <h4 className="heading_h2">How would you like to sign up?</h4>
            <div className="signup_radio mt-4">
              <div className="radio_panel border-right">
                <MDBInput
                  gap
                  onClick={() => {
                    this.onClick('manufacturer');
                  }}
                  checked={emailType === 'manufacturer'}
                  label={
                    registrationType === 'rep'
                      ? 'Sign up with manufacturer email'
                      : 'Sign up with organization email'
                  }
                  type="radio"
                  id="radio1"
                />
              </div>
              <div className="radio_panel pl-5">
                <div className="radio_tooltip position-relative">
                  <MDBInput
                    disabled
                    gap
                    onClick={() => {
                      this.onClick('personal');
                    }}
                    checked={emailType === 'personal'}
                    label={
                      registrationType === 'rep'
                        ? 'Sign up with personal email or distributor email'
                        : 'Sign up with National Provider ID number'
                    }
                    type="radio"
                    id="radio2"
                  />
                  <div className="info-tooltip">Coming Soon!</div>
                </div>

                <div className="help_txt">
                  {registrationType === 'rep' ? (
                    ''
                  ) : (
                    <div>Help me find this</div>
                  )}
                </div>
              </div>
            </div>
            <div className="text-center termconditon">
              <MDBInput
                filled
                label={
                  <>
                    By checking this box and clicking the [Next] button, I agree
                    to be bound by the REPCARDz
                    <a
                      href={TERMS_CONDITION_URL}
                      rel="noopener noreferrer"
                      target="_blank"
                      className="blue-text"
                    >
                      {' '}
                      Terms of Use
                    </a>{' '}
                    and
                    <a
                      href={PRIVACY_POLICY_URL}
                      rel="noopener noreferrer"
                      target="_blank"
                      className="blue-text"
                    >
                      {' '}
                      Privacy Policy
                    </a>
                  </>
                }
                type="checkbox"
                id="checkbox1"
                onChange={this.onChangeCheckbox}
              />
            </div>
            <div className="text-center sign_next mt-5">
              <button
                type="button"
                className="fill-orange-btn"
                onClick={this.onBtnClick}
                disabled={!(emailType && isChecked)}
                data-repcard-test="next"
              >
                Next
              </button>
            </div>
          </div>
        </MDBCol>
      </MDBRow>
    );
  }
}

export default StepOne;
