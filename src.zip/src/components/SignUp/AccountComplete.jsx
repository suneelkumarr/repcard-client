/**
 *
 * Description. Sign up (Account complete)
 *
 * @link   URL
 * @file   When User completes the signup process and user is created the this
           page is displayed. Success page of signup complete process
 * @since  1.0.0
 */
import React from 'react';
/**
 * Summary. Sign up API success page
 *
 * Description. Display this page after registration complete
 *
 * @since      1.0
 * @deprecated No //x.x.x Use new_function_name() instead.
 * @access     export public
 *
 * @param  {string}      registrationType        can be 'rep' or 'provider'
 * @param  {function}    onLoginClick            callback function of login
 * @param  {boolean}     isAPICalled             flag for disable login btn
 */
const AccountComplete = ({ registrationType, onLoginClick, isAPICalled }) => {
  return (
    <>
      <div className="steps_heading">
        Your REPCARDz account has been created!
      </div>
      <p className="acc_copy_txt mt-4">
        A one-time 4-digit code has been sent to your email for verification.
        Click on the link in that email to enter the code{' '}
        {registrationType === 'rep'
          ? 'and activate your account.'
          : 'and begin searching.'}
        <br />
        <br />
        {registrationType === 'rep'
          ? 'In the meantime, you may log in to REPCARDz and continue setting up your profile.'
          : ''}
      </p>
      <div className="text-center btn_panel mt-5">
        <button
          type="button"
          className="fill-orange-btn"
          onClick={onLoginClick}
          disabled={isAPICalled}
        >
          {isAPICalled ? (
            <span className="spinner-border spinner-border-sm" />
          ) : (
            ''
          )}
          Log In
        </button>
      </div>
    </>
  );
};

export default AccountComplete;
