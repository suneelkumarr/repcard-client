import React, { Component } from 'react';
import { MDBContainer, MDBCol, MDBRow, MDBInput, Fa } from 'mdbreact';
import { Redirect } from 'react-router-dom';
import querystring from 'querystring';
import ProfileHeading from '../Common/ProfileHeading';
import validateObj from '../../validations/repprofile/repfront.js';
import { loginApiNew } from '../Common/callLoginApi';
import { axiosApi } from '../../apis/axiosApiCall';
import { encrypt } from '../../config/encrypt-decrypt';
import './claimaccount.scss';

class ClaimAccount extends Component {
  constructor(props) {
    super(props);

    const search = props.location.search.substr(1);
    const { email, userType } = querystring.parse(search);

    this.state = {
      email,
      userType,
      password: '',
      inputClass: {},
      errorObj: {},
      redirectToReferrer: '',
    };
  }

  componentDidMount() {}

  /**
   * Summary. Set input values
   *
   * Description. Update All the input values to state
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   name           name of the input
   * @param {string}   value          value of the input
   *
   */
  setValue = (name, value) => {
    this.setState({
      [name]: value,
    });
  };

  /**
   * Summary. OnChange event
   *
   * Description. Input Change method for all input
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   e           Input element event object
   *
   */
  onChange = (e) => {
    const { name, value } = e.target;
    this.setValue(name, value);
  };

  /**
   * Summary. OnBlur event
   *
   * Description. Blur method for all input
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   e           Input element event object
   *
   */
  onBlur = (e) => {
    const { password } = this.state;
    const { name, value } = e.target;
    this.validateInput(name, value, password);
  };

  /**
   * Summary. Validate Input
   *
   * Description. Sets the error to errorObj and className to inputClass object
   *              if any validation error found.
   *              errorObj is used for displaying the errors for particular input
   *              inputClas is used for Adding error classNames for particular input
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   name           Input element name
   * @param {string}   value          Input element value
   * @param {string}   value1         additional value
   *
   * @return {String} Error if any else null
   */
  validateInput(name, value, value1) {
    if (validateObj[name]) {
      let error = '';
      let className = 'error-border';
      error = validateObj[name](value, value1);
      if (!error) {
        className = '';
      }

      this.setState((prevState) => ({
        errorObj: {
          ...prevState.errorObj,
          [name]: error,
        },
        inputClass: {
          ...prevState.inputClass,
          [name]: className,
        },
      }));

      return error;
    }
    return '';
  }

  /**
   * Summary. Form validation
   *
   * Description. Validate form on submit click
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @return {boolean} false if not valid else true
   */
  validate() {
    const { password, email, confirmpass } = this.state;
    let isValid = true;
    let error;

    error = this.validateInput('email', email);
    if (error) {
      isValid = false;
    }

    error = this.validateInput('password', password);
    if (error) {
      isValid = false;
    }

    error = this.validateInput('confirmpass', confirmpass, password);
    if (error) {
      isValid = false;
    }

    return isValid;
  }

  /**
   * Summary. Form submit on login button
   *
   * Description. Validate on form submit and call the login API. On suceess
   *              Redirect to appropriate page otherwise show error
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   e           event object
   *
   */
  onLogin = async (e) => {
    e.preventDefault();
    const isValid = this.validate();
    if (isValid) {
      const { email, password, userType } = this.state;
      this.setState({
        isAPICalled: true,
        apiErrorMessage: '',
      });

      const reqObj = {
        email: encrypt(email),
        password: encrypt(password),
        userType,
      };

      axiosApi(`/signUp/claimAccount`, 'POST', reqObj, (res) => {
        if (res.error) {
          this.setState({
            apiErrorMessage: res.message,
          });
        } else {
          loginApiNew(email, password)
            .then((data) => {
              this.setState({
                isAPICalled: false,
                redirectToReferrer: data.redirectURL,
              });
            })
            .catch((error) => {
              this.setState({
                apiErrorMessage: error.message,
              });
            });
        }
      });
    }
  };

  /**
   * Summary. Password Toggle
   *
   * Description. Toggle password on click of eye icon
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   e           Input element event object
   * @param {String}   name        name of the inout field
   */
  handleClickShowPassword = (e, name) => {
    e.preventDefault();
    this.setState((prevState) => ({
      [name]: !prevState[name],
    }));
  };

  render() {
    const {
      errorObj,
      inputClass,
      email,
      password,
      confirmpass,
      isAPICalled,
      showPassword,
      showPassword1,
      apiErrorMessage,
      redirectToReferrer,
    } = this.state;

    if (redirectToReferrer) {
      const { location } = this.props;
      const { from } = location.state || {
        from: { pathname: redirectToReferrer },
      };
      return <Redirect to={from} />;
    }

    return (
      <MDBContainer>
        <MDBRow>
          <MDBCol lg="12" className="signup_wrap">
            <MDBRow>
              <MDBCol>
                <ProfileHeading headingtxt="Claim Account" />
                <form onSubmit={this.onLogin} noValidate>
                  <div className="login_fields">
                    <div className={`input-field  ${inputClass.email}`}>
                      <MDBInput
                        type="email"
                        value={email}
                        onBlur={this.onBlur}
                        name="email"
                        onChange={this.onChange}
                        label="Your Email"
                      />
                      {errorObj.email ? (
                        <span className="error-message">{errorObj.email}</span>
                      ) : (
                        ''
                      )}
                    </div>
                    <div className={`input-field  ${inputClass.password}`}>
                      <MDBInput
                        label="Password"
                        name="password"
                        onChange={this.onChange}
                        type={showPassword ? 'text' : 'password'}
                        value={password}
                        onBlur={this.onBlur}
                      />
                      <div
                        className="p-0 password-icon"
                        onClick={(e) => {
                          this.handleClickShowPassword(e, 'showPassword');
                        }}
                        onMouseDown={(e) => e.preventDefault()}
                        role="presentation"
                        data-repcard-test="pass-icon"
                      >
                        <Fa far icon={showPassword ? 'eye' : 'eye-slash'} />
                      </div>
                      {errorObj.password ? (
                        <span className="error-message">
                          {errorObj.password}
                        </span>
                      ) : (
                        ''
                      )}
                    </div>
                    <div className={`input-field  ${inputClass.confirmpass}`}>
                      <MDBInput
                        label="Confirm Password"
                        name="confirmpass"
                        onChange={this.onChange}
                        type={showPassword1 ? 'text' : 'password'}
                        value={confirmpass}
                        onBlur={this.onBlur}
                      />
                      <div
                        className="p-0 password-icon"
                        onClick={(e) => {
                          this.handleClickShowPassword(e, 'showPassword1');
                        }}
                        onMouseDown={(e) => e.preventDefault()}
                        role="presentation"
                        data-repcard-test="pass-icon"
                      >
                        <Fa far icon={showPassword1 ? 'eye' : 'eye-slash'} />
                      </div>
                      {errorObj.confirmpass ? (
                        <span className="error-message">
                          {errorObj.confirmpass}
                        </span>
                      ) : (
                        ''
                      )}
                    </div>
                    <div className="Login-btn-panel mt-5">
                      <button
                        type="submit"
                        className="fill-orange-btn"
                        disabled={isAPICalled}
                      >
                        {isAPICalled ? (
                          <span className="spinner-border spinner-border-sm" />
                        ) : (
                          ''
                        )}
                        Login
                      </button>
                      {apiErrorMessage ? (
                        <p
                          className="error-message1"
                          style={{ fontSize: '14px' }}
                        >
                          {apiErrorMessage}
                        </p>
                      ) : (
                        ''
                      )}
                    </div>
                  </div>
                </form>
              </MDBCol>
            </MDBRow>
          </MDBCol>
        </MDBRow>
      </MDBContainer>
    );
  }
}

export default ClaimAccount;
