/**
 *
 * Description. Sign up (Main Component)
 *
 * @link   URL
 * @file   Main component for signup section and calls other pages like step 1,
           step 2 and step 3 whenever required. Stores all the other pages info.
 * @since  1.0.0
 */
import React, { Component } from 'react';
import { Link, Redirect } from 'react-router-dom';
import { MDBContainer, MDBRow, MDBCol } from 'mdbreact';
import querystring from 'querystring';
import ProfileHeading from '../Common/ProfileHeading';
import StepThree from './StepThree';
import StepTwo from './StepTwo';
import StepOne from './StepOne';
import AccountComplete from './AccountComplete';
import StepNumbers from './StepNumbers';
import { loginApi } from '../Common/callLoginApi';
import {
  getTextForPage,
  getTextValueByTextId,
} from '../../utils/getPageText.js';

class SignUp extends Component {
  constructor(props) {
    super(props);

    const search = props.location.search.substr(1);
    const {
      pageNum,
      userType,
      email,
      firstName,
      lastName,
      isClaimAccount,
      inviteBy,
      inviteUserType,
    } = querystring.parse(search);

    this.state = {
      pageNum: parseInt(pageNum, 10) || 0,
      emailType: '',
      registrationType: userType || '',
      profileRes: {
        email: email || '',
        firstName: firstName || '',
        lastName: lastName || '',
        inviteBy: inviteBy || '',
        inviteUserType: inviteUserType || '',
      },
      redirectToReferrer: '',
      pageTextPrefix: 'signup',
      pageText: {},
      isClaimAccount: Boolean(isClaimAccount) || false,
      userType: userType || '',
    };
  }

  async componentDidMount() {
    const { pageTextPrefix } = this.state;
    const pageText = await getTextForPage(pageTextPrefix);
    this.setState({ pageText });
  }

  /**
   *  Signup with REP
   */
  repCreateClick = () => {
    this.setState({
      pageNum: 1,
      registrationType: 'rep',
    });
  };

  /**
   *  Signup with Provider
   */
  providerCreateClick = () => {
    this.setState({
      pageNum: 1,
      registrationType: 'provider',
    });
  };

  /**
   *  Redirect to step 2 after step one complete
   */
  stepOneClick = (emailType) => {
    this.setState({
      pageNum: 2,
      emailType,
    });
  };

  /**
   * Summary. Step 2 next click event
   *
   * Description. Redirect to step 3 after step 2 complete and store user data
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param  {string}      profileRes        user signup response
   */
  stepTwoClick = (profileRes) => {
    this.setState({
      pageNum: 3,
      profileRes,
    });
  };

  /**
   * Summary. Step 3 next click event
   *
   * Description. Redirect to step 4 after step 3 complete and store password
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param  {string}      profileRes        user signup response
   */
  stepThreeClick = (password) => {
    this.setState({
      pageNum: 4,
      password,
    });
  };

  /**
   *  Go to Previous screen
   */
  gotoBackScreen = () => {
    this.setState((prevState) => ({
      pageNum: prevState.pageNum - 1,
    }));
  };

  /**
   * Summary. Login Btn click
   *
   * Description. Call Login API and redirect to appropriate page
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  onLoginClick = () => {
    const { password, profileRes } = this.state;
    const { email } = profileRes;
    this.setState({
      isAPICalled: true,
    });
    loginApi(email, password, (error, data) => {
      this.setState({
        isAPICalled: false,
      });
      if (!error) {
        this.setState({
          redirectToReferrer: data.redirectURL,
        });
      }
    });
  };

  render() {
    const {
      pageNum,
      emailType,
      registrationType,
      profileRes,
      redirectToReferrer,
      isAPICalled,
      pageText,
      isClaimAccount,
      userType,
    } = this.state;

    if (redirectToReferrer) {
      const from = { pathname: redirectToReferrer };
      return <Redirect to={from} />;
    }

    const headingtxt = isClaimAccount ? 'Claim Account' : 'Create Account';

    return (
      <>
        <MDBContainer>
          <MDBRow>
            <MDBCol lg="12" className="signup_wrap">
              {pageNum === 0 ? (
                <>
                  <ProfileHeading headingtxt={headingtxt} />
                  <div className="signup_main_panel">
                    <MDBRow>
                      <MDBCol lg="6" md="6">
                        <div className="sign_left">
                          <ProfileHeading headingtxt="Healthcare Provider Account" />
                          <p>
                            {getTextValueByTextId(
                              pageText,
                              'signup_provider_intro'
                            )}
                          </p>
                        </div>
                        <div className="text-center btn-panel">
                          <button
                            type="button"
                            className="outline-btn"
                            onClick={this.providerCreateClick}
                            data-repcard-test="provider"
                          >
                            Create Provider Account
                          </button>
                        </div>
                      </MDBCol>
                      <MDBCol lg="6" md="6">
                        <div className="sign_right">
                          <ProfileHeading headingtxt="Healthcare Representative Account" />
                          <p>
                            {getTextValueByTextId(pageText, 'signup_rep_intro')}
                          </p>
                        </div>
                        <div className="text-center btn-panel">
                          <button
                            type="button"
                            className="outline-btn"
                            onClick={this.repCreateClick}
                            data-repcard-test="rep"
                          >
                            Create Representative Account
                          </button>
                        </div>
                      </MDBCol>
                    </MDBRow>
                    <MDBRow>
                      <MDBCol className="mt-5">
                        <p className="text-center login_txt">
                          Already have an account?{' '}
                          <Link to="/Login">Log In</Link>
                        </p>
                      </MDBCol>
                    </MDBRow>
                  </div>
                </>
              ) : (
                ''
              )}

              {pageNum === 1 || pageNum === 2 || pageNum === 3 ? (
                <>
                  <div className="steps_heading clearfix">
                    <div className="float-left">
                      <span
                        className="left_icon cursor"
                        onClick={this.gotoBackScreen}
                        role="presentation"
                        data-repcard-test="back"
                      />
                      <ProfileHeading headingtxt={headingtxt} />{' '}
                      <span className="d-none d-md-inline-block d-lg-inline-block">
                        |
                      </span>
                      {registrationType === 'rep'
                        ? ' Healthcare  Representative'
                        : ' Healthcare Provider'}
                    </div>
                    <StepNumbers stepnumber={pageNum} />
                  </div>
                  <div className="signup_main_panel">
                    {pageNum === 1 ? (
                      <StepOne
                        onClick={this.stepOneClick}
                        emailType={emailType}
                        registrationType={registrationType}
                      />
                    ) : (
                      ''
                    )}
                    {pageNum === 2 ? (
                      <StepTwo
                        emailType={emailType}
                        onClick={this.stepTwoClick}
                        profileRes={profileRes}
                        registrationType={registrationType}
                      />
                    ) : (
                      ''
                    )}
                    {pageNum === 3 ? (
                      <StepThree
                        emailType={emailType}
                        profileRes={profileRes}
                        onClick={this.stepThreeClick}
                        registrationType={registrationType}
                        isClaimAccount={isClaimAccount}
                        userType={userType}
                      />
                    ) : (
                      ''
                    )}
                  </div>
                </>
              ) : (
                ''
              )}
              {pageNum === 4 ? (
                <AccountComplete
                  registrationType={registrationType}
                  onLoginClick={this.onLoginClick}
                  isAPICalled={isAPICalled}
                />
              ) : (
                ''
              )}
            </MDBCol>
          </MDBRow>
        </MDBContainer>
      </>
    );
  }
}

export default SignUp;
