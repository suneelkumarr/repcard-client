import React from 'react';

/**
 * Summary. Step number header
 *
 * Description. return html part of step number
 *
 * @since      1.0
 * @deprecated No //x.x.x Use new_function_name() instead.
 * @access     export public
 *
 * @param  {string}      stepnumber       step number 1, 2 or 3
 */
const StepNumbers = ({ stepnumber, totalSteps }) => {
  return (
    <div className="step_numbers">
      Step {stepnumber} of {totalSteps !== undefined ? totalSteps : '3'}
    </div>
  );
};

export default StepNumbers;
