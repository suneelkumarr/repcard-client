import React, { Component } from 'react';
import { MDBRow, MDBCol, MDBInput, MDBModal, MDBModalBody } from 'mdbreact';
import ProfileHeading from '../Common/ProfileHeading';

class AddCompanyDomain extends Component {
  constructor(props) {
    super(props);
    this.state = {
      modal: false,
    };
  }

  /**
   *  Toggle the modal popup
   */
  toggle = () => {
    this.setState((prevState) => ({
      modal: !prevState.modal,
    }));
  };

  render() {
    const { modal } = this.state;

    return (
      <>
        <p className="domain-add" role="presentation" onClick={this.toggle}>
          click here
        </p>
        <MDBModal
          className="add_account_popup"
          isOpen={modal}
          toggle={this.toggle}
        >
          <MDBModalBody className="p-5">
            <div>
              <ProfileHeading headingtxt="Rep Details" />
              <MDBRow>
                <MDBCol lg="6">
                  <div className="input-field">
                    <MDBInput label="User Name" name="username" type="text" />
                  </div>
                </MDBCol>
                <MDBCol lg="6">
                  <div className="input-field">
                    <MDBInput
                      label="Company Email"
                      name="companyemail"
                      type="text"
                    />
                  </div>
                </MDBCol>
                <MDBCol lg="6">
                  <div className="input-field">
                    <MDBInput
                      label="Parent Company"
                      name="parentcompany"
                      type="text"
                    />
                  </div>
                </MDBCol>
                <MDBCol lg="6">
                  <div className="input-field">
                    <MDBInput
                      label="Acquired Company"
                      name="acquiredcompany"
                      type="text"
                    />
                  </div>
                </MDBCol>
                <MDBCol lg="12">
                  <div className="text-center repdtl_btn">
                    <button type="button" className="fill-orange-btn">
                      Submit
                    </button>
                  </div>
                </MDBCol>
              </MDBRow>
            </div>
            {/*
            <div className="text-center">
              <div
                role="presentation"
                onClick={this.toggle}
                className="close_auth_popup close"
              >
                X close
              </div>
              <p className="record_info">
                Thank you for helping us keep our company records updated. Once
                this M&amp;A activity is verified, we&apos;ll update our records
                and email you so you can finish creating your REPCARDz account.
                Hold tight and we&apos;ll be right back with you.”
              </p>
            </div>
            */}
          </MDBModalBody>
        </MDBModal>
      </>
    );
  }
}

export default AddCompanyDomain;
