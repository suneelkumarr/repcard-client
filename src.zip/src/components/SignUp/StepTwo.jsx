/**
 *
 * Description. Sign up (Step 2)
 *
 * @link   URL
 * @file   Fill All the details like firstname, lastname, title, email and
           companyName for Reps.
           And firstname, lastname, hospital and email for Providers
 * @since  1.0.0
 */
import React, { Component, lazy, Suspense } from 'react';
import { MDBRow, MDBCol, MDBInput } from 'mdbreact';
import isEmpty from 'lodash/isEmpty';
import RepAutocomplete from '../../utils/RepAutocomplete.jsx';
import { matchStateToTermCustom } from '../../utils/autoCompleteUtils';
import isEnterKeyPressed from '../../utils/checkEnterKeyPressed';
import validateObj from '../../validations/repprofile/repfront.js';
import { axiosApi } from '../../apis/axiosApiCall';
import { getMasterStatesDataWithCities } from '../../utils/masterProductCategoryData';
import '../Search/search.scss';

const Loading = () => <div>Loading...</div>;
const SearchHospitalList = lazy(() => import('../Search/SearchHospitalList'));

class StepTwo extends Component {
  constructor(props) {
    super(props);
    this.state = {
      inputClass: {},
      errorObj: {},
      isFocustitle: false,
      isFocuscompany: false,
      // isFocushospital: false,
      isFocusspecialty: false,
      masterStateList: [],
      text: '',
      keyVal: 1,
      open: false,
      profileRes: {
        firstName: props.profileRes.firstName || '',
        lastName: props.profileRes.lastName || '',
        email: props.profileRes.email || '',
        inviteBy: props.profileRes.inviteBy || '',
        inviteUserType: props.profileRes.inviteUserType || '',
        title: props.profileRes.title || '',
        company: props.profileRes.company || '',
        hospital: {},
        specialty: {},
      },
    };
  }

  componentDidMount() {
    this.getStatesData();
  }

  /**
   * Summary. Form validation
   *
   * Description. Validate form on submit click
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @return {boolean} false if not valid else true
   */
  validate() {
    const { profileRes } = this.state;
    const { registrationType } = this.props;
    const {
      firstName,
      lastName,
      company,
      title,
      hospital,
      email,
      specialty,
    } = profileRes;
    let isValid = true;
    let error;

    error = this.validateInput('firstName', firstName);
    if (error) {
      isValid = false;
    }

    error = this.validateInput('lastName', lastName);
    if (error) {
      isValid = false;
    }

    error = this.validateInput('title', title.value, title.id);
    if (error) {
      isValid = false;
    }

    error = this.validateInput('email', email);
    if (error) {
      isValid = false;
    }

    if (registrationType === 'rep') {
      error = this.validateInput('company', company.value, company.id);
      if (error) {
        isValid = false;
      }
    } else {
      error = this.validateInput('hospital', hospital.value, hospital.id);
      if (error) {
        isValid = false;
      }
      error = this.validateInput('specialty', specialty.value, specialty.id);
      if (error) {
        isValid = false;
      }
    }

    return isValid;
  }

  /**
   * Summary. Get Domain
   *
   * Description. returns the domain param from email input
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param  {string}      email       email input
   */
  getDomainFromEmail = (email) => {
    return email.split('@')[1];
  };

  /**
   * Summary. Domain validation API
   *
   * Description. Call Domain validation API and check the correct email is being
   *              used or not
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  onDomainApiCall = () => {
    const { profileRes } = this.state;
    const { company, hospital, email } = profileRes;
    const domain = this.getDomainFromEmail(email);
    this.setState({
      isAPICalled: true,
      apiErrorMessage: '',
      isEmailDomainError: false,
    });

    const { registrationType } = this.props;
    let urlname = '';
    if (registrationType === 'rep') {
      urlname = `/manufacturers/checkManufacturerDomain?manufacturerId=${company.id}&domain=${domain}`;
    } else {
      urlname = `/hospitalsbyname/checkProviderDomain?hospitalId=${hospital.id}&domain=${domain}`;
    }

    axiosApi(urlname, 'GET', '', (res) => {
      this.setState({
        isAPICalled: false,
      });
      if (res.error) {
        this.setState({
          apiErrorMessage: res.message,
        });
      } else if (res.data) {
        if (res.data.allowed) {
          this.goToNextPage();
        } else {
          this.setState({
            isEmailDomainError: true,
          });
        }
      }
    });
  };

  /**
   *  Go to next page once the form is submit and validated
   */
  goToNextPage = () => {
    const { profileRes } = this.state;
    const { onClick } = this.props;
    onClick(profileRes);
  };

  /**
   * Summary. Form submit
   *
   * Description. Validate the form and call the api
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param  {object}      e       event object
   */
  onBtnClick = (e) => {
    e.preventDefault();
    const isValid = this.validate();
    if (isValid) {
      this.onDomainApiCall();
      /*
      const { registrationType } = this.props;
      if (registrationType === 'rep') {
        this.onDomainApiCall();
      } else {
        this.goToNextPage();
      } */
    }
  };

  /**
   * Summary. Validate Input
   *
   * Description. Sets the error to errorObj and className to inputClass object
   *              if any validation error found.
   *              errorObj is used for displaying the errors for particular input
   *              inputClas is used for Adding error classNames for particular input
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   name           Input element name
   * @param {string}   value          Input element value
   * @param {string}   value1         additional value
   *
   * @return {String} Error if any else null
   */
  validateInput(name, value, value1) {
    if (validateObj[name]) {
      let error = '';
      let className = 'error-border';
      error = validateObj[name](value, value1);
      if (!error) {
        className = '';
      }

      this.setState((prevState) => ({
        errorObj: {
          ...prevState.errorObj,
          [name]: error,
        },
        inputClass: {
          ...prevState.inputClass,
          [name]: className,
        },
      }));

      return error;
    }
    return '';
  }

  /**
   * Summary. Set input values
   *
   * Description. Update All the input values to state
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   name           name of the input
   * @param {string}   value          value of the input
   *
   */
  setValue = (name, value) => {
    this.setState((prevState) => ({
      profileRes: {
        ...prevState.profileRes,
        [name]: value,
      },
    }));
  };

  /**
   * Summary. OnChange event
   *
   * Description. Input Change method for all input
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   e           Input element event object
   *
   */
  onChange = (e) => {
    const { name, value } = e.target;
    this.setValue(name, value);
  };

  /**
   * Summary. OnBlur event
   *
   * Description. Blur method for all input
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   e           Input element event object
   *
   */
  onBlur = (e) => {
    const { name } = e.target;
    const { profileRes } = this.state;
    this.validateInput(name, profileRes[name]);
  };

  /**
   * Summary. Set Autocomplete data
   *
   * Description. Set company/hospital autocomplete data values to state
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   name           name of the input
   * @param {string}   value          autocomplete value
   * @param {string}   id             id of the company/hospital
   *
   */
  setProfileValue = (name, value, id) => {
    this.setState(
      (prevState) => ({
        profileRes: {
          ...prevState.profileRes,
          [name]: {
            value,
            id,
          },
        },
      }),
      () => {
        if (id) {
          this.validateInput(name, value, id);
        }
      }
    );
  };

  /*
   *
   * Set isFocus flag to true on focus of autocomplete input
   */
  onFocusAutocomplete = (fieldName) => {
    if (fieldName === 'hospital') {
      this.setState({ open: true });
    }
    this.setState({
      [`isFocus${fieldName}`]: true,
    });
  };

  /*
   *
   * Set isFocus flag to false on blur event of autocomplete input if no value is filled
   */
  onBlurAutocomplete = (fieldName) => {
    console.log(fieldName);
    const { profileRes } = this.state;
    const fieldObj = profileRes[fieldName];
    this.validateInput(fieldName, fieldObj.value, fieldObj.id);
    if (!fieldObj.value) {
      this.setState({
        [`isFocus${fieldName}`]: false,
      });
    }
  };

  /**
   *  Load master states with cities array data and set to state
   */
  getStatesData = () => {
    getMasterStatesDataWithCities((dataArr) => {
      if (!isEmpty(dataArr)) {
        this.setState({
          masterStateList: dataArr,
        });
      }
    });
  };

  onHospitalSelect = (e) => {
    const { profileRes } = this.state;
    this.setState({
      profileRes: {
        ...profileRes,
        hospital: { id: e.target.value.id, value: e.target.value.hospital },
      },
    });
  };

  onSearch = () => {
    const { text } = this.state;
    if (text.length < 3) {
      alert('minimum 3 characters');
    }
  };

  onKeyDown = (e) => {
    if (isEnterKeyPressed(e)) {
      this.onSearch();
    }
  };

  render() {
    const {
      profileRes,
      errorObj,
      inputClass,
      isFocustitle,
      isFocuscompany,
      // isFocushospital,
      isFocusspecialty,
      apiErrorMessage,
      isAPICalled,
      isEmailDomainError,
      masterStateList,
      text,
      keyVal,
      open,
    } = this.state;
    const {
      firstName,
      lastName,
      company,
      title,
      hospital,
      email,
      specialty,
    } = profileRes;
    const { registrationType } = this.props;

    return (
      <MDBRow>
        <MDBCol lg="12">
          <div className="signup_form_panel">
            {registrationType === 'rep' ? (
              <p className="pt-4">
                Tell us your name, the manufacturer you represent, and your
                company &amp; email
              </p>
            ) : (
              <p className="pt-4">
                Tell us your name, the provider organization that you work for,
                and your organization’s email
              </p>
            )}
            <form onSubmit={this.onBtnClick} noValidate>
              <div className="form_fields mt-4">
                <div className="row">
                  <div className="col-lg-4 col-md-4">
                    <div className={`input-field ${inputClass.firstName}`}>
                      <MDBInput
                        type="text"
                        value={firstName}
                        name="firstName"
                        onChange={this.onChange}
                        onBlur={this.onBlur}
                        label="First Name"
                      />
                      {errorObj.firstName ? (
                        <span className="error-message">
                          {errorObj.firstName}
                        </span>
                      ) : (
                        ''
                      )}
                    </div>
                  </div>
                  <div className="col-lg-4 col-md-4">
                    <div className={`input-field ${inputClass.lastName}`}>
                      <MDBInput
                        type="text"
                        value={lastName}
                        name="lastName"
                        onChange={this.onChange}
                        onBlur={this.onBlur}
                        label="Last Name"
                      />
                      {errorObj.lastName ? (
                        <span className="error-message">
                          {errorObj.lastName}
                        </span>
                      ) : (
                        ''
                      )}
                    </div>
                  </div>
                  <div className="col-lg-4 col-md-4">
                    <div className={`input-field ${inputClass.title}`}>
                      <RepAutocomplete
                        inputName="title"
                        inputClass={inputClass.title}
                        placeholder=""
                        onFocus={() => {
                          this.onFocusAutocomplete('title');
                        }}
                        onBlur={() => {
                          this.onBlurAutocomplete('title');
                        }}
                        getItemValue={(item) => item.title}
                        shouldItemRender={(state, value) =>
                          matchStateToTermCustom(state.title, value)
                        }
                        sortItems={() => 1}
                        renderInput={(props) => [
                          <input key="1" {...props} />,
                          <label
                            className={
                              isFocustitle || title.value ? 'active' : ''
                            }
                            style={{ pointerEvents: 'none' }}
                            key="2"
                          >
                            Title
                          </label>,
                        ]}
                        apiurl={
                          registrationType === 'rep'
                            ? '/titles/getAllRepTitles'
                            : '/titles/getAllProviderTitles'
                        }
                        renderItem={(item, isHighlighted) => {
                          return (
                            <li
                              style={{
                                background: isHighlighted ? '#eeeeee' : '',
                              }}
                              key={item.id}
                            >
                              {item.title}
                            </li>
                          );
                        }}
                        value={title.value}
                        onChange={(event, value) => {
                          this.setProfileValue('title', value, '');
                        }}
                        minChar={0}
                        onSelect={(value, item) => {
                          this.setProfileValue('title', value, item.id);
                        }}
                      />
                      {errorObj.title ? (
                        <span className="error-message">{errorObj.title}</span>
                      ) : (
                        ''
                      )}
                    </div>
                  </div>
                  <div className="col-lg-4 col-md-4">
                    <div
                      className={`input-field ${
                        inputClass.company || inputClass.hospital
                      }`}
                    >
                      {registrationType === 'rep' ? (
                        <RepAutocomplete
                          inputName="company"
                          inputClass={inputClass.company}
                          placeholder=""
                          onFocus={() => {
                            this.onFocusAutocomplete('company');
                          }}
                          onBlur={() => {
                            this.onBlurAutocomplete('company');
                          }}
                          getItemValue={(item) => item.companyName}
                          shouldItemRender={(state, value) =>
                            matchStateToTermCustom(state.companyName, value)
                          }
                          sortItems={() => 1}
                          renderInput={(props) => [
                            <input key="1" {...props} />,
                            <label
                              className={
                                isFocuscompany || company.value ? 'active' : ''
                              }
                              style={{ pointerEvents: 'none' }}
                              key="2"
                            >
                              Manufacturing Company
                            </label>,
                          ]}
                          apiurl="/manufacturers"
                          renderItem={(item, isHighlighted) => {
                            return (
                              <li
                                style={{
                                  background: isHighlighted ? '#eeeeee' : '',
                                }}
                                key={item.companyId}
                              >
                                {item.companyName}
                              </li>
                            );
                          }}
                          value={company.value}
                          onChange={(event, value) => {
                            this.setProfileValue('company', value, '');
                          }}
                          minChar={0}
                          onSelect={(value, item) => {
                            this.setProfileValue(
                              'company',
                              value,
                              item.companyId
                            );
                          }}
                        />
                      ) : (
                        <div>
                          <MDBInput
                            type="text"
                            value={hospital.value}
                            onFocus={() => {
                              this.onFocusAutocomplete('hospital');
                            }}
                            onBlur={() => {
                              this.onBlurAutocomplete('hospital');
                            }}
                            name="text"
                            onChange={(e) => {
                              const { value } = e.target;
                              this.setState({ text: value });
                              this.setProfileValue('hospital', value, '');
                            }}
                            label="Medical Facility"
                          />
                          {open ? (
                            <div className="position-relative mt-2">
                              <Suspense fallback={<Loading />}>
                                <SearchHospitalList
                                  onChange={this.onChange}
                                  onHospitalSelect={this.onHospitalSelect}
                                  masterStateList={masterStateList}
                                  onKeyDown={this.onKeyDown}
                                  selectedHospital={hospital.value}
                                  key={keyVal}
                                  handleClose={() => {
                                    this.setState({ open: false });
                                    this.onBlurAutocomplete('hospital');
                                  }}
                                  handleOpen={() =>
                                    this.setState({ open: true })
                                  }
                                  open
                                  hideText
                                  searchText={text}
                                />
                              </Suspense>
                            </div>
                          ) : null}
                        </div>
                      )}
                      {errorObj.hospital || errorObj.company ? (
                        <span className="error-message">
                          {errorObj.hospital || errorObj.company}
                        </span>
                      ) : (
                        ''
                      )}
                      <span className="not_list_txt">
                        Not listed? Click Support in the bottom right corner of
                        your screen.
                      </span>
                    </div>
                  </div>
                  <div className="col-lg-4 col-md-4">
                    <div
                      className={`input-field ${
                        isEmailDomainError ? 'email_field' : ''
                      } ${inputClass.email}`}
                    >
                      <MDBInput
                        type="email"
                        value={email}
                        onBlur={this.onBlur}
                        name="email"
                        onChange={this.onChange}
                        label={
                          registrationType === 'rep'
                            ? 'Your Company Email'
                            : 'My Medical Facility Email'
                        }
                      />
                      {errorObj.email ? (
                        <span className="error-message">{errorObj.email}</span>
                      ) : isEmailDomainError ? (
                        registrationType === 'rep' ? (
                          <span className="error-message">
                            The email domain entered does not match the company
                            on record. Please re-enter an email address
                            associated with the manufacturer you’ve selected, or
                            select another manufacturer. If you are part of a
                            recent merger or acquisition, click Support in the
                            bottom right corner of the screen and let us know!
                          </span>
                        ) : (
                          <span className="error-message provider">
                            The email domain{' '}
                            <b>{this.getDomainFromEmail(email)}</b> is not
                            registered with the organization {hospital.value}.
                            Please re-enter an email address associated with the
                            organization that you’ve selected, or select another
                            organization.
                          </span>
                        )
                      ) : (
                        ''
                      )}
                    </div>
                  </div>

                  {registrationType !== 'rep' && (
                    <div className="col-lg-4 col-md-4">
                      <div className={`input-field ${inputClass.specialty}`}>
                        <RepAutocomplete
                          inputName="specialty"
                          inputClass={inputClass.specialty}
                          placeholder=""
                          onFocus={() => {
                            this.onFocusAutocomplete('specialty');
                          }}
                          onBlur={() => {
                            this.onBlurAutocomplete('specialty');
                          }}
                          getItemValue={(item) => item.name}
                          shouldItemRender={(state, value) =>
                            matchStateToTermCustom(state.name, value)
                          }
                          sortItems={() => 1}
                          renderInput={(props) => [
                            <input key="1" {...props} />,
                            <label
                              className={
                                isFocusspecialty || specialty.value
                                  ? 'active'
                                  : ''
                              }
                              style={{ pointerEvents: 'none' }}
                              key="2"
                            >
                              Specialty
                            </label>,
                          ]}
                          apiurl="/providersSpecialties"
                          renderItem={(item, isHighlighted) => {
                            return (
                              <li
                                style={{
                                  background: isHighlighted ? '#eeeeee' : '',
                                }}
                                key={item.id}
                              >
                                {item.name}
                              </li>
                            );
                          }}
                          value={specialty.value}
                          onChange={(event, value) => {
                            this.setProfileValue('specialty', value, '');
                          }}
                          minChar={0}
                          onSelect={(value, item) => {
                            this.setProfileValue('specialty', value, item.id);
                          }}
                        />
                        {errorObj.specialty ? (
                          <span className="error-message">
                            {errorObj.specialty}
                          </span>
                        ) : (
                          ''
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </div>
              <div className="text-center sign_next mt-5">
                <button
                  type="submit"
                  className="fill-orange-btn"
                  disabled={isAPICalled}
                >
                  {isAPICalled ? (
                    <span className="spinner-border spinner-border-sm" />
                  ) : (
                    ''
                  )}
                  Next
                </button>
                {apiErrorMessage ? (
                  <p className="error-message1">{apiErrorMessage}</p>
                ) : (
                  ''
                )}
              </div>
            </form>
          </div>
        </MDBCol>
      </MDBRow>
    );
  }
}

export default StepTwo;
