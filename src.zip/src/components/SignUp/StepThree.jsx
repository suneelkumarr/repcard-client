/**
 *
 * Description. Sign up (Step 3)
 *
 * @link   URL
 * @file   Add Password and confirm password and click on next after click on
           agree checkbox
 * @since  1.0.0
 */
import React, { Component } from 'react';
import { MDBRow, MDBCol, MDBInput, Fa } from 'mdbreact';
import { Redirect } from 'react-router-dom';
import { axiosApi } from '../../apis/axiosApiCall';
import validateObj from '../../validations/repprofile/repfront.js';
import { loginApiNew } from '../Common/callLoginApi';
import { encrypt } from '../../config/encrypt-decrypt';

class StepThree extends Component {
  constructor(props) {
    super(props);
    this.state = {
      inputClass: {},
      errorObj: {},
      password: '',
    };
  }

  componentDidMount() {}

  /**
   * Summary. Validate Input
   *
   * Description. Sets the error to errorObj and className to inputClass object
   *              if any validation error found.
   *              errorObj is used for displaying the errors for particular input
   *              inputClas is used for Adding error classNames for particular input
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   name           Input element name
   * @param {string}   value          Input element value
   * @param {string}   value1         additional value
   *
   * @return {String} Error if any else null
   */
  validateInput(name, value, value1) {
    if (validateObj[name]) {
      let error = '';
      let className = 'error-border';
      error = validateObj[name](value, value1);
      if (!error) {
        className = '';
      }

      this.setState((prevState) => ({
        errorObj: {
          ...prevState.errorObj,
          [name]: error,
        },
        inputClass: {
          ...prevState.inputClass,
          [name]: className,
        },
      }));

      return error;
    }
    return '';
  }

  /**
   * Summary. OnChange event
   *
   * Description. Input Change method for all input
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   e           Input element event object
   *
   */
  onChange = (e) => {
    const { password } = this.state;
    const { name, value } = e.target;
    this.validateInput(name, value, password);
    this.setState({
      [name]: value,
    });
  };

  /**
   * Summary. OnBlur event
   *
   * Description. Blur method for all input
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   e           Input element event object
   *
   */
  onBlur = (e) => {
    const { password } = this.state;
    const { name, value } = e.target;
    this.validateInput(name, value, password);
  };

  /**
   * Summary. Form validation
   *
   * Description. Validate form on submit click
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @return {boolean} false if not valid else true
   */
  validate() {
    const { password, confirmpass } = this.state;
    let isValid = true;
    let error;

    error = this.validateInput('password', password);
    if (error) {
      isValid = false;
    }

    error = this.validateInput('confirmpass', confirmpass, password);
    if (error) {
      isValid = false;
    }

    return isValid;
  }

  /**
   * Summary. Signup API
   *
   * Description. Register Rep/Provider user using an API call
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  registerApiCall = () => {
    const {
      profileRes,
      registrationType,
      isClaimAccount,
      userType,
    } = this.props;
    const { password } = this.state;
    const {
      firstName,
      lastName,
      title,
      company,
      hospital,
      email,
      specialty,
      inviteBy,
      inviteUserType,
    } = profileRes;
    const reqObj = {
      firstName,
      lastName,
      email: encrypt(email),
      password: encrypt(password),
      userType: registrationType,
      titleId: title.id,
      inviteBy,
      inviteUserType,
    };

    if (registrationType === 'rep') {
      reqObj.companyId = company.id;
    } else {
      reqObj.hospitalId = hospital.id;
      reqObj.specialtyId = specialty.id;
    }

    if (isClaimAccount) {
      reqObj.userType = userType;
    }

    this.setState({
      isAPICalled: true,
      apiErrorMessage: '',
    });

    let urlname = '/signUp';
    if (isClaimAccount) {
      urlname += '/claimAccount';
    }
    if (inviteBy && inviteUserType) {
      urlname += '/inviteAccount';
    }

    axiosApi(urlname, 'POST', reqObj, (res) => {
      this.setState({
        isAPICalled: false,
      });
      if (res.error) {
        this.setState({
          apiErrorMessage: res.message,
        });
      } else if (isClaimAccount) {
        this.setState({
          isAPICalled: true,
        });
        loginApiNew(email, password)
          .then((data) => {
            this.setState({
              isAPICalled: false,
              redirectToReferrer: data.redirectURL,
            });
          })
          .catch((error) => {
            this.setState({
              apiErrorMessage: error.message,
            });
          });
      } else {
        const { onClick } = this.props;
        onClick(password);
      }
    });
  };

  /**
   * Summary. Form submit
   *
   * Description. Validate the form and call the api
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param  {object}      e       event object
   */
  onBtnClick = (e) => {
    e.preventDefault();
    const isValid = this.validate();
    if (isValid) {
      this.registerApiCall();
    }
  };

  /**
   * Summary. Password Toggle
   *
   * Description. Toggle password on click of eye icon
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   e           Input element event object
   * @param {String}   name        name of the inout field
   */
  handleClickShowPassword = (e, name) => {
    e.preventDefault();
    this.setState((prevState) => ({
      [name]: !prevState[name],
    }));
  };

  // onFocus method to remove readOnly field if there
  onFocus = (e) => {
    const node = e.target;
    // This is used for prevent autofill passwords on the input
    if (node.hasAttribute('readonly')) {
      node.removeAttribute('readonly');
      // fix for mobile safari to show virtual keyboard
      // node.blur();
      // node.focus();
    }
  };

  render() {
    const { isClaimAccount } = this.props;
    const {
      errorObj,
      inputClass,
      password,
      confirmpass,
      apiErrorMessage,
      isAPICalled,
      showPassword,
      showPassword1,
      redirectToReferrer,
    } = this.state;

    const isBtnDisable =
      !(
        password &&
        !errorObj?.password &&
        confirmpass &&
        !errorObj?.confirmpass
      ) || isAPICalled;

    if (redirectToReferrer) {
      return <Redirect to={{ pathname: redirectToReferrer }} />;
    }

    return (
      <MDBRow>
        <MDBCol lg="12">
          <div className="signup_form_panel">
            <p className="pt-3">
              Create a secure password with 8 to 15 characters including: 1
              upper-case letter, 1 lower-case letter,{' '}
              <br className="d-none d-lg-inline-block d-md-display-none" /> 1
              number and 1 special character.
            </p>
            <form onSubmit={this.onBtnClick} noValidate>
              <div className="form_fields mt-4">
                <div className="row">
                  <div className="col-lg-4 col-md-4">
                    <div
                      className={`input-field input-password ${
                        errorObj.password && errorObj.password.length > 100
                          ? 'password_field'
                          : ''
                      } ${inputClass.password}`}
                    >
                      <MDBInput
                        label="Password"
                        name="password"
                        readOnly
                        onFocus={this.onFocus}
                        onChange={this.onChange}
                        type={showPassword ? 'text' : 'password'}
                        required
                        value={password}
                        onBlur={this.onBlur}
                      />
                      <div
                        className="p-0 password-icon"
                        onClick={(e) => {
                          this.handleClickShowPassword(e, 'showPassword');
                        }}
                        onMouseDown={(e) => e.preventDefault()}
                        role="presentation"
                        data-repcard-test="pass-icon"
                      >
                        <Fa far icon={showPassword ? 'eye' : 'eye-slash'} />
                      </div>
                      {errorObj.password ? (
                        <span className="error-message">
                          {errorObj.password}
                        </span>
                      ) : (
                        ''
                      )}
                    </div>
                  </div>
                  <div className="col-lg-4 col-md-4">
                    <div
                      className={`input-field input-password ${inputClass.confirmpass}`}
                    >
                      <MDBInput
                        label="Confirm Password"
                        name="confirmpass"
                        readOnly
                        onFocus={this.onFocus}
                        onChange={this.onChange}
                        type={showPassword1 ? 'text' : 'password'}
                        required
                        value={confirmpass}
                        onBlur={this.onBlur}
                        onContextMenu={(e) => {
                          e.preventDefault();
                        }}
                        onPaste={(e) => {
                          e.preventDefault();
                        }}
                      />
                      <div
                        className="p-0 password-icon"
                        onClick={(e) => {
                          this.handleClickShowPassword(e, 'showPassword1');
                        }}
                        onMouseDown={(e) => e.preventDefault()}
                        role="presentation"
                        data-repcard-test="pass-icon1"
                      >
                        <Fa far icon={showPassword1 ? 'eye' : 'eye-slash'} />
                      </div>
                      {errorObj.confirmpass ? (
                        <span className="error-message">
                          {errorObj.confirmpass}
                        </span>
                      ) : (
                        ''
                      )}
                    </div>
                  </div>
                </div>
              </div>
              <div className="text-center sign_next mt-4">
                <button
                  type="submit"
                  className="fill-orange-btn"
                  disabled={isBtnDisable}
                >
                  {isAPICalled ? (
                    <span className="spinner-border spinner-border-sm" />
                  ) : (
                    ''
                  )}
                  {isClaimAccount ? 'Claim Account' : 'Create Account'}
                </button>
                {apiErrorMessage ? (
                  <p className="error-message1">{apiErrorMessage}</p>
                ) : (
                  ''
                )}
              </div>
            </form>
          </div>
        </MDBCol>
      </MDBRow>
    );
  }
}

export default StepThree;
