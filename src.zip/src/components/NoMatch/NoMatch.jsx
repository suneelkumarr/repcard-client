/**
 *
 * Description. 404 Page
 *
 * @link   URL
 * @file   If no match found then display this page
 * @since  1.0.0
 */
import React from 'react';
import '../../css/404.css';

const NoMatch = () => (
  <div className="text-center">
    <h1>Page Not Found</h1>
    <p>Sorry, but the page you were trying to view does not exist.</p>
  </div>
);

export default NoMatch;
