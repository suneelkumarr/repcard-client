/* eslint-disable no-unused-vars */
/**
 *
 * Description. Popover
 *
 * @link   URL
 * @file   Rep's My Account and productcategory information with flip card.
           This is available in 3 ways, Normal html, Popover and Modal Popup
 * @since  1.0.0
 */
import React, { Component } from 'react';
import isEmpty from 'lodash/isEmpty';
import isEqual from 'lodash/isEqual';
import { MDBPopover, MDBModal, MDBModalBody } from 'mdbreact';
import RepCard from '../Common/RepCard/RepCard';
import RepProductCategory from '../Common/RepProductCategory/RepProductCategory';
import { getProductCategoryApi } from '../../utils/getProductCategoryApi';
import { axiosApi } from '../../apis/axiosApiCall';
import app from '../../helpers/appGlobal';

import './popover.scss';

class RepcardPopover extends Component {
  constructor(props) {
    super(props);
    const { profileRes, productcategoryRes, initialView } = this.props;
    this.state = {
      profileRes,
      productcategoryRes: productcategoryRes || [],
      isFlipped: initialView !== 'profile',
      modal: false,
    };
  }

  componentDidMount() {
    const { isHtml } = this.props;
    if (isHtml) {
      this.showModal(); // show modal and call apis
    }
  }

  componentDidUpdate() {
    const { profileRes, productcategoryRes } = this.props;
    const { profileRes: oprofileRes, oproductcategoryRes } = this.state;
    if (!isEqual(profileRes, oprofileRes)) {
      this.updateRes();
    }
  }

  updateRes() {
    const { profileRes, productcategoryRes, initialView } = this.props;
    this.setState({
      profileRes,
      productcategoryRes,
      isFlipped: initialView !== 'profile',
    });
  }

  /**
   * Summary. Get My Account Information
   *
   * Description. Call API for Rep's to get my account data
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  getMyAccountApi = () => {
    const { id } = this.props;
    this.setState({
      isAPICalled1: true,
    });
    axiosApi(`/repProfile/getMyAccountRepProfile/${id}`, 'GET', '', (res) => {
      if (!isEmpty(res.data)) {
        this.setState({
          profileRes: res.data,
        });
      }
      this.setState({
        isAPICalled1: false,
      });
    });
  };

  /**
   * Summary. Rep's ProductCategory
   *
   * Description. To Retrive all the Rep's productcategories information
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  getProductCategoryApi = () => {
    const { id } = this.props;
    this.setState({
      isAPICalled: true,
    });
    getProductCategoryApi(id, (results) => {
      this.setState({
        isAPICalled: false,
        productcategoryRes: results,
      });
    });
  };

  /**
   * Summary. onchange event
   *
   * Description. set modal flag to true/false and call apis
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {boolean}   flag      open  or close state of popover and modal
   */
  onChange = (flag) => {
    this.setState({
      modal: flag,
    });
    if (flag) {
      this.showModal();
    } else {
      this.hideModal();
    }
  };

  /**
   *  Flip event either my account or productcategories
   */
  flipEvent = () => {
    this.setState((prevState) => ({
      isFlipped: !prevState.isFlipped,
    }));
  };

  /**
   *  Toggle modal popup
   */
  toggle = () => {
    this.setState((prevState) => ({
      modal: !prevState.modal,
    }));
  };

  /**
   *  Call my account or productcategory API if required for showing data
   */
  showModal = () => {
    const { profileRes } = this.state;
    if (isEmpty(profileRes)) {
      this.getMyAccountApi();
    }
    this.getProductCategoryApi();
  };

  /**
   *  Close popover or modal and change flip flag to initial view
   */
  hideModal = () => {
    const { initialView } = this.props;
    this.setState({
      isFlipped: initialView !== 'profile',
    });
  };

  /**
   * Summary. Add/Remove favourite
   *
   * Description. API call for adding and removing Rep's from favourite section
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  onFavouriteClick = () => {
    const { profileRes } = this.state;
    const { id } = this.props;
    const { isFavourite } = profileRes;
    const reqObj = {
      providerId: app.user.id,
      repIds: [id],
    };

    let urlname = '';
    if (isFavourite) {
      urlname = `/provider/removeFavoriteRepProvider`;
    } else {
      urlname = `/provider/addFavoriteRepProvider`;
    }
    this.setState({
      isFavouriteAPI: true,
    });
    axiosApi(urlname, 'POST', reqObj, (res) => {
      this.setState({
        isFavouriteAPI: false,
      });
      if (res.error) {
        alert(res.message);
      } else {
        this.setState((prevState) => ({
          profileRes: {
            ...prevState.profileRes,
            isFavourite: !isFavourite,
          },
        }));
        this.onChange(false);
        const { updateFavourites } = this.props;
        if (updateFavourites) {
          updateFavourites();
        }
        if (isFavourite) {
          alert('Favourite removed Succesfully');
        } else {
          alert('Favourite Added Succesfully');
        }
      }
    });
  };

  /**
   * Summary. Html part of popup
   *
   * Description. Html generation of RepCard and ProductCategory section
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  getPopupHtml = () => {
    const {
      profileRes,
      productcategoryRes,
      isAPICalled,
      isAPICalled1,
      isFavouriteAPI,
      isFlipped,
    } = this.state;
    const {
      isHtml,
      isFavourite,
      className,
      setProductCategoryFlag,
      showFullProfileLink,
      id,
    } = this.props;

    return (
      <div className={`card-wrapper ${className && className}`}>
        {!isHtml ? (
          <span
            className="popbox_close"
            onClick={this.toggle}
            role="presentation"
          >
            x Close
          </span>
        ) : (
          ''
        )}
        <div className={`card card-rotating ${isFlipped ? 'flipped' : ''}`}>
          <div className="face front">
            {isAPICalled1 ? (
              <div className="rep-profile-card-view boxpanel">Please wait</div>
            ) : (
              <RepCard
                profileRes={profileRes}
                flipicondisable
                isFavourite={isFavourite}
                onFavouriteClick={this.onFavouriteClick}
                isFavouriteAPI={isFavouriteAPI}
                isChat
                boxclass="boxpanel"
                shadows="shadows"
                onClick={this.flipEvent}
                showFullProfileLink={showFullProfileLink}
                id={id}
              />
            )}
          </div>
          <div className="face back">
            {isAPICalled ? (
              <div className="rep-profile-card-view boxpanel">Please wait</div>
            ) : (
              <RepProductCategory
                flipicondisable
                isNameRemove
                productcategoryRes={productcategoryRes}
                profileRes={profileRes}
                boxclass="boxpanel"
                onClick={this.flipEvent}
                setProductCategoryFlag={setProductCategoryFlag}
              />
            )}
          </div>
        </div>
      </div>
    );
  };

  render() {
    const { placement, textHtml, isPopover, isHtml } = this.props;
    const { modal } = this.state;

    if (isHtml) {
      return this.getPopupHtml();
    }

    if (isPopover) {
      return (
        <MDBPopover
          onChange={this.onChange}
          placement={placement}
          popover
          clickable
          domElement
          id="popover"
          isVisible={modal}
          className={textHtml ? 'ml-3' : ''}
        >
          <div>{textHtml}</div>
          {this.getPopupHtml()}
        </MDBPopover>
      );
    }

    return (
      <>
        <div
          onClick={this.toggle}
          role="presentation"
          data-repcard-test="toggle"
        >
          {textHtml}
        </div>
        <MDBModal
          isOpen={modal}
          toggle={this.toggle}
          showModal={this.showModal}
          hideModal={this.hideModal}
        >
          <MDBModalBody className="p-0">{this.getPopupHtml()}</MDBModalBody>
        </MDBModal>
      </>
    );
  }
}

export default RepcardPopover;
