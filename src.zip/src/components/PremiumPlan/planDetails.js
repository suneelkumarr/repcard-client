/**
 *
 * Description. Global Variables for month and year plans
 *
 * @link   URL
 * @file   Plans Global Variable for Rep and Provider
 * @since  1.0.0
 */
const repPlanMonthPrice = 15;
const repPlanYearPrice = 162;
const repPlanMonthName = 'RepMonthly'; // 'dailyPlan_repcardz_123';
const repPlanYearName = 'RepYearly'; // 'plan_H1VeM5BXrtETD4';

const providerPlanMonthPrice = 15;
const providerPlanYearPrice = 162;
const providerPlanMonthName = 'ProviderMonthly'; // 'dailyPlan_repcardz_123';
const providerPlanYearName = 'ProviderYearly'; // 'plan_H1VeM5BXrtETD4';

// Rep plan object - month and year to plan id
export const repPlanType = {
  month: {
    planId: repPlanMonthName,
    price: repPlanMonthPrice,
  },
  year: {
    planId: repPlanYearName,
    price: repPlanYearPrice,
  },
};
// Plan to month and year
export const repPlanObj = {
  [repPlanMonthName]: {
    type: 'month',
    price: repPlanMonthPrice,
  },
  [repPlanYearName]: {
    type: 'year',
    price: repPlanYearPrice,
  },
};

// Provider plan object - month and year to plan id
export const providerPlanType = {
  month: {
    planId: providerPlanMonthName,
    price: providerPlanMonthPrice,
  },
  year: {
    planId: providerPlanYearName,
    price: providerPlanYearPrice,
  },
};
// Plan to month and year
export const providerPlanObj = {
  [providerPlanMonthName]: {
    type: 'month',
    price: providerPlanMonthPrice,
  },
  [providerPlanYearName]: {
    type: 'year',
    price: providerPlanYearPrice,
  },
};
