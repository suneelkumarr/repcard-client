/**
 *
 * Description. Stripe Credit card element
 *
 * @link   URL
 * @file   Stripe component for display credit card UI with cvc, expiry date
           and postal code
 * @since  1.0.0
 */
import React from 'react';
import {
  CardElement,
  CardNumberElement, // eslint-disable-line
  CardCvcElement, // eslint-disable-line
  CardExpiryElement, // eslint-disable-line
} from '@stripe/react-stripe-js';
import './CardSectionStyles.css';
import { MDBRow, MDBCol } from 'mdbreact';

const CARD_ELEMENT_OPTIONS = {
  style: {
    base: {
      color: '#32325d',
      fontFamily: '"Helvetica Neue", Helvetica, sans-serif',
      fontSmoothing: 'antialiased',
      fontSize: '16px',
      '::placeholder': {
        color: '#aab7c4',
      },
    },
    invalid: {
      color: '#fa755a',
      iconColor: '#fa755a',
    },
  },
};

/**
 * Summary. Stripe card html
 *
 * Description. Stripe card html like cc number, cvv, expiry
 *
 * @since      1.0
 * @deprecated No //x.x.x Use new_function_name() instead.
 * @access     export public
 *
 * @param {string}   cardError          credit card validation error
 *
 */
const CardSection = ({ cardError }) => {
  return (
    <>
      <MDBRow>
        <MDBCol lg="12">
          <div
            className={`input-field card_field ${
              cardError ? 'error-border' : ''
            }`}
          >
            <label className="w-100">
              Card details
              <CardElement options={CARD_ELEMENT_OPTIONS} />
            </label>
            {cardError ? (
              <p className="error-message">
                <span /> {cardError}
              </p>
            ) : (
              ''
            )}
          </div>
        </MDBCol>
      </MDBRow>

      {/*
      <MDBRow>
        <MDBCol lg="6">
          <div className="input-field card_field visa_icon">
            <label>
              Card number
              <CardNumberElement
                options={CARD_ELEMENT_OPTIONS}
                onReady={() => {
                  console.log('CardNumberElement [ready]');
                }}
                onChange={event => {
                  console.log('CardNumberElement [change]', event);
                }}
                onBlur={() => {
                  console.log('CardNumberElement [blur]');
                }}
                onFocus={() => {
                  console.log('CardNumberElement [focus]');
                }}
              />
            </label>
          </div>
        </MDBCol>
        <MDBCol lg="3" className="px-0">
          <div className="input-field card_field">
            <label>
              Expiration date
              <CardExpiryElement
                options={CARD_ELEMENT_OPTIONS}
                onReady={() => {
                  console.log('CardNumberElement [ready]');
                }}
                onChange={event => {
                  console.log('CardNumberElement [change]', event);
                }}
                onBlur={() => {
                  console.log('CardNumberElement [blur]');
                }}
                onFocus={() => {
                  console.log('CardNumberElement [focus]');
                }}
              />
            </label>
          </div>
        </MDBCol>
        <MDBCol lg="3">
          <div className="input-field card_field">
            <label>
              CVC
              <CardCvcElement
                options={CARD_ELEMENT_OPTIONS}
                onReady={() => {
                  console.log('CardNumberElement [ready]');
                }}
                onChange={event => {
                  console.log('CardNumberElement [change]', event);
                }}
                onBlur={() => {
                  console.log('CardNumberElement [blur]');
                }}
                onFocus={() => {
                  console.log('CardNumberElement [focus]');
                }}
              />
            </label>
          </div>
        </MDBCol>
      </MDBRow> */}
    </>
  );
};

export default CardSection;
