/**
 *
 * Description. Load Stripe
 *
 * @link   URL
 * @file   Load stripe using stripe publish key and call credit Card Details
           component accordingly
 * @since  1.0.0
 */
import React from 'react';
import { Elements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import app from '../../helpers/appGlobal';
import CardDetails from './CardDetails';

// Make sure to call `loadStripe` outside of a component’s render to avoid
// recreating the `Stripe` object on every render.
const stripePromise = loadStripe(app.config.STRIPE_PUBLISHABLE_KEY);

/**
 * Summary. Load Stripe form
 *
 * Description. Load Stripe form
 *
 * @since      1.0
 * @deprecated No //x.x.x Use new_function_name() instead.
 * @access     export public
 *
 * @param {function} onCancelClick     callback function of cancel btn click
 * @param {function} onSuccessOrFail   callback function of save btn click
 *
 */
const UpdatePayment = ({ onCancelClick, onSuccessOrFail }) => {
  return (
    <Elements stripe={stripePromise}>
      {app.user.paymentMethod && (
        <CardDetails
          onCancelClick={onCancelClick}
          onSuccessOrFail={onSuccessOrFail}
        />
      )}
    </Elements>
  );
};

export default UpdatePayment;
