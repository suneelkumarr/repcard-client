/**
 *
 * Description. Unsubscribe functionality
 *
 * @link   URL
 * @file   When user subscribes to payment plan and want to downgrade to basic.
           It displays the Downgrade button with expiry date.
 * @since  1.0.0
 */
import React, { Component } from 'react';
import { MDBModal, MDBModalBody } from 'mdbreact';
import { getSubscriptionId, getEndDate } from '../../utils/getPlanInfo';
import { getUnsubscribeApi } from '../../utils/stripeApis';

class Unsubscribe extends Component {
  constructor(props) {
    super(props);
    this.state = {
      modal: false,
    };
  }

  /**
   *  toggle unsubscribe modal popup
   */
  premiumPopup = () => {
    this.setState((prevState) => ({
      modal: !prevState.modal,
    }));
  };

  /**
   *  close unsubscribe modal popup forcefully
   */
  onCloseModal = () => {
    this.setState({
      modal: false,
    });
  };

  /**
   *  On succesfull unsubscribe complete close the modal and show the message
   */
  onDowngradeSuccess = () => {
    this.onCloseModal();
    const { downgradeSuccess } = this.props;
    downgradeSuccess();
  };

  /**
   * Summary. Unsubscribe API
   *
   * Description. Calls payment plan unsubscribe api and on success close the modal
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  onDowngrade = () => {
    this.setState({
      isAPICalled: true,
    });
    const subscriptionId = getSubscriptionId();
    getUnsubscribeApi(subscriptionId, (res) => {
      this.setState({
        isAPICalled: false,
      });
      if (res) {
        this.setState({
          isDownGradeDone: true,
        });
      }
    });
  };

  componentDidMount() {}

  render() {
    const { modal, isDownGradeDone, isAPICalled } = this.state;

    return (
      <>
        <button
          type="button"
          onClick={this.premiumPopup}
          className="fill-orange-btn m-0"
          data-repcard-test="popup"
        >
          Downgrade
        </button>
        {/* modal popup */}
        <MDBModal
          className="coupon_plan_panel"
          isOpen={modal}
          toggle={this.premiumPopup}
          disableBackdrop
        >
          <MDBModalBody>
            {isDownGradeDone ? (
              <div className="downgrade_preaccount_plan">
                <h5 className="heading_h5 mb-3">
                  Your REPCARDz Membership plan has changed. A confirmation has
                  been sent to your email ID.
                </h5>
                <div className="center_panel mt-4">
                  <button
                    type="button"
                    className="fill-orange-btn"
                    onClick={this.onDowngradeSuccess}
                    data-repcard-test="close"
                  >
                    Close
                  </button>
                </div>
              </div>
            ) : (
              <div className="downgrade_preaccount_plan">
                <h5 className="heading_h5 mb-3">
                  Your Premium membership will{' '}
                  <br className="d-none d-md-inline-block" /> expire on{' '}
                  {getEndDate()}
                </h5>
                <div className="center_panel mt-4">
                  <button
                    type="button"
                    className="fill-orange-btn"
                    onClick={this.onDowngrade}
                    disabled={isAPICalled}
                    data-repcard-test="next"
                  >
                    Downgrade Now
                  </button>
                  <button
                    type="button"
                    className="outline-btn"
                    onClick={this.onCloseModal}
                    data-repcard-test="popupclose"
                  >
                    Cancel
                  </button>
                </div>
                <div className="downgrade_info">
                  Once you click on downgrade button your plan will{' '}
                  <br className="d-none d-md-inline-block" /> automatically
                  expire on the specified date.
                </div>
              </div>
            )}
          </MDBModalBody>
        </MDBModal>
      </>
    );
  }
}

export default Unsubscribe;
