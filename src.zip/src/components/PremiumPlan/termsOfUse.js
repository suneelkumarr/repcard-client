import React from 'react';

const GetTermsOfUseHtml = () => {
  return (
    <div className="term_copy">
      REPCARDz™ TERMS OF USE
      <br />
      Last Updated: April 8, 2020
      <br />
      REPCARDz, LLC (“REPCARDz,” “we,” “us,” or “our”) oversees the website
      www.repcardz.com (the “Site”) and related services made accessible through
      the Site or any REPCARDz mobile application as available (collectively,
      the “Services”). These Terms of Use (the “Terms”) are applicable to you
      (“user(s),” “you,” or “your”) and govern your access to and use of
      REPCARDz Services, as well as any information, text, graphics, photos or
      other material uploaded, downloaded or appearing on the Services. The
      Terms contained herein apply to all users of this Site and our Services.
      <br />
      Read these Terms carefully before you begin using the Services. BY
      ENTERING, ACCESSING, BROWSING, SUBMITTING INFORMATION TO, OR OTHERWISE
      USING THE SERVICES AND THE CONTENT AVAILABLE HEREIN, YOU ACKNOWLEDGE AND
      AGREE TO THESE TERMS AND THE REPCARDZ PRIVACY POLICY.
      <br />
      Access to the Services is intended only for users located within the
      United States. REPCARDz makes no representation or warranty of any kind
      that use of the Services outside of the United States is lawful or
      permissible. Those who access the Services from other jurisdictions are
      responsible for their compliance with local laws pertaining to the use of
      the Services. The Services are also not intended for use by minor
      children. By using the Services, you represent and warrant that you are
      eighteen (18) years of age or older.
      <br />
      Note that these Terms may be updated from time to time, and any user’s
      continued use of the Services after we have made updates to the terms is
      considered acceptance of those updates. For clarity, all updates are
      effective immediately when posted. It is your responsibility to check
      these Terms periodically for updates.
      <br />
      1. Access to and Use of the Services
      <br />
      Access to certain portions of the Services is restricted to registered
      users. To register an account and/or make a purchase through our Services,
      you may be required to provide your name, telephone number(s), e-mail,
      and/or street address, credit card number, debit card number, charge card
      number, or other payment information, as well as and other personally
      identifiable information (“Personal Information”). By providing such
      information, you acknowledge and agree that we may, and you specifically
      authorize us or permitted third parties, to process all transactions
      related to the Services, including without limitation purchases and/or
      registration for products and/or services. You agree to pay all fees and
      charges, including applicable taxes and surcharges, incurred through your
      activity on or through the Services and/or through your account/profile.
      <br />
      a. License Grant. Subject to these Terms, REPCARDz grants you a limited,
      non-exclusive, and nontransferable license to access and use the Services
      as made available on the Site or through any REPCARDz mobile application,
      strictly in accordance with these Terms.
      <br />
      b. Registration and Security. You agree, represent, warrant, and guarantee
      that all Personal Information provided by you, either through our Services
      or when speaking to an REPCARDz representative over the phone, is true,
      accurate, complete, up-to-date, and solely yours. You may not impersonate,
      imitate, or pretend to be somebody else when registering for our Services.
      When you create an account and subsequently log in, you will be asked to
      choose a password. You are responsible for safeguarding and maintaining
      the confidentiality of your password, and you agree not to disclose your
      password to any third party. You will be solely responsible for any
      activities or actions taken under your account, whether or not you have
      authorized such activities or actions. You must notify us immediately if
      you know or suspect that any unauthorized person is using your password or
      your account (for example, your password has been lost or stolen, someone
      has attempted to use the Services through your account without your
      consent or your account has been accessed without your permission). We
      also recommend that you do not store your password through your web
      browser or other software. We strongly recommend that you do not use the
      Services on any public computer.
      <br />
      c. Limitations on Use. The Services may be used and accessed for lawful
      purposes only. You agree to abide by all applicable local, state,
      national, and foreign laws, treaties, and regulations in connection with
      your use of the Services and its content. In addition, without limitation,
      you agree that you will not do any of the following while using or
      accessing the Services:
      <br />
      • in any manner transmit or submit any content to which you do not have
      the lawful right to copy, transmit, and display (including any content
      that would violate any confidentiality or fiduciary obligations that you
      might have with respect to the content);
      <br />
      • in any manner transmit or submit any content that infringes the
      intellectual property rights or violates the privacy rights of any third
      party (including, without limitation, copyright, trademark, patent, trade
      secret, or other intellectual property right, or moral right, or right of
      publicity);
      <br />
      • in any manner transmit or submit harmful, threatening, abusive,
      harassing, defamatory, deceptive, fraudulent, obscene, indecent, vulgar,
      lewd, violent, hateful, or otherwise objectionable content or material;
      <br />
      • copy, reproduce, republish, upload, post, transmit, or distribute the
      Services, the Site, or any content thereof;
      <br />
      • share or sell information derived from or related to the Services, the
      Site, or any content thereof;
      <br />
      • modify, translate, alter, adapt, decompile, disassemble (except to the
      extent applicable laws specifically prohibit such restriction), reproduce,
      distribute, or display, or create derivative works, compilations, or
      collective works based on the Services, the Site, or any content thereof;
      <br />
      • knowingly or negligently permit other individuals or entities to use or
      copy the Service or “frame” or “mirror” the Service on any other server or
      wireless or Internet-based device;
      <br />
      • circumvent, disable, or otherwise interfere with security-related
      features on the Services or features that prevent or restrict use or
      copying of any content;
      <br />
      • use the Services to collect or store Personal Information about other
      users;
      <br />
      • knowingly include or use any false or inaccurate information in any
      customer account;
      <br />
      • in any way transmit any unsolicited or unauthorized advertising,
      promotional materials, junk mail, spam, chain letters, “pyramid schemes,”
      or any other form of solicitation, as well as viruses or other computer
      code that may interrupt, destroy, limit the functionality of the Services,
      or interfere with the access of any other user to the Services;
      <br />
      • attempt to probe, scan, or test the vulnerability of any system or
      network operated by us, or breach or impair or circumvent any security or
      authentication measures protecting the Services;
      <br />
      • attack the Services via a denial-of-service attack or a distributed
      denial-of-service attack or otherwise attempt to interfere with the proper
      working of the Services;
      <br />
      • transmit or upload any material to the Services that contains viruses,
      trojan horses, worms, time bombs, or any other harmful or deleterious
      programs;
      <br />
      • attempt to decipher, decompile, disassemble, reverse engineer, or
      otherwise attempt to discover or determine the source code of any software
      or any proprietary algorithm used to provide the Services;
      <br />
      • use the Services in any way that competes with us; or
      <br />
      • encourage, collaborate, or instruct any other person or entity to do any
      of the foregoing.
      <br />
      ANY ATTEMPT TO DO ANY OF THE FOREGOING PROHIBITED ACTS OR TO OTHERWISE
      UNDERMINE THE OPERATION OF THE SERVICES MAY BE A VIOLATION OF CRIMINAL AND
      CIVIL LAW. SHOULD SUCH AN ATTEMPT BE MADE, WE RESERVE THE RIGHT, IN
      ADDITION TO OUR OTHER REMEDIES, TO SEEK DAMAGES (INCLUDING WITHOUT
      LIMITATION ATTORNEYS’ FEES) FROM ANY SUCH INDIVIDUAL OR ENTITY TO THE
      FULLEST EXTENT PERMITTED BY LAW.
      <br />
      We reserve the right, in our sole discretion, to audit or otherwise
      monitor any communication transmitted using the Services. We further
      reserve the right at all times to review, retain, and/or disclose any
      information as necessary to satisfy any applicable law, regulation, legal
      process, governmental request, or business assessment. NOTWITHSTANDING THE
      FOREGOING, WE HEREBY DISCLAIM ANY OBLIGATION TO MONITOR USE OF THE
      SERVICES OR TO RETAIN THE CONTENT ON THE SERVICES UNLESS OTHERWISE AGREED
      OR REQUIRED BY LAW.
      <br />
      d. User Feedback and Suggestions. All feedback, suggestions, ideas, and
      other submissions disclosed, submitted, or offered to REPCARDz or
      otherwise disclosed, submitted, or offered concerning the Services in
      connection with your use of the Services (collectively, “Feedback”) will
      be REPCARDz’s property. Such disclosure, submission, or offer of any
      Feedback will constitute an assignment to REPCARDz of all worldwide
      rights, titles, and interests in all copyrights and other intellectual
      property in the Feedback. REPCARDz will be under no obligation to (i)
      maintain any Feedback in confidence; (ii) pay any compensation for any
      Feedback; or (iii) respond to any Feedback.
      <br />
      e. Ongoing Subscription and Fees. While we may offer certain functions of
      the Services for free, we charge fees for upgrades to additional
      functions. If you subscribe to a paid service, we will bill you in advance
      for your subscription. Your subscription will continue and automatically
      renew on a recurring basis corresponding to the term of your subscription
      unless and until you cancel your subscription, or your account is
      otherwise suspended or terminated pursuant to these Terms. REPCARDz
      reserves the right to change the terms of your subscription, including
      price, from time to time, effective as of the beginning of your next
      billing period following the date of the change. We will give you advance
      notice of these changes, but we will not be able to notify you of changes
      in any applicable taxes.
      <br />
      f. Payment, Fees, and Other Charges. If you elect to access any paid
      component of the Services, you agree to pay all fees and charges
      associated with that paid component on a timely basis. Unless otherwise
      stated, all fees and charges are due and payable in advance, are
      non-refundable, and are exclusive of any applicable federal, state, or
      local taxes. All such fees and charges (including any taxes and late fees,
      as applicable) will be charged to the payment method you provided when you
      elected to access that paid component of the Services. You agree to
      maintain a valid payment method during the term of your use of such
      Services.
      <br />
      g. Cancellation, Termination, and Account Deletion. You may cancel your
      account at any time by emailing us at customerservice@repcardz.com. At
      cancellation, your account will be inactivated and you will no longer be
      able to log into your account. REPCARDz may terminate your password,
      account, or use of the Services at any time if you breach or otherwise
      fail to comply with these Terms or REPCARDz’s then-current payment or
      refund policies, if any and as applicable. In addition, REPCARDz may
      terminate a free account at any time in its sole discretion. If Services
      are suspended, whether for non-payment or any other reason, in order to
      reinstate service, you must re-subscribe to the Services, including the
      payment of any fees required to be paid by a new subscriber.
      <br />
      h. Updates and Outages. REPCARDz may from time to time in its sole
      discretion develop and provide updates to the Services, which may include
      upgrades, bug fixes, patches, other error corrections, and/or new features
      (collectively, “Updates”). Updates may also modify or delete in their
      entirety certain features and functionality. You agree that REPCARDz has
      no obligation to provide any Updates or to continue to provide or enable
      any particular features or functionality. Additionally, it may be
      necessary for REPCARDz to perform scheduled or unscheduled repairs,
      maintenance, or upgrades and such activities may temporarily degrade the
      quality of the Services or result in a partial or complete outage of the
      Service. REPCARDz provides no assurance that you will receive advance
      notification of such activities or that the Services will be uninterrupted
      or error-free. Any degradation or interruption of the Service will not
      give rise to a refund or credit of any fees paid by you. <br />
      i. Links to Third-Party Websites. This Services may contain links to other
      websites on the Internet, which are not maintained by us. When you leave
      the Services, you do so at your own risk. By providing a link to a
      third-party website, we are not endorsing or attempting to associate with
      any other entity. Other websites are not under our control, and you
      acknowledge that we shall not be responsible or liable for any of the
      text, images, videos, content or any other content or information from a
      third-party website. You also acknowledge that we shall not be responsible
      or liable for any damage or loss caused or alleged to be caused by, or in
      connection with, your reliance on any information, any good, any service,
      or any other material provided through a third-party website.
      <br />
      j. Reliance on Information Posted. We reserve the right to modify the
      Services in our sole discretion without notice. We will not be liable if,
      for any reason, any part of the Services or the entire Site is unavailable
      for any period of time. Periodically, we may restrict access to portions
      of the Services or the entire Site. We may make these modifications at any
      time and for any reason without prior notice. You assume any and all risk
      for decisions based on information contained within the Services. The
      information presented on or through the Services is made available solely
      for general information purposes. We do not warrant the accuracy,
      completeness, or usefulness of this information. Any reliance you place,
      or decisions you make, on such information is strictly at your own risk.
      We disclaim all liability and responsibility arising from any reliance
      placed on the Services by you or any other user of the Services, or by
      anyone who may be informed of any of its contents.
      <br />
      k. Carrier Fees. Use of the Services may involve transmission of data
      through your carrier or service provider&apos;s network. You are
      responsible for all carrier, text/SMS, data, or other related fees or
      charges you incur from your carrier or service provider in connection with
      or related to your use of the Services. REPCARDz assumes no liability or
      responsibility for the payment of any charges you may incur.
      <br />
      2. Intellectual Property
      <br />
      The Services, including all text, images, designs, graphics, content,
      source code, object code, data, features, functionality (including but not
      limited to all information, software, displays, enablement of video and
      audio, and the design, selection, and arrangement thereof) are owned by
      us, our licensors, or other providers of such materials. For purposes of
      clarity, REPCARDz owns the rights to the compilation, arrangement, and
      assembly, along with any modifications, variations, updates, versions, and
      changes to all information entered and stored within our Site database(s)
      as part of the Site. This material, collectively, is protected by United
      States copyright, trademark, patent, trade secret, and other intellectual
      property or proprietary rights laws. All of the Services content is
      copyrighted material and is protected by the Copyright Act of 1976. You
      are not permitted to republish, reproduce, transmit, transfer, prepare
      derivative versions or works, or otherwise use any content on the Services
      without our prior, express, and written permission.
      <br />
      You do not and will not acquire any intellectual property rights in the
      Services, including but not limited to the underlying Services and the
      content published herein, by your use of the Services. Subject to your
      compliance with the terms and conditions of these Terms, we grant you a
      limited, non-exclusive, non-transferable, and revocable license, without
      the right to sublicense, to access and use the Services and to download
      and print any content provided by us, solely for your personal and
      non-commercial purposes. No licenses or rights are granted to you by
      implication or otherwise under any intellectual property rights owned or
      controlled by us or our licensors, except for the limited license
      expressly granted in the preceding sentence. REPCARDz and its licensors
      and service providers reserve and shall retain their entire right, title,
      and interest in and to the Services, including all copyrights, trademarks,
      and other intellectual property rights therein or relating thereto, except
      as expressly granted to you in these Terms.
      <br />
      3. Disclaimer of Warranties
      <br />
      THE SERVICES AND ALL INFORMATION CONTAINED HEREIN ARE PROVIDED ON AN “AS
      IS” BASIS WITHOUT ANY WARRANTIES OF ANY KIND.
      <br />
      REPCARDZ, TOGETHER WITH ITS DIRECTORS, OFFICERS, EMPLOYEES, CONTRACTORS,
      AGENTS, AND REPRESENTATIVES, HEREBY DISCLAIM ALL WARRANTIES, EXPRESS OR
      IMPLIED, INCLUDING THE WARRANTY OF MERCHANTABILITY AND NON-INFRINGEMENT OF
      THIRD PARTIES’ RIGHTS, AND THE WARRANTY OF FITNESS FOR A PARTICULAR
      PURPOSE. WE DISCLAIM ALL WARRANTIES WHETHER ARISING OUT OF LAW, STATUTE,
      COURSE OF DEALING, TRADE USAGE, OR ANY OTHER RELATIONSHIP. WE MAKE NO
      WARRANTIES OF ANY KIND REGARDING THE SERVICES OR INFORMATION FOUND ON THE
      SERVICES. WE MAKE NO WARRANTIES WITH REGARD TO THE ACCURACY, RELIABILITY,
      COMPLETENESS, QUALITY, FUNCTIONALITY, TIMELINESS, SPEED, OR ACCESSIBILITY
      OF ANY INFORMATION SUPPLIED WITHIN THE SERVICES. WE DO NOT WARRANT THAT
      THE SERVICES WILL BE OPERATIONAL, SECURE, ERROR-FREE, OR VIRUS FREE. TO
      THE EXTENT ANY JURISDICTION DOES NOT PERMIT US TO DISCLAIM WARRANTIES IN
      THESE WAYS, WE DISCLAIM WARRANTIES TO THE FULLEST EXTENT PERMITTED UNDER
      APPLICABLE LAW.
      <br />
      4. Your Security and Privacy
      <br />
      a. You are responsible for implementing sufficient procedures and security
      mechanisms to satisfy your particular requirements for anti-virus
      protection and accuracy of data input and output, and for maintaining a
      means external to and separate from the Services to reconstruct any lost
      data.
      <br />
      We will not be liable for any loss or damage caused by a distributed
      denial-of-service attack, viruses, or other technologically harmful
      material that may infect your computer equipment, computer programs, data,
      or other proprietary material due to your use of the Services or to your
      downloading of any material posted on it, or on any third-party website
      linked to it.
      <br />
      Some jurisdictions do not permit us to exclude warranties in these ways,
      so it is possible that these exclusions will not apply to our agreement
      with you. In such event, the exclusions shall apply to the fullest extent
      permitted under applicable law.
      <br />
      b. Collection and Use of Your Information. You acknowledge that when you
      use the Services, REPCARDz may use automatic means (including, for
      example, cookies and web beacons) to collect information about your use of
      the Application. You also may be required to provide certain information
      about yourself as a condition to using certain of its features or
      functionality, and the Services shall provide you with opportunities to
      share information about yourself with others. All information we collect
      through or in connection with the Services is subject to the REPCARDz
      Privacy Policy (“Privacy Policy”). By using the Site or creating an
      account to use the Services, you consent to all actions taken by us with
      respect to your information in compliance with the Privacy Policy.
      <br />
      5. User Content and Copyright Policy. <br />
      a. User Content. The Services may contain areas in which you may post or
      upload user-generated content, including profile pictures, feedback,
      posts, other materials or items (collectively, “User Content”). You are
      solely responsible for your use of any User Content you submit. <br />
      By submitting any User Content, you agree that you will not upload, post
      or otherwise transmit any User Content that (a) violates or infringes in
      any way upon the rights of others, including any statements which may
      defame, harass, stalk or threaten others; (b) you know to be false,
      misleading or inaccurate; (c) contains blatant expressions of bigotry,
      racism, racially or ethnically offensive content, hate speech,
      abusiveness, vulgarity or profanity; (d) contains or advocates pornography
      or sexually explicit content, pedophilia, incest, bestiality, or that is
      otherwise obscene or lewd; (e) violates any law or advocates or provides
      instruction on dangerous, illegal, or predatory acts, or discusses illegal
      activities with the intent to commit them; (f) advocates violent behavior;
      (g) is protected by copyright, trademark, trade secret, right of publicity
      or other proprietary right without the express permission of the owner of
      such right; or (h) uses the name or likeness of an identifiable natural
      person without such person’s consent.
      <br />
      b. Reporting Claims of Copyright Infringement. We take claims of copyright
      infringement seriously. We will respond to notices of alleged copyright
      infringement that comply with applicable law. If you believe any materials
      accessible on or from the Services infringe your copyright, you may
      request removal of those materials (or access to them) from the Services
      by submitting written notification to our copyright agent designated
      below. In accordance with the Online Copyright Infringement Liability
      Limitation Act of the Digital Millennium Copyright Act (&quot;DMCA&quot;),
      the written notice (the &quot;DMCA Notice&quot;) must include
      substantially the following: <br />
      • Your physical or electronic signature. <br />
      • Identification of the copyrighted work you believe to have been
      infringed or, if the claim involves multiple works on the Services, a
      representative list of such works. <br />• Identification of the material
      you believe to be infringing in a sufficiently precise manner to allow us
      to locate that material. <br />• Adequate information by which we can
      contact you (including your name, postal address, telephone number, and,
      if available, email address). <br />
      • A statement that you have a good faith belief that use of the
      copyrighted material is not authorized by the copyright owner, its agent,
      or the law. <br />• A statement that the information in the written notice
      is accurate. <br />
      • A statement, under penalty of perjury, that you are authorized to act on
      behalf of the copyright owner. <br />
      If you fail to comply with all of the requirements of the DMCA, your DMCA
      Notice may not be effective. Please be aware that if you knowingly
      materially misrepresent that material or activity on the Services is
      infringing your copyright, you may be held liable for damages (including
      costs and attorneys&apos; fees) under the DMCA. <br />
      Our designated copyright agent to receive DMCA Notices and Counter-Notices
      (as further defined below) may be contacted at
      customerservice@repcardz.com.
      <br />
      c. Counter-Notification Procedures. If you believe that material you
      posted on the Services was removed or access to it was disabled by mistake
      or misidentification, you may file a counter-notification with us (a
      &quot;Counter-Notice&quot;) by submitting written notification to our
      copyright agent designated below. Pursuant to the DMCA, the Counter-Notice
      must include substantially the following: <br />
      • Your physical or electronic signature. <br />
      • An identification of the material that has been removed or to which
      access has been disabled and the location at which the material appeared
      before it was removed or access disabled. <br />• Adequate information by
      which we can contact you (including your name, postal address, telephone
      number, and, if available, email address). <br />
      • A statement under penalty of perjury by you that you have a good faith
      belief that the material identified above was removed or disabled as a
      result of a mistake or misidentification of the material to be removed or
      disabled. <br />• A statement that you will consent to the jurisdiction of
      the Federal District Court for the judicial district in which your address
      is located (or if you reside outside the United States for any judicial
      district in which the Services may be found) and that you will accept
      service from the person (or an agent of that person) who provided the
      Services with the complaint at issue. <br />
      The DMCA allows us to restore the removed content if the party filing the
      original DMCA Notice does not file a court action against you within ten
      business days of receiving the copy of your Counter-Notice. Please be
      aware that if you knowingly materially misrepresent that material or
      activity on the Services was removed or disabled by mistake or
      misidentification, you may be held liable for damages (including costs and
      attorneys&apos; fees) under the DMCA. <br />
      It is our policy in appropriate circumstances to disable and/or terminate
      the accounts of users who are repeat infringers.
      <br />
      d. License Grant of User Content. You retain ownership rights in your User
      Content. However, by providing User Content to the Service, you grant to
      REPCARDz a worldwide, non-exclusive, royalty-free, sublicensable and
      transferable license to use that User Content (including to reproduce,
      distribute, prepare derivative works, display and perform it) in
      connection with the Service and REPCARDz’ (and its successors&apos; and
      Affiliates&apos;) business, including for the purpose of promoting and
      redistributing part or all of the Service.
      <br />
      6. Limitation of Liability
      <br />
      TO THE EXTENT PERMITTED BY LAW, YOU HEREBY RELEASE REPCARDZ, TOGETHER WITH
      ITS DIRECTORS, OFFICERS, EMPLOYEES, CONTRACTORS, AGENTS, AND
      REPRESENTATIVES, FROM ALL LIABILITY ASSOCIATED WITH YOUR USE OF THE
      SERVICES.
      <br />
      You acknowledge that you are responsible for any actions you take while
      using the Services. You recognize that your use of the Services and any
      subsequent actions arising from your use of the Services are taken solely
      at your own risk.
      <br />
      IN NO EVENT WILL REPCARDZ, OUR DIRECTORS, OUR OFFICERS, OUR EMPLOYEES, OUR
      CONTRACTORS, OUR AGENTS, OR OUR REPRESENTATIVES BE LIABLE FOR DAMAGES OF
      ANY KIND UNDER ANY LEGAL THEORY OR UNDER ANY EQUITABLE THEORY ARISING OUT
      OF OR IN CONNECTION WITH YOUR USE OR INABILITY TO USE THE SERVICES, ANY
      WEBSITES LINKED TO IT, ANY CONTENT ON THE SERVICES, INCLUDING ANY DIRECT,
      INDIRECT, SPECIAL, INCIDENTAL, CONSEQUENTIAL, OR PUNITIVE DAMAGES,
      INCLUDING, BUT NOT LIMITED TO, PERSONAL INJURY, PAIN AND SUFFERING,
      EMOTIONAL DISTRESS, CLINICAL OUTCOMES, LOSS OF REVENUE, LOSS OF PROFITS,
      LOSS OF BUSINESS, LOSS OF BUSINESS OPPORTUNITIES, OR ANTICIPATED SAVINGS,
      LOSS OF USE, LOSS OF GOODWILL, LOSS OF DATA, AND WHETHER CAUSED BY TORT
      (INCLUDING NEGLIGENCE), BREACH OF CONTRACT, OR OTHERWISE, EVEN IF
      FORESEEABLE. THE FOREGOING DOES NOT AFFECT ANY LIABILITY WHICH CANNOT BE
      EXCLUDED OR LIMITED UNDER APPLICABLE LAW. <br />
      7. Indemnification
      <br />
      You will indemnify, defend, and hold harmless REPCARDz, our licensors and
      affiliates, and our and their respective directors, officers, employees,
      contractors, agents, and representatives, from and against any and all
      claims, causes of action, demands, liabilities, losses, costs, or expenses
      (including, but not limited to, reasonable attorneys’ fees and expenses)
      arising out of, in connection with, or resulting from:
      <br />
      • your access to or use of the Services;
      <br />
      • your violation of any of the provisions of these Terms;
      <br />
      • any activity related to your account by you or any other person
      accessing the Services through your account, including, without
      limitation, negligent or wrongful conduct; or
      <br />
      • your violation of any third-party right, including, without limitation,
      any intellectual property right, publicity, confidentiality, property, or
      privacy right.
      <br />
      For purposes of clarity, these indemnification obligations apply to your
      use of the Services, other than as expressly authorized in this Terms, and
      your use of any information obtained from the Services or any information
      you provide to the Services. We reserve the right, at your expense, to
      assume the exclusive defense and control of any matter otherwise subject
      to indemnification by you, in which event you will cooperate with us in
      asserting any available defenses.
      <br />
      8. Users under 16 years old
      <br />
      THE SERVICES ARE NOT INTENDED FOR USERS WHO ARE YOUNGER THAN SIXTEEN (16)
      YEARS OF AGE. You can learn more about our treatment of data for young
      Users by reviewing our Privacy Policy.
      <br />
      9. Assignment; Change in Control. You may not assign your account or these
      Terms in whole or in part, for any reason. These Terms will be binding
      upon and will inure to the benefit of the parties and their heirs,
      executors, administrators, successors, and assigns. REPCARDz may assign
      this agreement or delegate any of our rights or obligations hereunder, or
      any part thereof, to any third party, including our successor in interest,
      without requiring your written consent. <br />
      10. Changes to the Terms of Use
      <br />
      We will make changes to these Terms from time to time. The date that these
      Terms were last revised is identified at the top of the page. You are
      responsible for ensuring that you periodically visit our Services and
      these Terms to check for any changes.
      <br />
      11. Entire Agreement
      <br />
      If you have not entered into another agreement with REPCARDz regarding the
      subject matter contained in the Terms, then the Terms, together with the
      Privacy Policy, comprise the entire agreement between you and REPCARDz and
      supersede all prior or contemporaneous negotiations, discussions, or
      agreements, whether written or oral, between you and REPCARDz regarding
      such subject matter. However, if you and REPCARDz have entered into
      another agreement regarding the subject matter set forth in the Terms that
      is a written and signed agreement between you and REPCARDz, then the Terms
      and Privacy Policy should be read and interpreted in conjunction with such
      agreement and, in the event of a conflict between the Terms and a written,
      signed agreement between the parties, the written, signed agreement will
      govern and control.
      <br />
      12. Force Majeure
      <br />
      No party to these Terms will be liable to the other party for any failure
      to perform any of its obligations, except payment obligations, under the
      Terms during any period in which such performance is delayed by
      circumstances beyond its reasonable control, including, but not limited
      to, fire, flood, war, embargo, strike, riot, unavailability of the
      Internet, or the intervention of any governmental authority.
      <br />
      13. Governing Law and Venue
      <br />
      This Terms shall be construed, governed, and enforced under the laws of
      the United States and the State of Texas (without regard to rules
      governing conflict of laws), and any disputes, actions, claims, or causes
      of action arising out of or in connection with the Terms or the Services,
      with the exception of claims for injunctive relief, will be resolved in
      arbitration administered by the American Arbitration Association and
      located in Austin, Texas. You may not, and hereby agree that you will not,
      under any circumstances commence or maintain against REPCARDz any class
      action, class arbitration, or other representative action or proceeding.
      In the event that this arbitration agreement is for any reason held to be
      unenforceable, any litigation against REPCARDz may be commenced only in
      the federal or state courts located in Travis County, Texas. You hereby
      irrevocably consent to the jurisdiction of those courts for such purposes.
      <br />
      14. Limitation of Time to File Claims. ANY CAUSE OF ACTION OR CLAIM YOU
      MAY HAVE ARISING OUT OF OR RELATING TO THESE TERMS OR YOUR USE OF THE
      SERVICES MUST BE COMMENCED WITHIN ONE (1) YEAR AFTER THE CAUSE OF ACTION
      ACCRUES OTHERWISE SUCH CAUSE OF ACTION OR CLAIM IS PERMANENTLY BARRED.
      <br />
      15. Notice
      <br />
      REPCARDz may give notice by means of a general notice via the Service,
      electronic mail to your e-mail address on record in REPCARDz’s account
      information, or by written communication sent by first class mail or
      pre-paid post to your address on record in REPCARDz’s account information.
      Such notice will be deemed to have been given upon the expiration of
      forty-eight (48) hours after mailing or posting (if sent by first class
      mail or pre-paid post) or twelve (12) hours after sending (if sent by
      email). You may give notice to REPCARDz (such notice will be deemed given
      when received by REPCARDz) at any time by any of the following: e-mail at
      customerservice@repcardz.com; letter sent by confirmed facsimile to
      REPCARDz at the following fax number: (888) 684-7379; letter delivered by
      nationally recognized overnight delivery service or first class postage
      prepaid mail to REPCARDz, LLC, 11211 Taylor Draper Lane, Suite 110,
      Austin, Texas 78759.
      <br />
      16. Severability and Waiver
      <br />
      If any provision hereof is declared invalid by a court of competent
      jurisdiction, such provision shall be ineffective only to the extent of
      such invalidity so that the remainder of that provision and all remaining
      provisions will continue in full force and effect. No waiver by us of any
      term or condition set forth herein shall be deemed a further or continuing
      waiver of such term or condition or a waiver of any other term or
      condition, and any failure of us to assert a right or provision shall not
      constitute a waiver of such right or provision
      <br />
      17. Relationship
      <br />
      No joint venture, partnership, employment, or agency relationship exists
      between you and REPCARDz as a result of the Terms or use of the Services.
      The failure of REPCARDz to enforce any right or provision in the Terms
      will not constitute a waiver of such right or provision unless
      acknowledged and agreed to by REPCARDz in writing.
      <br />
      BY USING THE SERVICES, YOU ACKNOWLEDGE THAT YOU HAVE READ THESE TERMS OF
      USE, AND YOU AGREE TO BE BOUND BY ALL APPLICABLE TERMS AND CONDITIONS.
      <br />
      18. Contact Us
      <br />
      To ask questions or comment about these Terms, you may contact us at:
      <br />
      E-mail Address: customerservice@repcardz.com
      <br />
      Mailing Address: Attention: Website Inquiry
      <br />
      REPCARDz, LLC
      <br />
      11211 Taylor Draper Lane, Suite 110
      <br />
      Austin, Texas 78759
      <br />
    </div>
  );
};

export default GetTermsOfUseHtml;
