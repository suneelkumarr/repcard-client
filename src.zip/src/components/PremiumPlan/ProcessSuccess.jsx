/**
 *
 * Description. Stripe payment screens
 *
 * @link   URL
 * @file   Display Success page if payment is successful Otherwise display
          failure page
 * @since  1.0.0
 */
import React from 'react';
import { Link } from 'react-router-dom';

/**
 * Summary. Payment success or fail
 *
 * Description. Display success or failure message html
 *
 * @since      1.0
 * @deprecated No //x.x.x Use new_function_name() instead.
 * @access     export public
 *
 * @param {string}   paymentStatus     can be 'fail' or 'success'
 * @param {function} goBackPayment     callback function of back to payment btn click
 *
 */
const ProcessSuccess = ({ paymentStatus, goBackPayment }) => {
  const isFail = paymentStatus === 'fail';
  return (
    <>
      <div className="success_msg_panel text-center">
        <div className={`success_icon ${isFail ? 'fail_icon' : ''}`} />
        <p>
          {isFail
            ? 'There was a problem processing your credit card. Please try again.'
            : ' Congratulations! Your payment was successful. You are now a Premium Member'}
        </p>
        <div className="center_panel go-back text-center mt-4">
          {isFail ? (
            <button
              type="button"
              className="outline-btn mr-2"
              onClick={goBackPayment}
            >
              Go Back to Payment
            </button>
          ) : (
            ''
          )}
          <Link to="/RepDashboard">
            <button type="button" className="fill-orange-btn m-0">
              Back to Home
            </button>
          </Link>
        </div>
      </div>
    </>
  );
};

export default ProcessSuccess;
