/**
 *
 * Description. Upgrade to Premium plan
 *
 * @link   URL
 * @file   when User wants to upgrade premium plan, Displays month and year plan
           with coupan code (if available)
 * @since  1.0.0
 */
import React, { Component } from 'react';
import { MDBModal, MDBModalBody, MDBInput } from 'mdbreact';
import App from './formIndex';
import ProcessSuccess from './ProcessSuccess';
import { axiosApi } from '../../apis/axiosApiCall';
import { repPlanType, providerPlanType } from './planDetails';

class UpgradePopup extends Component {
  constructor(props) {
    super(props);
    const { isRep } = this.props;
    this.state = {
      modal: false,
      planName: '',
      goTopaymentScreen: false,
      promoCodeObj: {},
      planObj: isRep ? repPlanType : providerPlanType,
      paymentStatus: '',
    };

    this.startTimer = null;
  }

  /**
   *  toggle upgrade modal popup
   */
  premiumPopup = () => {
    this.setState((prevState) => ({
      modal: !prevState.modal,
    }));
  };

  /**
   *  close upgrade modal popup forcefully and set default states
   */
  onCloseModal = () => {
    this.setState({
      planName: '',
      goTopaymentScreen: false,
      promoCodeObj: {},
      modal: false,
    });
  };

  /**
   *  Set to initial screen of payment
   */
  goBackPayment = () => {
    this.setState({
      planName: '',
      goTopaymentScreen: false,
      promoCodeObj: {},
      paymentStatus: '',
    });
  };

  /**
   * Summary. OnChange event
   *
   * Description. Input Change method for coupan input
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   e           Input element event object
   *
   */
  onChange = (e) => {
    const { name, value } = e.target;
    this.setState((prevState) => ({
      promoCodeObj: {
        ...prevState.promoCodeObj,
        [name]: value,
      },
    }));
    this.getCouponApi(value); // Call coupan API
  };

  /**
   * Summary. choose plan
   *
   * Description. Select plan either month or year
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   planName      plan name (month or year)
   */
  selectPlan = (planName) => {
    this.setState({
      planName,
    });
  };

  /**
   * Summary. continue btn click
   *
   * Description. Go to payment screen on continue click
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  onPlanSelectClick = () => {
    this.setState({
      goTopaymentScreen: true,
    });
  };

  /**
   * Summary. Get Coupan API
   *
   * Description. To retrieve All coupan details using get API
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   couponId      id of the coupan
   */
  getCouponApi = (couponId) => {
    clearTimeout(this.startTimer);
    this.startTimer = setTimeout(() => {
      const reqObj = {
        couponId,
      };
      this.setState({
        isAPICalled: true,
      });
      axiosApi('/payment/retrievecoupon', 'POST', reqObj, (res) => {
        this.setState({
          isAPICalled: false,
        });
        if (res.error) {
          this.setState((prevState) => ({
            promoCodeObj: {
              ...prevState.promoCodeObj,
              id: '',
              type: '',
              price: '',
              percentage: '',
            },
          }));
        } else {
          const { planObj } = this.state;
          const percentage = res.data.percent_off;
          const pricePlan = res.data.metadata.PricePlan;
          let type = 'month';
          if (planObj.year.planId === pricePlan) {
            type = 'year';
          }
          this.setState((prevState) => ({
            promoCodeObj: {
              ...prevState.promoCodeObj,
              id: couponId,
              type,
              percentage,
              price:
                planObj[type].price - (planObj[type].price * percentage) / 100,
            },
            planName: type,
          }));
        }
      });
    }, 500);
  };

  componentDidMount() {}

  componentWillUnmount() {
    clearTimeout(this.startTimer); // Clear coupan API timeout
  }

  /**
   * Summary. Payment success or fail
   *
   * Description. Go to payment success or fail screen after payment done or fail
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {boolean}   flag      flag for payment done or fail
   */
  onSuccessOrFail = (flag) => {
    this.setState({
      paymentStatus: flag ? 'success' : 'fail',
    });
  };

  /**
   * Summary. Price plan info with coupan details
   *
   * Description. Gather all the plan information with price and coupan details
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  getPriceObj = () => {
    const { promoCodeObj, planName, planObj } = this.state;
    if (promoCodeObj.id) {
      if (planName === promoCodeObj.type) {
        return {
          planId: planObj[planName].planId,
          coupanId: promoCodeObj.id,
          price: promoCodeObj.price,
          planName,
        };
      }
    }
    return {
      planId: planObj[planName].planId,
      coupanId: '',
      price: planObj[planName].price,
      planName,
    };
  };

  render() {
    const {
      modal,
      promoCodeObj,
      planName,
      goTopaymentScreen,
      paymentStatus,
      // planObj,
      isAPICalled,
    } = this.state;

    return (
      <>
        <button
          type="button"
          onClick={this.premiumPopup}
          className="fill-orange-btn m-0"
          data-repcard-test="popup"
        >
          Upgrade Now
        </button>
        {/* modal popup */}
        <MDBModal
          className="coupon_plan_panel"
          isOpen={modal}
          toggle={this.premiumPopup}
          disableBackdrop
        >
          <MDBModalBody>
            {paymentStatus ? (
              <ProcessSuccess
                paymentStatus={paymentStatus}
                goBackPayment={this.goBackPayment}
              />
            ) : goTopaymentScreen ? (
              <App
                priceObj={this.getPriceObj()}
                onCancelClick={this.onCloseModal}
                onSuccessOrFail={this.onSuccessOrFail}
              />
            ) : (
              <div className="preaccount_plan">
                <h5 className="heading_h5 mb-3">
                  PREMIUM ACCOUNT (choose a plan)
                </h5>
                <div
                  className={`premium_plans ${
                    planName === 'month' ? 'active' : ''
                  }`}
                >
                  <div className="item auto">
                    Monthly
                    {promoCodeObj.type === 'month' ? (
                      <span className="prem_small_text">
                        Additional {promoCodeObj.percentage}% discount applied
                      </span>
                    ) : (
                      ''
                    )}
                  </div>
                  <div className="item auto">
                    {/* $
                    {promoCodeObj.type === 'month'
                      ? promoCodeObj.price
                      : planObj.month.price}
                    /month */}
                    {'TBD'}
                  </div>
                  <div className="item auto">
                    <button
                      type="button"
                      className="outline-btn"
                      onClick={() => {
                        this.selectPlan('month');
                      }}
                      data-repcard-test="month"
                    >
                      Select
                    </button>
                  </div>
                </div>
                <div
                  className={`premium_plans position-relative ${
                    planName === 'year' ? 'active' : ''
                  }`}
                >
                  <div className="item auto">
                    Annual
                    <div className="tooltip_hover">
                      <div className="info-icon"> </div>
                      <span className="tooltiptext">1o% discount applied</span>
                    </div>
                    {promoCodeObj.type === 'year' ? (
                      <span className="prem_small_text">
                        Additional {promoCodeObj.percentage}% discount applied
                      </span>
                    ) : (
                      ''
                    )}
                  </div>
                  <div className="item auto">
                    {/* $
                    {promoCodeObj.type === 'year'
                      ? promoCodeObj.price
                      : planObj.year.price}
                    /year */}
                    {'TBD'}
                  </div>
                  <div className="item auto">
                    <button
                      type="button"
                      className="outline-btn"
                      onClick={() => {
                        this.selectPlan('year');
                      }}
                      data-repcard-test="year"
                    >
                      Select
                    </button>
                  </div>
                </div>

                <div className="center_panel">
                  <MDBInput
                    className="coupon_input"
                    onChange={this.onChange}
                    value={promoCodeObj.promoCode}
                    name="promoCode"
                    hint="Enter your promo code"
                  />
                  <span className="coupon_info">
                    Enter your discount or premium enterprise code here
                  </span>
                </div>
                <div className="center_panel mt-4">
                  <button
                    type="button"
                    className="fill-orange-btn"
                    disabled={!planName || isAPICalled}
                    onClick={this.onPlanSelectClick}
                    data-repcard-test="next"
                  >
                    Continue
                  </button>
                  <button
                    type="button"
                    className="outline-btn"
                    onClick={this.onCloseModal}
                    data-repcard-test="popupclose"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}
          </MDBModalBody>
        </MDBModal>
      </>
    );
  }
}

export default UpgradePopup;
