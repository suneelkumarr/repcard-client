/**
 *
 * Description. Load Stripe
 *
 * @link   URL
 * @file   Load stripe using stripe publish key and call payment component
           accordingly
 * @since  1.0.0
 */
import React from 'react';
import { Elements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import app from '../../helpers/appGlobal';
import CheckoutForm from './CheckoutForm';

// Make sure to call `loadStripe` outside of a component’s render to avoid
// recreating the `Stripe` object on every render.
const stripePromise = loadStripe(app.config.STRIPE_PUBLISHABLE_KEY);

/**
 * Summary. Load Stripe form
 *
 * Description. Load Stripe form
 *
 * @since      1.0
 * @deprecated No //x.x.x Use new_function_name() instead.
 * @access     export public
 *
 * @param {object}   priceObj          information related to coupan and plan info
 * @param {function} onCancelClick     callback function of cancel btn click
 * @param {function} onSuccessOrFail   callback function of save btn click
 *
 */
const App = ({ priceObj, onCancelClick, onSuccessOrFail }) => {
  return (
    <div className="acc_upgrade_plan">
      <h5 className="heading_h5 mb-3">Account Upgrade</h5>
      <div className="acc_info">
        You have selected to upgrade to REPCARDz PREMIUM - Billed{' '}
        {priceObj.planName === 'month' ? 'monthly' : 'Annually'} $
        {priceObj.price} Please fill in all the required fields below.
      </div>
      <div className="form_panel text-left">
        <Elements stripe={stripePromise}>
          <CheckoutForm
            priceObj={priceObj}
            onCancelClick={onCancelClick}
            onSuccessOrFail={onSuccessOrFail}
          />
        </Elements>
      </div>
    </div>
  );
};

export default App;
