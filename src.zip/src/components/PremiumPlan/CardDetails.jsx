/**
 *
 * Description. Credit card details Update
 *
 * @link   URL
 * @file   Stripe component for credit card details update along with
           name, phone and email
 * @since  1.0.0
 */
import React, { Component } from 'react';
import { MDBInput, MDBRow, MDBCol } from 'mdbreact';
import {
  ElementsConsumer,
  CardElement,
  CardNumberElement, // eslint-disable-line
  CardCvcElement, // eslint-disable-line
  CardExpiryElement, // eslint-disable-line
} from '@stripe/react-stripe-js';
import RepNumberFormat from '../../utils/RepNumberFormat.jsx';
import validateObj from '../../validations/repprofile/repfront.js';
import CardSection from './Cardsection';
import { axiosApi } from '../../apis/axiosApiCall';
import app from '../../helpers/appGlobal';

class CardDetails extends Component {
  constructor(props) {
    super(props);
    const billingDetails = app.user.paymentMethod.billing_details;
    const { name, email, phone } = billingDetails;
    this.state = {
      inputClass: {},
      errorObj: {},
      isSaveCard: false,
      cardError: '',
      cardName: name,
      email,
      phone,
    };
  }

  /**
   * Summary. Form validation
   *
   * Description. Validate form on submit click
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @return {boolean} false if not valid else true
   */
  validate() {
    const { cardName, phone, email, isSaveCard } = this.state;
    let isValid = true;
    let error;

    error = this.validateInput('cardName', cardName);
    if (error) {
      isValid = false;
    }

    error = this.validateInput('phone', phone);
    if (error) {
      isValid = false;
    }

    error = this.validateInput('email', email);
    if (error) {
      isValid = false;
    }

    if (!isSaveCard) {
      isValid = false;
    }

    const { stripe, elements } = this.props;
    if (!stripe || !elements) {
      // Stripe.js has not yet loaded.
      // Make  sure to disable form submission until Stripe.js has loaded.
      isValid = false;
    }

    return isValid;
  }

  /**
   * Summary. Credit card save API
   *
   * Description. Validate and save the credit card info using api call
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Object}   event      event object
   */
  handleSubmit = async (event) => {
    // We don't want to let default form submission happen here,
    // which would refresh the page.
    event.preventDefault();

    const isValid = this.validate();
    if (isValid) {
      const { stripe, elements } = this.props;
      const { cardName, phone, email } = this.state;

      this.setState({
        isAPICalled: true,
      });
      // Stripe paymentMethod call - it validates the credit card details
      const result = await stripe.createPaymentMethod({
        type: 'card',
        card: elements.getElement(CardElement),
        billing_details: {
          name: cardName,
          phone,
          email,
        },
      });
      // error if credit card details invalid
      if (result.error) {
        this.setState({
          cardError: result.error.message,
          isAPICalled: false,
        });
      } else {
        this.setState({
          cardError: '',
        });
        const reqObj = {
          email,
          payment_method: result.paymentMethod.id,
          userId: app.user.id,
          userType: app.user.userType,
        };

        axiosApi(`/payment/updatePaymentMethods`, 'POST', reqObj, (res) => {
          this.setState({
            isAPICalled: false,
          });
          const { onSuccessOrFail } = this.props;
          if (res.error) {
            alert(res.message || 'error occured');
          } else {
            onSuccessOrFail(true, res.data);
          }
        });
      }
    }
  };

  /**
   * Summary. Validate Input
   *
   * Description. Sets the error to errorObj and className to inputClass object
   *              if any validation error found.
   *              errorObj is used for displaying the errors for particular input
   *              inputClas is used for Adding error classNames for particular input
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   name           Input element name
   * @param {string}   value          Input element value
   *
   * @return {String} Error if any else null
   */
  validateInput(name, value) {
    if (validateObj[name]) {
      let error = '';
      let className = 'error-border';
      error = validateObj[name](value);
      if (!error) {
        className = '';
      }

      this.setState((prevState) => ({
        errorObj: {
          ...prevState.errorObj,
          [name]: error,
        },
        inputClass: {
          ...prevState.inputClass,
          [name]: className,
        },
      }));

      return error;
    }
    return '';
  }

  /**
   * Summary. OnBlur event
   *
   * Description. Blur method for all input
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   e           Input element event object
   *
   */
  onBlur = (e) => {
    const { name } = e.target;
    const stateVal = this.state;
    this.validateInput(name, stateVal[name]);
  };

  /**
   * Summary. Set input values
   *
   * Description. Update All the input values to state
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   name           name of the input
   * @param {string}   value          value of the input
   *
   */
  setValue = (name, value) => {
    this.setState({
      [name]: value,
    });
  };

  /**
   * Summary. Input phone number change event
   *
   * Description. update phone number value to state
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   values         number object contains formatted value
   * @param {string}   name           name of the input
   * @param {string}   apiValue       value which needs to pass in API
   *
   */
  onDateChange = (values, name, apiValue) => {
    this.setValue(name, apiValue);
  };

  /**
   * Summary. OnChange event
   *
   * Description. Input Change method for all input
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   e           Input element event object
   *
   */
  onChange = (e) => {
    const { name, value } = e.target;
    this.setValue(name, value);
  };

  /**
   * Summary. checkbox change event
   *
   * Description. Set isAgree and save Card checkbox to state
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   e           Input element event object
   *
   */
  onChangeCheckbox = (e) => {
    const { checked, name } = e.target;
    this.setState({
      [name]: checked,
    });
  };

  render() {
    const { stripe, onCancelClick } = this.props;
    const {
      cardName,
      phone,
      email,
      cardError,
      inputClass,
      errorObj,
      isAPICalled,
      isSaveCard,
    } = this.state;

    return (
      <form onSubmit={this.handleSubmit}>
        <MDBRow>
          <MDBCol lg="6" md="6" sm="12">
            <div className={`input-field ${inputClass.cardName}`}>
              <MDBInput
                type="text"
                value={cardName}
                name="cardName"
                onChange={this.onChange}
                onBlur={this.onBlur}
                label="Name on the card"
              />
              {errorObj.cardName ? (
                <p className="error-message">
                  <span /> {errorObj.cardName}
                </p>
              ) : (
                ''
              )}
            </div>
          </MDBCol>
          <MDBCol lg="3" md="3" sm="3" className="pl-lg-0 pl-md-0 pl-sm-0">
            <div className={`input-field ${inputClass.email}`}>
              <MDBInput
                type="email"
                value={email}
                name="email"
                onChange={this.onChange}
                onBlur={this.onBlur}
                label="Email"
              />
              {errorObj.email ? (
                <p className="error-message">
                  <span /> {errorObj.email}
                </p>
              ) : (
                ''
              )}
            </div>
          </MDBCol>
          <MDBCol lg="3" md="3" sm="3" className="pl-lg-0 pl-md-0 pl-sm-0">
            <div className={`input-field fixed-field ${inputClass.phone}`}>
              <label className="field_label">Phone</label>
              <RepNumberFormat
                onChange={this.onDateChange}
                onBlur={this.onBlur}
                value={phone}
                className="form-control"
                name="phone"
                format="XXX.XXX.XXXX"
              />
              {errorObj.phone ? (
                <p className="error-message">
                  <span /> {errorObj.phone}
                </p>
              ) : (
                ''
              )}
            </div>
          </MDBCol>
          <MDBCol lg="12">
            <CardSection cardError={cardError} />
          </MDBCol>
          <MDBCol lg="12">
            <div className="cardlabel">
              <MDBInput
                label="Save my payment details for auto renewal (your details will be saved on My Account Page)"
                filled
                type="checkbox"
                id="chekbox2"
                name="isSaveCard"
                onChange={this.onChangeCheckbox}
              />
            </div>
            <div className="text-left mt-4 mb-5">
              <button
                type="submit"
                className="fill-orange-btn"
                disabled={!stripe || isAPICalled || !isSaveCard}
              >
                {isAPICalled ? (
                  <span className="spinner-border spinner-border-sm" />
                ) : (
                  ''
                )}
                Save
              </button>
              <button
                type="button"
                className="outline-btn"
                onClick={onCancelClick}
              >
                Cancel
              </button>
            </div>
          </MDBCol>
        </MDBRow>
      </form>
    );
  }
}

export default function InjectedCheckoutForm({
  onCancelClick,
  onSuccessOrFail,
}) {
  return ({ stripe, elements }) => {
    if (app.user.paymentMethod) {
      return (
        <ElementsConsumer>
          <CardDetails
            stripe={stripe}
            elements={elements}
            onCancelClick={onCancelClick}
            onSuccessOrFail={onSuccessOrFail}
          />
        </ElementsConsumer>
      );
    }
    return <ElementsConsumer />;
  };
}
