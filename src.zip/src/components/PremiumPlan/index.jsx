/**
 *
 * Description. Plans page
 *
 * @link   URL
 * @file   Display All Plans Such as Basic, Premium and President’s Club
           Also Update credit card details if plan is premium
 * @since  1.0.0
 */
import React, { Component, lazy, Suspense } from 'react';
import { MDBContainer, MDBRow, MDBCol } from 'mdbreact';
import { Link } from 'react-router-dom';
import Unsubscribe from './Unsubscribe.jsx';
import {
  getBasicPlanNew,
  getPlanCancel,
  getEndDate,
} from '../../utils/getPlanInfo';
import ProfileHeading from '../Common/ProfileHeading';
import app from '../../helpers/appGlobal';
import './premiumplan.scss';

const Loading = () => <div>Loading...</div>;
const UpdatePayment = lazy(() => import('./formIndex1'));
// const UpgradePopup = lazy(() => import('./UpgradePopup'));

class Plans extends Component {
  constructor(props) {
    super(props);
    this.state = {
      keyVal: 0,
    };
  }

  componentDidMount() {}

  /**
   *  re render html on successful unsubscribe
   */
  downgradeSuccess = () => {
    this.setState((prevState) => ({
      keyVal: prevState.keyVal + 1,
    }));
  };

  onClick = (e) => {
    e.preventDefault();
  };

  render() {
    const { goBackToDashboard, goBackToDashboardAndSave, isRep } = this.props;
    const { keyVal } = this.state;
    const isBasicPlan = getBasicPlanNew();
    const isPlanCancel = getPlanCancel();
    const isEndDate = getEndDate();
    return (
      <MDBContainer key={keyVal}>
        <MDBRow className="my-5 justify-content-center">
          <MDBCol lg="12">
            <div className="premium_plan_heading">
              <span
                className="left_icon cursor"
                role="presentation"
                data-repcard-test="back"
                onClick={goBackToDashboard}
              />
              Current Plan
            </div>
          </MDBCol>
          <MDBCol lg="12">
            <div className="text-center premuim_info_txt mt-4 mt-lg-0 mt-md-4">
              Save <span className="prem_percnt">20%</span> when you pay{' '}
              <span className="prem_orange">annually!</span>
            </div>
            <ul className="list">
              <li
                className={`list-item basic-account ${
                  isBasicPlan ? 'selected' : ''
                }`}
              >
                <div className="current_label" />
                <p className="prem_list_name">Basic</p>
                <ul className="prem_list_features">
                  {isRep ? (
                    <>
                      <li>Name</li>
                      <li>Company Name and Product Lines Listed</li>
                      <li>Email Listed</li>
                      <li>My Accounts Covered</li>
                    </>
                  ) : (
                    <>
                      <li>
                        Search for Reps by Company, Name, and Product Line
                      </li>
                      <li>View Rep’s Email</li>
                    </>
                  )}
                </ul>

                {isBasicPlan || isPlanCancel ? (
                  ''
                ) : (
                  <div className="text-center upgrade_btn">
                    <Unsubscribe
                      isRep={isRep}
                      downgradeSuccess={this.downgradeSuccess}
                    />
                  </div>
                )}
                <p
                  className="text-center prem_list_name bottom_txt mt-4 pt-4"
                  style={{
                    textTransform: 'uppercase',
                    fontSize: 'inherit',
                  }}
                >
                  Price to be Determined by our pilot program
                </p>
              </li>
              <li
                className={`list-item premium ${isRep ? '' : 'prov_point'} ${
                  isBasicPlan ? '' : 'selected'
                }`}
              >
                <div className="current_label" />
                <p className="prem_list_name">Premium</p>
                <ul className="prem_list_features">
                  {isRep ? (
                    <>
                      <li>Name</li>
                      <li>Company Name and Product Lines Listed</li>
                      <li>Email Listed</li>
                      <li>My Accounts Covered</li>
                      <li>Phone Numbers Listed</li>
                      <li>Profile Picture</li>
                      <li>Products Listed</li>
                    </>
                  ) : (
                    <>
                      <li>
                        Search for Reps by Company, Name, and Product Line
                      </li>
                      <li>View Rep’s Email </li>
                      <li>View Rep’s Phone Numbers and Profile Picture</li>
                      <li>
                        Search for Reps by Product Name, Re-order Number or
                        Keyword
                      </li>
                      <li>Save your Favorite Reps for Easy Recall</li>
                    </>
                  )}
                </ul>

                {isBasicPlan ? (
                  <Suspense fallback={<Loading />}>
                    <div className="text-center upgrade_btn">
                      {/* <UpgradePopup isRep={isRep} /> */}
                    </div>
                    <p
                      className="text-center prem_list_name bottom_txt mt-4 pt-4"
                      style={{
                        textTransform: 'uppercase',
                        fontSize: 'inherit',
                      }}
                    >
                      Price to be Determined by our pilot program
                    </p>
                  </Suspense>
                ) : isPlanCancel ? (
                  <p className="text-center prem_list_name expiry bottom_txt mt-3 m-0 px-2">
                    Your Complimentary Premium Trial will{' '}
                    <br className="d-none d-md-inline-block" /> end on{' '}
                    {getEndDate()}.
                  </p>
                ) : isEndDate ? (
                  <p className="text-center prem_list_name expiry bottom_txt mt-3 m-0 px-2">
                    Your Premium membership will{' '}
                    <br className="d-none d-md-inline-block" /> end on{' '}
                    {isEndDate}
                  </p>
                ) : (
                  ''
                )}
                {(isPlanCancel || isEndDate) && (
                  <p
                    className="text-center prem_list_name bottom_txt mt-4 pt-4"
                    style={{
                      textTransform: 'uppercase',
                      fontSize: 'inherit',
                    }}
                  >
                    Price to be Determined by our pilot program
                  </p>
                )}
              </li>
              <li
                className={`list-item last president ${
                  isRep ? '' : 'prov_point'
                } `}
              >
                <div className="current_label" />
                <p className="prem_list_name">President’s Club</p>
                <ul className="prem_list_features mb-5">
                  {isRep ? (
                    <>
                      <li>Name</li>
                      <li>Company Name and Product Lines Listed</li>
                      <li>Email Listed</li>
                      <li>My Accounts Covered</li>
                      <li>Phone Numbers Listed</li>
                      <li>Profile Picture</li>
                      <li>Products Listed</li>
                      <li>HIPAA Compliant Live Chat and Videoconferencing</li>
                      <li>Provider Requests</li>
                    </>
                  ) : (
                    <>
                      <li>
                        Search for Reps by Company, Name, and Product Line
                      </li>
                      <li>View Rep’s Email </li>
                      <li>View Rep’s Phone Numbers and Profile Picture</li>
                      <li>
                        Search for Reps by Product Name, Re-order Number or
                        Keyword
                      </li>
                      <li>Save your Favorite Reps for Easy Recall</li>
                      <li>HIPAA Compliant Live Chat and Videoconferencing</li>
                      <li>Schedule a Rep</li>
                    </>
                  )}
                </ul>

                <p className="text-center prem_list_name bottom_txt">
                  Coming Soon
                </p>
              </li>
            </ul>
          </MDBCol>
          <MDBCol lg="12">
            <div className="text-center enterprise_info pb-5">
              You could categorize your REPCARDz membership as a
              <br className="d-none d-lg-inline-block d-md-display-none" />
              Business Card or Membership expense.
              <br className="d-none d-lg-inline-block d-md-display-none" />
              REPCARDz, LLC does not provide tax, legal or accounting advice.
            </div>

            <div className="text-center enterprise_info">
              Want to create an enterprise account for your manufacturer?{' '}
              <Link to="/" onClick={this.onClick} className="i_tooltip_hover">
                Click here
                <div className="info-tooltip bottom">Coming Soon</div>
              </Link>
              .
            </div>
          </MDBCol>
        </MDBRow>
        {isBasicPlan ? (
          ''
        ) : (
          <div className={isPlanCancel ? 'noEvents' : ''}>
            <MDBRow>
              <MDBCol lg="12">
                {app.user.paymentMethod && (
                  <ProfileHeading headingtxt="Payment Details" />
                )}
              </MDBCol>
            </MDBRow>
            <Suspense fallback={<Loading />}>
              <UpdatePayment
                onSuccessOrFail={goBackToDashboardAndSave}
                onCancelClick={goBackToDashboard}
              />
            </Suspense>
          </div>
        )}
      </MDBContainer>
    );
  }
}

export default Plans;
