/**
 *
 * Description. Reset Password
 *
 * @link   URL
 * @file   When user clicks on Forgot password link form email this page appears.
           User can reset the new password from this page.
 * @since  1.0.0
 */
import React, { Component } from 'react';
import { Redirect } from 'react-router-dom';
import { MDBContainer, MDBCol, MDBRow, MDBInput, Fa } from 'mdbreact';
import { decrypt } from '../../config/encrypt-decrypt';
import { axiosApi } from '../../apis/axiosApiCall';
import validateObj from '../../validations/repprofile/repfront.js';
import app from '../../helpers/appGlobal';

class ResetPassword extends Component {
  constructor(props) {
    super(props);
    this.state = {
      apiErrorMessage: '',
      dataObj: {},
      errorObj: {},
      inputClass: {},
      redirectToReferrer: '',
    };
  }

  /**
   * Summary. Token expired API
   *
   * Description. Check if password reset token is already used or not via API
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Object}    dataObj      Object contains userId, token, email and userType
   */
  isTokenExpired = (dataObj) => {
    const { userId, token, email, userType } = dataObj;
    const reqObj = {
      userid: userId,
      recovery_token: token,
      email,
      userType,
    };
    axiosApi('/resetpwd/verifyPasswordToken', 'POST', reqObj, (res) => {
      if (res.error) {
        // Token expired
        this.setState({
          isLinkExpired: true,
        });
      } else {
        this.setState({
          dataObj,
          isLinkExpired: false,
        });
      }
    });
  };

  /**
   * Summary. decrypt data from URL
   *
   * Description. retrive all the user related info from URL.
                  Redirected to 404 page if any error found
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  decryptData() {
    const { match } = this.props;
    const str = match.params.token;
    if (str) {
      let dataObj = decrypt(str, app.config.AES_ENCRYPTION_KEY);
      if (dataObj) {
        dataObj = JSON.parse(dataObj);
        if (
          dataObj.token &&
          dataObj.userId &&
          dataObj.email &&
          dataObj.userType
        ) {
          this.isTokenExpired(dataObj);
        } else {
          window.location.href = '/404';
        }
      } else {
        window.location.href = '/404';
      }
    } else {
      window.location.href = '/404';
    }
  }

  componentDidMount() {
    this.decryptData();
  }

  /**
   * Summary. Validate Input
   *
   * Description. Sets the error to errorObj and className to inputClass object
   *              if any validation error found.
   *              errorObj is used for displaying the errors for particular input
   *              inputClas is used for Adding error classNames for particular input
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   name           Input element name
   * @param {string}   value          Input element value
   * @param {string}   value1         Input element Addtional value
   *
   * @return {String} Error if any else null
   */
  validateInput(name, value, value1) {
    if (validateObj[name]) {
      let error = '';
      let className = 'error-border';
      error = validateObj[name](value, value1);
      if (!error) {
        className = '';
      }

      this.setState((prevState) => ({
        errorObj: {
          ...prevState.errorObj,
          [name]: error,
        },
        inputClass: {
          ...prevState.inputClass,
          [name]: className,
        },
      }));

      return error;
    }
    return '';
  }

  /**
   * Summary. OnChange event
   *
   * Description. Input Change method for all input
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   e           Input element event object
   *
   */
  onChange = (e) => {
    const { name, value } = e.target;
    this.setState({
      [name]: value,
    });
  };

  /**
   * Summary. OnBlur event
   *
   * Description. Blur method for all input
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   e           Input element event object
   *
   */
  onBlur = (e) => {
    const { password } = this.state;
    const { name, value } = e.target;
    this.validateInput(name, value, password);
  };

  /**
   * Summary. Form validation
   *
   * Description. Validate form on submit click
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @return {boolean} false if not valid else true
   */
  validate() {
    const { password, confirmpass } = this.state;
    let isValid = true;
    let error;

    error = this.validateInput('password', password);
    if (error) {
      isValid = false;
    }

    error = this.validateInput('confirmpass', confirmpass, password);
    if (error) {
      isValid = false;
    }

    return isValid;
  }

  /**
   * Summary. Password reset API
   *
   * Description. Update the new password with reset password API
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  resetPasswordApi = () => {
    const { password, dataObj } = this.state;
    const { userId, token, email, userType } = dataObj;
    const reqObj = {
      userid: userId,
      recovery_token: token,
      userType,
      password,
      email,
    };
    this.setState({
      isAPICalled: true,
    });
    axiosApi(`/resetpwd/updatePassword`, 'POST', reqObj, (res) => {
      this.setState({
        isAPICalled: false,
      });
      if (res.error) {
        this.setState({
          apiErrorMessage: res.message || 'Some Error occured',
        });
      } else {
        this.setState({
          redirectToReferrer: '/ForgotPassword',
        });
      }
    });
  };

  /**
   * Summary. Form submit
   *
   * Description. Validate the form and call the api
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param  {object}      e       event object
   */
  onBtnClick = (e) => {
    e.preventDefault();
    const isValid = this.validate();
    if (isValid) {
      this.resetPasswordApi();
    }
  };

  /**
   * Summary. Password Toggle
   *
   * Description. Toggle password on click of eye icon
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   e           Input element event object
   * @param {String}   name        name of the inout field
   */
  handleClickShowPassword = (e, name) => {
    e.preventDefault();
    this.setState((prevState) => ({
      [name]: !prevState[name],
    }));
  };

  render() {
    const {
      dataObj,
      errorObj,
      inputClass,
      password,
      confirmpass,
      isAPICalled,
      redirectToReferrer,
      isLinkExpired,
      apiErrorMessage,
      showPassword,
      showPassword1,
    } = this.state;

    if (redirectToReferrer) {
      app.passwordReset = true;
      const from = {
        pathname: redirectToReferrer,
      };
      return <Redirect to={from} />;
    }

    let isDataEmpty = false;
    if (!(dataObj.userId && dataObj.token && dataObj.email)) {
      isDataEmpty = true;
    }

    const isBtnDisable = !(password && confirmpass) || isAPICalled;

    return (
      <MDBContainer>
        <MDBRow>
          <MDBCol lg="12" className="signup_wrap">
            <MDBRow className="d-flex justify-content-center">
              <MDBCol lg="5" className="mt-5">
                {isLinkExpired ? (
                  <div className="forgot_pwd_panel">
                    <h5 className="heading_h5">Reset your password</h5>
                    <p>
                      Link expired. Please follow the most recent link sent to
                      your email or reset your password again for a new link.
                    </p>
                  </div>
                ) : isDataEmpty ? (
                  'Please wait...'
                ) : (
                  <div className="forgot_pwd_panel">
                    <h5 className="heading_h5">Reset your password</h5>
                    <p>You can reset your password here</p>
                    <form onSubmit={this.onBtnClick} noValidate>
                      <div
                        style={{ marginBottom: '2rem' }}
                        className={`input-field ${
                          errorObj.password && errorObj.password.length > 100
                            ? 'password_field'
                            : ''
                        } ${inputClass.password}`}
                      >
                        <MDBInput
                          label="Reset Password"
                          name="password"
                          onChange={this.onChange}
                          type={showPassword ? 'text' : 'password'}
                          required
                          value={password}
                          onBlur={this.onBlur}
                        />
                        <div
                          className="p-0 password-icon"
                          onClick={(e) => {
                            this.handleClickShowPassword(e, 'showPassword');
                          }}
                          onMouseDown={(e) => e.preventDefault()}
                          role="presentation"
                          data-repcard-test="pass-icon"
                        >
                          <Fa far icon={showPassword ? 'eye' : 'eye-slash'} />
                        </div>
                        {errorObj.password ? (
                          <span className="error-message">
                            {errorObj.password}
                          </span>
                        ) : (
                          ''
                        )}
                      </div>
                      <div className={`input-field ${inputClass.confirmpass}`}>
                        <MDBInput
                          label="Confirm Password"
                          name="confirmpass"
                          onChange={this.onChange}
                          type={showPassword1 ? 'text' : 'password'}
                          required
                          value={confirmpass}
                          onBlur={this.onBlur}
                          onContextMenu={(e) => {
                            e.preventDefault();
                          }}
                          onPaste={(e) => {
                            e.preventDefault();
                          }}
                        />
                        <div
                          className="p-0 password-icon"
                          onClick={(e) => {
                            this.handleClickShowPassword(e, 'showPassword1');
                          }}
                          onMouseDown={(e) => e.preventDefault()}
                          role="presentation"
                          data-repcard-test="pass-icon1"
                        >
                          <Fa far icon={showPassword1 ? 'eye' : 'eye-slash'} />
                        </div>
                        {errorObj.confirmpass ? (
                          <span className="error-message">
                            {errorObj.confirmpass}
                          </span>
                        ) : (
                          ''
                        )}
                      </div>
                      <div className="fwd-btn-panel my-4">
                        <button
                          type="submit"
                          className="fill-orange-btn"
                          disabled={isBtnDisable}
                        >
                          {isAPICalled ? (
                            <span className="spinner-border spinner-border-sm" />
                          ) : (
                            ''
                          )}
                          Reset
                        </button>
                        {apiErrorMessage ? (
                          <p className="error-message1">{apiErrorMessage}</p>
                        ) : (
                          ''
                        )}
                      </div>
                    </form>
                  </div>
                )}
              </MDBCol>
            </MDBRow>
          </MDBCol>
        </MDBRow>
      </MDBContainer>
    );
  }
}

export default ResetPassword;
