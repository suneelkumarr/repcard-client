/**
 *
 * Description. Forgot Password page
 *
 * @link   URL
 * @file   Rep/Provider can send the forgot password link from this page by
           providing email id.
 * @since  1.0.0
 */
import React, { Component } from 'react';
import { MDBContainer, MDBCol, MDBRow, MDBInput } from 'mdbreact';
import { axiosApi } from '../../apis/axiosApiCall';
import validateObj from '../../validations/repprofile/repfront.js';
import app from '../../helpers/appGlobal';

class ForgotPassword extends Component {
  constructor(props) {
    super(props);
    this.state = {
      email: '',
      inputClass: {},
      errorObj: {},
      isPasswordReset: app.passwordReset,
    };
  }

  componentDidMount() {
    // To check if this comes from reset password page
    app.passwordReset = false;
  }

  /**
   * Summary. Validate Input
   *
   * Description. Sets the error to errorObj and className to inputClass object
   *              if any validation error found.
   *              errorObj is used for displaying the errors for particular input
   *              inputClas is used for Adding error classNames for particular input
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   name           Input element name
   * @param {string}   value          Input element value
   *
   * @return {String} Error if any else null
   */
  validateInput(name, value) {
    if (validateObj[name]) {
      let error = '';
      let className = 'error-border';
      error = validateObj[name](value);
      if (!error) {
        className = '';
      }

      this.setState((prevState) => ({
        errorObj: {
          ...prevState.errorObj,
          [name]: error,
        },
        inputClass: {
          ...prevState.inputClass,
          [name]: className,
        },
      }));

      return error;
    }
    return '';
  }

  /**
   * Summary. Set input values
   *
   * Description. Update All the input values to state
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   name           name of the input
   * @param {string}   value          value of the input
   *
   */
  setValue = (name, value) => {
    this.setState({
      [name]: value,
    });
  };

  /**
   * Summary. OnChange event
   *
   * Description. Input Change method for all input
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   e           Input element event object
   *
   */
  onChange = (e) => {
    const { name, value } = e.target;
    this.setValue(name, value);
  };

  /**
   * Summary. OnBlur event
   *
   * Description. Blur method for all input
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   e           Input element event object
   *
   */
  onBlur = (e) => {
    const { name, value } = e.target;
    this.validateInput(name, value);
  };

  /**
   * Summary. Form validation
   *
   * Description. Validate form on submit click
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @return {boolean} false if not valid else true
   */
  validate() {
    const { email } = this.state;
    let isValid = true;

    const error = this.validateInput('email', email);
    if (error) {
      isValid = false;
    }

    return isValid;
  }

  /**
   * Summary. Forgot password API call
   *
   * Description. Call forgot password API
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Object}    e      event object
   */
  onForgotPassword = (e) => {
    e.preventDefault();
    const isValid = this.validate();
    if (isValid) {
      const { email } = this.state;
      const reqObj = {
        email,
      };
      this.setState({
        isAPICalled: true,
        apiErrorMessage: '',
      });
      axiosApi(`/resetpwd/createTokenForMail`, 'POST', reqObj, (res) => {
        this.setState({
          isAPICalled: false,
        });
        if (res.error) {
          this.setState({
            apiErrorMessage: res.message,
          });
        } else {
          this.setState({
            isEmailSent: true,
          });
        }
      });
    }
  };

  render() {
    const {
      inputClass,
      errorObj,
      email,
      isAPICalled,
      apiErrorMessage,
      isEmailSent,
      isPasswordReset,
    } = this.state;
    return (
      <MDBContainer>
        <MDBRow>
          <MDBCol lg="12" className="signup_wrap">
            <MDBRow className="d-flex justify-content-center">
              <MDBCol lg="5" className="mt-5">
                {isPasswordReset ? (
                  <div className="forgot_pwd_panel">
                    <h5 className="heading_h5">Reset your password</h5>
                    <p>Your Password has been updated.</p>
                  </div>
                ) : isEmailSent ? (
                  <div className="forgot_pwd_panel">
                    <h5 className="heading_h5">Email Sent</h5>
                    <p>
                      If an account was found with the email address {email},
                      password reset instructions will be provided to that
                      email.
                    </p>
                    <p>
                      Please click on the link in the email message to reset
                      your password.
                    </p>
                  </div>
                ) : (
                  <div className="forgot_pwd_panel">
                    <h5 className="heading_h5">Forgot your password?</h5>
                    <p>
                      Don’t worry! Resetting your password is easy. Just type in
                      the email you registered to REPCARDz
                    </p>
                    <form onSubmit={this.onForgotPassword} noValidate>
                      <div className={`input-field ${inputClass.email}`}>
                        <MDBInput
                          type="email"
                          value={email}
                          onBlur={this.onBlur}
                          name="email"
                          onChange={this.onChange}
                          label="Enter your Email address"
                        />
                        {errorObj.email ? (
                          <span className="error-message">
                            {errorObj.email}
                          </span>
                        ) : (
                          ''
                        )}
                      </div>
                      <div className="fwd-btn-panel my-4">
                        <button
                          type="submit"
                          className="fill-orange-btn"
                          disabled={isAPICalled}
                        >
                          {isAPICalled ? (
                            <span className="spinner-border spinner-border-sm" />
                          ) : (
                            ''
                          )}
                          Send
                        </button>
                        {apiErrorMessage ? (
                          <p className="error-message1">{apiErrorMessage}</p>
                        ) : (
                          ''
                        )}
                      </div>
                    </form>
                  </div>
                )}
              </MDBCol>
            </MDBRow>
          </MDBCol>
        </MDBRow>
      </MDBContainer>
    );
  }
}

export default ForgotPassword;
