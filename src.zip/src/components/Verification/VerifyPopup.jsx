/**
 *
 * Description. OTP verify Modal Popup
 *
 * @link   URL
 * @file   Opens the OTP verification in modal popup. After OTP is verified
           then it closes the modal and set isOtpVerified flag to true in
           localstorage
 * @since  1.0.0
 */
import React, { Component } from 'react';
import { MDBModal } from 'mdbreact';
import app from '../../helpers/appGlobal';
import OTPVerify from './OTPVerify.jsx';
import { updateToLocalStorage } from '../../utils/editUpdateStorage';

class VerifyPopup extends Component {
  constructor(props) {
    super(props);
    this.state = {
      modal: false,
    };
  }

  componentDidMount() {}

  /**
   *  Toggle modal popup
   */
  toggle = () => {
    this.setState((prevState) => ({
      modal: !prevState.modal,
    }));
  };

  /**
   * Success function of OTP verified = update the localstorage with new flag
   */
  otpverify = () => {
    const { userType } = this.props;
    const newUserType = userType || app.user.userType;
    const status = 'verified';
    let updatedata;
    if (newUserType === 'rep') {
      updatedata = [{ name: 'isOtpVerified', value: true }];
    } else {
      updatedata = [{ name: 'status', value: status }];
    }
    updateToLocalStorage(updatedata);
    this.setState({
      modal: false,
    });

    const { otpVerify } = this.props;
    if (otpVerify) {
      otpVerify(status);
    }
  };

  render() {
    const { modal } = this.state;
    const { isDirectVerify, email, userType } = this.props;
    const newEmail = email || app.user.email;
    const newUserType = userType || app.user.userType;
    return (
      <>
        {isDirectVerify ? (
          ''
        ) : (
          <div className="textDiv">
            Check your email to get the 4-digit verfication code to confirm your
            identity and enter it{' '}
            <span
              className="linkTag"
              onClick={this.toggle}
              role="presentation"
              data-repcard-test="modal"
            >
              <b>here</b>
            </span>
            .
          </div>
        )}

        {/* Authontication Popup */}
        <div className="step_autontication_popup">
          {isDirectVerify ? (
            <>
              <div className="heading_h5">Two-Factor Authentication</div>
              <OTPVerify
                onOTPverify={this.otpverify}
                email={newEmail}
                userType={newUserType}
              />
            </>
          ) : (
            <MDBModal
              md="10"
              className="text-center"
              isOpen={modal}
              toggle={this.toggle}
            >
              <div className="heading_h5 mt-5 pt-3">
                Two-Factor Authentication
              </div>

              <div
                role="presentation"
                onClick={this.toggle}
                className="close_auth_popup"
              >
                X close
              </div>

              <OTPVerify
                onOTPverify={this.otpverify}
                email={newEmail}
                userType={newUserType}
              />
            </MDBModal>
          )}
        </div>
      </>
    );
  }
}

export default VerifyPopup;
