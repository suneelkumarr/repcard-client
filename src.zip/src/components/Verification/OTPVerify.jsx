/**
 *
 * Description. OTP verification
 *
 * @link   URL
 * @file   Enter 4 Digit OTP details or Send New OTP code
 * @since  1.0.0
 */
import React, { Component } from 'react';
import { MDBModalBody } from 'mdbreact';
import NumberFormat from 'react-number-format';
import { axiosApi } from '../../apis/axiosApiCall';

import './OTP.scss';

class OTPVerify extends Component {
  constructor(props) {
    super(props);
    this.state = {
      digit1: '',
      digit2: '',
      digit3: '',
      digit4: '',
    };
  }

  componentDidMount() {
    this.moveFocus(1);
  }

  /**
   *  Move focus to next input element
   */
  moveFocus = (id) => {
    setTimeout(() => {
      const elem = this[`inputElem${id}`];
      if (elem) {
        elem.focus();
      }
    }, 0); // This timeout is required because of library issue
  };

  /**
   * Summary. Input phone number change event
   *
   * Description. update phone number value to state
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   values         number object contains formatted value
   * @param {string}   name           name of the input
   *
   */
  onDateChange = (values, name) => {
    const newVal = values.formattedValue;
    this.setState(
      {
        [name]: values.formattedValue,
      },
      () => {
        if (newVal) {
          if (name === 'digit1') {
            this.moveFocus(2);
          } else if (name === 'digit2') {
            this.moveFocus(3);
          } else if (name === 'digit3') {
            this.moveFocus(4);
          }
        }
      }
    );
  };

  /**
   * Summary. OTP verify API
   *
   * Description. Send 4 digit verification code for otp verification
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  onSubmitClick = () => {
    const { digit1, digit2, digit3, digit4 } = this.state;
    const { email, userType } = this.props;
    if (digit1 && digit2 && digit3 && digit4) {
      const otp = `${digit1}${digit2}${digit3}${digit4}`;
      const reqObj = {
        otp: parseInt(otp, 10),
        email,
        userType,
      };
      this.setState({
        isAPICalled: true,
        apiErrorMessage: '',
      });
      axiosApi(`/confirm`, 'POST', reqObj, (res) => {
        this.setState({
          isAPICalled: false,
        });
        if (res.error) {
          this.setState({
            apiErrorMessage: res.message,
          });
        } else {
          const { onOTPverify } = this.props;
          onOTPverify();
        }
      });
    }
  };

  /**
   * Summary. Resend OTP API
   *
   * Description. Resend 4 digit verification code using below API
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  onResendApi = () => {
    const { email, userType } = this.props;
    this.setState({
      isResendApi: true,
    });
    const reqObj = {
      email,
      userType,
    };
    axiosApi(`/resendOtp`, 'POST', reqObj, (res) => {
      this.setState({
        isResendApi: false,
      });
      if (res.error) {
        alert(res.message);
      } else {
        alert('Code sent Successfully');
      }
    });
  };

  render() {
    const {
      digit1,
      digit2,
      digit3,
      digit4,
      isAPICalled,
      isResendApi,
      apiErrorMessage,
    } = this.state;
    const isBtnDisable = !(digit1 && digit2 && digit3 && digit4) || isAPICalled;
    return (
      <>
        <MDBModalBody className="text-center">
          Please enter the verification code we sent to your email:
          <div className="otp_input_field clearfix">
            <NumberFormat
              format="#"
              placeholder=""
              mask={['X']}
              type="tel"
              value={digit1}
              onValueChange={(values) => {
                this.onDateChange(values, 'digit1');
              }}
              className="Otp_number"
              name="digit1"
              getInputRef={(el) => {
                this.inputElem1 = el;
              }}
            />
            <NumberFormat
              format="#"
              placeholder=""
              mask={['X']}
              type="tel"
              value={digit2}
              onValueChange={(values) => {
                this.onDateChange(values, 'digit2');
              }}
              className="Otp_number"
              name="digit2"
              getInputRef={(el) => {
                this.inputElem2 = el;
              }}
            />
            <NumberFormat
              format="#"
              placeholder=""
              mask={['X']}
              type="tel"
              value={digit3}
              onValueChange={(values) => {
                this.onDateChange(values, 'digit3');
              }}
              className="Otp_number"
              name="digit3"
              getInputRef={(el) => {
                this.inputElem3 = el;
              }}
            />
            <NumberFormat
              format="#"
              placeholder=""
              mask={['X']}
              type="tel"
              value={digit4}
              onValueChange={(values) => {
                this.onDateChange(values, 'digit4');
              }}
              className="Otp_number"
              name="digit4"
              getInputRef={(el) => {
                this.inputElem4 = el;
              }}
            />
          </div>
          <div className="otp-btn-panel mt-3">
            <button
              type="button"
              className="fill-orange-btn"
              disabled={isBtnDisable}
              onClick={this.onSubmitClick}
              data-repcard-test="submit"
            >
              {isAPICalled ? (
                <span className="spinner-border spinner-border-sm" />
              ) : (
                ''
              )}
              Submit
            </button>
            {apiErrorMessage ? (
              <p className="error-message1">{apiErrorMessage}</p>
            ) : (
              ''
            )}
          </div>
          <button
            type="button"
            className="send_new_txt"
            disabled={isResendApi}
            onClick={this.onResendApi}
            data-repcard-test="resend"
          >
            {isResendApi ? (
              <span className="spinner-border spinner-border-sm" />
            ) : (
              ''
            )}
            Send new code
          </button>
        </MDBModalBody>
      </>
    );
  }
}

export default OTPVerify;
