/**
 *
 * Description. Main Page for OTP verify
 *
 * @link   URL
 * @file   It checks and calls the verfied API and display the information accordingly
           If user is not verified then verification popup appears
 * @since  1.0.0
 */
import React, { Component } from 'react';
import { Redirect } from 'react-router-dom';
import { MDBContainer, MDBCol, MDBRow } from 'mdbreact';
import { decrypt } from '../../config/encrypt-decrypt';
import { axiosApi } from '../../apis/axiosApiCall';
import app from '../../helpers/appGlobal';
import VerifyPopup from './VerifyPopup.jsx';
import { removeOnLogout } from '../../utils/editUpdateStorage';

class Verify extends Component {
  constructor(props) {
    super(props);
    this.state = {
      dataObj: {},
      isOtpVerified: false,
    };
  }

  /**
   * Summary. Status check API
   *
   * Description. Check if OTP is already verified or not using this API
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  isVerified = (dataObj) => {
    const { userType, userId } = dataObj;
    const { setVerify } = this.props;
    axiosApi(`/getStatus/${userId}?userType=${userType}`, 'GET', '', (res) => {
      let isVerified = false;
      if (res.data) {
        if (userType === 'rep') {
          isVerified = res.data.isOtpVerified;
        } else {
          isVerified = res.data.status === 'verified';
        }
      }
      if (isVerified) {
        this.setState(
          {
            isVerified: true,
          },
          () => {
            setVerify(true);
          }
        );
      } else {
        this.setState(
          {
            dataObj,
            isVerified: false,
          },
          () => {
            setVerify(false);
          }
        );
      }
    });
  };

  /**
   * Summary. decrypt data from URL
   *
   * Description. retrive all the user related info from URL.
                  Redirected to 404 page if any error found
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  decryptData() {
    const { match } = this.props;
    const str = match.params.token;
    if (str) {
      let dataObj = decrypt(str, app.config.AES_ENCRYPTION_KEY);
      if (dataObj) {
        dataObj = JSON.parse(dataObj);
        if (dataObj.email && dataObj.userType && dataObj.userId) {
          this.isVerified(dataObj);
        } else {
          window.location.href = '/404';
        }
      } else {
        window.location.href = '/404';
      }
    } else {
      window.location.href = '/404';
    }
  }

  componentDidMount() {
    this.decryptData();
  }

  /**
   * Success function of OTP verified = set the flag to true
   */
  otpVerify = () => {
    this.setState({
      isOtpVerified: true,
    });
  };

  /**
   *  Redirected to login page after removing localstorage session data
   */
  login = () => {
    removeOnLogout(true);
    this.setState({
      redirectToReferrer: '/Login',
    });
  };

  render() {
    const {
      dataObj,
      isVerified,
      isOtpVerified,
      redirectToReferrer,
    } = this.state;

    if (redirectToReferrer) {
      const from = { pathname: redirectToReferrer };
      return <Redirect to={from} />;
    }

    let isDataEmpty = false;
    if (!(dataObj.userType && dataObj.email)) {
      isDataEmpty = true;
    }

    return (
      <MDBContainer>
        <MDBRow>
          <MDBCol lg="12" className="signup_wrap">
            <MDBRow className="d-flex justify-content-center">
              <MDBCol lg="5" className="my-4">
                {isVerified ? (
                  <div className="forgot_pwd_panel">
                    <p>Your Email is already verified</p>
                  </div>
                ) : isDataEmpty ? (
                  'Please wait...'
                ) : isOtpVerified ? (
                  <div className="forgot_pwd_panel">
                    <p>Thank you for verifying your account.</p>
                    <p className="pb-4">
                      You can now login and continue completing your profile.
                    </p>
                    <span
                      className="login_btn1"
                      role="presentation"
                      onClick={this.login}
                    >
                      Log In
                    </span>
                  </div>
                ) : (
                  <div className="forgot_pwd_panel">
                    <VerifyPopup
                      isDirectVerify
                      userType={dataObj.userType}
                      email={dataObj.email}
                      otpVerify={this.otpVerify}
                    />
                  </div>
                )}
              </MDBCol>
            </MDBRow>
          </MDBCol>
        </MDBRow>
      </MDBContainer>
    );
  }
}

export default Verify;
