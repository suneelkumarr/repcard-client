/**
 *
 * Description. Rep's Dashboard page
 *
 * @link   URL
 * @file   When user is in basic plan, Ask user to verify otp, add productcategory
           and add hospital information.
           If user already verified above three details and premium plan is
           created then switch to premium dashboard page.
 * @since  1.0.0
 */
import React, { Component, lazy, Suspense } from 'react';
import { Redirect, Link } from 'react-router-dom';
import { MDBContainer, MDBCol, MDBRow, MDBIcon } from 'mdbreact';
import RepcardPopover from '../Popover/popover.jsx';
import ProfileHeading from '../Common/ProfileHeading';
import SetupSteps from './SetupSteps';
import app from '../../helpers/appGlobal';
import { getBasicPlan } from '../../utils/getPlanInfo';
import {
  getTextForPage,
  getTextValueByTextId,
} from '../../utils/getPageText.js';

import './RepDashboard.scss';
import StepNumbers from '../SignUp/StepNumbers.jsx';
import MyAccount from '../MyProducts/MyProducts.jsx';
import InvitePopup from '../Common/InvitePopup';
import Share from '../Common/Share';

const Loading = () => <div>Loading...</div>;
// const UpgradeBox = lazy(() => import('../Upgrade/UpgradeBox.jsx'));
const PremiumDashboard = lazy(() => import('./PremiumDashboard.jsx'));

class RepDashboard extends Component {
  constructor(props) {
    super(props);
    this.state = {
      pageTextPrefix: 'rep_dashboard',
      pageText: {},
      redirectToReferrer: '',
      hasAddedProducts: false,
      isViewFullProfile: props.fullProfile === 'yes',
      invitePopupOpen: false,
      shareOpen: false,
    };
  }

  async componentDidMount() {
    const { pageTextPrefix } = this.state;
    const pageText = await getTextForPage(pageTextPrefix);
    this.setState({ pageText });
  }

  componentDidUpdate = (prevProps) => {
    const { fullProfile } = this.props;
    if (prevProps.fullProfile !== fullProfile) {
      if (fullProfile) this.viewFullProfile(true);
      else this.viewFullProfile(false);
    }
  };

  handleAddedProducts = (val) => {
    this.setState({ hasAddedProducts: val });
  };

  /**
   * Summary. ProductCategory flag
   *
   * Description. Set/Reset productcategory edit
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {boolean}    flag      productcategory flag for edit data
   *
   */
  setProductCategoryFlag = (flag) => {
    if (flag) {
      app.productLineEdit = true;
      this.goToPage('/Dashboard');
    }
  };

  /**
   * Summary. ProductCategory Add/update callback
   *
   * Description. Success callback of productcategories update
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Array}    res      productcategory response
   *
   */
  onEditSuccess = (res) => {
    this.setProductCategoryFlag(false);
    const { setProductCategoryRes } = this.props;

    if (setProductCategoryRes) {
      setProductCategoryRes(res);
    }
  };

  /**
   * Remove productcategory edit html
   */
  onCancel = () => {
    this.setProductCategoryFlag(false);
  };

  /**
   * Summary. Page Redirect
   *
   * Description. Redirect to specific page
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}    pagename      Redirect page name
   *
   */
  goToPage = (pagename) => {
    this.setState({
      redirectToReferrer: pagename,
    });
  };

  /**
   * Open Rep's Full profile
   */
  viewFullProfile = (val) => {
    const { setShowClaimBtn } = this.props;
    if (setShowClaimBtn) {
      setShowClaimBtn(val);
    }
    this.setState({
      isViewFullProfile: val,
    });
  };

  onClick = (e) => {
    e.preventDefault();
  };

  onPremiumClick = () => {
    // Open plan page directly on click of Learn more
    app.isUpgrade = true;
  };

  toggleInvitePopupOpen = () => {
    this.setState((prevState) => ({
      invitePopupOpen: !prevState.invitePopupOpen,
    }));
  };

  toggleShareOpen = () => {
    this.setState((prevState) => ({
      shareOpen: !prevState.shareOpen,
    }));
  };

  render() {
    const {
      profileRes,
      productcategoryRes,
      flagData,
      otpVerify,
      planDetails,
      fullProfile,
      profileId,
      profileRep,
      productcategoryRep,
    } = this.props;
    const {
      redirectToReferrer,
      isViewFullProfile,
      pageText,
      hasAddedProducts,
      invitePopupOpen,
      shareOpen,
    } = this.state;

    if (redirectToReferrer) {
      const from = { pathname: redirectToReferrer };
      return <Redirect push to={from} />;
    }

    const {
      isAccountSelected,
      isOtpVerified,
      isProductcategorySelected,
    } = flagData;

    const isFullComplete =
      isOtpVerified && isProductcategorySelected && isAccountSelected;

    const { photoUrl, phone, customerServicePhone, profileurl } = profileRes;
    const isPhoneNumbers = phone && customerServicePhone;

    const isBasicPlan = getBasicPlan(planDetails);

    return (
      <MDBContainer className="preLogin">
        <Suspense fallback={<Loading />}>
          <MDBRow>
            <MDBCol lg="12">
              <div className="mt-4">
                <div className="rep_left_panel">
                  {isViewFullProfile && isBasicPlan && (
                    <h3 className="d-md-inline-block d-xl-inline-block pb-4">
                      My Full Profile
                    </h3>
                  )}
                  <ProfileHeading
                    headingtxt={profileId ? 'REPCARD' : 'My REPCARD'}
                  />
                  <div className="mt-2">
                    {!profileId && (
                      <div className="d-flex justify-content-between">
                        <Link to="/Dashboard">
                          <MDBIcon icon="aa" className="edit_icon" /> Edit
                          Profile
                        </Link>
                        <span
                          className="txt_orange cursor"
                          onClick={this.toggleShareOpen}
                        >
                          <MDBIcon icon="aa" className="edit_icon bg-warning" />{' '}
                          Share
                        </span>
                      </div>
                    )}

                    {profileId ? (
                      <RepcardPopover
                        profileRes={profileRep}
                        productcategoryRes={productcategoryRep}
                        initialView="profile"
                        id={profileId}
                        isHtml
                      />
                    ) : (
                      <RepcardPopover
                        profileRes={profileRes}
                        productcategoryRes={productcategoryRes}
                        initialView="profile"
                        id={app.user.id}
                        isHtml
                        setProductCategoryFlag={this.setProductCategoryFlag}
                      />
                    )}
                  </div>
                  {isViewFullProfile ? (
                    ''
                  ) : (
                    <p>
                      <Link to="/FullProfile">
                        <span
                          className="linkTag"
                          role="presentation"
                          data-repcard-test="Dashboard"
                        >
                          View
                        </span>{' '}
                      </Link>
                      your full profile as it will appear to Providers
                    </p>
                  )}
                </div>
                {isViewFullProfile ? (
                  <div className="rep_right_panel">
                    {!isBasicPlan ? (
                      <div className="d-flex align-items-center">
                        <MyAccount
                          dashboard
                          fullProfile={fullProfile}
                          profileId={profileId}
                        />
                      </div>
                    ) : (
                      <div className="rep_right_panel">
                        <div className="d-flex align-items-center">
                          {fullProfile ? (
                            <Link
                              className="mb-2 ml-4 cursor-pointer"
                              to="/RepDashboard"
                            >
                              <MDBIcon icon="arrow-left" />
                            </Link>
                          ) : null}
                          <ProfileHeading headingtxt="My Full Profile" />
                        </div>
                        <div className="rep_right_sec">
                          <p>
                            {getTextValueByTextId(
                              pageText,
                              'rep_dashboard_add_products'
                            )}
                          </p>
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="rep_right_panel">
                    <div className="row">
                      <div className="col">
                        <ProfileHeading headingtxt="Welcome to REPCARDz&#8482;" />
                        {!isBasicPlan ? (
                          <div className="heading-h5 congratulation_panel">
                            <p className="cong_txt">
                              Congratulations. Your 90-Day Complimentary Premium
                              Access Pass is Now Active.
                            </p>
                            <p className="cong_txt">
                              Complete Steps 1 through 6 to Complete Your
                              Premium Profile.
                            </p>
                          </div>
                        ) : null}
                      </div>
                      <div className="col-4">
                        <div className="d-flex flex-column float-right text-center font-md">
                          <StepNumbers
                            stepnumber={
                              (isOtpVerified ? 1 : 0) +
                              (isProductcategorySelected ? 1 : 0) +
                              (isAccountSelected ? 1 : 0) +
                              (photoUrl ? 1 : 0) +
                              (isPhoneNumbers ? 1 : 0) +
                              (hasAddedProducts ? 1 : 0) +
                              1
                            }
                            totalSteps={6}
                          />
                          <div
                            className="claim_btn mt-1"
                            onClick={this.toggleInvitePopupOpen}
                          >
                            Give a Month, Get a Month
                          </div>
                        </div>
                      </div>
                    </div>

                    {isFullComplete && !isBasicPlan ? (
                      <PremiumDashboard
                        handleAddedProducts={(val) =>
                          this.handleAddedProducts(val)
                        }
                        profileRes={profileRes}
                        viewFullProfile={() => this.viewFullProfile(true)}
                        onClick={(pageName, type) => {
                          app.ProfileEdit = true;
                          if (type === 'photo') {
                            app.photoEdit = true;
                          }
                          this.goToPage(pageName);
                        }}
                      />
                    ) : (
                      <>
                        <div className="rep_right_sec">
                          {isFullComplete ? (
                            <div className="congratulation_panel">
                              <p className="cong_txt">Congratulations!</p>
                              <p>
                                {getTextValueByTextId(
                                  pageText,
                                  'rep_dashboard_full_complete'
                                )}
                              </p>
                              <div className="mt-5 pt-5">
                                Helpful Tips:
                                <ul>
                                  <li>
                                    * Want to add a profile picture, phone
                                    numbers, and products you rep?{' '}
                                    <Link
                                      onClick={this.onPremiumClick}
                                      to="/Dashboard"
                                    >
                                      Upgrade to Premium
                                    </Link>
                                  </li>
                                  <li>
                                    * To update your contact information, click
                                    your name in the top right corner and select{' '}
                                    <Link to="/Dashboard">Account Profile</Link>{' '}
                                    to make edits.
                                  </li>
                                  <li>
                                    * To update the accounts you cover, go to
                                    the{' '}
                                    <Link to="/RepMyAccount">My Accounts</Link>{' '}
                                    page.
                                  </li>
                                  <li>
                                    * Got a new product you’re launching? Go to
                                    the{' '}
                                    <Link to="/" onClick={this.onClick}>
                                      My Products
                                      <div className="info-tooltip bottom">
                                        Coming soon!
                                      </div>
                                    </Link>{' '}
                                    page to add it to your profile so your
                                    customers know to call you.
                                  </li>
                                </ul>
                              </div>
                            </div>
                          ) : (
                            <>
                              <p>
                                {getTextValueByTextId(
                                  pageText,
                                  'rep_dashboard_setup_list'
                                )}
                              </p>
                              <SetupSteps
                                shouldShowOtp
                                isOtpVerified={isOtpVerified}
                                otpVerify={otpVerify}
                                shouldShowProductCategory
                                isProductcategorySelected={
                                  isProductcategorySelected
                                }
                                setProductCategoryFlag={
                                  this.setProductCategoryFlag
                                }
                                shouldShowAccount
                                isAccountSelected={isAccountSelected}
                                goToPage={this.goToPage}
                              />
                            </>
                          )}
                        </div>
                        {/* {isBasicPlan ? <UpgradeBox /> : ''} */}
                      </>
                    )}
                  </div>
                )}
              </div>
              <InvitePopup
                open={invitePopupOpen}
                toggle={this.toggleInvitePopupOpen}
              />

              <Share
                open={shareOpen}
                profileurl={profileurl}
                toggle={this.toggleShareOpen}
              />
            </MDBCol>
          </MDBRow>
        </Suspense>
      </MDBContainer>
    );
  }
}

export default RepDashboard;
