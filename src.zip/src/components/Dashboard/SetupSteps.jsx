import React, { Component, lazy } from 'react';

const VerifyPopup = lazy(() => import('../Verification/VerifyPopup.jsx'));

class SetupSteps extends Component {
  otpStep = () => {
    const { isOtpVerified, otpVerify } = this.props;

    return {
      isComplete: isOtpVerified,
      heading: () => (
        <>
          Verify your <b>Identity</b>
        </>
      ),
      incomplete: () => <VerifyPopup otpVerify={otpVerify} />,
    };
  };

  productCategoryStep = () => {
    const { isProductcategorySelected, setProductCategoryFlag } = this.props;

    return {
      isComplete: isProductcategorySelected,
      heading: () => (
        <>
          Select the <b>Product Lines</b> you Rep
        </>
      ),
      onClick: () => setProductCategoryFlag(true),
      incomplete: () => (
        <div className="textDiv">
          Help Providers find you by identifying the Product Categories and
          Product Lines you Rep: go to <b>My Profile</b> (top right) or{' '}
          <span
            className="linkTag"
            onClick={() => {
              setProductCategoryFlag(true);
            }}
            role="presentation"
            data-repcard-test="edit"
          >
            <b>click here</b>
          </span>
        </div>
      ),
    };
  };

  accountStep = () => {
    const { isAccountSelected, goToPage } = this.props;

    return {
      isComplete: isAccountSelected,
      heading: () => (
        <>
          Select the <b>Accounts</b> you Rep
        </>
      ),
      onClick: () => goToPage('/RepMyAccount'),
      incomplete: () => (
        <div className="textDiv">
          Identify the accounts you represent so providers can easily find you:
          go to <b>My Accounts</b> (top nav) or{' '}
          <span
            className="linkTag"
            onClick={() => {
              goToPage('/RepMyAccount');
            }}
            role="presentation"
            data-repcard-test="myAccount"
          >
            <b>click here</b>
          </span>
        </div>
      ),
    };
  };

  render() {
    const {
      shouldShowOtp,
      shouldShowProductCategory,
      shouldShowAccount,
    } = this.props;

    const steps = [];

    if (shouldShowOtp) {
      steps.push(this.otpStep());
    }
    if (shouldShowProductCategory) {
      steps.push(this.productCategoryStep());
    }
    if (shouldShowAccount) {
      steps.push(this.accountStep());
    }

    return (
      <>
        {steps.map((step, index) => {
          const { isComplete, onClick, heading, incomplete } = step;
          const key = `setup-step-${index}`;

          return (
            <div
              className={`mt-4 rep-verify ${onClick ? 'setup-step-click' : ''}`}
              key={key}
              onClick={onClick || null}
            >
              <div className="circle">
                {isComplete ? (
                  <img alt="Done" src="/images/icons/Check1.svg" />
                ) : (
                  index + 1
                )}
              </div>
              <div className="d-inline-block code">
                <p className="dashboard_heading">{heading()}</p>
                {isComplete ? (
                  <div className="textDiv">Done</div>
                ) : (
                  incomplete()
                )}
              </div>
            </div>
          );
        })}
      </>
    );
  }
}

export default SetupSteps;
