/**
 *
 * Description. Rep's Premium Dashboard page (Premium plan)
 *
 * @link   URL
 * @file   When user is in premium plan, Ask user to enter profile picture, phone number
           and my products details
 * @since  1.0.0
 */
import React, { Component } from 'react';
import { axiosApi } from '../../apis/axiosApiCall';
import app from '../../helpers/appGlobal';

class PremiumDashboard extends Component {
  constructor(props) {
    super(props);
    this.state = {
      hasAddedProducts: false,
    };
  }

  getRepProducts = () => {
    const urlname = `/repProfile/getProductsForRep?repId=${app.user.id}`;
    const reqBody = {
      filters: { company: [] },
    };

    axiosApi(urlname, 'POST', reqBody, (res) => {
      app.user.products = [];
      if (res.data) {
        app.user.products = res.data;
      }
      if (res && res.data && res.data.length > 0) {
        this.setState({
          hasAddedProducts: true,
        });
      }
    });
  };

  componentDidMount() {
    this.getRepProducts();
  }

  componentDidUpdate(prevProps, prevState) {
    const { hasAddedProducts } = this.state;
    const { handleAddedProducts } = this.props;
    if (prevState.hasAddedProducts !== hasAddedProducts) {
      handleAddedProducts(true);
    }
  }

  render() {
    const { profileRes, onClick, viewFullProfile } = this.props;
    const { photoUrl, phone, customerServicePhone } = profileRes;
    const { hasAddedProducts } = this.state;
    const isPhoneNumbers = phone && customerServicePhone;

    if (photoUrl && isPhoneNumbers && hasAddedProducts) viewFullProfile();

    return (
      <div className="rep_right_sec">
        <p>
          As a <b>Premium</b> member, you can now add the following to your
          REPCARD:
        </p>
        <div
          className="rep-verify setup-step-click"
          onClick={() => onClick('/Dashboard', 'photo')}
        >
          <div className="circle">
            {photoUrl ? <img alt="Done" src="/images/icons/Check1.svg" /> : 4}
          </div>
          <div className="d-inline-block code">
            <div className="textDiv">
              <span className="dashboard_heading-1">
                Add a <b>Profile Picture</b>
              </span>
              <br />
              {photoUrl ? (
                'Done'
              ) : (
                <>
                  click{' '}
                  <span
                    className="linkTag"
                    onClick={() => {
                      onClick('/Dashboard', 'photo');
                    }}
                    role="presentation"
                    data-repcard-test="picedit"
                  >
                    <b>here</b>
                  </span>
                </>
              )}
            </div>
          </div>
        </div>
        <div
          className="mt-4 rep-verify setup-step-click"
          onClick={() => onClick('/Dashboard')}
        >
          <div className="circle">
            {isPhoneNumbers ? (
              <img alt="Done" src="/images/icons/Check1.svg" />
            ) : (
              5
            )}
          </div>
          <div className="d-inline-block code">
            <div className="textDiv">
              <span className="dashboard_heading-1">
                Add your <b>Phone Numbers</b>
              </span>
              <br />
              {isPhoneNumbers ? (
                'Done'
              ) : (
                <>
                  click{' '}
                  <span
                    className="linkTag"
                    onClick={() => {
                      onClick('/Dashboard');
                    }}
                    role="presentation"
                    data-repcard-test="phoneedit"
                  >
                    <b>here</b>
                  </span>
                </>
              )}
            </div>
          </div>
        </div>
        <div
          className="mt-4 rep-verify setup-step-click"
          onClick={() => onClick('/RepMyProducts')}
        >
          <div className="circle">
            {hasAddedProducts ? (
              <img alt="Done" src="/images/icons/Check1.svg" />
            ) : (
              6
            )}
          </div>
          <div className="d-inline-block code">
            <div className="textDiv">
              <span className="dashboard_heading-1">
                Add <b>My Products</b>
              </span>
              <br />
              {hasAddedProducts ? (
                'Done'
              ) : (
                <>
                  click{' '}
                  <span
                    className="linkTag i_tooltip_hover"
                    onClick={() => {
                      onClick('/RepMyProducts');
                    }}
                    role="presentation"
                    data-repcard-test="myproducts"
                  >
                    <b>here</b>
                  </span>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default PremiumDashboard;
