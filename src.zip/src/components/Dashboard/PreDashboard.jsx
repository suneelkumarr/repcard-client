/**
 *
 * Description. Rep's PreDashboard page
 *
 * @link   URL
 * @file   Calls Rep verifed API, My Account API, payment API and display information accordingly
           Loads master productcategory data so it can use further pages
 * @since  1.0.0
 */
import React, { Component, lazy, Suspense } from 'react';
import isEmpty from 'lodash/isEmpty';
import Header from '../NavHeader/RepHeader/Header';
import Footer from '../Footer/Footer';
import { getMasterProductCategoryData } from '../../utils/masterProductCategoryData';
import app from '../../helpers/appGlobal';
import { getProductCategoryApi } from '../../utils/getProductCategoryApi';
import { getSubscriptionApi } from '../../utils/stripeApis';
import { axiosApi } from '../../apis/axiosApiCall';

const Loading = () => <div>Loading...</div>;
const RepDashboard = lazy(() => import('./RepDashboard.jsx'));
const ProviderHeader = lazy(() => import('../NavHeader/ProviderHeader/Header'));

class PreDashboard extends Component {
  constructor(props) {
    super(props);
    this.state = {
      profileRes: {},
      productcategoryRes: [],
      flagData: {},
      isCustomerAPI: true,
      profileId: 0,
      profileurlProfileId: 0,
      profileurl: '',
      profileRep: {},
      productcategoryRep: [],
      showClaimBtn: false,
    };
  }

  componentDidMount() {
    const {
      id,
      status,
      isAccountSelected,
      isOtpVerified,
      isProductcategorySelected,
      userType,
    } = app.user;

    // Check All the Rep's status flag
    if (isAccountSelected && isOtpVerified && isProductcategorySelected) {
      this.setState({
        flagData: {
          isAccountSelected: true,
          isOtpVerified: true,
          isProductcategorySelected: true,
        },
      });
      if (status !== 'verified') {
        this.isRepVerifiedApi(id);
      }
    } else {
      this.isRepVerifiedApi(id); // Call status API
    }
    this.getMasterProductCategoryData(); // Load master productcategory data
    this.getProductCategoryApi(id); // call Rep's productcategory API
    this.getMyAccountApi(id, userType);
  }

  componentDidUpdate() {
    const { profileId, profileurl } = this.props;
    const { profileId: spid, profileurl: sprofileurl, profileRep } = this.state;

    if (!profileId && !isEmpty(profileRep) && !profileurl) {
      this.resetProfile();
    }

    if (profileurl) {
      if (profileurl !== sprofileurl) {
        this.getProfileIdProfileurl(profileurl);
      }
    }

    if (profileId && !profileurl) {
      if (spid !== profileId) {
        this.setProfileId(profileId);
      }
    }
  }

  setProfileId = (profileId) => {
    this.setState({ profileId }, () => {
      this.getProductCategoryApi(profileId); // call Rep's productcategory API
      this.getMyAccountApi(profileId, 'rep');
    });
  };

  getProfileIdProfileurl = (profileurl) => {
    this.setState({
      isAPICalled2: true,
    });
    this.setState({ profileurl }, () => {
      axiosApi(`/repProfile/getProfileId/${profileurl}`, 'GET', '', (res) => {
        this.setState({
          isAPICalled2: false,
        });
        if (res.error) {
          this.setState({
            repNotFound: true,
          });
        } else if (res.data) {
          // this.setProfileId(res.data.id);
          this.setState({ profileurlProfileId: res.data.id }, () => {
            this.getProductCategoryApi(res.data.id); // call Rep's productcategory API
            this.getMyAccountApi(res.data.id, 'rep');
          });
        }
      });
    });
  };

  resetProfile = () => {
    this.setState({
      profileId: 0,
      profileurl: '',
      profileurlProfileId: 0,
      profileRep: {},
      productcategoryRep: [],
    });
  };

  /**
   * Summary. Status Verification API
   *
   * Description. To retrive Rep's verification status like OTP, My Account and
   *              ProductCategories flag
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   id       Rep's User Id
   *
   */
  isRepVerifiedApi = (id) => {
    const { userType } = app.user;
    axiosApi(`/getStatus/${id}?userType=${userType}`, 'GET', '', (res) => {
      if (res.error) {
        console.log(res.message);
      } else if (res.data) {
        this.setState({
          flagData: res.data,
        });
      }
    });
  };

  /**
   * Summary. Payment API
   *
   * Description. To retrive all the payment related info (plan details)
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   subscriptionId        Plan subscription id
   *
   */
  getPaymentInfoAPI = (subscriptionId) => {
    if (subscriptionId) {
      this.setState({
        isCustomerAPI: true,
      });
      getSubscriptionApi(subscriptionId, (plan) => {
        if (plan) {
          this.setState({
            planDetails: plan,
          });
        }
        this.setState({
          isCustomerAPI: false,
        });
      });
    } else {
      this.setState({
        isCustomerAPI: false,
      });
    }
  };

  /**
   * Summary. Get My Account Information
   *
   * Description. Call API for Rep to get my account data
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   id        user id
   * @param {string}   userType        user type
   */
  getMyAccountApi = (id, userType) => {
    const { profileId, profileurlProfileId } = this.state;
    this.setState({
      isAPICalled1: true,
    });
    let urlname = `/providerProfile/getMyAccountProfile/${id}`;
    if (userType === 'rep') {
      urlname = `/repProfile/getMyAccountRepProfile/${id}`;
    }
    axiosApi(urlname, 'GET', '', (res) => {
      if (!isEmpty(res.data)) {
        if (profileId || profileurlProfileId) {
          this.setState({
            profileRep: res.data,
          });
        } else {
          this.setState({
            profileRes: res.data,
          });
          this.getPaymentInfoAPI(res.data.subscriptionId);
        }
      } else {
        this.getPaymentInfoAPI('');
      }
      this.setState({
        isAPICalled1: false,
      });
    });
  };

  /**
   * Summary. Rep's ProductCategory
   *
   * Description. To Retrive all the Rep's productcategories information
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   id        Rep's user id
   */
  getProductCategoryApi = (id) => {
    const { profileId, profileurlProfileId } = this.state;
    this.setState({
      isAPICalled: true,
    });
    getProductCategoryApi(id, (results) => {
      if (profileId || profileurlProfileId) {
        this.setState({
          isAPICalled: false,
          productcategoryRep: results,
        });
      } else {
        this.setState({
          isAPICalled: false,
          productcategoryRes: results,
        });
      }
    });
  };

  /**
   * Summary. Load Master ProductCategory Data
   *
   * Description. Call API for Master data of productcategory
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  getMasterProductCategoryData = () => {
    this.setState({
      masterAPICalled: true,
    });
    getMasterProductCategoryData((flag) => {
      if (flag) {
        this.setState({
          masterAPICalled: false,
        });
      }
    });
  };

  // Success function of OTP verified
  otpVerify = () => {
    const { id, userType } = app.user;
    this.setState(
      (prevState) => ({
        flagData: {
          ...prevState.flagData,
          isOtpVerified: true,
        },
      }),
      this.getMyAccountApi(id, userType)
    );
  };

  // Success function of the productcategory API. Set the productcategory flag to true And
  // set the response of productcategories
  setProductCategoryRes = (res) => {
    this.setState((prevState) => ({
      productcategoryRes: res,
      flagData: {
        ...prevState.flagData,
        isProductcategorySelected: true,
      },
    }));
  };

  setShowClaimBtn = (val) => {
    this.setState({
      showClaimBtn: val,
    });
  };

  render() {
    const {
      masterAPICalled,
      isAPICalled,
      isAPICalled1,
      isAPICalled2,
      isCustomerAPI,
      profileRes,
      productcategoryRes,
      flagData,
      planDetails,
      profileId,
      profileRep,
      productcategoryRep,
      showClaimBtn,
      profileurl,
      repNotFound,
      profileurlProfileId,
    } = this.state;

    const { fullProfile } = this.props;

    return (
      <>
        {app.user.userType === 'rep' ? (
          <Header
            profileRes={profileRes}
            isHome={!fullProfile}
            isAPINotNeeded
            {...this.props}
            showClaimBtn={showClaimBtn || fullProfile}
          />
        ) : (
          <ProviderHeader profileRes={profileRes} isAPINotNeeded />
        )}
        {profileurl && repNotFound ? (
          <div className="add_acc_btnpanel">
            <p>Rep&apos;s profile not found!</p>
          </div>
        ) : (
          <>
            {masterAPICalled ||
            isCustomerAPI ||
            isAPICalled ||
            isAPICalled1 ||
            isAPICalled2 ||
            isEmpty(flagData) ? (
              'Please wait...'
            ) : (
              <Suspense fallback={<Loading />}>
                <RepDashboard
                  flagData={flagData}
                  profileId={profileId || profileurlProfileId}
                  profileRep={profileRep}
                  productcategoryRep={productcategoryRep}
                  profileRes={profileRes}
                  productcategoryRes={productcategoryRes}
                  otpVerify={this.otpVerify}
                  setProductCategoryRes={this.setProductCategoryRes}
                  planDetails={planDetails}
                  fullProfile={fullProfile}
                  setShowClaimBtn={this.setShowClaimBtn}
                />
              </Suspense>
            )}
          </>
        )}
        <Footer />
      </>
    );
  }
}

export default PreDashboard;
