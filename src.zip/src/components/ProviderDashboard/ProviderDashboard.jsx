/**
 *
 * Description. Provider Dashboard Verification page
 *
 * @link   URL
 * @file   Verify OTP details for provider before Rep search
 * @since  1.0.0
 */
import React, { Component } from 'react';
import VerifyPopup from '../Verification/VerifyPopup.jsx';
import ProfileHeading from '../Common/ProfileHeading';

import '../Dashboard/RepDashboard.scss';

class ProviderDashboard extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  componentDidMount() {}

  render() {
    const { otpVerify } = this.props;
    return (
      <div className="rep_right_panel">
        <ProfileHeading headingtxt="Welcome to REPCARDz&#8482;" />
        <div className="rep_right_sec">
          <p>
            Before you can begin searching for Reps, you need to do the
            following.
          </p>
          <div className="rep-verify">
            <div className="circle">1</div>
            <div className="d-inline-block code">
              <p className="dashboard_heading">
                Verify your <b>Identity</b>
              </p>
              <VerifyPopup otpVerify={otpVerify} />
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default ProviderDashboard;
