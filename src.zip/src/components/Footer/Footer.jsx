/**
 *
 * Description. Website Common footer
 *
 * @link   URL
 * @file   Returns the Footer part which consist of many links
 * @since  1.0.0
 */
import React from 'react';
import Zendesk from 'react-zendesk';

import { MDBFooter, MDBContainer } from 'mdbreact';
import {
  TERMS_CONDITION_URL,
  PRIVACY_POLICY_URL,
  ABOUT_US_URL,
  CONTACT_US_URL,
} from '../../config';
import './footer.scss';

const ZENDESK_KEY = '40d6bbc9-b7d7-45cd-b0ce-7c60a311ffec';

const zendeskSettings = {
  color: {
    theme: '#F27E44',
  },
  launcher: {
    chatLabel: {
      'en-US': 'Need Help',
    },
  },
  contactForm: {
    fields: [{ id: 'description' }],
  },
};

/**
 *  Website Footer html
 */
const Footer = () => {
  return (
    <MDBFooter>
      <MDBContainer fluid className="footer">
        <ul className="footer-menu-list pt-3">
          <li>
            <a href={ABOUT_US_URL} rel="noopener noreferrer" target="_blank">
              About Us
            </a>
          </li>
          <li>
            <a href={CONTACT_US_URL} rel="noopener noreferrer" target="_blank">
              Contact Us
            </a>
          </li>
          <li>
            <a
              href={PRIVACY_POLICY_URL}
              rel="noopener noreferrer"
              target="_blank"
            >
              Privacy Policy
            </a>
          </li>
          <li>
            <a
              href={TERMS_CONDITION_URL}
              rel="noopener noreferrer"
              target="_blank"
            >
              Terms of Use
            </a>
          </li>
        </ul>
        <div className="footer-copyright text-center">
          &copy; 2019-{new Date().getFullYear()}{' '}
          <span className="mx-2">REPCARDz&#8482; LLC</span> All Rights Reserved.
        </div>
        <Zendesk zendeskKey={ZENDESK_KEY} {...zendeskSettings} />;
      </MDBContainer>
    </MDBFooter>
  );
};

export default Footer;
