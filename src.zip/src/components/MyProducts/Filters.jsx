/* eslint-disable react/no-unused-state */
/**
 *
 * Description. Filters section for products
 *
 * @link   URL
 * @file   Filter the hospital list by choosing the city filter
 * @since  1.0.0
 */
import React, { Component } from 'react';
import { MDBInput } from 'mdbreact';
import uniq from 'lodash/uniq';
import { axiosApi } from '../../apis/axiosApiCall';
import app from '../../helpers/appGlobal';
import getCancelToken from '../../apis/getCancelToken';
import FilterButtons from '../Search/FilterButtons';
import ClickAwayListner from '../Common/ClickAwayListner';

class Filters extends Component {
  constructor(props) {
    super(props);
    const { companyArr } = this.props;
    this.state = {
      companyList: [],
      companyArr: companyArr || [],
      isAPICalled: false,
    };
  }

  componentDidMount() {
    this.callCompanyApi();
  }

  componentWillUnmount() {}

  /**
   * Summary. Get company list information API
   *
   * Description. To retrive all the companies with name filter or productcategory filter
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  callCompanyApi = () => {
    const source1 = getCancelToken();
    this.setState({
      isAPICalled: true,
      source1,
    });
    const { limit, offset } = this.state;
    const { text } = this.props;

    const urlname = `/repProfile/getCompaniesFromRepProducts?repId=${app.user.id}&companyId=${app.user.companyId}`;

    axiosApi(
      `${urlname}&type=all&text=${text}`,
      'GET',
      '',
      (res) => {
        if (res.error) {
          console.log(res);
        } else {
          const resObj = res.data;
          if (offset === 0) {
            this.setState({
              companyList: resObj,
            });
          } else {
            this.setState((prevState) => ({
              companyList: [...prevState.companyList, ...resObj],
            }));
          }
          if (res.data.isMore) {
            this.setState({
              offset: offset + limit,
            });
          } else {
            this.setState({
              offset: 0,
            });
          }
        }
        this.setState({
          isAPICalled: false,
          apiOnScroll: false,
          source1: '',
        });
      },
      source1.token
    );
  };

  /**
   * Summary. Checkbox change event
   *
   * Description. Set/Reset city to companyArray
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Object}   e               event object
   * @param {Object}   item            City object
   *
   */
  onCheckboxChange = (e, item) => {
    const { checked } = e.target;
    const { name } = item;
    if (checked) {
      this.setState((prevState) => ({
        companyArr: uniq([...prevState.companyArr, name]),
      }));
    } else {
      this.setState((prevState) => ({
        companyArr: prevState.companyArr.filter((c) => c !== name),
      }));
    }
  };

  /**
   *  Apply filter btn click event
   */
  onFilterClick = () => {
    const { companyArr } = this.state;
    if (companyArr.length) {
      const { onFilterClick } = this.props;
      onFilterClick(companyArr);
    }
  };

  /**
   *  Reset btn click event
   */
  onResetClick = () => {
    const { onResetClick } = this.props;
    onResetClick();
  };

  onClickAway = () => {
    const { onClickAway } = this.props;
    if (onClickAway) onClickAway();
    else this.onResetClick();
  };

  render() {
    const { companyArr, companyList } = this.state;

    return (
      <ClickAwayListner handleClickAway={() => this.onClickAway()}>
        <div className="filter-list-wrap" style={{ right: '-55px' }}>
          <div className="product-wrap height_add">
            <div className="wid-50">
              <ul className="filter-list">
                <li role="presentation" className="selected">
                  Company
                </li>
              </ul>
              <div className="filter-btn">
                <FilterButtons
                  onFilterClick={this.onFilterClick}
                  onResetClick={this.onResetClick}
                  isBtnEnable={!!companyArr.length}
                />
              </div>
            </div>
            <div className="wid-50 selected">
              <ul className="filter-list">
                {companyList.map((c) => {
                  const { name, id } = c;
                  return (
                    <li key={id}>
                      <MDBInput
                        label={name}
                        filled
                        type="checkbox"
                        checked={companyArr.indexOf(name) !== -1}
                        id={`filtermain${id}`}
                        onChange={(e) => {
                          this.onCheckboxChange(e, c);
                        }}
                      />
                    </li>
                  );
                })}
              </ul>
            </div>
          </div>
        </div>
      </ClickAwayListner>
    );
  }
}

export default Filters;
