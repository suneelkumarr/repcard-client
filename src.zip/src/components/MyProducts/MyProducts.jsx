/**
 *
 * Description. Main component for rep products
 *
 * @link   URL
 * @file   Used for add, edit and remove products with filters.
           Redirect to specific components for above functionality
 * @since  1.0.0
 */
import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import {
  MDBContainer,
  MDBCol,
  MDBRow,
  MDBModal,
  MDBInput,
  MDBIcon,
} from 'mdbreact';
import ProfileHeading from '../Common/ProfileHeading';
import AddProduct from './AddProduct.jsx';
import { axiosApi } from '../../apis/axiosApiCall';
import app from '../../helpers/appGlobal';
import scrollCheck from '../../utils/scrollCheck';
import EditProducts from './EditProducts';
import RowFilters from './RowFilters';
import isEnterKeyPressed from '../../utils/checkEnterKeyPressed';
import RecentSearch from '../Search/RecentSearch.jsx';

import './myproducts.scss';

class MyAccount extends Component {
  constructor(props) {
    super(props);
    this.state = {
      limit: 1000,
      totalCount: 0,
      offset: 0,
      apiOnScroll: false,
      modal: false,
      filterOpen: false,
      sortOpen: false,
      isAPICalled: true,
      isRemove: false,
      tagCompanyArr: [],
      keyname: 'cities',
      text: '',
      sortBy: 'brand_name',
      sortList: [
        {
          key: 'brand_name',
          value: 'Product Name',
        },
        {
          key: 'device_description',
          value: 'Product Description',
        },
        {
          key: 'version_model_number',
          value: 'Product Number',
        },
      ],
    };
  }

  /**
   * Summary. Toggle remove
   *
   * Description. Toggle isRemove flag (edit)
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  onRemoveToggle = () => {
    this.setState((prevState) => ({
      isRemove: !prevState.isRemove,
    }));
  };

  /**
   *  Cancel click event form edit view
   */
  onCancelClick = () => {
    this.onRemoveToggle();
  };

  /**
   *  Remove All the filters
   */
  onRemoveClick = () => {
    this.removeAllFilter();
  };

  /**
   * Summary. Apply filter click
   *
   * Description. Set data to state and get new hospital list as per the filter
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Array}       tagCompanyArr             company Array list
   */
  onFilterClick = (tagCompanyArr) => {
    this.setState(
      {
        offset: 0,
        apiResponse: [],
        tagCompanyArr,
        filterOpen: false,
        sortOpen: false,
      },
      () => {
        this.getRepProductsList();
      }
    );
  };

  /**
   * Summary. Remove tags click
   *
   * Description. Remove the city from tagCompanyArr and reload the hospital list
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}       city             id/name of the city
   */
  removeTags = (name) => {
    this.setState(
      (prevState) => ({
        offset: 0,
        apiResponse: [],
        tagCompanyArr: prevState.tagCompanyArr.filter((c) => c.name !== name),
        filterOpen: false,
        sortOpen: false,
      }),
      () => {
        this.getRepProductsList();
      }
    );
  };

  /**
   *  Remove all the filters on reset click and refresh the hospital list
   */
  onResetClick = () => {
    this.setState(
      {
        offset: 0,
        tagCompanyArr: [],
        apiResponse: [],
        filterOpen: false,
        sortOpen: false,
      },
      () => {
        this.getRepProductsList();
      }
    );
  };

  /**
   *  Remove all the applied filters whenever required
   */
  removeAllFilter = () => {
    this.setState(
      {
        offset: 0,
        tagCompanyArr: [],
        apiResponse: [],
        filterOpen: false,
        sortOpen: false,
        modal: false,
        isRemove: false,
      },
      () => {
        this.getRepProductsList();
      }
    );
  };

  /**
   *  Toggle filter view
   */
  filterSelectOpen = () => {
    this.setState((prevState) => ({
      filterOpen: !prevState.filterOpen,
      sortOpen: false,
    }));
  };

  /**
   *  Open/close modal popup for adding new hospital
   */
  toggle = () => {
    this.setState((prevState) => ({
      modal: !prevState.modal,
    }));
  };

  getRepProductsList = (isFlag) => {
    this.setState({
      isAPICalled: true,
    });
    const { limit, offset, tagCompanyArr, text, sortBy } = this.state;
    const { updateProducts, profileId } = this.props;

    const reqObj = {
      filters: {
        company: tagCompanyArr.map((c) => c.id),
        text,
      },
      sortBy,
    };
    let { id } = app.user;
    if (profileId) id = profileId;
    const urlname = `/repProfile/getProductsForRep?repId=${id}`;
    axiosApi(urlname, 'POST', reqObj, (res) => {
      // app.user.products = [];
      if (res.error) {
        console.log(res.message);
      } else if (res.data) {
        const resObj = res.data;
        if (offset === 0) {
          this.setState({
            apiResponse: resObj,
          });
        } else {
          this.setState((prevState) => ({
            apiResponse: [...prevState.apiResponse, ...resObj],
          }));
        }

        if (!profileId) {
          app.user.products = res.data;
          updateProducts();
        }

        // fix this later!!!
        this.setState({
          totalCount: res.data.length,
        });

        if (isFlag) {
          this.setState({
            isDoneBtnShow: !resObj.length,
          });
        }

        if (res.data.isMore) {
          this.setState({
            offset: offset + limit,
          });
        } else {
          this.setState({
            offset: 0,
          });
        }
      }
      this.setState({
        isAPICalled: false,
        apiOnScroll: false,
      });
    });
  };

  /**
   * Summary. On scroll event
   *
   * Description. Load more hospital list on scroll
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param  {Object}   e      event object
   */
  onScroll = (e) => {
    const { offset, apiOnScroll } = this.state;
    if (scrollCheck(e, offset, apiOnScroll)) {
      this.setState({
        apiOnScroll: true,
      });
      this.getRepProductsList();
    }
  };

  /**
   *  Remove All the applied filters after Adding new hospitals
   */
  onAddSuccess = () => {
    this.removeAllFilter();
  };

  componentDidMount() {
    this.getRepProductsList(true);
  }

  /**
   * Summary. Search input
   *
   * Description. Input Change method for search input
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   e           Input element event object
   * @param {function} cb          Callback function
   *
   */
  onChange = (e, cb) => {
    const { value } = e.target;
    this.setState(
      {
        text: value,
        filterOpen: false,
        sortOpen: false,
      },
      () => {
        if (cb) {
          cb();
        }
      }
    );
  };

  /**
   * Summary. On keyDown event
   *
   * Description. Check if enter key pressed and call search api if true
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param  {Object}   e      event object
   */
  onKeyDown = (e) => {
    if (isEnterKeyPressed(e)) {
      this.onSearch();
    }
  };

  /**
   * Summary. Search API call
   *
   * Description. Call the search API as per the text
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  onSearch = () => {
    const { text } = this.state;
    if (text.length < 3) {
      alert('minimum 3 characters');
    } else {
      this.setState(
        {
          offset: 0,
          isAPICalled: false,
          apiOnScroll: false,
          filterOpen: false,
          sortOpen: false,
        },
        () => {
          this.setState({
            apiOnScroll: true,
          });
          this.getRepProductsList();
        }
      );
    }
  };

  /**
   *  Toggle sort view
   */
  sortSelectOpen = () => {
    this.setState((prevState) => ({
      filterOpen: false,
      sortOpen: !prevState.sortOpen,
    }));
  };

  setSortBy(sortBy) {
    this.setState(
      {
        sortBy,
        sortOpen: false,
      },
      () => {
        this.getRepProductsList();
      }
    );
  }

  clearSearch() {
    this.setState(
      {
        text: '',
      },
      () => this.getRepProductsList()
    );
  }

  /**
   * Summary. Recent search click
   *
   * Description. Call the search API as per the recent search click details
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   str           text input of search
   * @param {string}   type          can be name, company
   */
  onRecentSearchClick = (str) => {
    this.setState(
      {
        text: str,
      },
      () => {
        this.getRepProductsList();
      }
    );
  };

  render() {
    const {
      modal,
      filterOpen,
      sortOpen,
      apiResponse,
      isAPICalled,
      isRemove,
      tagCompanyArr,
      keyname,
      filterCities,
      isDoneBtnShow,
      totalCount,
      text,
      sortBy,
      sortList,
    } = this.state;
    const { dashboard, fullProfile, profileId } = this.props;

    return (
      <MDBContainer className="preLogin position-relative">
        <MDBRow>
          <MDBCol
            lg="12"
            className={`${dashboard ? 'dashboard_product_list' : 'my-5'}`}
          >
            {isAPICalled && !dashboard ? (
              <div className="clearfix">
                <ProfileHeading
                  headingtxt={profileId ? 'Products' : 'My Products'}
                />
                <div>Please wait...</div>
              </div>
            ) : (
              <>
                <div className="clearfix">
                  <div className="d-flex justify-content-between">
                    <div className="d-flex align-items-center">
                      {fullProfile && !profileId ? (
                        <Link
                          className="mb-2 mr-4 cursor-pointer"
                          to="/RepDashboard"
                        >
                          <MDBIcon icon="arrow-left" />
                        </Link>
                      ) : null}
                      <ProfileHeading
                        headingtxt={profileId ? 'Products' : 'My Products'}
                      />
                    </div>
                  </div>

                  {(apiResponse && apiResponse.length && !isRemove) ||
                  dashboard ? (
                    <div className="float-right">
                      {dashboard && (
                        <RecentSearch
                          onRecentSearchClick={this.onRecentSearchClick}
                          dashboardProductList
                        />
                      )}
                      <div className="filter-section">
                        <div className="filter-panel">
                          <div
                            className={`filter-list-name ${
                              filterOpen ? 'active' : ''
                            }`}
                            onClick={this.filterSelectOpen}
                            role="presentation"
                            data-repcard-test="filter"
                          >
                            <span className="shape mr-1" />
                            Filter
                          </div>
                          {filterOpen ? (
                            <RowFilters
                              onFilterClick={this.onFilterClick}
                              onResetClick={this.onResetClick}
                              hospitalArr={filterCities}
                              tagCompanyArr={tagCompanyArr}
                              keyname={keyname}
                            />
                          ) : (
                            ''
                          )}
                        </div>
                      </div>
                      {dashboard && (
                        <div className="filter-section">
                          <div className="filter-panel">
                            <div
                              className={`filter-list-name ${
                                sortOpen ? 'active' : ''
                              }`}
                              onClick={this.sortSelectOpen}
                              role="presentation"
                              data-repcard-test="sort"
                            >
                              <span className="sortby mr-1" />
                              Sort
                            </div>
                            {sortOpen ? (
                              <div
                                className="filter-list-wrap sort-product-list"
                                style={{ right: '0px' }}
                              >
                                <div className="product-wrap height_add">
                                  <div className="wid-50">
                                    <ul className="filter-list">
                                      {sortList.map((s, i) => {
                                        return (
                                          <li
                                            key={i.toString()}
                                            role="presentation"
                                            className={
                                              sortBy === s.key ? 'selected' : ''
                                            }
                                            onClick={() =>
                                              this.setSortBy(s.key)
                                            }
                                            data-repcard-test={s.key}
                                          >
                                            {s.value}
                                          </li>
                                        );
                                      })}
                                    </ul>
                                  </div>
                                </div>
                              </div>
                            ) : (
                              ''
                            )}
                          </div>
                        </div>
                      )}
                      {!dashboard && (
                        <div
                          className="add_remove_sec"
                          role="presentation"
                          onClick={this.onRemoveToggle}
                          data-repcard-test="remove"
                        >
                          <i className="remove_icon" /> Remove
                        </div>
                      )}
                      {!dashboard && (
                        <div
                          className="add_remove_sec ml-4"
                          role="presentation"
                          onClick={this.toggle}
                          data-repcard-test="modal"
                        >
                          <i className="add_account_icon" /> Add Product
                        </div>
                      )}
                    </div>
                  ) : (
                    ''
                  )}
                </div>
                {dashboard && (
                  <div className="search-box">
                    <MDBInput
                      type="search"
                      className="search_field"
                      placeholder="Search by product name or manufacturer"
                      onChange={this.onChange}
                      name="textSearch"
                      value={text}
                      autoComplete="off"
                      onKeyDown={this.onKeyDown}
                      icon="search"
                      outline
                      size="lg"
                    />
                    <MDBIcon
                      className="clear-icon"
                      icon="times"
                      onClick={() => this.clearSearch()}
                    />
                    <hr />
                  </div>
                )}
                {apiResponse && apiResponse.length ? (
                  <>
                    {isAPICalled && dashboard ? (
                      <div className="clearfix">
                        <div>Please wait...</div>
                      </div>
                    ) : (
                      <EditProducts
                        productArr={apiResponse}
                        isEdit={isRemove}
                        onCancelClick={this.onCancelClick}
                        onRemove={this.onRemoveClick}
                        tagCompanyArr={tagCompanyArr}
                        removeTags={this.removeTags}
                        onScroll={this.onScroll}
                        keyname={keyname}
                        isDoneBtnShow={isDoneBtnShow}
                        totalCount={totalCount}
                        dashboard={dashboard}
                      />
                    )}
                  </>
                ) : dashboard && isAPICalled ? (
                  <div className="clearfix">
                    <div>Please wait...</div>
                  </div>
                ) : (
                  <div className="add_acc_btnpanel">
                    {!dashboard && (
                      <button
                        type="button"
                        className="add_acc_btn"
                        onClick={this.toggle}
                        data-repcard-test="modal"
                      >
                        <span className="add_icon" /> Add Products
                      </button>
                    )}
                    <p>
                      {dashboard
                        ? 'No products are found related to searched query.'
                        : 'No Products added yet'}
                      <span className="add_acc_txt">
                        {dashboard
                          ? 'Please try an alternative search or go to the My Products tab to add the product(s) searched.'
                          : 'You must have at least one product associated with your profile. Add one now before proceeding.'}
                      </span>
                    </p>
                  </div>
                )}
                <MDBModal
                  className="add_product_popup"
                  contentClassName="add-min-height"
                  isOpen={modal}
                  toggle={this.toggle}
                >
                  <div
                    role="presentation"
                    onClick={this.toggle}
                    className="close_auth_popup close"
                  >
                    X close
                  </div>
                  {modal ? <AddProduct onAddSuccess={this.onAddSuccess} /> : ''}
                </MDBModal>
              </>
            )}
          </MDBCol>
        </MDBRow>
      </MDBContainer>
    );
  }
}

export default MyAccount;
