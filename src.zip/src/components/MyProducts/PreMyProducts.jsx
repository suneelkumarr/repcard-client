/**
 *
 * Description. PreMyProducts Page
 *
 * @link   URL
 * @file   Redirect to my products page with header and footer
 * @since  1.0.0
 */
import React, { Component } from 'react';
import Header from '../NavHeader/RepHeader/Header';
import Footer from '../Footer/Footer';
import MyAccount from './MyProducts.jsx';
import app from '../../helpers/appGlobal';

class PreMyProducts extends Component {
  constructor(props) {
    super(props);
    this.state = {
      products: [],
    };
    this.updateProducts = this.updateProducts.bind(this);
  }

  componentDidMount() {}

  updateProducts() {
    this.setState({
      products: app.user.products,
    });
  }

  render() {
    const { products } = this.state;
    return (
      <>
        <Header
          isMyProducts
          {...this.props}
          products={products}
          updateProducts={this.updateProducts}
        />
        <MyAccount updateProducts={this.updateProducts} />
        <Footer />
      </>
    );
  }
}

export default PreMyProducts;
