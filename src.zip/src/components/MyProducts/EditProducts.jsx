/**
 *
 * Description. Edit products
 *
 * @link   URL
 * @file   Remove Already added products (By select all or by selecting multiple checkboxes)
           This is also used to display the Already added products.
 * @since  1.0.0
 */
import React, { Component } from 'react';
import { Redirect } from 'react-router-dom';
import { MDBInput, MDBModal, MDBModalBody } from 'mdbreact';
import { axiosApi } from '../../apis/axiosApiCall';
import app from '../../helpers/appGlobal';
import ProfileHeading from '../Common/ProfileHeading';

class EditProducts extends Component {
  constructor(props) {
    super(props);
    this.state = {
      modal: false,
      deleteIdArr: [],
      deletedProductList: [],
      isSelectAll: false,
      redirectToReferrer: '',
    };
  }

  componentDidMount() {}

  /**
   *  Minimum 1 hospital needs to be there
   */
  isValidate = () => {
    const { totalCount } = this.props;
    const { deleteIdArr } = this.state;
    if (deleteIdArr.length < totalCount) {
      return true;
    }
    return false;
  };

  /**
   * Summary. Modal Open
   *
   * Description. Toggle Modal for removing hospitals
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  toggle = () => {
    const isValid = this.isValidate();
    if (isValid) {
      this.setState((prevState) => ({
        modal: !prevState.modal,
      }));
    } else {
      alert(
        'You must have at least one product associated with your profile to populate in search results. Please select "Other" if your product is not listed or "Not Applicable" if you provide a non-FDA-approved product or service.'
      );
    }
  };

  /**
   *  Set default react state parameters
   */
  setDefaultStates = () => {
    this.setState({
      deleteIdArr: [],
      deletedProductList: [],
      isSelectAll: false,
      modal: false,
    });
  };

  /**
   *  Cancel click event, Remove all the selected hospitals
   */
  onCancel = () => {
    const { onCancelClick } = this.props;
    this.setDefaultStates();
    onCancelClick();
  };

  /**
   * Summary. Remove hospital API
   *
   * Description. API call for removing hospital list
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  onRemoveClick = () => {
    const { deleteIdArr } = this.state;
    this.setState({
      isAPICalled: true,
    });
    const urlname = `/repProfile/removeRepProducts?repId=${app.user.id}`;
    const reqObj = {
      productIds: deleteIdArr,
    };

    axiosApi(urlname, 'POST', reqObj, (res) => {
      this.setState({
        isAPICalled: false,
      });
      if (res.error) {
        this.setState({
          apiErrorMessage: res.message,
        });
      } else {
        this.setDefaultStates();
        const { onRemove } = this.props;
        onRemove(deleteIdArr);
      }
    });
  };

  /**
   * Summary. Checkbox change event
   *
   * Description. Set/Reset deleted products to state
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Object}   e               event object
   * @param {string}   productId       id of the product
   * @param {Object}   product         product object for deleted product
   *
   */
  onChangeCheckbox = (e, productId, product) => {
    const { checked } = e.target;
    if (checked) {
      this.setState((prevState) => ({
        deleteIdArr: [...prevState.deleteIdArr, productId],
        deletedProductList: [...prevState.deletedProductList, product],
      }));
    } else {
      this.setState((prevState) => ({
        deleteIdArr: prevState.deleteIdArr.filter((p) => p !== productId),
        deletedProductList: prevState.deletedProductList.filter(
          (p) => p.id !== productId
        ),
        isSelectAll: false,
      }));
    }
  };

  /**
   * Summary. Select All checkbox
   *
   * Description. Set All the deleted products to state
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Object}   e               event object
   *
   */
  onSelectAll = (e) => {
    const { checked } = e.target;
    const { productArr } = this.props;
    let deleteIdArr = [];
    let deletedProductList = [];
    if (checked) {
      productArr.forEach((p) => {
        deleteIdArr = [...deleteIdArr, p.id];
        deletedProductList = [...deletedProductList, p];
      });
    }
    this.setState({
      isSelectAll: checked,
      deleteIdArr,
      deletedProductList,
    });
  };

  /**
   *  Redirect to REpDashboard Page
   */
  redirectToPage = () => {
    this.setState({
      redirectToReferrer: '/RepDashboard',
    });
  };

  render() {
    const {
      modal,
      deleteIdArr,
      isSelectAll,
      deletedProductList,
      isAPICalled,
      apiErrorMessage,
      redirectToReferrer,
    } = this.state;
    const {
      isEdit,
      productArr,
      tagCompanyArr,
      removeTags,
      onScroll,
      isDoneBtnShow,
      dashboard,
    } = this.props;

    if (redirectToReferrer) {
      const from = { pathname: redirectToReferrer };
      return <Redirect to={from} />;
    }

    return (
      <>
        <div
          className={`product_name_list edit_list ${
            dashboard ? 'dashboard_product_list' : ''
          }`}
        >
          {isEdit ? (
            ''
          ) : (
            <div className="tagPanel">
              {tagCompanyArr &&
                tagCompanyArr.map((c) => {
                  return (
                    <div className="tags" key={c.id}>
                      {c.name}
                      <span
                        className="close_tag"
                        role="presentation"
                        onClick={() => {
                          removeTags(c.name);
                        }}
                      />
                    </div>
                  );
                })}
            </div>
          )}
          <ul onScroll={onScroll}>
            <li>
              <div className="product_name selectall">
                {isEdit ? (
                  <MDBInput
                    label="Select All"
                    filled
                    type="checkbox"
                    id="checkboxSelectAll"
                    className="selectall"
                    checked={isSelectAll}
                    onChange={this.onSelectAll}
                  />
                ) : (
                  <>Product Name</>
                )}
              </div>
              <div className="product_company">
                {dashboard ? 'Product Description' : 'Product Company'}
              </div>
              <div className="product_number">Product Number</div>
            </li>
            {productArr.map((p) => {
              const {
                id,
                name,
                versionModelNumber,
                companyName,
                description,
              } = p;
              return (
                <li key={id}>
                  <div className="product_name">
                    {isEdit ? (
                      <MDBInput
                        label={name}
                        filled
                        type="checkbox"
                        id={`editCheck${id}`}
                        checked={deleteIdArr.indexOf(id) !== -1}
                        onChange={(e) => {
                          this.onChangeCheckbox(e, id, p);
                        }}
                      />
                    ) : (
                      <div>{name}</div>
                    )}
                  </div>
                  <div className="product_company">
                    {dashboard ? description : companyName}
                  </div>
                  <div className="product_number">{versionModelNumber}</div>
                </li>
              );
            })}
          </ul>
          {isEdit || !productArr.length ? (
            ''
          ) : isDoneBtnShow ? (
            <div className="text-left product_name_btn">
              <button
                type="button"
                className="fill-orange-btn mr-3"
                onClick={this.redirectToPage}
                data-repcard-test="done"
              >
                Done
              </button>
            </div>
          ) : (
            ''
          )}

          {isEdit ? (
            <div className="text-left product_name_btn">
              <button
                type="button"
                className="fill-orange-btn mr-3"
                onClick={this.toggle}
                disabled={!deleteIdArr.length}
                data-repcard-test="modal"
              >
                Remove
              </button>
              <button
                type="button"
                className="fill-orange-btn"
                onClick={this.onCancel}
                data-repcard-test="cancel"
              >
                Cancel
              </button>
            </div>
          ) : (
            ''
          )}
        </div>

        <MDBModal
          className="add_product_popup"
          centered
          isOpen={modal}
          toggle={this.toggle}
        >
          <MDBModalBody className="p-5">
            <div className="d-block">
              <ProfileHeading headingtxt="Remove Products" />
            </div>
            <div className="remove_txt mb-5">
              Are you sure you want to remove{' '}
              {deletedProductList.map((p, i) => {
                if (i === deletedProductList.length - 1) {
                  return <span key={p.id}>“{p.name}”</span>;
                }
                return (
                  <span key={p.id}>
                    <span>“{p.name}”</span>
                    {i === deletedProductList.length - 2 ? ' and ' : ', '}
                  </span>
                );
              })}{' '}
              ?
            </div>
            <div className="text-center mt-3">
              <button
                type="button"
                className="fill-orange-btn"
                onClick={this.onRemoveClick}
                disabled={isAPICalled}
                data-repcard-test="remove"
              >
                {isAPICalled ? (
                  <span className="spinner-border spinner-border-sm" />
                ) : (
                  ''
                )}
                Ok
              </button>
              {apiErrorMessage ? (
                <p className="error-message1">{apiErrorMessage}</p>
              ) : (
                ''
              )}
            </div>
          </MDBModalBody>
        </MDBModal>
      </>
    );
  }
}

export default EditProducts;
