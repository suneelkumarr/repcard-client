/**
 *
 * Description. Filter for Already added hospital section
 *
 * @link   URL
 * @file   Display list of states (whatever is available) and display cities
           accordingly by choosing state option. Apply or Reset filter by choosing
           cities. The list of hospitals get filtered accordingly
 * @since  1.0.0
 */
import React, { Component } from 'react';
import uniq from 'lodash/uniq';
import FilterButtons from '../Search/FilterButtons';
import { SearchFilterListCompany } from '../Search/SearchFilterList';
import { axiosApi } from '../../apis/axiosApiCall';
import app from '../../helpers/appGlobal';
import getCancelToken from '../../apis/getCancelToken';
import scrollCheck from '../../utils/scrollCheck';

class RowFilters extends Component {
  constructor(props) {
    super(props);
    this.state = {
      limit: 10,
      offset: 0,
      companyList: [],
      companyArr: (props.tagCompanyArr || []).map((c) => c.id),
      tagCompanyArr: props.tagCompanyArr || [],
      isAPICalled: false,
    };
  }

  componentDidMount() {
    this.callCompanyApi();
  }

  componentWillUnmount() {}

  /**
   * Summary. Get company list information API
   *
   * Description. To retrive all the companies with name filter or productcategory filter
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  callCompanyApi = () => {
    const source1 = getCancelToken();
    this.setState({
      isAPICalled: true,
      // source1,
    });
    const { limit, offset } = this.state;

    const urlname = `/repProfile/getCompaniesFromRepProducts?repId=${app.user.id}&companyId=${app.user.companyId}`;

    axiosApi(
      urlname,
      'GET',
      '',
      (res) => {
        if (res.error) {
          console.log(res);
        } else {
          const resObj = res.data;
          if (offset === 0) {
            this.setState({
              companyList: resObj,
            });
          } else {
            this.setState((prevState) => ({
              companyList: [...prevState.companyList, ...resObj],
            }));
          }
          if (res.data.isMore) {
            this.setState({
              offset: offset + limit,
            });
          } else {
            this.setState({
              offset: 0,
            });
          }
        }
        this.setState({
          isAPICalled: false,
          apiOnScroll: false,
          // source1: '',
        });
      },
      source1.token
    );
  };

  /**
   * Summary. On scroll event
   *
   * Description. Load more company list on scroll
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param  {Object}   e      event object
   */
  onScroll = (e) => {
    const { offset, apiOnScroll } = this.state;
    if (scrollCheck(e, offset, apiOnScroll)) {
      this.setState({
        apiOnScroll: true,
      });
      this.callCompanyApi();
    }
  };

  /**
   * Summary. company checkbox change event
   *
   * Description. Set/Reset company to companyArr
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Object}   e               event object
   * @param {Object}   item            company object
   *
   */
  companyCheckboxChange = (e, item) => {
    const { checked } = e.target;
    const { id } = item;
    if (checked) {
      this.setState((prevState) => ({
        companyArr: uniq([...prevState.companyArr, id]),
        tagCompanyArr: [...prevState.tagCompanyArr, item],
      }));
    } else {
      this.setState((prevState) => ({
        companyArr: prevState.companyArr.filter((v) => v !== id),
        tagCompanyArr: prevState.tagCompanyArr.filter((v) => v.id !== id),
      }));
    }
  };

  /**
   * Summary. Checkbox change event
   *
   * Description. Set/Reset city to tagCompanyArr list
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Object}       e               event object
   * @param {string}       id              City Id
   * @param {Object}       item            City object
   * @param {Object}       stateObj        State object for current city
   *
   */
  onCheckboxChange = (e, id, item, stateObj) => {
    const { checked } = e.target;
    if (checked) {
      const newItem = { ...item, state: stateObj.state };
      this.setState((prevState) => ({
        tagCompanyArr: [...prevState.tagCompanyArr, newItem],
      }));
    } else {
      this.setState((prevState) => ({
        tagCompanyArr: prevState.tagCompanyArr.filter((v) => v.city !== id),
      }));
    }
  };

  /**
   *  Apply filter btn click event
   */
  onFilterClick = () => {
    const { tagCompanyArr } = this.state;
    if (tagCompanyArr.length) {
      const { onFilterClick } = this.props;
      onFilterClick(tagCompanyArr);
    }
  };

  /**
   *  Reset btn click event
   */
  onResetClick = () => {
    const { onResetClick } = this.props;
    onResetClick();
  };

  render() {
    const { companyList, companyArr, isAPICalled } = this.state;

    return (
      <div className="filter-list-wrap" style={{ right: '-55px' }}>
        <div className="product-wrap height_add">
          <div className="wid-50">
            <ul className="filter-list">
              <li
                role="presentation"
                className="selected"
                data-repcard-test="company"
              >
                Company (<span>{companyArr.length}</span>)
              </li>
            </ul>
            <div className="filter-btn">
              <FilterButtons
                onFilterClick={this.onFilterClick}
                onResetClick={this.onResetClick}
                isBtnEnable={companyArr.length}
              />
            </div>
          </div>
          <div className="wid-50 selected">
            <SearchFilterListCompany
              onChange={this.companyCheckboxChange}
              companyList={companyList}
              onScroll={this.onScroll}
              companyArr={companyArr}
              isAPICalled={isAPICalled}
            />
          </div>
        </div>
      </div>
    );
  }
}

export default RowFilters;
