/**
 *
 * Description. Add product for rep
 *
 * @link   URL
 * @file   Seacrh hospitals from state dropdown and add it to the account.
           Also search hospitals using city filter.
 * @since  1.0.0
 */

import React, { Component } from 'react';
import { MDBModalBody, MDBInput } from 'mdbreact';
import { axiosApi } from '../../apis/axiosApiCall';
import app from '../../helpers/appGlobal';
import Filters from './Filters';
import ProfileHeading from '../Common/ProfileHeading';
import getCancelToken from '../../apis/getCancelToken';
import scrollCheck from '../../utils/scrollCheck';

class AddProduct extends Component {
  constructor(props) {
    super(props);
    this.state = {
      searchVal: '',
      productList: [],
      companyList: [],
      companyArr: [],
      selectedArr: [],
      offset: 0,
      limit: 100,
      apiOnScroll: false,
      source: '',
    };

    this.timeout = null;
  }

  /**
   * Summary. Select search parameter
   *
   * Description. Select state from dropdown
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Array}   val       select value
   *
   */
  searchVal = (val) => {
    this.setState(
      {
        searchVal: val.toString(),
        companyList: [],
        selectedArr: [],
        filterOpen: false,
      },
      () => {
        console.warn('this used to do something');
      }
    );
  };

  /**
   * Summary. filter tab
   *
   * Description. Toggle filter html
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  filterSelectOpen = () => {
    this.setState((prevState) => ({
      filterOpen: !prevState.filterOpen,
    }));
  };

  /**
   * Summary. Apply filter click
   *
   * Description. Set cities and hospital list
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  onFilterClick = (companyArr) => {
    const { companyList } = this.state;
    let newCompanyList = [];
    companyArr.forEach((companyName) => {
      const value = companyList.filter(
        (company) => company.name === companyName
      );
      newCompanyList = [...newCompanyList, ...value];
    });

    this.setState(
      {
        companyArr,
        filterOpen: false,
      },
      () => {
        this.getAllProductsList();
      }
    );
  };

  /**
   * Summary. Reset btn click
   *
   * Description. Remove All the filters and research
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  onResetClick = () => {
    const { searchVal } = this.state;
    this.searchVal([searchVal]);
    this.setState(
      {
        companyArr: [],
      },
      () => {
        this.getAllProductsList();
      }
    );
  };

  /**
   * Summary. Add button click
   *
   * Description. Toggle hospitals on Add button click
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   hospitalId      id of the hospital
   *
   */
  onAddClick = (productId) => {
    const { selectedArr } = this.state;
    const index = selectedArr.findIndex((p) => p === productId);
    if (index === -1) {
      this.setState((prevState) => ({
        selectedArr: [...prevState.selectedArr, productId],
      }));
    } else {
      this.setState((prevState) => ({
        selectedArr: prevState.selectedArr.filter((p) => p !== productId),
        isSelectAll: false,
      }));
    }
  };

  /**
   * Summary. Select All checkbox click
   *
   * Description. Add all the hospitals to the array
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Object}   e      event object
   *
   */
  onSelectAll = (e) => {
    const { checked } = e.target;
    const { productList } = this.state;
    let selectedArr = [];
    if (checked) {
      productList.forEach((p) => {
        selectedArr = [...selectedArr, p.id];
      });
    }
    this.setState({
      isSelectAll: checked,
      selectedArr,
    });
  };

  /**
   * Summary. Add hospitals API
   *
   * Description. Save hospital array list via calling an API
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  onSaveClick = () => {
    const { selectedArr } = this.state;
    this.setState({
      isAPICalled: true,
    });
    const urlname = `/repProfile/addRepProducts?repId=${app.user.id}`;
    const reqObj = {
      productIds: selectedArr,
    };

    axiosApi(urlname, 'POST', reqObj, (res) => {
      this.setState({
        isAPICalled: false,
      });
      if (res.error) {
        this.setState({
          apiErrorMessage: res.message,
        });
      } else {
        const { onAddSuccess } = this.props;
        onAddSuccess();
      }
    });
  };

  updateSearchVal = (e) => {
    clearTimeout(this.timeout);
    const { value } = e.target;
    const { source } = this.state;

    this.timeout = setTimeout(() => {
      if (value.length >= 3) {
        this.setState(
          {
            searchVal: value.toLowerCase(),
            offset: 0,
          },
          () => {
            if (source) {
              source.cancel('API request canceled.');
            }
            this.getAllProductsList();
          }
        );
      } else if (!value) {
        this.setState(
          {
            searchVal: '',
            offset: 0,
          },
          () => {
            if (source) {
              source.cancel('API request canceled.');
            }
            this.getAllProductsList();
          }
        );
      }
    }, 250);
  };

  getAllProductsList = (isFlag) => {
    const source = getCancelToken();

    this.setState({
      isAPICalled: true,
      source,
    });
    const { limit, offset, companyArr, apiOnScroll, searchVal } = this.state;

    const reqObj = {
      filters: {},
    };

    if (companyArr.length > 0) {
      reqObj.filters.company = companyArr;
    }

    let urlname = `/repProfile/getAllProductsForRepByCompany?companyId=${app.user.companyId}`;

    if (searchVal && searchVal.length >= 3) {
      urlname += `&text=${searchVal}`;
    }

    axiosApi(
      `${urlname}&limit=${limit}&offset=${offset}`,
      'POST',
      reqObj,
      (res) => {
        if (res.error) {
          console.log(res.message);
        } else if (res.data) {
          const resObj = res.data.items;
          if (offset === 0 || !apiOnScroll) {
            this.setState({
              productList: resObj,
            });
          } else if (apiOnScroll) {
            this.setState((prevState) => ({
              productList: [...prevState.productList, ...resObj],
            }));
          }

          if (isFlag) {
            this.setState({
              // isDoneBtnShow: !resObj.length, unused...
            });
          }

          if (res.data.isMore) {
            this.setState({
              offset: offset + limit,
            });
          } else {
            this.setState({
              offset: 0,
            });
          }
        }
        this.setState({
          isAPICalled: false,
          apiOnScroll: false,
          source: '',
        });
      },
      source.token
    );
  };

  /**
   * Summary. On scroll event
   *
   * Description. Load more search results on scroll
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param  {Object}   e      event object
   */
  onScroll = (e) => {
    const { offset, apiOnScroll } = this.state;
    if (scrollCheck(e, offset, apiOnScroll)) {
      this.setState({
        apiOnScroll: true,
      });
      this.getAllProductsList();
    }
  };

  componentDidMount() {
    this.getAllProductsList(true);
  }

  onClickAway = () => {
    const { searchVal } = this.state;
    this.searchVal([searchVal]);
    this.setState({
      companyArr: [],
    });
  };

  render() {
    const {
      searchVal,
      filterOpen,
      selectedArr,
      isSelectAll,
      isAPICalled,
      apiErrorMessage,
      productList,
      companyList,
      companyArr,
    } = this.state;

    return (
      <MDBModalBody>
        <div className="d-block">
          <ProfileHeading headingtxt="Add Products" />
        </div>
        <>
          <div className="d-inline-block">
            <MDBInput
              label="Enter text to filter by product name or product number"
              type="search"
              className="d-inline-block myproducts_search_field"
              onChange={this.updateSearchVal}
              style={{ width: 428 }}
            />
          </div>
          <div className="d-inline-block ml-4 product_name_btn">
            <button
              type="button"
              className="fill-orange-btn"
              disabled={!selectedArr.length || isAPICalled}
              onClick={this.onSaveClick}
              data-repcard-test="save"
            >
              {isAPICalled ? (
                <span className="spinner-border spinner-border-sm" />
              ) : (
                ''
              )}
              Save
            </button>
            {apiErrorMessage ? (
              <p className="error-message1">{apiErrorMessage}</p>
            ) : (
              ''
            )}
          </div>

          <div
            className="filter-panel account_filter_panel orange_bg"
            style={{ marginLeft: 5 }}
          >
            <div
              className={`filter-list-name ${filterOpen ? 'active' : ''}`}
              onClick={this.filterSelectOpen}
              role="presentation"
              data-repcard-test="filter"
              style={{ padding: '15px 12px', borderRadius: 2 }}
            >
              <span className="shape mr-1" />
              Filter
            </div>
            {filterOpen && (
              <Filters
                text={searchVal}
                onFilterClick={this.onFilterClick}
                onResetClick={this.onResetClick}
                onClickAway={this.onClickAway}
                companyList={companyList}
                companyArr={companyArr}
              />
            )}
          </div>
          {productList.length ? (
            <div className="product_name_list">
              <div className="account_info_txt clearfix">
                <div className="center_name">Product Name</div>
                <div className="product_company">Product Company</div>
                <div className="product_number">Product Number</div>
                <div className="float-right">
                  <MDBInput
                    label="Add All"
                    filled
                    type="checkbox"
                    id="checkboxAddAll"
                    checked={isSelectAll}
                    onChange={this.onSelectAll}
                  />
                </div>
              </div>
              <ul
                onScroll={this.onScroll}
                className={isAPICalled ? 'add-products-loading' : ''}
                style={{ maxHeight: 375 }}
              >
                {productList.map((p) => {
                  const { id, name, versionModelNumber, companyName } = p;

                  return (
                    <li key={id}>
                      <div className="center_name">{name}</div>
                      <div className="product_company">{companyName}</div>
                      <div className="product_number">{versionModelNumber}</div>
                      <div className="mobile-block">
                        <button
                          type="button"
                          className={`add_btn ${
                            selectedArr.indexOf(id) !== -1 ? 'active' : ''
                          }`}
                          onClick={() => {
                            this.onAddClick(id);
                          }}
                          data-repcard-test="add"
                        >
                          Add
                        </button>
                      </div>
                    </li>
                  );
                })}
              </ul>
              <div className="text-center product_name_btn">
                {/* <button
                  type="button"
                  className="fill-orange-btn"
                  disabled={!selectedArr.length || isAPICalled}
                  onClick={this.onSaveClick}
                  data-repcard-test="save"
                >
                  {isAPICalled ? (
                    <span className="spinner-border spinner-border-sm" />
                  ) : (
                    ''
                  )}
                  Save
                </button> */}
                {apiErrorMessage ? (
                  <p className="error-message1">{apiErrorMessage}</p>
                ) : (
                  ''
                )}
              </div>
              <div style={{ width: '100%', padding: 10 }} />
            </div>
          ) : searchVal ? (
            <div>
              No products are found related to searched query. Either the
              product searched is no longer in commercial distribution or an
              alternate search query is required.
            </div>
          ) : (
            ''
          )}
        </>
      </MDBModalBody>
    );
  }
}

export default AddProduct;
