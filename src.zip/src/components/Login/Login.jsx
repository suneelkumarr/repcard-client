/**
 *
 * Description. Login page
 *
 * @link   URL
 * @file   Rep/Provider can login from this page by providing email and password.
           User can also go to signup, forgot password pages from here.
 * @since  1.0.0
 */
import React, { Component } from 'react';
import { MDBContainer, MDBCol, MDBRow, MDBInput, Fa } from 'mdbreact';
import { Link, Redirect } from 'react-router-dom';
import querystring from 'querystring';
import ProfileHeading from '../Common/ProfileHeading';
import validateObj from '../../validations/repprofile/repfront.js';
import { getTextForPage } from '../../utils/getPageText.js';
import { loginApiNew } from '../Common/callLoginApi';
import CHROME from '../../images/chrome.png';
import EDGE from '../../images/edge.png';
import SAFARI from '../../images/safari.png';
import FIREFOX from '../../images/firefox.png';

class Login extends Component {
  constructor(props) {
    super(props);

    const search = props.location.search.substr(1);
    const { email } = querystring.parse(search);
    const { profileurl } = querystring.parse(search);

    this.state = {
      email: email || '',
      profileurl: profileurl || '',
      loginPassword: '',
      inputClass: {},
      errorObj: {},
      redirectToReferrer: '',
      pageTextPrefix: 'login',
      pageText: {},
      isBrowsersBoxShow: true,
    };
  }

  async componentDidMount() {
    // on load, we need to retrieve all the text for this page from the db
    const { pageTextPrefix } = this.state;
    const pageText = await getTextForPage(pageTextPrefix);
    this.setState({ pageText });
  }

  /**
   * Summary. Set input values
   *
   * Description. Update All the input values to state
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   name           name of the input
   * @param {string}   value          value of the input
   *
   */
  setValue = (name, value) => {
    this.setState({
      [name]: value,
    });
  };

  /**
   * Summary. OnChange event
   *
   * Description. Input Change method for all input
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   e           Input element event object
   *
   */
  onChange = (e) => {
    const { name, value } = e.target;
    this.setValue(name, value);
  };

  /**
   * Summary. OnBlur event
   *
   * Description. Blur method for all input
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   e           Input element event object
   *
   */
  onBlur = (e) => {
    const { name, value } = e.target;
    this.validateInput(name, value);
  };

  /**
   * Summary. Validate Input
   *
   * Description. Sets the error to errorObj and className to inputClass object
   *              if any validation error found.
   *              errorObj is used for displaying the errors for particular input
   *              inputClas is used for Adding error classNames for particular input
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   name           Input element name
   * @param {string}   value          Input element value
   *
   * @return {String} Error if any else null
   */
  validateInput(name, value) {
    if (validateObj[name]) {
      let error = '';
      let className = 'error-border';
      error = validateObj[name](value);
      if (!error) {
        className = '';
      }

      this.setState((prevState) => ({
        errorObj: {
          ...prevState.errorObj,
          [name]: error,
        },
        inputClass: {
          ...prevState.inputClass,
          [name]: className,
        },
      }));

      return error;
    }
    return '';
  }

  /**
   * Summary. Form validation
   *
   * Description. Validate form on submit click
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @return {boolean} false if not valid else true
   */
  validate() {
    const { loginPassword, email } = this.state;
    let isValid = true;
    let error;

    error = this.validateInput('email', email);
    if (error) {
      isValid = false;
    }

    error = this.validateInput('loginPassword', loginPassword);
    if (error) {
      isValid = false;
    }

    return isValid;
  }

  /**
   * Summary. Form submit on login button
   *
   * Description. Validate on form submit and call the login API. On suceess
   *              Redirect to appropriate page otherwise show error
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   e           event object
   *
   */
  onLogin = async (e) => {
    e.preventDefault();
    const isValid = this.validate();
    if (isValid) {
      const { email, loginPassword } = this.state;
      this.setState({
        isAPICalled: true,
        apiErrorMessage: '',
      });
      console.log('CALLING LOGIN API NEW');

      const data = await loginApiNew(email, loginPassword).catch((error) => {
        this.setState({
          apiErrorMessage: error.message,
        });
      });
      console.dir(data);
      this.setState({
        isAPICalled: false,
        redirectToReferrer: data.redirectURL,
      });
      if (data.error) {
        this.setState({
          apiErrorMessage: data.message,
        });
      }
    }
  };

  /**
   * Summary. Password Toggle
   *
   * Description. Toggle password on click of eye icon
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   e           Input element event object
   * @param {String}   name        name of the inout field
   */
  handleClickShowPassword = (e, name) => {
    e.preventDefault();
    this.setState((prevState) => ({
      [name]: !prevState[name],
    }));
  };

  render() {
    const {
      errorObj,
      inputClass,
      email,
      loginPassword,
      isAPICalled,
      showPassword,
      apiErrorMessage,
      redirectToReferrer,
      isBrowsersBoxShow,
    } = this.state;

    if (redirectToReferrer) {
      const from = { pathname: redirectToReferrer };
      return <Redirect to={from} />;
    }

    return (
      <MDBContainer>
        <MDBRow>
          <MDBCol
            lg="12"
            className={`signup_wrap ${isBrowsersBoxShow ? 'm-0 pt-0' : ''}`}
          >
            <MDBRow>
              {isBrowsersBoxShow && (
                <MDBCol lg="6" className="offset-md-1 offset-lg-3">
                  <div className="jumbotron .d-lg-none .d-xl-block ">
                    <ProfileHeading headingtxt="For the best REPCARDz user experience" />
                    <div
                      className="close_auth_popup"
                      onClick={() => {
                        this.setState({ isBrowsersBoxShow: false });
                      }}
                    >
                      X close
                    </div>
                    <p>Please use one of our supported browsers.</p>
                    <div className="logos">
                      <div className="icon">
                        <img className="icon-img" src={CHROME} alt="" />
                        <p className="icon-text">Chrome</p>
                      </div>
                      <div className="icon">
                        <img className="icon-img" src={SAFARI} alt="" />
                        <p className="icon-text">Safari</p>
                      </div>
                      <div className="icon">
                        <img className="icon-img" src={FIREFOX} alt="" />
                        <p className="icon-text">Firefox</p>
                      </div>
                      <div className="icon">
                        <img className="icon-img" src={EDGE} alt="" />
                        <p className="icon-text">Edge</p>
                      </div>
                    </div>
                  </div>
                </MDBCol>
              )}
              <MDBCol lg="4" md="5" className="offset-md-1 offset-lg-2">
                <ProfileHeading headingtxt="Login" />
                <form onSubmit={this.onLogin} noValidate>
                  <div className="login_fields">
                    <div className={`input-field  ${inputClass.email}`}>
                      <MDBInput
                        type="email"
                        value={email}
                        onBlur={this.onBlur}
                        name="email"
                        onChange={this.onChange}
                        label="Your Email"
                      />
                      {errorObj.email ? (
                        <span className="error-message">{errorObj.email}</span>
                      ) : (
                        ''
                      )}
                    </div>
                    <div
                      className={`input-field input-password ${inputClass.loginPassword}`}
                    >
                      <MDBInput
                        label="Password"
                        name="loginPassword"
                        onChange={this.onChange}
                        type={showPassword ? 'text' : 'password'}
                        value={loginPassword}
                        onBlur={this.onBlur}
                        onContextMenu={(e) => {
                          e.preventDefault();
                        }}
                        onPaste={(e) => {
                          e.preventDefault();
                        }}
                      />
                      <div
                        className="p-0 password-icon"
                        onClick={(e) => {
                          this.handleClickShowPassword(e, 'showPassword');
                        }}
                        onMouseDown={(e) => e.preventDefault()}
                        role="presentation"
                        data-repcard-test="pass-icon"
                      >
                        <Fa far icon={showPassword ? 'eye' : 'eye-slash'} />
                      </div>
                      {errorObj.loginPassword ? (
                        <span className="error-message">
                          {errorObj.loginPassword}
                        </span>
                      ) : (
                        ''
                      )}
                      <Link to="/ForgotPassword" className="forgot_pwd_txt">
                        Forgot Password?
                      </Link>
                    </div>
                    <div className="Login-btn-panel mt-5">
                      <button
                        type="submit"
                        className="fill-orange-btn"
                        disabled={isAPICalled}
                      >
                        {isAPICalled ? (
                          <span className="spinner-border spinner-border-sm" />
                        ) : (
                          ''
                        )}
                        Login
                      </button>
                      {apiErrorMessage ? (
                        <p
                          className="error-message1"
                          style={{ fontSize: '14px' }}
                        >
                          {apiErrorMessage}
                        </p>
                      ) : (
                        ''
                      )}
                    </div>
                  </div>
                </form>
              </MDBCol>
              <MDBCol lg="4" md="5">
                <div>
                  <ProfileHeading headingtxt="Don't have an Account?" />
                  <div className="btn-panel d-flex mt-2">
                    <Link className="sign_up_btn" to="/Signup">
                      Sign Up
                    </Link>
                  </div>
                </div>
              </MDBCol>
            </MDBRow>
          </MDBCol>
        </MDBRow>
      </MDBContainer>
    );
  }
}

export default Login;
