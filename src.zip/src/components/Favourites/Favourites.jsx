/**
 *
 * Description. Favourites Section for Providers
 *
 * @link   URL
 * @file   Html part of favourite functionality, Also remove the reps from
           favourites section, Drag and drop functionality
 * @since  1.0.0
 */
import React, { Component } from 'react';
import ReactDragListView from 'react-drag-listview/dist/react-drag-listview.min';
import ProfilePhoto from '../Common/ProfilePhoto';
import ProfileHeading from '../Common/ProfileHeading';
import RepcardPopover from '../Popover/popover.jsx';
import phoneFormat from '../../utils/getPhoneFormat.js';
import { axiosApi } from '../../apis/axiosApiCall';
import app from '../../helpers/appGlobal';
import scrollCheck from '../../utils/scrollCheck';

import './favourites.scss';

class Favourites extends Component {
  constructor(props) {
    super(props);
    this.state = {
      limit: 10,
      offset: 0,
      favList: [],
      isAPICalled: false,
      isFavouriteAPIId: '',
      apiOnScroll: false,
    };
  }

  componentDidMount() {
    this.callFavouriteApi();
  }

  /**
   * Summary. Get Api for favourite list
   *
   * Description. To retrieve favourite details for current provider
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  callFavouriteApi = () => {
    this.setState({
      isAPICalled: true,
    });
    const { limit, offset } = this.state;

    axiosApi(
      `/provider/getFavoriteRepProvider?limit=${limit}&offset=${offset}&providerId=${app.user.id}`,
      'GET',
      '',
      (res) => {
        if (res.data && res.data.items) {
          const resObj = res.data.items;
          if (offset === 0) {
            this.setState({
              favList: resObj,
            });
          } else {
            this.setState((prevState) => ({
              favList: [...prevState.favList, ...resObj],
            }));
          }

          if (res.data.isMore) {
            this.setState({
              offset: offset + limit,
            });
          } else {
            this.setState({
              offset: 0,
            });
          }
        }
        this.setState({
          isAPICalled: false,
          apiOnScroll: false,
        });
      }
    );
  };

  /**
   * Summary. On scroll event
   *
   * Description. Load more favourite list on scroll
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param  {Object}   e      event object
   */
  onScroll = (e) => {
    const { offset, apiOnScroll } = this.state;
    if (scrollCheck(e, offset, apiOnScroll)) {
      this.setState({
        apiOnScroll: true,
      });
      this.callFavouriteApi();
    }
  };

  /**
   * Summary. Remove Api
   *
   * Description. Remove Rep from the favourite list
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param  {String}   id      Rep's User id
   */
  removeFavourite = (id) => {
    const reqObj = {
      providerId: app.user.id,
      repIds: [id],
    };

    const urlname = `/provider/removeFavoriteRepProvider`;
    this.setState({
      isFavouriteAPIId: id,
    });
    axiosApi(urlname, 'POST', reqObj, (res) => {
      this.setState({
        isFavouriteAPIId: '',
      });
      if (res.error) {
        alert(res.message);
      } else {
        this.updateFavourites(id);
        alert('Favourite removed Succesfully');
      }
    });
  };

  /**
   *
   * Call updateFavourites prop on success of set/Reset favourite Rep
   */
  updateFavourites = (id) => {
    const { updateFavourites } = this.props;
    if (updateFavourites) {
      updateFavourites(id);
    }
  };

  /**
   * Summary. Update Positions of Rep's
   *
   * Description. Change and update the position of Rep's using drag and drop
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param  {Integer}   from      user id of Rep (from position)
   * @param  {Integer}   to        user id of Rep (to position)
   * @param  {function}  cb        Callback function
   */
  updatePosition = (from, to, cb) => {
    const reqObj = {
      providerId: app.user.id,
      changeRank: {
        from,
        to,
      },
    };
    const urlname = `/provider/updatePositionFavoriteRepProvider`;
    axiosApi(urlname, 'POST', reqObj, (res) => {
      if (res.error) {
        alert(res.message);
      } else {
        cb(true);
      }
    });
  };

  /**
   * Summary. Dragend function
   *
   * Description. Drag end function when user completes drag and drop event
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param  {Integer}   from      from index of Rep
   * @param  {Integer}   to        to index of Rep
   */
  onDragEnd = (fromIndex, toIndex) => {
    const { favList } = this.state;
    const fromIndexId = favList[fromIndex].id;
    const toIndexId = favList[toIndex].id;
    this.updatePosition(fromIndexId, toIndexId, (flag) => {
      if (flag) {
        const data = [...favList];
        const item = data.splice(fromIndex, 1)[0];
        data.splice(toIndex, 0, item);
        this.setState({ favList: data });
      }
    });
  };

  render() {
    const { favList, isAPICalled, offset, isFavouriteAPIId } = this.state;

    return (
      <div
        className="search-left-panel mt-sm-5 mt-md-5 mt-lg-0"
        onScroll={this.onScroll}
      >
        <div className="heading-txt">
          <ProfileHeading headingtxt="Favorite Reps" />
        </div>

        {isAPICalled && offset === 0 ? (
          'Please wait'
        ) : favList.length ? (
          <ReactDragListView
            nodeSelector="li"
            handleSelector="li"
            onDragEnd={this.onDragEnd}
          >
            <ul className="favt_list_dtl">
              {favList.map((v) => {
                v.isFavourite = true; // eslint-disable-line
                return (
                  <li
                    className={`fav_list ${
                      isFavouriteAPIId === v.id ? 'noEvents' : ''
                    }`}
                    key={v.id}
                  >
                    <span
                      className="fav_heart_icon"
                      role="presentation"
                      onClick={() => {
                        this.removeFavourite(v.id);
                      }}
                    />
                    <div className="fav_profilepic">
                      <ProfilePhoto
                        addProfile="fav_avtar_pic d-inline-block"
                        photoUrl={v.photoUrl}
                      />
                      <div className="repcard_popup">
                        <div className="popover_view">
                          <RepcardPopover
                            profileRes={v}
                            productcategoryRes={[]}
                            initialView="profile"
                            id={v.id}
                            placement="right"
                            textHtml={<span className="rep-icon" />}
                            isFavourite
                            updateFavourites={() => {
                              this.updateFavourites(v.id);
                            }}
                            showFullProfileLink
                          />
                        </div>
                      </div>
                    </div>
                    <div className="fav_avtar_dtl">
                      <div className="avatar_number">
                        <span className="phone_icon" />
                        <span className="phone_number">
                          {v.phone ? (
                            <a
                              style={{ color: '#ffffff' }}
                              href={`tel: ${phoneFormat(v.phone)}`}
                            >
                              {phoneFormat(v.phone)}
                            </a>
                          ) : (
                            'NA'
                          )}
                        </span>
                      </div>
                      <div className="no_fav_data">
                        <span />
                        <span />
                        <span />
                      </div>
                      <div className="avatar_name">
                        {v.firstName} {v.lastName}
                      </div>
                      <div className="avatar_company">{v.companyName}</div>
                      <div className="avatar_email">
                        <a href={`mailto:${v.email}`}>{v.email}</a>
                      </div>
                      {/*
                  <div className="avtar_back_contact">
                    Backup Contact:
                    <p>Carla Johnson</p>
                  </div>
                  */}
                    </div>
                  </li>
                );
              })}
            </ul>
          </ReactDragListView>
        ) : (
          <>
            <div className="fav_list no_fav_added">
              <div className="fav_profilepic">
                <ProfilePhoto addProfile="fav_avtar_pic d-inline-block" />
              </div>
              <div className="fav_avtar_dtl">
                <div className="avatar_number">
                  <span className="phone_icon" />
                  <span className="phone_number">
                    <a
                      style={{ color: '#ffffff' }}
                      href={`tel: ${phoneFormat('2025550132')}`}
                    >
                      {phoneFormat('2025550132')}
                    </a>
                  </span>
                </div>
                <div className="no_fav_data">
                  <span />
                  <span />
                  <span />
                </div>
              </div>
            </div>
            <p className="no_fav_txt">No favorites currently saved</p>
          </>
        )}
      </div>
    );
  }
}

export default Favourites;
