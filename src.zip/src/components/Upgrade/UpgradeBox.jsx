/* eslint-disable react/no-danger */
/**
 *
 * Description. Upgrade to Premium Component
 *
 * @link   URL
 * @file   Display basic details of premmium plan for Rep's and Provider's
 * @since  1.0.0
 */
import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import app from '../../helpers/appGlobal';
import {
  getTextForPage,
  getTextValueByTextId,
} from '../../utils/getPageText.js';

import './Upgrade.scss';

class UpgradeBox extends Component {
  constructor(props) {
    super(props);
    this.state = {
      pageTextPrefix: 'upgrade_box',
      pageText: {},
    };
  }

  async componentDidMount() {
    const { pageTextPrefix } = this.state;
    const pageText = await getTextForPage(pageTextPrefix);
    this.setState({ pageText });
  }

  onClick = () => {
    // Open plan page directly on click of Learn more
    app.isUpgrade = true;
  };

  render() {
    const { userType } = app.user;
    const { pageText } = this.state;

    return (
      <div className="upgrade_box">
        <div className="dashboard_heading">Upgrade to PREMIUM</div>
        <div className="upgrade_copy">
          {userType === 'rep' ? (
            <span
              dangerouslySetInnerHTML={{
                __html: getTextValueByTextId(
                  pageText,
                  'upgrade_box_rep_upgrade'
                ),
              }}
            />
          ) : (
            <span
              dangerouslySetInnerHTML={{
                __html: getTextValueByTextId(
                  pageText,
                  'upgrade_box_provider_upgrade'
                ),
              }}
            />
          )}

          {userType === 'rep' ? (
            <ul className="feature_list">
              <li>Profile Picture</li>
              <li>Phone Numbers Listed</li>
              <li>My Products Listed</li>
              {/* <li>
                In-app Chat <span className="normal_txt">(COMING SOON)</span>
              </li> */}
            </ul>
          ) : (
            <ul className="feature_list">
              <li>View Rep’s Phone Numbers and Profile Picture</li>
              <li>
                Search for Reps by Product Name, Re-order Number or Keyword
              </li>
              <li>Save your Favorite Reps for Easy Recall</li>
            </ul>
          )}

          <div className="upgrade_btn-panel text-center mt-3">
            <Link onClick={this.onClick} to="/Dashboard">
              <button type="button" className="fill-orange-btn">
                Learn more
              </button>
            </Link>
          </div>
        </div>
      </div>
    );
  }
}

export default UpgradeBox;
