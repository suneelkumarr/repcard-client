/**
 *
 * Description. Filters
 *
 * @link   URL
 * @file   Filters for Rep's search by company and productcategory
           (whatever is available in search results for displaying company and productcategory)
           User can do the filtering by choosing any of these things.
 * @since  1.0.0
 */
import React, { Component } from 'react';
import PublishSubscribe from 'publish-subscribe-js';
import uniq from 'lodash/uniq';
import PUB_SUB from '../../constants/events.constant';
import {
  SearchFilterListCompany,
  SearchFilterListProductCategory,
} from './SearchFilterList';
import FilterButtons from './FilterButtons';
import { axiosApi } from '../../apis/axiosApiCall';
import getCancelToken from '../../apis/getCancelToken';
import scrollCheck from '../../utils/scrollCheck';
import handleClickOutside from '../../utils/handleClickOutside';

const getPreFiltersArr = (masterData, filterArr) => {
  if (filterArr.length) {
    masterData.forEach((v) => {
      v.productlines.forEach((item) => {
        if (filterArr.indexOf(item.id) !== -1) {
          item.checked = true; // eslint-disable-line
          v.checked = true; // eslint-disable-line
        }
      });
    });
  }
  return masterData;
};

class Filters extends Component {
  constructor(props) {
    super(props);
    const {
      companyArr,
      productcategoryFilterArr,
      tagCompanyList,
      tagProductCategoryArr,
    } = this.props;
    let isSelected = '';
    if (companyArr && companyArr.length) {
      isSelected = 'isCompany';
    } else if (
      !this.checkIsProductCategorySearch() &&
      productcategoryFilterArr &&
      productcategoryFilterArr.length
    ) {
      isSelected = 'isProductCategory';
    }
    this.state = {
      limit: this.checkIsProductSearch() ? 500 : 10,
      offset: 0,
      limit1: 20,
      offset1: 0,
      companyList: [],
      companyArr: companyArr || [],
      productcategoryList: [],
      productcategoryFilterArr: productcategoryFilterArr || [],
      isAPICalled: false,
      apiOnScroll: false,
      isAPICalled1: false,
      apiOnScroll1: false,
      isSelected,
      tagCompanyList,
      tagProductCategoryArr,
      // open: false, unused...
    };

    this.mousedownSubKey = 0;
    this.myRef = React.createRef();
    this.myRef1 = props.myRef1;
  }

  /**
   * Summary. Outside click event
   *
   * Description. Check if click event is occured not in the html part and closes
                  the popup on outside click
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   eventObj   click event object
   *
   */
  handleClickOutside = (eventObj) => {
    const { filterSelectToggle } = this.props;

    if (handleClickOutside(true, this.myRef, eventObj, this.myRef1)) {
      filterSelectToggle();
    }
  };

  /**
   *  Check and return true/false from searchBy value
   */
  checkSearchBy = (fromWhere) => {
    const { searchby } = this.props;
    return searchby === fromWhere;
  };

  /**
   *  Check if selection is for search by name
   */
  checkIsNameSearch = () => {
    return this.checkSearchBy('name');
  };

  /**
   *  Check if selection is for search by company
   */
  checkIsCompanySearch = () => {
    return this.checkSearchBy('company');
  };

  /**
   *  Check if selection is for search by productcategory
   */
  checkIsProductCategorySearch = () => {
    return this.checkSearchBy('productcategory');
  };

  /**
   *  Check if selection is for search by product
   */
  checkIsProductSearch = () => {
    return this.checkSearchBy('product');
  };

  componentDidMount() {
    // Mouse down event subscribe for html click event check
    this.mousedownSubKey = PublishSubscribe.subscribe(
      PUB_SUB.MOUSEDOWN,
      this.handleClickOutside
    );
    // Don't call company API in case of search by company
    if (!this.checkIsCompanySearch()) {
      this.callCompanyApi();
    }
    // Don't call productcategory API in case of search by productcategory
    if (!this.checkIsProductCategorySearch() || !this.checkIsProductSearch()) {
      this.callProductCategoryApi();
    }
  }

  componentWillUnmount() {
    PublishSubscribe.unsubscribe(PUB_SUB.MOUSEDOWN, this.mousedownSubKey);
    this.cancelAPIreq(); // Cancel API req if api is in progress
  }

  /**
   *  To cancel Api reuqest
   */
  cancelAPIreq() {
    const { source, source1 } = this.state;
    if (source) {
      source.cancel('API request canceled.');
    }
    if (source1) {
      source1.cancel('API request canceled.');
    }
  }

  /**
   * Summary. ProductCategory main category checkbox change
   *
   * Description. Set/Reset productcategories to productcategoryList
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Object}   e               event object
   * @param {Object}   productcategoryId    id of the productcategory
   *
   */
  handleCheckChange = (e, productcategoryId) => {
    const { checked } = e.target;
    const {
      productcategoryList,
      productcategoryFilterArr,
      tagProductCategoryArr,
    } = this.state;
    const newArr = [...productcategoryList];
    let newproductcategoryFilterArr = [...productcategoryFilterArr];
    let newtagProductCategoryArr = [...tagProductCategoryArr];
    const index = productcategoryList.findIndex(
      (v) => v.productcategoryId === productcategoryId
    );
    newArr[index].checked = checked;
    if (!checked) {
      newArr[index].productlines.forEach((v) => {
        v.checked = false; // eslint-disable-line
        newproductcategoryFilterArr = newproductcategoryFilterArr.filter(
          (val) => val !== v.id
        );
      });
      newtagProductCategoryArr = newtagProductCategoryArr.filter(
        (v) => v.productcategoryId !== productcategoryId
      );
    }
    this.setState({
      productcategoryList: newArr,
      productcategoryFilterArr: newproductcategoryFilterArr,
      tagProductCategoryArr: newtagProductCategoryArr,
    });
  };

  /**
   * Summary. ProductCategory sub category checkbox change
   *
   * Description. Set/Reset productcategories to productcategoryList
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Object}   e               event object
   * @param {Object}   category        productcategory sub category object
   * @param {Object}   mainCategory    productcategory main category object
   *
   */
  onSubCategoryChange = (e, category, mainCategory) => {
    const { id } = category;
    const { productcategoryId } = mainCategory;
    const { checked } = e.target;
    const {
      productcategoryList,
      productcategoryFilterArr,
      tagProductCategoryArr,
    } = this.state;
    const newArr = [...productcategoryList];
    let newproductcategoryFilterArr = [...productcategoryFilterArr];
    let newtagProductCategoryArr = [...tagProductCategoryArr];
    const index = productcategoryList.findIndex(
      (v) => v.productcategoryId === productcategoryId
    );
    const productcategoryIndex = newArr[index].productlines.findIndex(
      (v) => v.id === id
    );
    newArr[index].productlines[productcategoryIndex].checked = checked;
    if (checked) {
      newproductcategoryFilterArr = uniq([...newproductcategoryFilterArr, id]);
    } else {
      newproductcategoryFilterArr = newproductcategoryFilterArr.filter(
        (val) => val !== id
      );
    }

    const index1 = newtagProductCategoryArr.findIndex(
      (v) => v.productcategoryId === productcategoryId
    );
    if (index1 !== -1) {
      if (checked) {
        const catIndex = newtagProductCategoryArr[
          index1
        ].productlines.findIndex((v) => v.id === id);
        if (catIndex === -1) {
          newtagProductCategoryArr[index1].productlines = [
            ...newtagProductCategoryArr[index1].productlines,
            category,
          ];
        }
      } else {
        newtagProductCategoryArr[
          index1
        ].productlines = newtagProductCategoryArr[index1].productlines.filter(
          (v) => v.id !== id
        );
        if (!newtagProductCategoryArr[index1].productlines.length) {
          newtagProductCategoryArr = newtagProductCategoryArr.filter(
            (v) => v.productcategoryId !== productcategoryId
          );
        }
      }
    } else if (checked) {
      const newVal = {
        productcategoryId: mainCategory.productcategoryId,
        productcategoryName: mainCategory.productcategoryName,
        productlines: [category],
      };
      newtagProductCategoryArr = [...newtagProductCategoryArr, newVal];
    }
    this.setState({
      productcategoryList: newArr,
      productcategoryFilterArr: newproductcategoryFilterArr,
      tagProductCategoryArr: newtagProductCategoryArr,
    });
  };

  /**
   * Summary. Call ProductCategory API
   *
   * Description. To retrive all the productcategories with company filter or name filter
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  callProductCategoryApi = () => {
    const source = getCancelToken();
    this.setState({
      isAPICalled1: true,
      source,
    });
    const { limit1, offset1 } = this.state;
    const { text } = this.props;

    let urlname = 'getRepByCompanyProductCategory';
    if (this.checkIsNameSearch()) {
      urlname = 'getSearchRepProfileByNameProductCategoryFilter';
    }

    axiosApi(
      `/search/${urlname}?name=${text}&limit=${limit1}&offset=${offset1}`,
      'GET',
      '',
      (res) => {
        if (res.error) {
          console.log(res);
        } else {
          const resObj = res.data.items;
          const { productcategoryFilterArr } = this.state;
          if (offset1 === 0) {
            this.setState({
              productcategoryList: getPreFiltersArr(
                resObj,
                productcategoryFilterArr
              ),
            });
          } else {
            this.setState((prevState) => ({
              productcategoryList: getPreFiltersArr(
                [...prevState.productcategoryList, ...resObj],
                productcategoryFilterArr
              ),
            }));
          }
          if (res.data.isMore) {
            this.setState({
              offset1: offset1 + limit1,
            });
          } else {
            this.setState({
              offset1: 0,
            });
          }
        }
        this.setState({
          isAPICalled1: false,
          apiOnScroll1: false,
          source: '',
        });
      },
      source.token
    );
  };

  /**
   * Summary. Get company list information API
   *
   * Description. To retrive all the companies with name filter or productcategory filter
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  callCompanyApi = () => {
    const source1 = getCancelToken();
    this.setState({
      isAPICalled: true,
      source1,
    });
    const { limit, offset } = this.state;
    const { text } = this.props;

    let urlname = '';
    if (this.checkIsNameSearch()) {
      urlname = `/search/getSearchRepProfileByNameCompanyFilter?name=${text}`;
    } else if (this.checkIsProductSearch()) {
      urlname = `/search/getCompaniesFromProductName?name=${text}`;
    } else {
      const { productcategoryFilterArr } = this.state;
      urlname = `/search/getCompaniesFromProductCategories?productcategories=${productcategoryFilterArr.join(
        ','
      )}`;
    }

    axiosApi(
      `${urlname}&limit=${limit}&offset=${offset}`,
      'GET',
      '',
      (res) => {
        if (res.error) {
          console.log(res);
        } else {
          const resObj = res.data.items;
          if (offset === 0) {
            this.setState({
              companyList: resObj,
            });
          } else {
            this.setState((prevState) => ({
              companyList: [
                ...prevState.companyList,
                ...resObj.filter((company) => {
                  return !prevState.companyList.find(
                    (c) => c.id === company.id
                  );
                }),
              ],
            }));
          }
          if (res.data.isMore) {
            this.setState({
              offset: offset + limit,
            });
            if (res.data.items.length === 0) {
              // make sure SOME results populate--go to next page.
              this.callCompanyApi();
            }
          } else {
            this.setState({
              offset: 0,
            });
          }
        }
        this.setState({
          isAPICalled: false,
          apiOnScroll: false,
          source1: '',
        });
      },
      source1.token
    );
  };

  /**
   * Summary. On scroll event
   *
   * Description. Load more company list on scroll
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param  {Object}   e      event object
   */
  onScroll = (e) => {
    const { offset, apiOnScroll } = this.state;
    if (scrollCheck(e, offset, apiOnScroll)) {
      this.setState({
        apiOnScroll: true,
      });
      this.callCompanyApi();
    }
  };

  /**
   * Summary. On scroll event
   *
   * Description. Load more productcategory list on scroll
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param  {Object}   e      event object
   */
  onScroll1 = (e) => {
    const { offset1, apiOnScroll1 } = this.state;
    if (scrollCheck(e, offset1, apiOnScroll1)) {
      this.setState({
        apiOnScroll1: true,
      });
      this.callProductCategoryApi();
    }
  };

  /**
   * Summary. Change filter name
   *
   * Description. Change the filter either company or productcategory
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}       name             name of the filter
   *
   */
  onChangeFilter = (name) => {
    this.setState({
      isSelected: name,
    });
  };

  /**
   * Summary. company checkbox change event
   *
   * Description. Set/Reset company to companyArr
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Object}   e               event object
   * @param {Object}   item            company object
   *
   */
  companyCheckboxChange = (e, item) => {
    const { checked } = e.target;
    const { name, id } = item;
    if (checked) {
      this.setState((prevState) => ({
        companyArr: uniq([...prevState.companyArr, name]),
        tagCompanyList: [...prevState.tagCompanyList, item],
      }));
    } else {
      this.setState((prevState) => ({
        companyArr: prevState.companyArr.filter((v) => v !== name),
        tagCompanyList: prevState.tagCompanyList.filter((v) => v.id !== id),
      }));
    }
  };

  /**
   *  Apply filter btn click event
   */
  onFilterClick = () => {
    const {
      companyArr,
      tagCompanyList,
      productcategoryFilterArr,
      tagProductCategoryArr,
    } = this.state;

    if (companyArr.length || productcategoryFilterArr.length) {
      const { onFilterClick } = this.props;
      onFilterClick(
        companyArr,
        productcategoryFilterArr,
        tagCompanyList,
        tagProductCategoryArr
      );
    } else if (this.checkIsCompanySearch()) {
      alert('Please select any product line');
    } else if (this.checkIsProductCategorySearch()) {
      alert('Please select any company');
    } else {
      alert('Please select any company or product line');
    }
  };

  /**
   *  Reset btn click event
   */
  onResetClick = () => {
    const { onResetClick } = this.props;
    onResetClick();
  };

  render() {
    const {
      isSelected,
      companyList,
      companyArr,
      productcategoryFilterArr,
      productcategoryList,
      isAPICalled,
      isAPICalled1,
    } = this.state;

    return (
      <div className="filter-list-wrap" ref={this.myRef}>
        <div className={`product-wrap ${isSelected ? 'height_add' : ''}`}>
          <div className="wid-50">
            <ul className="filter-list">
              {this.checkIsCompanySearch() ? (
                ''
              ) : (
                <li
                  role="presentation"
                  onClick={() => {
                    this.onChangeFilter('isCompany');
                  }}
                  className={isSelected === 'isCompany' ? 'selected' : ''}
                  data-repcard-test="company"
                >
                  Company (<span>{companyArr.length}</span>)
                </li>
              )}
              {this.checkIsProductCategorySearch() ||
              this.checkIsProductSearch() ? (
                ''
              ) : (
                <li
                  role="presentation"
                  onClick={() => {
                    this.onChangeFilter('isProductCategory');
                  }}
                  className={
                    isSelected === 'isProductCategory' ? 'selected' : ''
                  }
                  data-repcard-test="productcategory"
                >
                  Product Line (<span>{productcategoryFilterArr.length}</span>)
                </li>
              )}
            </ul>
            {isSelected ? (
              <div className="filter-btn">
                <FilterButtons
                  onFilterClick={this.onFilterClick}
                  onResetClick={this.onResetClick}
                  isBtnEnable={
                    companyArr.length || productcategoryFilterArr.length
                  }
                />
              </div>
            ) : (
              ''
            )}
          </div>
          {isSelected === 'isCompany' ? (
            <div className="wid-50 selected">
              <SearchFilterListCompany
                onChange={this.companyCheckboxChange}
                companyList={companyList}
                onScroll={this.onScroll}
                companyArr={companyArr}
                isAPICalled={isAPICalled}
              />
            </div>
          ) : isSelected === 'isProductCategory' ? (
            <div className="wid-50 selected">
              <SearchFilterListProductCategory
                productcategoryList={productcategoryList}
                onScroll={this.onScroll1}
                onChange={this.handleCheckChange}
                onSubCategoryChange={this.onSubCategoryChange}
                isAPICalled={isAPICalled1}
              />
            </div>
          ) : (
            ''
          )}
        </div>
      </div>
    );
  }
}

export default Filters;
