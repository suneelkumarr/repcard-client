/**
 *
 * Description. Rep's search grid
 *
 * @link   URL
 * @file   Display Rep's information in search grid such as email, phone, name,
           company name
 * @since  1.0.0
 */
import React, { Component } from 'react';
import { MDBModal } from 'mdbreact';
import RepcardPopover from '../Popover/popover.jsx';
import app from '../../helpers/appGlobal';
import { axiosApi } from '../../apis/axiosApiCall';
import ProfileHeading from '../Common/ProfileHeading.jsx';

class SearchProductRow extends Component {
  constructor(props) {
    super(props);
    this.state = {
      toggle: false,
      showStack: false,
      showPopup: false,
      isAPICalled: false,
      reps: [],
      showDesc: false,
    };
  }

  onGridClick = () => {
    // Click event is only for tablet and mobile device
    if (window.innerWidth < 768) {
      this.setState((prevState) => ({
        toggle: !prevState.toggle,
      }));
    }
  };

  getReps = (shouldReset = false) => {
    const { reps } = this.state;
    if (reps.length > 0 && !shouldReset) {
      return false;
    }

    const { item } = this.props;
    const urlname = `/search/getRepsFromProductId?productId=${item.id}&providerId=${app.user.id}`;

    this.setState({
      isAPICalled: true,
    });

    axiosApi(urlname, 'GET', '', (res) => {
      if (res.data) {
        this.setState({
          reps: res.data.reps || [],
        });
      }
      this.setState({
        isAPICalled: false,
      });
    });
    return true;
  };

  showStack = () => {
    this.getReps();
    this.setState({
      showStack: true,
    });

    const { props } = this;
    const { id } = props.item;
    props.setStackId(id);
  };

  showPopup = () => {
    this.getReps();
    this.setState({
      showPopup: true,
    });

    const { props } = this;
    const { id } = props.item;
    props.setPopupId(id);
  };

  toggleDesc = () => {
    this.setState((prevState) => ({
      showDesc: !prevState.showDesc,
    }));
  };

  hideStack = () => {
    this.setState({
      showStack: false,
    });
    const { props } = this;
    props.setStackId(null);
  };

  hidePopup = () => {
    this.setState({
      showPopup: false,
    });
    const { props } = this;
    props.setPopupId(null);
  };

  render() {
    const {
      toggle,
      showStack,
      showPopup,
      isAPICalled,
      reps,
      showDesc,
    } = this.state;
    const {
      item,
      updateFavourites,
      showRepGrid,
      openStackId,
      openPopupId,
    } = this.props;
    const { id } = item;
    const firstThreeReps = reps.slice(0, 3).reverse();
    const shouldShowStack = showStack && openStackId === id && !isAPICalled;
    const shouldShowPopup = showPopup && openPopupId === id && !isAPICalled;

    return (
      <>
        <div className="tr">
          <div
            className="td"
            onClick={this.showPopup}
            onFocus=""
            onMouseOver={this.showStack}
            onMouseLeave={this.hideStack}
          >
            <div className="rep-icon" />
            <div
              className={`product-rep-hover popover_view ${
                shouldShowStack && 'show-stack'
              }`}
            >
              {shouldShowStack && (
                <div
                  onFocus=""
                  onMouseOver={this.showStack}
                  onMouseLeave={this.hideStack}
                >
                  {reps.length > 1 && (
                    <button
                      type="button"
                      className="fill-orange-btn view-rep-grid"
                      onClick={() => showRepGrid(reps)}
                    >
                      View All Reps ({reps.length})
                    </button>
                  )}
                  {reps.length > 0 ? (
                    firstThreeReps.map((rep, index) => {
                      return (
                        <RepcardPopover
                          className={`rep-stack-${index}`}
                          key={rep.id}
                          flipicondisable
                          isHtml
                          isFavourite
                          profileRes={rep}
                          initialView="profile"
                          updateFavourites={() => {
                            updateFavourites();
                            this.getReps(true);
                          }}
                          id={rep.id}
                          showFullProfileLink
                        />
                      );
                    })
                  ) : (
                    <div className="no-rep-stack">
                      We’re sorry.
                      <br />
                      <br />
                      There is no rep associated with this product for your
                      facility.
                      <br />
                      <br />
                      Alternatively, try searching by product line.
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
          <div className={`active_in_mobile ${toggle ? ' expand' : ''}`}>
            <div className="td" onClick={this.onGridClick} role="presentation">
              {item.name}
            </div>
            <div className="td">{item.companyName}</div>
            <div className="td d-inline-flex justify-content-between">
              {item.versionModelNumber}
              <span
                className="badge badge-pill badge-orange m-1"
                onClick={this.toggleDesc}
              >
                i
              </span>
            </div>
          </div>
        </div>
        <div className={shouldShowPopup && 'product-rep-pop-div'}>
          <MDBModal isOpen={shouldShowPopup} toggle={this.hidePopup}>
            <div
              className={`product-rep-hover-popup popover_view ${
                shouldShowPopup && 'show-stack'
              }`}
            >
              {shouldShowPopup && (
                <div>
                  {reps.length > 1 && (
                    <button
                      type="button"
                      className="fill-orange-btn view-rep-grid"
                      onClick={() => showRepGrid(reps)}
                    >
                      View All Reps ({reps.length})
                    </button>
                  )}
                  {reps.length > 0 ? (
                    firstThreeReps.map((rep, index) => {
                      return (
                        <RepcardPopover
                          className={`rep-stack-${index}`}
                          key={rep.id}
                          flipicondisable
                          isHtml
                          isFavourite
                          profileRes={rep}
                          initialView="profile"
                          updateFavourites={() => {
                            updateFavourites();
                            this.getReps(true);
                          }}
                          id={rep.id}
                          showFullProfileLink
                        />
                      );
                    })
                  ) : (
                    <div className="no-rep-stack">
                      We’re sorry.
                      <br />
                      <br />
                      There is no rep associated with this product for your
                      facility.
                      <br />
                      <br />
                      Alternatively, try searching by product line.
                    </div>
                  )}
                </div>
              )}
            </div>
          </MDBModal>
        </div>
        <MDBModal centered isOpen={showDesc} toggle={this.toggleDesc}>
          <div className="product-desc-pop d-flex flex-column">
            <div className="heading-txt">
              <ProfileHeading headingtxt="Product Description" />
            </div>
            <div className="product-desc">
              {item.description ? item.description : 'No Description'}
            </div>
          </div>
        </MDBModal>
      </>
    );
  }
}

export default SearchProductRow;
