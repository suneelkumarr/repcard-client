/**
 *
 * Description. Rep's search grid
 *
 * @link   URL
 * @file   Display Rep's information in search grid such as email, phone, name,
           company name
 * @since  1.0.0
 */
import React, { Component } from 'react';
import phoneFormat from '../../utils/getPhoneFormat.js';
import RepcardPopover from '../Popover/popover.jsx';
import { getBasicPlanNew } from '../../utils/getPlanInfo';

class SearchRow extends Component {
  constructor(props) {
    super(props);
    this.state = {
      toggle: false,
    };
  }

  onGridClick = () => {
    // Click event is only for tablet and mobile device
    if (window.innerWidth < 768) {
      this.setState((prevState) => ({
        toggle: !prevState.toggle,
      }));
    }
  };

  render() {
    const { toggle } = this.state;
    const { item, updateFavourites } = this.props;
    const isBasicPlan = getBasicPlanNew();
    return (
      <div className="tr">
        <div className="td">
          <div className="popover_view">
            <RepcardPopover
              profileRes={item}
              productcategoryRes={[]}
              initialView="profile"
              id={item.id}
              placement="right"
              textHtml={<span className="rep-icon" />}
              isFavourite
              updateFavourites={updateFavourites}
              showFullProfileLink
            />
          </div>
        </div>
        <div className={`active_in_mobile ${toggle ? ' expand' : ''}`}>
          <div className="td" onClick={this.onGridClick} role="presentation">
            {item.firstName} {item.lastName}
          </div>
          <div className="td">{item.companyName}</div>
          <div className="td">
            <div className="popover_view">
              <RepcardPopover
                profileRes={item}
                productcategoryRes={[]}
                initialView=""
                id={item.id}
                placement="right"
                textHtml={<span className="underline">View</span>}
                isFavourite
                showFullProfileLink
              />
            </div>
          </div>
          <div className="td">
            <a className="searchLink" href={`mailto:${item.email}`}>
              {item.email}
            </a>
          </div>
          <div className="td">
            {isBasicPlan || !item.phone ? (
              'XXX-XXX-XXXX'
            ) : (
              <a
                className="searchLink"
                href={`tel: ${phoneFormat(item.phone)}`}
              >
                {phoneFormat(item.phone)}
              </a>
            )}
          </div>
        </div>
      </div>
    );
  }
}

export default SearchRow;
