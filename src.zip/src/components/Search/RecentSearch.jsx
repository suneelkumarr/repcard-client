/**
 *
 * Description. Recent Search
 *
 * @link   URL
 * @file   Calls the API and displays the Recent search list (Maximum 5)
           User can also choose from this list and display search results accordingly
 * @since  1.0.0
 */
import React, { Component } from 'react';
import PublishSubscribe from 'publish-subscribe-js';
import PUB_SUB from '../../constants/events.constant';
import handleClickOutside from '../../utils/handleClickOutside';
import { axiosApi } from '../../apis/axiosApiCall';
import getCancelToken from '../../apis/getCancelToken';
import app from '../../helpers/appGlobal';
import { getMasterProductCategoryData } from '../../utils/masterProductCategoryData';
import { getBasicPlanNew } from '../../utils/getPlanInfo';

class RecentSearch extends Component {
  constructor(props) {
    super(props);
    this.state = {
      open: false,
      results: [],
      productcategoryList: [],
    };

    this.mousedownSubKey = 0;
    this.myRef = React.createRef();
    this.myRef1 = React.createRef();
  }

  /**
   * Summary. Recent search list
   *
   * Description. To retrive all the recent search list using api call
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  getRecentSearch = () => {
    const {
      isBasicPlan = getBasicPlanNew(),
      dashboardProductList,
    } = this.props;
    const source = getCancelToken();
    this.setState({
      source,
    });
    let type = '';
    if (dashboardProductList) {
      type = '&type=dashboard_product';
    }
    axiosApi(
      `/searchLog/getlatestRecentSearchLog/${app.user.id}?userType=${app.user.userType}${type}`,
      'GET',
      '',
      (res) => {
        if (!res.error) {
          let { items } = res.data;
          if (isBasicPlan) {
            items = items.filter((item) => item.type !== 'product');
          }
          this.setState({
            results: items || [],
          });
        }
        this.setState({
          source: '',
        });
      },
      source.token
    );
  };

  /**
   * Summary. Outside click event
   *
   * Description. Check if click event is occured not in the html part and closes
                  the popup on outside click
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   eventObj   click event object
   *
   */
  handleClickOutside = (eventObj) => {
    const { open } = this.state;
    if (handleClickOutside(open, this.myRef, eventObj, this.myRef1)) {
      this.closePopup();
    }
  };

  componentDidMount() {
    // make sure user productcategory data is present
    getMasterProductCategoryData((flag) => {
      if (flag) {
        this.setState({
          productcategoryList: JSON.parse(
            JSON.stringify(app.user.productcategories)
          ),
        });
      }
    });
    // Mouse down event subscribe for html click event check
    this.mousedownSubKey = PublishSubscribe.subscribe(
      PUB_SUB.MOUSEDOWN,
      this.handleClickOutside
    );
  }

  componentWillUnmount() {
    // PublishSubscribe.unsubscribe(PUB_SUB.MOUSEDOWN, this.mousedownSubKey);
    this.cancelAPIreq(); // Cancel API req if api is in progress
  }

  /**
   *  To cancel Api reuqest
   */
  cancelAPIreq() {
    const { source } = this.state;
    if (source) {
      source.cancel('API request canceled.');
    }
  }

  /**
   *  Recent search click event, Open the popup and load the data
   */
  recentOpen = () => {
    this.setState(
      (prevState) => ({
        open: !prevState.open,
      }),
      () => {
        const { open } = this.state;
        if (open) {
          this.getRecentSearch();
        }
      }
    );
  };

  /**
   * Close the Recent Search popup
   */
  closePopup = () => {
    this.setState({
      open: false,
    });
  };

  /**
   * Summary. Html generation
   *
   * Description. Recent search html part
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   item   recent search object to display
   * @param {integer}  index  index for key param
   *
   */
  getLiHtml = (item, index) => {
    const { type, text } = item;
    const {
      onRecentSearchClick,
      onSearchProductCategory,
      onSearchCity,
    } = this.props;

    if (type === 'productcategory') {
      const { productcategories } = item;

      let productcategoryName = '';
      let newArr = [];
      const { productcategoryList } = this.state;
      productcategoryList.forEach((v) => {
        v.productlines.forEach((category) => {
          if (productcategories.indexOf(category.id) !== -1) {
            productcategoryName = v.productcategoryName;
            newArr = [...newArr, category.name];
          }
        });
      });

      return (
        <li
          key={index}
          onClick={() => {
            this.closePopup();
            onSearchProductCategory(productcategories, 'productcategory');
          }}
          role="presentation"
          data-repcard-test={type}
        >
          Product Line:{' '}
          <span>
            {productcategoryName} -{' '}
            {productcategories.length === 1
              ? newArr[0]
              : `${productcategories.length} Product Lines`}
          </span>
        </li>
      );
    }

    if (type === 'city') {
      const { cities } = item;

      let stateName = '';
      let newArr = [];
      const { stateList } = this.props;
      stateList.forEach((s) => {
        s.cities.forEach((c) => {
          if (cities.indexOf(c.id) !== -1) {
            stateName = s.state;
            newArr = [...newArr, c.city];
          }
        });
      });

      return (
        <li
          key={index}
          onClick={() => {
            this.closePopup();
            onSearchCity(cities, 'city');
          }}
          role="presentation"
          data-repcard-test={type}
        >
          City:{' '}
          <span>
            {stateName} -{' '}
            {cities.length === 1 ? newArr[0] : `${cities.length} Cities`}
          </span>
        </li>
      );
    }

    if (type === 'company') {
      return (
        <li
          key={index}
          onClick={() => {
            this.closePopup();
            onRecentSearchClick(text, 'company');
          }}
          role="presentation"
          data-repcard-test={type}
        >
          Company: <span>{text}</span>
        </li>
      );
    }

    if (type === 'hospital') {
      return (
        <li
          key={index}
          onClick={() => {
            this.closePopup();
            onRecentSearchClick(text, 'hospital');
          }}
          role="presentation"
          data-repcard-test={type}
        >
          Account: <span>{text}</span>
        </li>
      );
    }

    if (type === 'product') {
      return (
        <li
          key={index}
          onClick={() => {
            this.closePopup();
            onRecentSearchClick(text, 'product');
          }}
          role="presentation"
          data-repcard-test={type}
        >
          Product: <span>{text}</span>
        </li>
      );
    }

    return (
      <li
        key={index}
        onClick={() => {
          this.closePopup();
          onRecentSearchClick(text, 'name');
        }}
        role="presentation"
        data-repcard-test={type}
      >
        Name: <span>{text}</span>
      </li>
    );
  };

  render() {
    const { open, results, source } = this.state;
    return (
      <div className="filter-panel">
        <div
          className={`filter-list-name ${open ? 'active' : ''}`}
          onClick={this.recentOpen}
          role="presentation"
          ref={this.myRef1}
          data-repcard-test="recentSearch"
        >
          <span className="search_icon mr-1" />
          Recent Searches
        </div>
        {open ? (
          <div className="filter_recent_panel" ref={this.myRef}>
            {results.length ? (
              <ul>
                {results.map((v, i) => {
                  return this.getLiHtml(v, i);
                })}
              </ul>
            ) : (
              <ul>
                <li>{source ? '' : 'No Search Results'}</li>
              </ul>
            )}
          </div>
        ) : (
          ''
        )}
        {/* <div className="filter-list-name">
        <span className="sortby mr-1"></span>
        Recent Search
      </div> */}
      </div>
    );
  }
}

export default RecentSearch;
