/**
 *
 * Description. Seacrh by company Autocomplete
 *
 * @link   URL
 * @file   User can type the company name and company list will appear in drop-down
           Select the company name and filter the data accordingly
 * @since  1.0.0
 */
import React, { Component } from 'react';
import { MDBInput } from 'mdbreact';
import isEmpty from 'lodash/isEmpty';
import PublishSubscribe from 'publish-subscribe-js';
import { v1 as uuidv1 } from 'uuid';
import PUB_SUB from '../../constants/events.constant';
import { axiosApi } from '../../apis/axiosApiCall';
import handleClickOutside from '../../utils/handleClickOutside';
import isEnterKeyPressed from '../../utils/checkEnterKeyPressed';
import scrollCheck from '../../utils/scrollCheck';

class SearchCompanyList extends Component {
  constructor(props) {
    super(props);
    const { text } = this.props;
    this.state = {
      limit: 10,
      offset: 0,
      companyList: [],
      apiOnScroll: false,
      isOpen: false,
      apiId: 0,
      minChar: 3,
      text: text || '',
    };

    this.requestTimer = null;
    this.mousedownSubKey = 0;
    this.myRef = React.createRef();
  }

  /**
   * Summary. Check valid API id
   *
   * Description. Check latest API id with state api id
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Integer}  id   API id
   */
  checkValidId = (id) => {
    const { apiId } = this.state;
    return id >= apiId;
  };

  /**
   * Summary. Company autoComplete API
   *
   * Description. To retrive all the company list using api call with limit and offset
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   text     autocomplete value
   * @param {Integer}  offset   offset for fetching the list
   */
  callCompanyApi = (text, offset) => {
    const { limit, apiId } = this.state;
    const apiId1 = apiId + 1;
    this.setState({
      apiId: apiId1,
    });

    axiosApi(
      `/manufacturers?text=${text}&limit=${limit}&offset=${offset}`,
      'GET',
      '',
      (res, id) => {
        if (this.checkValidId(id)) {
          if (!res.error) {
            const resObj = res.data.items;
            if (isEmpty(resObj)) {
              this.setState({
                companyList: [],
                isAutoCompleteData: false,
              });
            } else {
              if (offset === 0) {
                this.setState({
                  companyList: resObj,
                  isAutoCompleteData: true,
                });
              } else {
                this.setState((prevState) => ({
                  companyList: [...prevState.companyList, ...resObj],
                }));
              }
              let offset1 = 0;
              if (res.data.isMore) {
                offset1 = offset + limit;
              }
              this.setState({
                offset: offset1,
              });
            }
          }
        }
        this.setState({
          apiOnScroll: false,
        });
      },
      '',
      '',
      apiId1
    );
  };

  /**
   * Summary. On scroll event
   *
   * Description. Load more company list on scroll
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param  {Object}   e      event object
   */
  onScroll = (e) => {
    const { offset, apiOnScroll, text } = this.state;
    if (scrollCheck(e, offset, apiOnScroll)) {
      this.setState({
        apiOnScroll: true,
      });
      this.callCompanyApi(text, offset);
    }
  };

  /**
   * Summary. Call company Autocomplete API
   *
   * Description. Call the API with 250 ms timer (it prevents multiple api calls)
                  Also open the company dropdown list if available in api call
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}  value   input text value
   */
  callAutocomplete = (value) => {
    const { minChar } = this.state;
    if (value.length >= minChar) {
      const { isAutoCompleteData, text } = this.state;
      if (isAutoCompleteData === false && value.length > text.length) {
        return;
      }
      this.setState({
        companyList: [],
        isOpen: true,
      });
      clearTimeout(this.requestTimer);
      this.requestTimer = setTimeout(() => {
        this.callCompanyApi(value, 0);
      }, 250);
    } else {
      this.setState({
        isOpen: false,
        isAutoCompleteData: '',
      });
    }
  };

  /**
   * Summary. OnChange event
   *
   * Description. Input Change method for all input
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   e           Input element event object
   *
   */
  onChange = (e) => {
    const { onChange } = this.props;
    onChange(e);
    const { value } = e.target;
    this.setState({
      text: value,
    });
    this.callAutocomplete(value);
  };

  /**
   * Summary. On company click
   *
   * Description. Set the company and close dropdown list
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}  val   company value
   */
  onCompanyClick = (val) => {
    const { onCompanySelect } = this.props;
    onCompanySelect({ target: { value: val } });
    this.setState({
      text: val,
      isOpen: false,
    });
  };

  /**
   * Summary. Outside click event
   *
   * Description. Check if click event is occured not in the html part and closes
                  the popup on outside click
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   eventObj   click event object
   *
   */
  handleClickOutside = (eventObj) => {
    const { isOpen } = this.state;
    if (handleClickOutside(isOpen, this.myRef, eventObj)) {
      this.setState({
        isOpen: false,
      });
    }
  };

  componentDidMount() {
    this.callCompanyApi('', 0);
    // Mouse down event subscribe
    this.mousedownSubKey = PublishSubscribe.subscribe(
      PUB_SUB.MOUSEDOWN,
      this.handleClickOutside
    );
  }

  componentWillUnmount() {
    clearTimeout(this.requestTimer);
    // PublishSubscribe.unsubscribe(PUB_SUB.MOUSEDOWN, this.mousedownSubKey);
  }

  /**
   *  Toggle modal popup
   */
  companyOpen = () => {
    this.setState({
      isOpen: true,
      text: '',
    });
  };

  /**
   * Summary. company naame highlighted text
   *
   * Description. Check the input text and highlight the text accordingly
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param  {string}   text         company name
   * @param  {string}   higlight     highlighted text part
   */
  getHighlightedText = (text, higlight) => {
    const parts = text.split(new RegExp(`(${higlight})`, 'gi'));
    return parts.map((part) => (
      <span
        key={uuidv1()}
        style={
          part.toLowerCase() === higlight.toLowerCase()
            ? { textDecoration: 'underline' }
            : {}
        }
      >
        {part}
      </span>
    ));
  };

  /**
   * Summary. On keyDown event
   *
   * Description. Check if enter key pressed
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param  {Object}   e      event object
   */
  onKeyDown = (e) => {
    if (isEnterKeyPressed(e)) {
      const { onKeyDown } = this.props;
      onKeyDown(e);
      this.setState({
        isOpen: false,
      });
    }
  };

  render() {
    const { text, companyList, isOpen } = this.state;

    return (
      <>
        <MDBInput
          type="search"
          className="search_field"
          hint="Enter search text here"
          placeholder="Click here or begin typing a company"
          onChange={this.onChange}
          value={text}
          onFocus={this.onChange}
          name="textSearch"
          autoComplete="off"
          onKeyDown={this.onKeyDown}
          onClick={this.companyOpen}
        />
        {isOpen ? (
          <div className="search_list_wrap" ref={this.myRef}>
            <ul className="search_list_dtl" onScroll={this.onScroll}>
              {companyList.map((v) => {
                return (
                  <li
                    key={v.companyId}
                    onClick={() => {
                      this.onCompanyClick(v.companyName);
                    }}
                    role="presentation"
                    data-repcard-test="company"
                  >
                    {this.getHighlightedText(v.companyName, text)}
                  </li>
                );
              })}
            </ul>
          </div>
        ) : (
          ''
        )}
      </>
    );
  }
}

export default SearchCompanyList;
