/**
 *
 * Description. Filter Buttons
 *
 * @link   URL
 * @file   Common Module for filter's Apply and Reset btn html
 * @since  1.0.0
 */
import React from 'react';

/**
 * Summary. Filter and reset btn html
 *
 * Description. Return the html of Apply filter and reset btn for filters
 *
 * @since      1.0
 * @deprecated No //x.x.x Use new_function_name() instead.
 * @access     export private
 *
 * @param {function}   onFilterClick   callback function of Apply filter btn click
 * @param {function}   onResetClick    callback function of reset btn click
 * @param {boolean}    isBtnEnable     Flag for Apply filter btn enable/disable
 *
 */
const FilterButtons = ({ onFilterClick, onResetClick, isBtnEnable }) => {
  return (
    <>
      <button
        type="button"
        className={`fill-orange-btn ${
          isBtnEnable ? '' : 'noEvents background_grey'
        }`}
        onClick={onFilterClick}
      >
        Apply Filter
      </button>
      <div
        className="reset_filter"
        style={{ cursor: 'pointer' }}
        onClick={onResetClick}
        role="presentation"
      >
        <span className="reset_icon" /> Reset
      </div>
    </>
  );
};

export default FilterButtons;
