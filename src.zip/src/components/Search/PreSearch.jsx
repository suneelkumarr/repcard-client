/**
 *
 * Description. PreSearch
 *
 * @link   URL
 * @file   Calls Provider verifed API, My Account API, payment API and display information accordingly
           Loads master productcategory data so it can use further pages
 * @since  1.0.0
 */
import React, { Component, lazy, Suspense } from 'react';
import isEmpty from 'lodash/isEmpty';
import { MDBRow, MDBCol, MDBContainer } from 'mdbreact';
import Header from '../NavHeader/ProviderHeader/Header';
import Footer from '../Footer/Footer';
import { getMasterProductCategoryData } from '../../utils/masterProductCategoryData';
import { getSubscriptionApi } from '../../utils/stripeApis';
import app from '../../helpers/appGlobal';
import { axiosApi } from '../../apis/axiosApiCall';
import { getBasicPlan } from '../../utils/getPlanInfo';

const Loading = () => <div>Loading...</div>;
const Search = lazy(() => import('./Search.jsx'));
const RepGrid = lazy(() => import('./RepGrid.jsx'));
const Favourites = lazy(() => import('../Favourites/Favourites.jsx'));
// const UpgradeBox = lazy(() => import('../Upgrade/UpgradeBox.jsx'));
const ProviderDashboard = lazy(() =>
  import('../ProviderDashboard/ProviderDashboard.jsx')
);

class PreSearch extends Component {
  constructor(props) {
    super(props);
    this.state = {
      keyVal: 0,
      masterAPICalled: true,
      isAPICalled: true,
      isCustomerAPI: true,
      status: app.user.status,
      profileRes: {},
      repsForGrid: [],
      text: '',
      searchby: '',
    };

    this.ref = React.createRef();
  }

  /**
   * Summary. Payment API
   *
   * Description. To retrive all the payment related info (plan details)
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   subscriptionId        Plan subscription id
   *
   */
  getPaymentInfoAPI = (subscriptionId) => {
    if (subscriptionId) {
      this.setState({
        isCustomerAPI: true,
      });
      getSubscriptionApi(subscriptionId, (plan) => {
        if (plan) {
          this.setState({
            planDetails: plan,
          });
        }
        this.setState({
          isCustomerAPI: false,
        });
      });
    } else {
      this.setState({
        isCustomerAPI: false,
      });
    }
  };

  /**
   * Summary. Get My Account Information
   *
   * Description. Call API for Provider to get my account data
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  getMyAccountApi = () => {
    const { id } = app.user;
    axiosApi(`/providerProfile/getMyAccountProfile/${id}`, 'GET', '', (res) => {
      if (!isEmpty(res.data)) {
        this.setState({
          profileRes: res.data,
        });
        this.getPaymentInfoAPI(res.data.subscriptionId);
      } else {
        this.getPaymentInfoAPI('');
      }
    });
  };

  showRepGrid = (repsForGrid, text) => {
    this.setState({
      isRepGrid: true,
      repsForGrid,
      text,
      searchby: 'product',
    });
  };

  backFromRepGrid = () => {
    this.setState({
      isRepGrid: false,
      repsForGrid: [],
    });
  };

  componentDidMount() {
    const { status } = this.state;
    if (status === 'verified') {
      this.setState({
        isAPICalled: false,
      });
    } else {
      this.isVerifiedApi(); // Check status API
    }
    this.getMasterProductCategoryData(); // Load master productcategory data
    this.getMyAccountApi(); // Load My Account data
  }

  /**
   * Summary. Status Verification API
   *
   * Description. To retrive Provider's verification status flag
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   *
   */
  isVerifiedApi = () => {
    const { id, userType } = app.user;
    axiosApi(`/getStatus/${id}?userType=${userType}`, 'GET', '', (res) => {
      if (res.error) {
        console.log(res.message);
      } else if (res.data) {
        this.setState({
          status: res.data.status,
        });
      }
      this.setState({
        isAPICalled: false,
      });
    });
  };

  /**
   * Summary. Load Master ProductCategory Data
   *
   * Description. Call API for Master data of productcategory
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  getMasterProductCategoryData = () => {
    getMasterProductCategoryData((flag) => {
      if (flag) {
        this.setState({
          masterAPICalled: false,
        });
      }
    });
  };

  // Success function of OTP verified
  otpVerify = (status) => {
    this.setState(
      {
        status,
      },
      () => {
        this.getMyAccountApi();
      }
    );
  };

  /**
   * Summary. Favourites set/reset callback function
   *
   * Description. Reload the favourite page on update of favourite.
   *              Also update the search if any grid is available
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   id       Rep's User ID whose favourite is set/unset
   *
   */
  updateFavourites = (id) => {
    this.setState((prevState) => ({
      keyVal: prevState.keyVal + 1,
    }));
    if (id && this.ref && this.ref.current) {
      this.ref.current.updateSearchFavourites(id);
    }
  };

  render() {
    const {
      masterAPICalled,
      isCustomerAPI,
      isAPICalled,
      status,
      planDetails,
      keyVal,
      profileRes,
      isRepGrid,
      repsForGrid,
      text,
      searchby,
    } = this.state;

    const isBasicPlan = getBasicPlan(planDetails);

    return (
      <>
        <Header
          profileRes={profileRes}
          isAPINotNeeded
          isSearch
          showClaimBtn
          reps={repsForGrid}
          backFromRepGrid={this.backFromRepGrid}
        />
        <MDBContainer>
          <MDBRow>
            <MDBCol lg="12" className="my-5">
              <Suspense fallback={<Loading />}>
                {isCustomerAPI ? (
                  'Please wait'
                ) : status === 'verified' ? (
                  masterAPICalled ? (
                    'Please wait'
                  ) : isRepGrid ? (
                    <RepGrid
                      reps={repsForGrid}
                      backFromRepGrid={this.backFromRepGrid}
                    />
                  ) : (
                    <MDBRow className="search_reverse">
                      <MDBCol lg="3" className="pr-0">
                        {/* {isBasicPlan ? (
                          <UpgradeBox />
                        ) : ( */}
                        <Favourites
                          key={keyVal}
                          updateFavourites={this.updateFavourites}
                        />
                        {/* )} */}
                      </MDBCol>
                      <MDBCol lg="9">
                        <Search
                          ref={this.ref}
                          updateFavourites={this.updateFavourites}
                          showRepGrid={this.showRepGrid}
                          text={text}
                          searchby={searchby}
                          isBasicPlan={isBasicPlan}
                        />
                      </MDBCol>
                    </MDBRow>
                  )
                ) : isAPICalled ? (
                  'Please wait...'
                ) : (
                  <>
                    <MDBRow className="search_reverse">
                      <MDBCol lg="3" className="pr-0">
                        <div className="rep_left_panel">
                          {/* {isBasicPlan ? (
                            <UpgradeBox />
                          ) : ( */}
                          <Favourites
                            key={keyVal}
                            updateFavourites={this.updateFavourites}
                          />
                          {/* )} */}
                        </div>
                      </MDBCol>
                      <MDBCol lg="9">
                        <ProviderDashboard otpVerify={this.otpVerify} />
                      </MDBCol>
                    </MDBRow>
                  </>
                )}
              </Suspense>
            </MDBCol>
          </MDBRow>
        </MDBContainer>
        <Footer />
      </>
    );
  }
}

export default PreSearch;
