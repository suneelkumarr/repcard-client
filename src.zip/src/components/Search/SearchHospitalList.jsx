/**
 *
 * Description. Seacrh by hospital Autocomplete
 *
 * @link   URL
 * @file   User can type the hospital name and hospital list will appear in drop-down
           Select the hospital name and filter the data accordingly
 * @since  1.0.0
 */
import React, { Component } from 'react';
import { MDBInput } from 'mdbreact';
import PublishSubscribe from 'publish-subscribe-js';
import PUB_SUB from '../../constants/events.constant';
import { axiosApi } from '../../apis/axiosApiCall';
import handleClickOutside from '../../utils/handleClickOutside';

class SearchHospitalList extends Component {
  constructor(props) {
    super(props);
    this.state = {
      open: props.open,
      currentId: '',
      selectedState: [],
      cityFilterArr: [],
      hospitalSearch: props.searchText || '',
      searchResults: [],
      selectedCityHospitals: [],
      selectedHospital: '',
      isAPICalled: false,
    };

    this.mousedownSubKey = 0;
    this.myRef = React.createRef();
    this.myRef1 = React.createRef();
    this.timeout = null;
  }

  /**
   * Summary. City Master data prefill
   *
   * Description. Load all the city master data values
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  preFillValues = () => {
    const { selectedHospital } = this.props;
    this.setState({
      selectedHospital,
    });
  };

  /**
   * Summary. Outside click event
   *
   * Description. Check if click event is occured not in the html part and closes
                  the popup on outside click
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   eventObj   click event object
   *
   */
  handleClickOutside = (eventObj) => {
    const { open } = this.state;
    const { handleClose } = this.props;
    if (handleClickOutside(open, this.myRef, eventObj, this.myRef1)) {
      if (handleClose) handleClose();
      this.setState({
        open: false,
      });
    }
  };

  componentDidMount() {
    // Mouse down event to check outside click
    this.mousedownSubKey = PublishSubscribe.subscribe(
      PUB_SUB.MOUSEDOWN,
      this.handleClickOutside
    );
    this.preFillValues();
  }

  componentDidUpdate(prevProps) {
    const { searchText } = this.props;
    if (prevProps.searchText !== searchText)
      this.updateHospitalSearch({ target: { value: searchText } });
  }

  componentWillUnmount() {
    PublishSubscribe.unsubscribe(PUB_SUB.MOUSEDOWN, this.mousedownSubKey);
  }

  /**
   *  Toggle modal popup
   */
  hospitalOpen = () => {
    const { handleOpen } = this.props;
    if (handleOpen) handleOpen();
    this.setState({
      open: true,
      hospitalSearch: '',
      searchResults: [],
    });
  };

  /**
   * Summary. state click
   *
   * Description. set state
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   stateId    id of the selected state
   *
   */
  onClick = (stateId) => {
    this.setState({
      currentId: stateId,
    });
  };

  /**
   * Summary. Search input
   *
   * Description. Input Change method for search input. Uses setTimeout to only re-render when user has stopped typing.
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   e           Input element event object
   *
   */
  updateHospitalSearch = (e) => {
    clearTimeout(this.timeout);
    const { value } = e.target;
    if (value.length > 2) {
      this.timeout = setTimeout(() => {
        this.setState(
          {
            hospitalSearch: value.toLowerCase(),
          },
          () => {
            this.searchForHospital();
          }
        );
      }, 250);
    } else {
      this.setState({
        hospitalSearch: value.toLowerCase(),
        searchResults: [],
        selectedCityHospitals: [],
        selectedHospital: '',
        cityFilterArr: [],
        currentId: '',
      });
    }
  };

  /**
   * Summary. city checkbox change
   *
   * Description. Set/Reset cities and state
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Object}   e               event object
   * @param {Object}   city            city object
   * @param {Object}   mainState       state object
   *
   */
  onChangeCheckbox = (e, city, mainState) => {
    const { checked } = e.target;
    const { selectedState, cityFilterArr } = this.state;
    const cityId = city.id;
    const stateId = mainState.id;
    const stateName = mainState.state;
    const index = selectedState.findIndex((s) => s.id === stateId);
    let newSelectedStateArr = [];
    let newCityFilterArr = [];

    if (index === -1) {
      if (checked) {
        newSelectedStateArr = [
          ...newSelectedStateArr,
          { id: stateId, state: stateName, cities: [city] },
        ];
        newCityFilterArr = [cityId];
      }
    } else {
      newSelectedStateArr = [...selectedState];
      newCityFilterArr = [...cityFilterArr];
      if (checked) {
        newSelectedStateArr[index].cities = [
          ...newSelectedStateArr[index].cities,
          city,
        ];
        newCityFilterArr = [cityId];
      } else {
        newSelectedStateArr[index].cities = newSelectedStateArr[
          index
        ].cities.filter((c) => c.id !== cityId);
        if (!newSelectedStateArr[index].cities.length) {
          newSelectedStateArr = [];
        }
        newCityFilterArr = newCityFilterArr.filter((c) => c !== cityId);
      }
    }

    this.setState({
      selectedState: newSelectedStateArr,
      cityFilterArr: newCityFilterArr,
      selectedCityHospitals: [],
      selectedHospital: '',
    });

    const urlname = `/hospitals/search/getAllHospitalsByCityId?cityId=${city.id}`;
    axiosApi(urlname, 'GET', '', (res) => {
      if (res.data && res.data.length > 0) {
        this.setState({
          selectedCityHospitals: res.data,
        });
      }
    });
  };

  onHospitalClick = (e, val) => {
    const { checked } = e.target;
    const { onHospitalSelect } = this.props;
    const newSelectedHospital = checked ? val : '';

    onHospitalSelect({ target: { value: newSelectedHospital } });
    this.setState({
      selectedHospital: newSelectedHospital,
    });
  };

  onHospitalClickGetData = (e, data) => {
    const { checked } = e.target;
    const { onHospitalSelect } = this.props;
    const newSelectedHospital = checked ? data.hospital : '';

    onHospitalSelect({ target: { value: data } });
    this.setState({
      selectedHospital: newSelectedHospital,
    });
  };

  searchForHospital = () => {
    const { hospitalSearch } = this.state;
    const urlname = `/hospitals/search/getStatesAndCitiesByHospitalName?name=${hospitalSearch}`;

    this.setState({
      isAPICalled: true,
    });
    axiosApi(urlname, 'GET', '', (res) => {
      if (res.error) {
        console.log(res.error);
        this.setState({
          isAPICalled: false,
        });
      } else if (res.data) {
        this.setState({
          searchResults: res.data,
          isAPICalled: false,
        });
      }
    });
  };

  render() {
    const {
      open,
      currentId,
      selectedState,
      cityFilterArr,
      searchResults,
      selectedCityHospitals,
      selectedHospital,
      hospitalSearch,
      isAPICalled,
    } = this.state;
    const { masterStateList, hideText, searchText } = this.props;

    const isSearch = searchResults.length > 0;
    const stateList = isSearch ? searchResults : masterStateList;

    return (
      <>
        <div
          className="search_field productcategory_select"
          onClick={this.hospitalOpen}
          role="presentation"
          ref={this.myRef1}
          data-repcard-test="popup"
        >
          {hideText ? null : selectedHospital ? (
            <span className="productcategory_placeholder selected_productcategory">
              {selectedState[0] &&
                `${selectedState[0].state} - ${selectedState[0].cities[0].city} - `}
              {selectedHospital}
            </span>
          ) : (
            <span className="productcategory_placeholder">
              Click here or begin typing an account name
            </span>
          )}
        </div>
        {open ? (
          <div className="productcategory_sub_list" ref={this.myRef}>
            <ul className="search_list_dtl">
              <li>
                {searchText === undefined ? (
                  <MDBInput
                    type="text"
                    placeholder="Begin typing here for search"
                    className="d-inline-block"
                    maxLength="50"
                    hint="enter account name search text here"
                    onChange={this.updateHospitalSearch}
                  />
                ) : null}
              </li>
              {hospitalSearch && isAPICalled ? (
                <li>Please wait...</li>
              ) : (
                stateList.map((state) => {
                  const { cities } = state;
                  const isSelected = currentId === state.id;

                  return (
                    <li
                      key={state.id}
                      onClick={() => {
                        this.onClick(state.id);
                      }}
                      data-repcard-test="state"
                      role="presentation"
                    >
                      {state.state}
                      {isSelected || isSearch ? (
                        <ul>
                          {cities.map((city) => {
                            let hospitals = selectedCityHospitals;
                            let checked = cityFilterArr.indexOf(city.id) !== -1;
                            let shouldShowHospitals =
                              checked && hospitals.length > 0;

                            if (isSearch) {
                              hospitals = city.hospitals || [];
                              checked = !!hospitals.find(
                                (h) => h.hospital === selectedHospital
                              );
                              shouldShowHospitals = hospitals.length > 0;
                            }

                            return (
                              <li key={city.id}>
                                <MDBInput
                                  label={city.city}
                                  filled
                                  type="checkbox"
                                  id={`productcategoryFilter${city.id}`}
                                  checked={checked}
                                  onChange={(e) => {
                                    this.onChangeCheckbox(e, city, state);
                                  }}
                                />
                                {shouldShowHospitals ? (
                                  <ul>
                                    {hospitals.map((h) => {
                                      return (
                                        <li key={h.id}>
                                          <MDBInput
                                            label={h.hospital}
                                            filled
                                            type="checkbox"
                                            id={`hospitalSelect${h.id}`}
                                            checked={
                                              h.hospital === selectedHospital
                                            }
                                            onChange={(e) => {
                                              if (hideText)
                                                this.onHospitalClickGetData(
                                                  e,
                                                  h
                                                );
                                              else
                                                this.onHospitalClick(
                                                  e,
                                                  h.hospital
                                                );
                                            }}
                                          />
                                        </li>
                                      );
                                    })}
                                  </ul>
                                ) : (
                                  ''
                                )}
                              </li>
                            );
                          })}
                        </ul>
                      ) : (
                        ''
                      )}
                    </li>
                  );
                })
              )}
            </ul>
          </div>
        ) : (
          ''
        )}
      </>
    );
  }
}

export default SearchHospitalList;
