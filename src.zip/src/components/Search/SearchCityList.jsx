/**
 *
 * Description. Search by city
 *
 * @link   URL
 * @file   User can choose state with city from drop down and then
           filters the search results. (All the city can be choosen
           but for Only 1 state) Can't select multiple states
 * @since  1.0.0
 */
import React, { Component } from 'react';
import { MDBInput } from 'mdbreact';
import PublishSubscribe from 'publish-subscribe-js';
import PUB_SUB from '../../constants/events.constant';
import handleClickOutside from '../../utils/handleClickOutside';

class SearchCityList extends Component {
  constructor(props) {
    super(props);
    this.state = {
      open: false,
      currentId: '',
      selectedState: [],
      cityFilterArr: [],
      masterStateList: props.masterStateList,
      // citySearch: '', unused...
    };

    this.mousedownSubKey = 0;
    this.myRef = React.createRef();
    this.myRef1 = React.createRef();
    this.timeout = null;
  }

  /**
   * Summary. City Master data prefill
   *
   * Description. Load all the city master data values
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  preFillValues = () => {
    const { cityFilterArr } = this.props;
    if (cityFilterArr.length) {
      let stateId = '';
      let stateName = '';
      let newArr = [];
      const { masterStateList } = this.state;
      masterStateList.forEach((s) => {
        s.cities.forEach((c) => {
          if (cityFilterArr.indexOf(c.id) !== -1) {
            stateId = s.id;
            stateName = s.state;
            newArr = [...newArr, c];
          }
        });
      });

      if (stateId) {
        const newStateArr = [
          {
            id: stateId,
            state: stateName,
            cities: newArr,
          },
        ];
        this.setState({
          selectedState: newStateArr,
          cityFilterArr,
          currentId: stateId,
        });
      }
    }
  };

  /**
   * Summary. Outside click event
   *
   * Description. Check if click event is occured not in the html part and closes
                  the popup on outside click
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   eventObj   click event object
   *
   */
  handleClickOutside = (eventObj) => {
    const { open } = this.state;
    if (handleClickOutside(open, this.myRef, eventObj, this.myRef1)) {
      this.setState({
        open: false,
      });
    }
  };

  componentDidMount() {
    // Mouse down event to check outside click
    this.mousedownSubKey = PublishSubscribe.subscribe(
      PUB_SUB.MOUSEDOWN,
      this.handleClickOutside
    );
    this.preFillValues();
  }

  componentWillUnmount() {
    // PublishSubscribe.unsubscribe(PUB_SUB.MOUSEDOWN, this.mousedownSubKey);
  }

  /**
   *  Toggle modal popup
   */
  cityOpen = () => {
    this.setState({
      open: true,
      stateSearch: '',
    });
  };

  /**
   * Summary. state click
   *
   * Description. set state
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   stateId    id of the selected state
   *
   */
  onClick = (stateId) => {
    this.setState({
      currentId: stateId,
    });
  };

  /**
   * Summary. Search input
   *
   * Description. Input Change method for search input. Uses setTimeout to only re-render when user has stopped typing.
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   e           Input element event object
   *
   */
  updateProductSearch = (e) => {
    clearTimeout(this.timeout);
    const { value } = e.target;
    this.timeout = setTimeout(() => {
      this.setState({
        stateSearch: value.toLowerCase(),
      });
    }, 250);
  };

  onSelectAll = (e, stateId) => {
    const { checked } = e.target;
    const { masterStateList } = this.state;
    const selectedState = masterStateList.find((s) => s.id === stateId);
    const newSelectedState = { ...selectedState };
    const newCityFilterArr = checked
      ? newSelectedState.cities.map((c) => c.id)
      : [];

    this.setState({
      currentId: newSelectedState.id,
      selectedState: [newSelectedState],
      cityFilterArr: newCityFilterArr,
    });

    const { onSetCity } = this.props;
    onSetCity(newCityFilterArr);
  };

  /**
   * Summary. city checkbox change
   *
   * Description. Set/Reset cities and state
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Object}   e               event object
   * @param {Object}   city            city object
   * @param {Object}   mainState       state object
   *
   */
  onChangeCheckbox = (e, city, mainState) => {
    const { checked } = e.target;
    const { selectedState, cityFilterArr } = this.state;
    const cityId = city.id;
    const stateId = mainState.id;
    const stateName = mainState.state;
    const index = selectedState.findIndex((s) => s.id === stateId);
    let newSelectedStateArr = [];
    let newCityFilterArr = [];

    if (index === -1) {
      if (checked) {
        newSelectedStateArr = [
          ...newSelectedStateArr,
          { id: stateId, state: stateName, cities: [city] },
        ];
        newCityFilterArr = [...newCityFilterArr, cityId];
      }
    } else {
      newSelectedStateArr = [...selectedState];
      newCityFilterArr = [...cityFilterArr];
      if (checked) {
        newSelectedStateArr[index].cities = [
          ...newSelectedStateArr[index].cities,
          city,
        ];
        newCityFilterArr = [...newCityFilterArr, cityId];
      } else {
        newSelectedStateArr[index].cities = newSelectedStateArr[
          index
        ].cities.filter((c) => c.id !== cityId);
        if (!newSelectedStateArr[index].cities.length) {
          newSelectedStateArr = [];
        }
        newCityFilterArr = newCityFilterArr.filter((c) => c !== cityId);
      }
    }

    this.setState({
      currentId: newSelectedStateArr[0].id,
      selectedState: newSelectedStateArr,
      cityFilterArr: newCityFilterArr,
    });

    const { onSetCity } = this.props;
    onSetCity(newCityFilterArr);
  };

  render() {
    const {
      open,
      currentId,
      selectedState,
      cityFilterArr,
      masterStateList,
      stateSearch,
    } = this.state;

    return (
      <>
        <div
          className="search_field productcategory_select"
          onClick={this.cityOpen}
          role="presentation"
          ref={this.myRef1}
          data-repcard-test="popup"
        >
          {cityFilterArr.length ? (
            <span className="productcategory_placeholder selected_productcategory">
              {selectedState[0].state} -{' '}
              {cityFilterArr.length === 1
                ? selectedState[0].cities[0].city
                : `${cityFilterArr.length} Cities`}
            </span>
          ) : (
            <span className="productcategory_placeholder">
              Click here or begin typing a city
            </span>
          )}
        </div>
        {open ? (
          <div className="productcategory_sub_list" ref={this.myRef}>
            <ul className="search_list_dtl">
              <li>
                <MDBInput
                  type="text"
                  maxLength="50"
                  placeholder="Begin typing here for search"
                  className="d-inline-block"
                  hint="enter search text here"
                  onChange={this.updateProductSearch}
                />
              </li>
              {masterStateList.map((state) => {
                let { cities } = state;
                if (stateSearch) {
                  cities = cities.filter((city) => {
                    return city.city.toLowerCase().includes(stateSearch);
                  });
                }
                const isSearchMatch = stateSearch ? cities.length > 0 : false;

                const isSelected = stateSearch
                  ? isSearchMatch
                  : currentId === state.id;

                if (stateSearch && !isSearchMatch) {
                  return null;
                }

                return (
                  <li
                    key={state.id}
                    onClick={() => {
                      this.onClick(state.id);
                    }}
                    data-repcard-test="state"
                    role="presentation"
                  >
                    {state.state}
                    {isSelected || isSearchMatch ? (
                      <ul>
                        {isSelected && !isSearchMatch ? (
                          <li key={`selectAllCities${state.id}`}>
                            <MDBInput
                              label="Select All"
                              filled
                              type="checkbox"
                              id={`selectAllCities${state.id}`}
                              onChange={(e) => {
                                this.onSelectAll(e, state.id);
                              }}
                            />
                          </li>
                        ) : (
                          ''
                        )}
                        {cities.map((city) => {
                          return (
                            <li key={city.id}>
                              <MDBInput
                                label={city.city}
                                filled
                                type="checkbox"
                                id={`productcategoryFilter${city.id}`}
                                checked={cityFilterArr.indexOf(city.id) !== -1}
                                onChange={(e) => {
                                  this.onChangeCheckbox(e, city, state);
                                }}
                              />
                            </li>
                          );
                        })}
                      </ul>
                    ) : (
                      ''
                    )}
                  </li>
                );
              })}
            </ul>
          </div>
        ) : (
          ''
        )}
      </>
    );
  }
}

export default SearchCityList;
