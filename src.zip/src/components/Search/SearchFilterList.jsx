import React from 'react';
import { MDBInput } from 'mdbreact';

/**
 * Summary. Seacrh filter company list
 *
 * Description. Display All the company list which is used in filter section
 *
 * @since      1.0
 * @deprecated No //x.x.x Use new_function_name() instead.
 * @access     export public
 *
 * @param  {function}   onScroll        callback function of scroll
 * @param  {Array}      companyList     list of companies
 * @param  {Array}      companyArr      Selected company array
 * @param  {function}   onChange        callback function of checkbox change
 * @param  {boolean}    isAPICalled     flag for wait for an api
 */
export const SearchFilterListCompany = ({
  onScroll,
  companyList,
  companyArr,
  onChange,
  isAPICalled,
}) => {
  if (isAPICalled && !companyList.length) {
    return 'Please wait';
  }
  return (
    <ul className="filter-list overflow-lists" onScroll={onScroll}>
      {companyList.map((v) => {
        const companyId = v.id || v.companyId;
        const companyName = v.name || v.companyName;
        const item = { id: companyId, name: companyName };
        return (
          <li key={companyId}>
            <MDBInput
              label={companyName}
              filled
              type="checkbox"
              checked={companyArr.indexOf(item.name) !== -1}
              id={`filtermain${companyId}`}
              onChange={(e) => {
                onChange(e, item);
              }}
            />
          </li>
        );
      })}
    </ul>
  );
};

/**
 * Summary. Search filter productcategory list
 *
 * Description. Display All the productcategories which is used in filter section
 *
 * @since      1.0
 * @deprecated No //x.x.x Use new_function_name() instead.
 * @access     export public
 *
 * @param  {Array}      productcategoryList      list of productcategories
 * @param  {function}   onScroll            callback function of scroll
 * @param  {function}   onSubCategoryChange callback function of sub category checkbox change
 * @param  {function}   onChange            callback function of main category checkbox change
 * @param  {boolean}    isAPICalled         flag for wait for an api
 */
export const SearchFilterListProductCategory = ({
  productcategoryList,
  onScroll,
  onChange,
  onSubCategoryChange,
  isAPICalled,
}) => {
  if (isAPICalled && !productcategoryList.length) {
    return 'Please wait';
  }
  return (
    <ul className="filter-list overflow-lists" onScroll={onScroll}>
      {productcategoryList.map((v) => {
        return (
          <li key={v.productcategoryId}>
            <MDBInput
              label={v.productcategoryName}
              onChange={(e) => {
                onChange(e, v.productcategoryId);
              }}
              checked={v.checked}
              filled
              type="checkbox"
              id={`filter${v.productcategoryId}`}
            />
            {v.checked ? (
              <ul className="filter-list ml-3">
                {v.productlines.map((item) => {
                  return (
                    <li key={item.id}>
                      <MDBInput
                        label={item.name}
                        onChange={(e) => {
                          onSubCategoryChange(e, item, v);
                        }}
                        checked={item.checked}
                        filled
                        type="checkbox"
                        id={`filtersubcat${item.id}`}
                      />
                    </li>
                  );
                })}
              </ul>
            ) : (
              ''
            )}
          </li>
        );
      })}
    </ul>
  );
};

/**
 * Summary. Seacrh filter hospital list
 *
 * Description. Display All the hospital list which is used in filter section
 *
 * @since      1.0
 * @deprecated No //x.x.x Use new_function_name() instead.
 * @access     export public
 *
 * @param  {function}   onScroll        callback function of scroll
 * @param  {Array}      hospitalList     list of hospitals
 * @param  {Array}      hospitalArr      Selected hospital array
 * @param  {function}   onChange        callback function of checkbox change
 * @param  {boolean}    isAPICalled     flag for wait for an api
 */
export const SearchFilterListHospital = ({
  onScroll,
  hospitalList,
  hospitalArr,
  onChange,
  isAPICalled,
}) => {
  if (isAPICalled && !hospitalList.length) {
    return 'Please wait';
  }
  return (
    <ul className="filter-list overflow-lists" onScroll={onScroll}>
      {hospitalList.map((h) => {
        const item = { id: h.id, name: h.name };
        return (
          <li key={h.id}>
            <MDBInput
              label={h.name}
              filled
              type="checkbox"
              checked={hospitalArr.indexOf(h.id) !== -1}
              id={`filtermain${h.id}`}
              onChange={(e) => {
                onChange(e, item);
              }}
            />
          </li>
        );
      })}
    </ul>
  );
};

/**
 * Summary. Search filter city list
 *
 * Description. Display All the cities which are used in filter section
 *
 * @since      1.0
 * @deprecated No //x.x.x Use new_function_name() instead.
 * @access     export public
 *
 * @param  {Array}      stateList           list of states/cities
 * @param  {function}   onScroll            callback function of scroll
 * @param  {function}   onSubCategoryChange callback function of sub category checkbox change
 * @param  {function}   onChange            callback function of main category checkbox change
 * @param  {boolean}    isAPICalled         flag for wait for an api
 */
export const SearchFilterListCity = ({
  stateList,
  onScroll,
  onChange,
  onSubCategoryChange,
  isAPICalled,
}) => {
  if (isAPICalled && !stateList.length) {
    return 'Please wait';
  }
  return (
    <ul className="filter-list overflow-lists" onScroll={onScroll}>
      {stateList.map((state) => {
        return (
          <li key={state.id}>
            <MDBInput
              label={state.state}
              onChange={(e) => {
                onChange(e, state.id);
              }}
              checked={state.checked}
              filled
              type="checkbox"
              id={`filter${state.id}`}
            />
            {state.checked ? (
              <ul className="filter-list ml-3">
                {state.cities.map((city) => {
                  return (
                    <li key={city.id}>
                      <MDBInput
                        label={city.city}
                        onChange={(e) => {
                          onSubCategoryChange(e, city, state);
                        }}
                        checked={city.checked}
                        filled
                        type="checkbox"
                        id={`filtersubcat${city.id}`}
                      />
                    </li>
                  );
                })}
              </ul>
            ) : (
              ''
            )}
          </li>
        );
      })}
    </ul>
  );
};
