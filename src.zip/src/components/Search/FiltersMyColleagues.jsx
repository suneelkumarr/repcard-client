/**
 *
 * Description. Filters (My Colleagues page)
 *
 * @link   URL
 * @file   Filters for Rep's search by company and productcategory
           (whatever is available in search results for displaying company and productcategory)
           User can do the filtering by choosing any of these things.
 * @since  1.0.0
 */
import React, { Component } from 'react';
import uniq from 'lodash/uniq';
import {
  SearchFilterListHospital,
  SearchFilterListProductCategory,
  SearchFilterListCity,
} from './SearchFilterList';
import FilterButtons from './FilterButtons';
import { axiosApi } from '../../apis/axiosApiCall';
import getCancelToken from '../../apis/getCancelToken';
import scrollCheck from '../../utils/scrollCheck';
import ClickAwayListner from '../Common/ClickAwayListner';
import app from '../../helpers/appGlobal';

const getPreFiltersArrProductCategory = (masterData, filterArr) => {
  if (filterArr.length) {
    masterData.forEach((v) => {
      v.productlines.forEach((item) => {
        if (filterArr.indexOf(item.id) !== -1) {
          item.checked = true; // eslint-disable-line
          v.checked = true; // eslint-disable-line
        }
      });
    });
  }
  return masterData;
};

const getPreFiltersArrCity = (masterData, filterArr) => {
  if (filterArr.length) {
    masterData.forEach((s) => {
      s.cities.forEach((city) => {
        if (filterArr.indexOf(city.id) !== -1) {
          city.checked = true; // eslint-disable-line
          s.checked = true; // eslint-disable-line
        }
      });
    });
  }
  return masterData;
};

class FiltersMyColleagues extends Component {
  constructor(props) {
    super(props);
    const {
      hospitalArr,
      productcategoryFilterArr,
      masterStateList,
      stateList,
      cityFilterArr,
      tagHospitalList,
      tagProductCategoryArr,
      tagCityArr,
    } = this.props;
    let isSelected = '';
    if (hospitalArr && hospitalArr.length) {
      isSelected = 'isHospital';
    } else if (
      !this.checkIsProductCategorySearch() &&
      productcategoryFilterArr &&
      productcategoryFilterArr.length
    ) {
      isSelected = 'isProductCategory';
    } else if (
      !this.checkIsCitySearch() &&
      cityFilterArr &&
      cityFilterArr.length
    ) {
      isSelected = 'isCity';
    }
    this.state = {
      limit: 10,
      offset: 0,
      limit1: 20,
      offset1: 0,
      limit2: 20,
      offset2: 0,
      cityArr: [],
      hospitalList: [],
      hospitalArr: hospitalArr || [],
      productcategoryList: [],
      productcategoryFilterArr: productcategoryFilterArr || [],
      masterStateList,
      stateList: stateList || [],
      cityFilterArr: cityFilterArr || [],
      isAPICalled: false,
      apiOnScroll: false,
      isAPICalled1: false,
      isAPICalled2: false,
      apiOnScroll1: false,
      isSelected,
      tagHospitalList,
      tagProductCategoryArr,
      tagCityArr,
    };
  }

  /**
   *  Check and return true/false from searchBy value
   */
  checkSearchBy = (fromWhere) => {
    const { searchby } = this.props;
    return searchby === fromWhere;
  };

  /**
   *  Check if selection is for search by name
   */
  checkIsNameSearch = () => {
    return this.checkSearchBy('name');
  };

  /**
   *  Check if selection is for search by company
   */
  checkIsHospitalSearch = () => {
    return this.checkSearchBy('hospital');
  };

  /**
   *  Check if selection is for search by productcategory
   */
  checkIsProductCategorySearch = () => {
    return this.checkSearchBy('productcategory');
  };

  /**
   *  Check if selection is for search by city
   */
  checkIsCitySearch = () => {
    return this.checkSearchBy('city');
  };

  /**
   *  Check if selection is for search by product
   */
  checkIsProductSearch = () => {
    return this.checkSearchBy('product');
  };

  componentDidMount() {
    // Don't call hospital API in case of search by hospital
    if (!this.checkIsHospitalSearch()) {
      this.callHospitalApi();
    }
    // Don't call productcategory API in case of search by productcategory
    if (!this.checkIsProductCategorySearch()) {
      this.callProductCategoryApi();
    }
    // Don't call city API in case of search by city
    if (!this.checkIsCitySearch()) {
      this.callCityApi();
    }
  }

  componentWillUnmount() {
    this.cancelAPIreq(); // Cancel API req if api is in progress
  }

  /**
   *  To cancel Api reuqest
   */
  cancelAPIreq() {
    const { source, source1 } = this.state;
    if (source) {
      source.cancel('API request canceled.');
    }
    if (source1) {
      source1.cancel('API request canceled.');
    }
  }

  /**
   * Summary. ProductCategory main category checkbox change
   *
   * Description. Set/Reset productcategories to productcategoryList
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Object}   e               event object
   * @param {Object}   productcategoryId    id of the productcategory
   *
   */
  handleCheckChangeProductCategory = (e, productcategoryId) => {
    const { checked } = e.target;
    const {
      productcategoryList,
      productcategoryFilterArr,
      tagProductCategoryArr,
    } = this.state;
    const newArr = [...productcategoryList];
    let newproductcategoryFilterArr = [...productcategoryFilterArr];
    let newtagProductCategoryArr = [...tagProductCategoryArr];
    const index = productcategoryList.findIndex(
      (v) => v.productcategoryId === productcategoryId
    );
    newArr[index].checked = checked;
    if (!checked) {
      newArr[index].productlines.forEach((v) => {
        v.checked = false; // eslint-disable-line
        newproductcategoryFilterArr = newproductcategoryFilterArr.filter(
          (val) => val !== v.id
        );
      });
      newtagProductCategoryArr = newtagProductCategoryArr.filter(
        (v) => v.productcategoryId !== productcategoryId
      );
    }
    this.setState({
      productcategoryList: newArr,
      productcategoryFilterArr: newproductcategoryFilterArr,
      tagProductCategoryArr: newtagProductCategoryArr,
    });
  };

  /**
   * Summary. State main category checkbox change
   *
   * Description. Set/Reset state to stateList
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Object}   e               event object
   * @param {Object}   stateId         id of the state
   *
   */
  handleCheckChangeCity = (e, stateId) => {
    const { checked } = e.target;
    const { stateList, cityFilterArr, tagCityArr } = this.state;
    const newArr = [...stateList];
    let newCityFilterArr = [...cityFilterArr];
    let newTagCityArr = [...tagCityArr];
    const index = stateList.findIndex((s) => s.id === stateId);
    newArr[index].checked = checked;
    if (!checked) {
      newArr[index].cities.forEach((c) => {
        c.checked = false; // eslint-disable-line
        newCityFilterArr = newCityFilterArr.filter((val) => val !== c.id);
      });
      newTagCityArr = newTagCityArr.filter((c) => c.id !== stateId);
    }
    this.setState({
      stateList: newArr,
      cityFilterArr: newCityFilterArr,
      tagCityArr: newTagCityArr,
    });
  };

  /**
   * Summary. ProductCategory sub category checkbox change
   *
   * Description. Set/Reset productcategories to productcategoryList
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Object}   e               event object
   * @param {Object}   category        productcategory sub category object
   * @param {Object}   mainCategory    productcategory main category object
   *
   */
  onSubCategoryChangeProductCategory = (e, category, mainCategory) => {
    const { id } = category;
    const { productcategoryId } = mainCategory;
    const { checked } = e.target;
    const {
      productcategoryList,
      productcategoryFilterArr,
      tagProductCategoryArr,
    } = this.state;
    const newArr = [...productcategoryList];
    let newproductcategoryFilterArr = [...productcategoryFilterArr];
    let newtagProductCategoryArr = [...tagProductCategoryArr];
    const index = productcategoryList.findIndex(
      (v) => v.productcategoryId === productcategoryId
    );
    const productcategoryIndex = newArr[index].productlines.findIndex(
      (v) => v.id === id
    );
    newArr[index].productlines[productcategoryIndex].checked = checked;
    if (checked) {
      newproductcategoryFilterArr = uniq([...newproductcategoryFilterArr, id]);
    } else {
      newproductcategoryFilterArr = newproductcategoryFilterArr.filter(
        (val) => val !== id
      );
    }

    const index1 = newtagProductCategoryArr.findIndex(
      (v) => v.productcategoryId === productcategoryId
    );
    if (index1 !== -1) {
      if (checked) {
        const catIndex = newtagProductCategoryArr[
          index1
        ].productlines.findIndex((v) => v.id === id);
        if (catIndex === -1) {
          newtagProductCategoryArr[index1].productlines = [
            ...newtagProductCategoryArr[index1].productlines,
            category,
          ];
        }
      } else {
        newtagProductCategoryArr[
          index1
        ].productlines = newtagProductCategoryArr[index1].productlines.filter(
          (v) => v.id !== id
        );
        if (!newtagProductCategoryArr[index1].productlines.length) {
          newtagProductCategoryArr = newtagProductCategoryArr.filter(
            (v) => v.productcategoryId !== productcategoryId
          );
        }
      }
    } else if (checked) {
      const newVal = {
        productcategoryId: mainCategory.productcategoryId,
        productcategoryName: mainCategory.productcategoryName,
        productlines: [category],
      };
      newtagProductCategoryArr = [...newtagProductCategoryArr, newVal];
    }
    this.setState({
      productcategoryList: newArr,
      productcategoryFilterArr: newproductcategoryFilterArr,
      tagProductCategoryArr: newtagProductCategoryArr,
    });
  };

  /**
   * Summary. ProductCategory sub category checkbox change
   *
   * Description. Set/Reset productcategories to productcategoryList
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Object}   e               event object
   * @param {Object}   category        productcategory sub category object
   * @param {Object}   mainCategory    productcategory main category object
   *
   */
  onSubCategoryChangeCity = (e, city, mainState) => {
    const cityId = city.id;
    const stateId = mainState.id;
    const { checked } = e.target;
    const { stateList, cityFilterArr, tagCityArr } = this.state;
    const newArr = [...stateList];
    let newCityFilterArr = [...cityFilterArr];
    let newTagCityArr = [...tagCityArr];
    const index = stateList.findIndex((s) => s.id === stateId);
    const cityIndex = newArr[index].cities.findIndex((c) => c.id === cityId);
    newArr[index].cities[cityIndex].checked = checked;
    if (checked) {
      newCityFilterArr = uniq([...newCityFilterArr, cityId]);
    } else {
      newCityFilterArr = newCityFilterArr.filter((val) => val !== cityId);
    }

    const index1 = newTagCityArr.findIndex((s) => s.id === stateId);
    if (index1 !== -1) {
      if (checked) {
        const cityIndexNew = newTagCityArr[index1].cities.findIndex(
          (c) => c.id === cityId
        );
        if (cityIndexNew === -1) {
          newTagCityArr[index1].cities = [
            ...newTagCityArr[index1].cities,
            city,
          ];
        }
      } else {
        newTagCityArr[index1].cities = newTagCityArr[index1].cities.filter(
          (c) => c.id !== cityId
        );
        if (!newTagCityArr[index1].cities.length) {
          newTagCityArr = newTagCityArr.filter((s) => s.id !== stateId);
        }
      }
    } else if (checked) {
      const newVal = {
        id: mainState.id,
        state: mainState.state,
        cities: [city],
      };
      newTagCityArr = [...newTagCityArr, newVal];
    }
    this.setState({
      stateList: newArr,
      cityFilterArr: newCityFilterArr,
      tagCityArr: newTagCityArr,
    });
  };

  /**
   * Summary. Call ProductCategory API
   *
   * Description. To retrive all the productcategories with company filter or name filter
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  callProductCategoryApi = () => {
    const source = getCancelToken();
    this.setState({
      isAPICalled1: true,
      source,
    });
    const {
      limit1,
      offset1,
      cityFilterArr,
      productcategoryFilterArr,
    } = this.state;
    const { text } = this.props;
    const reqObj = {
      filters: {},
    };

    let urlname = 'searchRepByNameProductCategoryFilter';
    let method = 'GET';
    if (this.checkIsHospitalSearch()) {
      urlname = 'getRepByHospitalProductCategory';
    } else if (this.checkIsCitySearch()) {
      urlname = 'searchRepByCityProductCategory';
      reqObj.filters.city = cityFilterArr;
      method = 'POST';
    } else if (this.checkIsProductSearch()) {
      urlname = 'searchRepByProductNameProductCategory';
    }

    axiosApi(
      `/searchColleagues/${urlname}?name=${text}&limit=${limit1}&offset=${offset1}&repId=${app.user.id}&companyId=${app.user.companyId}`,
      method,
      reqObj,
      (res) => {
        if (res.error) {
          console.log(res);
        } else {
          const resObj = res.data.items;
          if (offset1 === 0) {
            this.setState({
              productcategoryList: getPreFiltersArrProductCategory(
                resObj,
                productcategoryFilterArr
              ),
            });
          } else {
            this.setState((prevState) => ({
              productcategoryList: getPreFiltersArrProductCategory(
                [...prevState.productcategoryList, ...resObj],
                productcategoryFilterArr
              ),
            }));
          }
          if (res.data.isMore) {
            this.setState({
              offset1: offset1 + limit1,
            });
          } else {
            this.setState({
              offset1: 0,
            });
          }
        }
        this.setState({
          isAPICalled1: false,
          apiOnScroll1: false,
          source: '',
        });
      },
      source.token
    );
  };

  /**
   * Summary. Call City API
   *
   * Description. To retrive all the cities with company filter or name filter
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  callCityApi = () => {
    const source = getCancelToken();
    this.setState({
      isAPICalled2: true,
      source,
    });
    const { limit2, offset2, productcategoryFilterArr } = this.state;
    const { text } = this.props;
    let type = '';
    let productcategory = [];
    let urlname = '/searchRepByNameCityFilter';
    if (this.checkIsHospitalSearch()) {
      urlname = '/searchRepByHospitalCityFilter';
    } else if (this.checkIsProductSearch()) {
      urlname = '/searchTypeByCityFilter';
      type = 'product';
    } else if (this.checkIsProductCategorySearch()) {
      urlname = '/searchTypeByCityFilter';
      type = 'productcategory';
      productcategory = productcategoryFilterArr;
    }

    axiosApi(
      `/searchColleagues/${urlname}?name=${text}&limit=${limit2}&offset=${offset2}&repId=${app.user.id}&companyId=${app.user.companyId}&type=${type}&productcategory=${productcategory}`,
      'GET',
      '',
      (res) => {
        if (res.error) {
          console.log(res);
        } else {
          const resObj = res.data.items;

          this.setState(
            (prevState) => ({
              cityArr: [...prevState.cityArr, ...resObj],
            }),
            () => {
              if (!res.data.isMore) {
                const { masterStateList, cityFilterArr, cityArr } = this.state;
                const allStateIds = cityArr.map((city) => city.stateId);
                const newStateList = masterStateList
                  .filter((state) => {
                    return allStateIds.includes(state.id);
                  })
                  .map((state) => {
                    return {
                      ...state,
                      cities: cityArr.filter(
                        (city) => city.stateId === state.id
                      ),
                    };
                  });
                this.setState({
                  stateList: getPreFiltersArrCity(newStateList, cityFilterArr),
                  isAPICalled2: false,
                  source: '',
                });
              }
            }
          );
          if (res.data.isMore) {
            this.setState(
              {
                offset2: offset2 + limit2,
              },
              () => {
                this.callCityApi();
              }
            );
          } else {
            this.setState({
              offset2: 0,
            });
          }
        }
      },
      source.token
    );
  };

  /**
   * Summary. Get company list information API
   *
   * Description. To retrive all the companies with name filter or productcategory filter
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  callHospitalApi = () => {
    const source1 = getCancelToken();
    this.setState({
      isAPICalled: true,
      source1,
    });
    const {
      limit,
      offset,
      productcategoryFilterArr,
      cityFilterArr,
    } = this.state;
    const { text } = this.props;

    const reqObj = {
      filters: {},
    };
    if (productcategoryFilterArr.length) {
      reqObj.filters.productcategory = productcategoryFilterArr;
    }
    if (cityFilterArr.length) {
      reqObj.filters.city = cityFilterArr;
    }

    let method = 'POST';
    let urlname = 'searchTypeByHospitalFilter';
    let type = '';
    if (this.checkIsProductSearch()) {
      type = 'product';
    }
    if (this.checkIsNameSearch()) {
      urlname = 'searchRepByNameHospitalFilter';
      method = 'GET';
    }

    axiosApi(
      `/searchColleagues/${urlname}?name=${text}&limit=${limit}&offset=${offset}&repId=${app.user.id}&companyId=${app.user.companyId}&type=${type}`,
      method,
      reqObj,
      (res) => {
        if (res.error) {
          console.log(res);
        } else {
          const resObj = res.data.items;
          if (offset === 0) {
            this.setState({
              hospitalList: resObj,
            });
          } else {
            this.setState((prevState) => ({
              hospitalList: [...prevState.hospitalList, ...resObj],
            }));
          }
          if (res.data.isMore) {
            this.setState({
              offset: offset + limit,
            });
          } else {
            this.setState({
              offset: 0,
            });
          }
        }
        this.setState({
          isAPICalled: false,
          apiOnScroll: false,
          source1: '',
        });
      },
      source1.token
    );
  };

  /**
   * Summary. On scroll event
   *
   * Description. Load more company list on scroll
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param  {Object}   e      event object
   */
  onScroll = (e) => {
    const { offset, apiOnScroll } = this.state;
    if (scrollCheck(e, offset, apiOnScroll)) {
      this.setState({
        apiOnScroll: true,
      });
      this.callHospitalApi();
    }
  };

  /**
   * Summary. On scroll event
   *
   * Description. Load more productcategory list on scroll
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param  {Object}   e      event object
   */
  onScroll1 = (e) => {
    const { offset1, apiOnScroll1 } = this.state;
    if (scrollCheck(e, offset1, apiOnScroll1)) {
      this.setState({
        apiOnScroll1: true,
      });
      this.callProductCategoryApi();
    }
  };

  /**
   * Summary. Change filter name
   *
   * Description. Change the filter either company or productcategory
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}       name             name of the filter
   *
   */
  onChangeFilter = (name) => {
    this.setState({
      isSelected: name,
    });
  };

  /**
   * Summary. company checkbox change event
   *
   * Description. Set/Reset company to hospitalArr
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Object}   e               event object
   * @param {Object}   item            company object
   *
   */
  hospitalCheckboxChange = (e, item) => {
    const { checked } = e.target;
    const { id } = item;
    if (checked) {
      this.setState((prevState) => ({
        hospitalArr: uniq([...prevState.hospitalArr, id]),
        tagHospitalList: [...prevState.tagHospitalList, item],
      }));
    } else {
      this.setState((prevState) => ({
        hospitalArr: prevState.hospitalArr.filter((v) => v !== id),
        tagHospitalList: prevState.tagHospitalList.filter((v) => v.id !== id),
      }));
    }
  };

  /**
   *  Apply filter btn click event
   */
  onFilterClick = () => {
    const {
      hospitalArr,
      tagHospitalList,
      productcategoryFilterArr,
      tagProductCategoryArr,
      cityFilterArr,
      tagCityArr,
    } = this.state;

    if (
      hospitalArr.length ||
      productcategoryFilterArr.length ||
      cityFilterArr.length
    ) {
      const { onFilterClick } = this.props;
      onFilterClick(
        hospitalArr,
        productcategoryFilterArr,
        cityFilterArr,
        tagHospitalList,
        tagProductCategoryArr,
        tagCityArr
      );
    } else if (this.checkIsHospitalSearch()) {
      alert('Please select any product line');
    } else if (this.checkIsProductCategorySearch()) {
      alert('Please select any hospital');
    } else {
      alert('Please select any hospital or product line');
    }
  };

  /**
   *  Reset btn click event
   */
  onResetClick = () => {
    const { onResetClick } = this.props;
    onResetClick();
  };

  onClickAway = () => {
    const { onClickAway } = this.props;
    if (onClickAway) onClickAway();
  };

  render() {
    const {
      isSelected,
      hospitalList,
      hospitalArr,
      productcategoryFilterArr,
      productcategoryList,
      cityFilterArr,
      stateList,
      masterStateList,
      isAPICalled,
      isAPICalled1,
      isAPICalled2,
    } = this.state;

    return (
      <ClickAwayListner handleClickAway={() => this.onClickAway()}>
        <div className="filter-list-wrap">
          <div className={`product-wrap ${isSelected ? 'height_add' : ''}`}>
            <div className="wid-50">
              <ul className="filter-list">
                {this.checkIsHospitalSearch() ? (
                  ''
                ) : (
                  <li
                    role="presentation"
                    onClick={() => {
                      this.onChangeFilter('isHospital');
                    }}
                    className={isSelected === 'isHospital' ? 'selected' : ''}
                    data-repcard-test="company"
                  >
                    Account (<span>{hospitalArr.length}</span>)
                  </li>
                )}
                {this.checkIsProductCategorySearch() ? (
                  ''
                ) : (
                  <li
                    role="presentation"
                    onClick={() => {
                      this.onChangeFilter('isProductCategory');
                    }}
                    className={
                      isSelected === 'isProductCategory' ? 'selected' : ''
                    }
                    data-repcard-test="productcategory"
                  >
                    Product Line (<span>{productcategoryFilterArr.length}</span>
                    )
                  </li>
                )}
                {this.checkIsCitySearch() || this.checkIsHospitalSearch() ? (
                  ''
                ) : (
                  <li
                    role="presentation"
                    onClick={() => {
                      this.onChangeFilter('isCity');
                    }}
                    className={isSelected === 'isCity' ? 'selected' : ''}
                    data-repcard-test="productcategory"
                  >
                    City/State (<span>{cityFilterArr.length}</span>)
                  </li>
                )}
              </ul>
              {isSelected ? (
                <div className="filter-btn">
                  <FilterButtons
                    onFilterClick={this.onFilterClick}
                    onResetClick={this.onResetClick}
                    isBtnEnable={
                      hospitalArr.length ||
                      productcategoryFilterArr.length ||
                      cityFilterArr.length
                    }
                  />
                </div>
              ) : (
                ''
              )}
            </div>
            {isSelected === 'isHospital' ? (
              <div className="wid-50 selected">
                <SearchFilterListHospital
                  onChange={this.hospitalCheckboxChange}
                  hospitalList={hospitalList}
                  onScroll={this.onScroll}
                  hospitalArr={hospitalArr}
                  isAPICalled={isAPICalled}
                />
              </div>
            ) : isSelected === 'isProductCategory' ? (
              <div className="wid-50 selected">
                <SearchFilterListProductCategory
                  productcategoryList={productcategoryList}
                  onScroll={this.onScroll1}
                  onChange={this.handleCheckChangeProductCategory}
                  onSubCategoryChange={this.onSubCategoryChangeProductCategory}
                  isAPICalled={isAPICalled1}
                />
              </div>
            ) : isSelected === 'isCity' ? (
              <div className="wid-50 selected">
                <SearchFilterListCity
                  masterStateList={masterStateList}
                  stateList={stateList}
                  onScroll={this.onScroll1}
                  onChange={this.handleCheckChangeCity}
                  onSubCategoryChange={this.onSubCategoryChangeCity}
                  isAPICalled={isAPICalled2}
                />
              </div>
            ) : (
              ''
            )}
          </div>
        </div>
      </ClickAwayListner>
    );
  }
}

export default FiltersMyColleagues;
