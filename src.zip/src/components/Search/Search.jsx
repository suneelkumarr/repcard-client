/**
 *
 * Description. Search Main component
 *
 * @link   URL
 * @file   Calls the specific component from here like filters, Recent search
           and search row. Manages all search functionalities
 * @since  1.0.0
 */
import React, { Component, lazy, Suspense } from 'react';
import {
  MDBSelect,
  MDBSelectInput,
  MDBSelectOptions,
  MDBSelectOption,
  MDBInput,
} from 'mdbreact';
import { axiosApi } from '../../apis/axiosApiCall';
import ProfileHeading from '../Common/ProfileHeading';
import SearchRow from './SearchRow';
import SearchProductRow from './SearchProductRow';
import Filters from './Filters.jsx';
import RecentSearch from './RecentSearch.jsx';
import app from '../../helpers/appGlobal';
import isEnterKeyPressed from '../../utils/checkEnterKeyPressed';
import scrollCheck from '../../utils/scrollCheck';

import './search.scss';

const Loading = () => <div>Loading...</div>;
const SearchCompanyList = lazy(() => import('./SearchCompanyList'));
const SearchProductCategoryList = lazy(() =>
  import('./SearchProductCategoryList')
);

class Search extends Component {
  constructor(props) {
    super(props);
    this.state = {
      limit: 10,
      offset: 0,
      searchby: props.searchby || '',
      text: props.text || '',
      searchResults: [],
      isAPICalled: false,
      apiOnScroll: false,
      filterOpen: false,
      companyArr: [],
      productcategoryFilterArr: [],
      tagCompanyList: [],
      tagProductCategoryArr: [],
      currentSearchName: '',
      keyVal: 1,
      updateSearchKey: 1,
      openStackId: null,
      openPopupId: null,
      optionsObj: {
        name: 'Name',
        company: 'Company',
        productcategory: 'Product Line',
        product: 'Product',
      },
      count: 0,
    };

    this.myRef = React.createRef();
  }

  filterSelectOpen = () => {
    this.setState((prevState) => ({
      filterOpen: !prevState.filterOpen,
    }));
  };

  setStackId = (id) => {
    this.setState({
      openStackId: id,
    });
  };

  setPopupId = (id) => {
    this.setState({
      openPopupId: id,
    });
  };

  /**
   * Summary. Provider Search API
   *
   * Description. To retrive all the search results using api call with company
   *              and productcategory filters along with limit and offset
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  callSearchApi = () => {
    this.setState({
      isAPICalled: true,
    });
    const {
      limit,
      offset,
      text,
      searchby,
      companyArr,
      productcategoryFilterArr,
      updateSearchKey,
    } = this.state;

    let urlname = '/search';

    if (searchby === 'product') {
      urlname += '/getProductsByName';
    }

    const reqObj = {
      filters: {},
    };

    if (companyArr.length) {
      reqObj.filters.company = companyArr;
    }
    if (productcategoryFilterArr.length) {
      reqObj.filters.productcategory = productcategoryFilterArr;
    }

    axiosApi(
      `${urlname}?type=${searchby}&name=${text}&limit=${limit}&offset=${offset}&providerId=${app.user.id}`,
      'POST',
      reqObj,
      (res) => {
        if (res.data) {
          const { items: resObj, count } = res.data;
          if (offset === 0) {
            this.setState({
              searchResults: resObj,
              updateSearchKey: updateSearchKey + 1,
              count,
            });
          } else {
            this.setState((prevState) => ({
              searchResults: [...prevState.searchResults, ...resObj],
              count,
            }));
          }

          if (res.data.isMore) {
            this.setState({
              offset: offset + limit,
            });
          } else {
            this.setState({
              offset: 0,
            });
          }
        }
        this.setState({
          isAPICalled: false,
          apiOnScroll: false,
          currentSearchName:
            searchby === 'productcategory'
              ? productcategoryFilterArr.join(',')
              : text,
        });
      }
    );
  };

  componentDidMount() {
    // get results again, if coming back from rep grid
    const { searchby, text } = this.state;
    if (searchby === 'product' && text.length > 2) {
      this.callSearchApi();
    }
  }

  /**
   * Summary. Select search parameter
   *
   * Description. Select search by name, company or productcategory
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Array}   val       select value (name, company or productcategory)
   *
   */
  searchVal = (val) => {
    const { searchby } = this.state;
    const newSearchVal = val.toString();
    if (searchby !== newSearchVal) {
      this.clearResults();
      this.setState({
        searchby: newSearchVal,
      });
    }
  };

  /**
   * Summary. Search input
   *
   * Description. Input Change method for search input
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   e           Input element event object
   * @param {function} cb          Callback function
   *
   */
  onChange = (e, cb) => {
    const { value } = e.target;
    this.setState(
      {
        text: value,
        filterOpen: false,
      },
      () => {
        if (cb) {
          cb();
        }
      }
    );
  };

  /**
   * Summary. On company select event
   *
   * Description. Set company and call the search API to get the new data
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   e           Input element event object
   *
   */
  onCompanySelect = (e) => {
    this.onChange(e, () => {
      this.onSearch();
    });
  };

  /**
   * Summary. On specialiy search event
   *
   * Description. Call the search API as per the productcategory filters
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  onProductCategorySearch = () => {
    const { productcategoryFilterArr } = this.state;
    if (productcategoryFilterArr.length <= 0) {
      alert('Select any product line first');
    } else {
      this.setState(
        {
          offset: 0,
          searchResults: [],
          isAPICalled: false,
          apiOnScroll: false,
          filterOpen: false,
          companyArr: [],
          tagCompanyList: [],
          tagProductCategoryArr: [],
        },
        () => {
          this.callSearchApi();
        }
      );
    }
  };

  /**
   * Summary. Search API call
   *
   * Description. Call the search API as per the text
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  onSearch = () => {
    const { text } = this.state;
    if (text.length < 3) {
      alert('minimum 3 characters');
    } else {
      this.setState(
        {
          offset: 0,
          searchResults: [],
          isAPICalled: false,
          apiOnScroll: false,
          filterOpen: false,
          companyArr: [],
          productcategoryFilterArr: [],
          tagCompanyList: [],
          tagProductCategoryArr: [],
        },
        () => {
          this.callSearchApi();
        }
      );
    }
  };

  /**
   * Summary. Recent search click
   *
   * Description. Call the search API as per the recent search click details
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   str           text input of search
   * @param {string}   type          can be name, company
   */
  onRecentSearchClick = (str, type) => {
    const { keyVal } = this.state;
    this.setState(
      {
        searchby: type,
        text: str,
        keyVal: keyVal + 1,
      },
      () => {
        this.onSearch();
      }
    );
  };

  /**
   * Summary. Recent search - search by productcategory click
   *
   * Description. Set spe filter details and call the search API to get the new data
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Array}   speclialityArr          array object of productcategories
   * @param {string}  type                    productcategory type
   *
   */
  onSearchProductCategory = (speclialityArr, type) => {
    const { keyVal } = this.state;
    this.setState(
      {
        searchby: type,
        text: '',
        productcategoryFilterArr: speclialityArr,
        keyVal: keyVal + 1,
      },
      () => {
        this.onProductCategorySearch();
      }
    );
  };

  /**
   * Summary. Apply filter click event
   *
   * Description. Call search API with company and productcategory filters
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Array}   companyArr           array list of companies
   * @param {Array}   productcategoryFilterArr  list of productcategories
   * @param {Array}   tagCompanyList       array list of companies with more info
   * @param {Array}   tagProductCategoryArr     array list of productcategories with more info
   *
   */
  onFilterClick = (
    companyArr,
    productcategoryFilterArr,
    tagCompanyList,
    tagProductCategoryArr
  ) => {
    this.setState(
      {
        offset: 0,
        searchResults: [],
        isAPICalled: false,
        apiOnScroll: false,
        filterOpen: false,
        companyArr,
        productcategoryFilterArr,
        tagCompanyList,
        tagProductCategoryArr,
      },
      () => {
        this.callSearchApi();
      }
    );
  };

  /**
   *  Reset btn click - Remove All the filters and call search API
   */
  onResetClick = () => {
    const { searchby } = this.state;
    if (searchby === 'productcategory') {
      this.setState(
        {
          offset: 0,
          searchResults: [],
          isAPICalled: false,
          apiOnScroll: false,
          filterOpen: false,
          companyArr: [],
          tagCompanyList: [],
          tagProductCategoryArr: [],
        },
        () => {
          this.callSearchApi();
        }
      );
    } else {
      this.setState(
        {
          offset: 0,
          searchResults: [],
          isAPICalled: false,
          apiOnScroll: false,
          filterOpen: false,
          companyArr: [],
          productcategoryFilterArr: [],
          tagCompanyList: [],
          tagProductCategoryArr: [],
        },
        () => {
          this.callSearchApi();
        }
      );
    }
  };

  /**
   * Summary. Set productcategory filters
   *
   * Description. Set productcategory filters on select
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Array}   productcategoryFilterArr  list of productcategories
   *
   */
  onSetProductCategory = (productcategoryFilterArr) => {
    this.setState({
      productcategoryFilterArr,
    });
  };

  /**
   * Summary. Clear results click event
   *
   * Description. Remove and clear all the results with filters
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  clearResults = () => {
    const { keyVal } = this.state;
    this.setState({
      offset: 0,
      searchResults: [],
      isAPICalled: false,
      apiOnScroll: false,
      filterOpen: false,
      companyArr: [],
      productcategoryFilterArr: [],
      tagCompanyList: [],
      tagProductCategoryArr: [],
      text: '',
      currentSearchName: '',
      keyVal: keyVal + 1,
    });
  };

  /**
   * Summary. Remove company from tags
   *
   * Description. Remove the company from company list and call search API
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   id  company id
   *
   */
  removeCompany = (name) => {
    this.setState(
      (prevState) => ({
        companyArr: prevState.companyArr.filter((v) => v !== name),
        tagCompanyList: prevState.tagCompanyList.filter((v) => v.name !== name),
        offset: 0,
        searchResults: [],
        isAPICalled: false,
        apiOnScroll: false,
        filterOpen: false,
      }),
      () => {
        this.callSearchApi();
      }
    );
  };

  /**
   * Summary. Remove productcategory from tags
   *
   * Description. Remove the productcategory from productcategory list and call search API
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   productcategoryId       productcategory id
   *
   */
  removeProductCategory = (productcategoryId) => {
    const { productcategoryFilterArr, tagProductCategoryArr } = this.state;
    const index = tagProductCategoryArr.findIndex(
      (v) => v.productcategoryId === productcategoryId
    );
    let newproductcategoryFilterArr = [...productcategoryFilterArr];
    if (index !== -1) {
      tagProductCategoryArr[index].productlines.forEach((item) => {
        newproductcategoryFilterArr = newproductcategoryFilterArr.filter(
          (v) => v !== item.id
        );
      });
    }

    this.setState(
      (prevState) => ({
        productcategoryFilterArr: newproductcategoryFilterArr,
        tagProductCategoryArr: prevState.tagProductCategoryArr.filter(
          (v) => v.productcategoryId !== productcategoryId
        ),
        offset: 0,
        searchResults: [],
        isAPICalled: false,
        apiOnScroll: false,
        filterOpen: false,
      }),
      () => {
        this.callSearchApi();
      }
    );
  };

  /**
   * Summary. On scroll event
   *
   * Description. Load more search results on scroll
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param  {Object}   e      event object
   */
  onScroll = (e) => {
    const { offset, apiOnScroll } = this.state;
    if (scrollCheck(e, offset, apiOnScroll)) {
      this.setState({
        apiOnScroll: true,
      });
      this.callSearchApi();
    }
  };

  /**
   * Summary. On keyDown event
   *
   * Description. Check if enter key pressed and call search api if true
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param  {Object}   e      event object
   */
  onKeyDown = (e) => {
    if (isEnterKeyPressed(e)) {
      this.onSearch();
    }
  };

  /**
   * Summary. Update favourite details
   *
   * Description. Update favourite flag details of search results
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param  {integer}   id     Rep's user id
   */
  updateSearchFavourites = (id) => {
    const { searchResults, updateSearchKey } = this.state;
    const arrIndex = searchResults.findIndex((v) => v.id === id);
    if (arrIndex !== -1) {
      const newSearchResults = [...searchResults];
      newSearchResults[arrIndex].isFavourite = false;
      this.setState({
        searchResults: newSearchResults,
        updateSearchKey: updateSearchKey + 1,
      });
    }
  };

  render() {
    const {
      optionsObj,
      searchby,
      text,
      isAPICalled,
      searchResults,
      filterOpen,
      companyArr,
      productcategoryFilterArr,
      tagCompanyList,
      tagProductCategoryArr,
      currentSearchName,
      keyVal,
      updateSearchKey,
      openStackId,
      openPopupId,
      count,
    } = this.state;
    const { updateFavourites, showRepGrid, isBasicPlan } = this.props;

    let isFilterDisable = false;
    let newSearchText = text;
    if (searchby === 'productcategory') {
      newSearchText = productcategoryFilterArr.join(',');
    }
    if (currentSearchName !== newSearchText) {
      isFilterDisable = true;
    }
    const searchPromptText =
      searchby === 'product'
        ? 'Search by product name, keyword or re-order number here'
        : 'Enter search text here';

    return (
      <div className="search-right-panel">
        <div className="clearfix text-right">
          <div className="heading-txt">
            <ProfileHeading headingtxt="Find A Rep" />
          </div>
          <RecentSearch
            onRecentSearchClick={this.onRecentSearchClick}
            onSearchProductCategory={this.onSearchProductCategory}
            isBasicPlan={isBasicPlan}
          />
          <span
            className={`clear_btn ${
              searchResults.length || currentSearchName || newSearchText
                ? 'cursor'
                : 'noEvents disable_text'
            }`}
            onClick={this.clearResults}
            role="presentation"
          >
            Clear Results
          </span>
        </div>
        <div className="provider_search_panel">
          <div className="provider_select">
            <MDBSelect getValue={this.searchVal} key={keyVal}>
              <MDBSelectInput
                selected={searchby ? optionsObj[searchby] : 'Search By'}
              />
              <MDBSelectOptions>
                {/* <MDBSelectOption disabled>
                            Search By
                          </MDBSelectOption> */}
                {Object.keys(optionsObj).map((v) => {
                  if (v === 'product' && isBasicPlan) {
                    return null;
                  }
                  return (
                    <MDBSelectOption key={v} value={v}>
                      {optionsObj[v]}
                    </MDBSelectOption>
                  );
                })}
              </MDBSelectOptions>
            </MDBSelect>
          </div>
          <div className="provider_search_bar">
            <div className="search_bar_panel">
              <div className="search_bar">
                <div className="position-relative">
                  <Suspense fallback={<Loading />}>
                    {searchby === 'company' ? (
                      <SearchCompanyList
                        onChange={this.onChange}
                        onCompanySelect={this.onCompanySelect}
                        onKeyDown={this.onKeyDown}
                        text={text}
                        key={keyVal}
                      />
                    ) : searchby === 'productcategory' ? (
                      <SearchProductCategoryList
                        onSetProductCategory={this.onSetProductCategory}
                        productcategoryFilterArr={productcategoryFilterArr}
                        key={keyVal}
                      />
                    ) : (
                      <MDBInput
                        type="search"
                        className="search_field"
                        hint={searchby ? searchPromptText : ''}
                        onChange={this.onChange}
                        name="textSearch"
                        value={text}
                        disabled={!searchby}
                        autoComplete="off"
                        onKeyDown={this.onKeyDown}
                        placeholder={
                          searchby
                            ? searchby === 'product'
                              ? ' Begin typing product name, reorder number or keyword here'
                              : `Begin typing rep's name here`
                            : ''
                        }
                      />
                    )}
                  </Suspense>
                </div>
              </div>

              {searchby === 'productcategory' ? (
                <button
                  type="button"
                  className={`search_btn ${
                    isAPICalled || productcategoryFilterArr.length <= 0
                      ? 'noEvents'
                      : ''
                  }`}
                  onClick={this.onProductCategorySearch}
                  disabled={
                    searchby &&
                    (isAPICalled || productcategoryFilterArr.length <= 0)
                  }
                  data-repcard-test="search"
                >
                  {isAPICalled ? (
                    <span className="spinner-border spinner-border-sm" />
                  ) : (
                    'Search'
                  )}
                </button>
              ) : (
                <button
                  type="button"
                  className={`search_btn ${
                    isAPICalled || text.length < 3 ? 'noEvents' : ''
                  }`}
                  onClick={this.onSearch}
                  disabled={searchby && (isAPICalled || text.length < 3)}
                  data-repcard-test="search"
                >
                  {isAPICalled ? (
                    <span className="spinner-border spinner-border-sm" />
                  ) : (
                    'Search'
                  )}
                </button>
              )}
            </div>
          </div>
        </div>
        {searchResults.length ||
        tagCompanyList.length ||
        tagProductCategoryArr.length ? (
          <div
            className={`filter-panel mt-1 ${isFilterDisable ? 'noEvents' : ''}`}
            ref={this.myRef}
          >
            <div
              className={`filter-list-name ${filterOpen ? 'active' : ''}`}
              onClick={this.filterSelectOpen}
              role="presentation"
              data-repcard-test="filter"
            >
              <span className="shape mr-1" />
              Filter
            </div>
            {filterOpen ? (
              <Filters
                myRef1={this.myRef}
                text={text}
                filterSelectToggle={this.filterSelectOpen}
                onFilterClick={this.onFilterClick}
                onResetClick={this.onResetClick}
                companyArr={companyArr}
                productcategoryFilterArr={productcategoryFilterArr}
                tagCompanyList={tagCompanyList}
                tagProductCategoryArr={tagProductCategoryArr}
                searchby={searchby}
              />
            ) : (
              ''
            )}
          </div>
        ) : (
          ''
        )}
        {searchResults.length ? (
          <div className="tagPanel">
            {tagCompanyList.map((v) => {
              return (
                <p className="tags" key={v.id}>
                  {v.name}
                  <span
                    className="close_tag"
                    onClick={() => {
                      this.removeCompany(v.name);
                    }}
                    role="presentation"
                    data-repcard-test="removeCompany"
                  />
                </p>
              );
            })}
            {tagProductCategoryArr.map((v) => {
              return (
                <p className="tags" key={v.productcategoryId}>
                  {v.productcategoryName} -{' '}
                  {v.productlines.map((item, i) => {
                    if (i === v.productlines.length - 1) {
                      return item.name;
                    }
                    return `${item.name}, `;
                  })}
                  <span
                    className="close_tag"
                    onClick={() => {
                      this.removeProductCategory(v.productcategoryId);
                    }}
                    role="presentation"
                    data-repcard-test="removeProductCategory"
                  />
                </p>
              );
            })}
          </div>
        ) : (
          ''
        )}
        {searchResults.length ? (
          <div className="search-result text-right">
            Search Results ({count})
          </div>
        ) : (
          ''
        )}
        {searchResults.length && searchby === 'product' ? (
          <div className="provider_table" onScroll={this.onScroll}>
            <div
              className="provider_search_list_products"
              key={updateSearchKey}
            >
              <div className="tr d-md-inline-block d-sm-none">
                <div className="th" />
                <div className="active_in_mobile">
                  <div className="th">Product Name</div>
                  <div className="th">Product Company</div>
                  <div className="th">Product Number</div>
                </div>
              </div>
              {searchResults.map((p) => {
                return (
                  <SearchProductRow
                    item={p}
                    key={p.id}
                    showRepGrid={(reps) => showRepGrid(reps, text)}
                    setStackId={this.setStackId}
                    setPopupId={this.setPopupId}
                    openStackId={openStackId}
                    openPopupId={openPopupId}
                    updateFavourites={updateFavourites}
                  />
                );
              })}
            </div>
          </div>
        ) : searchResults.length ? (
          <div className="provider_table" onScroll={this.onScroll}>
            <div className="provider_search_list" key={updateSearchKey}>
              <div className="tr d-md-inline-block d-sm-none">
                <div className="th" />
                <div className="active_in_mobile">
                  <div className="th">Rep Name</div>
                  <div className="th">Company</div>
                  <div className="th">Product Lines</div>
                  <div className="th">Email</div>
                  <div className="th">Phone</div>
                </div>
              </div>
              {searchResults.map((v) => {
                return (
                  <SearchRow
                    item={v}
                    key={v.id}
                    updateFavourites={updateFavourites}
                  />
                );
              })}
            </div>
          </div>
        ) : (
          <div className="no_result_txt">
            {currentSearchName && !isAPICalled ? (
              <>
                <p>Sorry.</p>

                {searchby === 'name' ? (
                  <>
                    <p>
                      We can&apos;t find any rep by that name in our directory.
                    </p>

                    <p>Please try another spelling or search term.</p>
                  </>
                ) : searchby === 'company' ? (
                  <>
                    <p>
                      We can&apos;t find any company by that name in our
                      <br className="d-none d-lg-inline-block d-md-display-none" />
                      directory. Was that company recently acquired?
                    </p>

                    <p>
                      {' '}
                      Please try another spelling or search by the parent
                      company name.
                    </p>
                  </>
                ) : searchby === 'productcategory' ? (
                  <>
                    <p>
                      We can&apos;t find any rep associated with that product
                      line for your facility.
                    </p>
                    <p>Please try an alternate search.</p>
                  </>
                ) : searchby === 'product' ? (
                  <>
                    <p>
                      The product you are searching for is listed as &quot;No
                      longer in Commercial Distribution&quot; per the FDA
                      database.
                    </p>
                    <p>Please try an alternate search.</p>
                  </>
                ) : (
                  ''
                )}
                <br />
              </>
            ) : (currentSearchName || text) && isAPICalled ? (
              'Searching...'
            ) : (
              ''
            )}
          </div>
        )}
      </div>
    );
  }
}

export default Search;
