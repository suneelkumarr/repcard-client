import React, { Component } from 'react';
import { chunk } from 'lodash';
import { MDBRow, MDBCol, MDBContainer } from 'mdbreact';
import { Link } from 'react-router-dom';
import RepcardPopover from '../Popover/popover.jsx';

// eslint-disable-next-line react/prefer-stateless-function
class RepGrid extends Component {
  render() {
    const { reps, backFromRepGrid } = this.props;
    const repsInFours = chunk(reps, 4);

    return (
      <MDBContainer className="rep-grid-container">
        <Link
          to="/SearchRep"
          onClick={backFromRepGrid}
          className="rep-grid-back"
        >
          Back to Search
        </Link>
        {repsInFours.map((group) => {
          return (
            <MDBRow key={group[0].id}>
              {group.map((rep) => {
                return (
                  <MDBCol
                    lg="3"
                    md="6"
                    sm="12"
                    key={rep.id}
                    className="rep-grid-col"
                  >
                    <RepcardPopover
                      flipicondisable
                      isHtml
                      isFavourite
                      profileRes={rep}
                      initialView="profile"
                      id={rep.id}
                      showFullProfileLink
                    />
                  </MDBCol>
                );
              })}
            </MDBRow>
          );
        })}
      </MDBContainer>
    );
  }
}

export default RepGrid;
