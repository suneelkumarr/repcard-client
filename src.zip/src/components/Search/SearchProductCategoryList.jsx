/**
 *
 * Description. Seacrh by productcategory
 *
 * @link   URL
 * @file   User can choose productcategory with sub category from drop down and then
           filters the search results. (All the sub categories can be choosen
           but for Only 1 productcategory) Can't select multiple productcategory
 * @since  1.0.0
 */
import React, { Component } from 'react';
import { MDBInput } from 'mdbreact';
import PublishSubscribe from 'publish-subscribe-js';
import app from '../../helpers/appGlobal';
import PUB_SUB from '../../constants/events.constant';
import handleClickOutside from '../../utils/handleClickOutside';

class SearchProductCategoryList extends Component {
  constructor(props) {
    super(props);
    this.state = {
      open: false,
      productcategoryList: JSON.parse(
        JSON.stringify(app.user.productcategories)
      ),
      currentId: '',
      selectedCategory: [],
      productcategoryFilterArr: [],
      productSearch: '',
    };

    this.mousedownSubKey = 0;
    this.myRef = React.createRef();
    this.myRef1 = React.createRef();
    this.timeout = null;
  }

  /**
   * Summary. ProductCategory Master data prefill
   *
   * Description. Load all the productcategory master data values
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  preFillValues = () => {
    const { productcategoryFilterArr } = this.props;
    if (productcategoryFilterArr.length) {
      let productcategoryId = '';
      let productcategoryName = '';
      let newArr = [];
      const { productcategoryList } = this.state;
      productcategoryList.forEach((v) => {
        v.productlines.forEach((item) => {
          if (productcategoryFilterArr.indexOf(item.id) !== -1) {
            productcategoryId = v.productcategoryId;
            productcategoryName = v.productcategoryName;
            newArr = [...newArr, item];
          }
        });
      });

      if (productcategoryId) {
        const newCategoryArr = [
          {
            productcategoryId,
            productcategoryName,
            productlines: newArr,
          },
        ];
        this.setState({
          selectedCategory: newCategoryArr,
          productcategoryFilterArr,
          currentId: productcategoryId,
        });
      }
    }
  };

  /**
   * Summary. Outside click event
   *
   * Description. Check if click event is occured not in the html part and closes
                  the popup on outside click
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   eventObj   click event object
   *
   */
  handleClickOutside = (eventObj) => {
    const { open } = this.state;
    if (handleClickOutside(open, this.myRef, eventObj, this.myRef1)) {
      this.setState({
        open: false,
      });
    }
  };

  componentDidMount() {
    // Mouse down event to check outside click
    this.mousedownSubKey = PublishSubscribe.subscribe(
      PUB_SUB.MOUSEDOWN,
      this.handleClickOutside
    );
    this.preFillValues();
  }

  componentWillUnmount() {
    // PublishSubscribe.unsubscribe(PUB_SUB.MOUSEDOWN, this.mousedownSubKey);
  }

  /**
   *  Toggle modal popup
   */
  productcategoryOpen = () => {
    this.setState({
      open: true,
      productSearch: '',
    });
  };

  /**
   * Summary. ProductCategory main category click
   *
   * Description. set productcategory main category
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   productcategoryId    id of the selected productcategory
   *
   */
  onClick = (productcategoryId) => {
    this.setState({
      currentId: productcategoryId,
    });
  };

  /**
   * Summary. Search input
   *
   * Description. Input Change method for search input. Uses setTimeout to only re-render when user has stopped typing.
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   e           Input element event object
   *
   */
  updateProductSearch = (e) => {
    clearTimeout(this.timeout);
    const { value } = e.target;
    this.timeout = setTimeout(() => {
      this.setState({
        productSearch: value.toLowerCase(),
      });
    }, 250);
  };

  /**
   * Summary. ProductCategory sub category checkbox change
   *
   * Description. Set/Reset productcategory sub categories and main category
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Object}   e               event object
   * @param {Object}   category        productcategory sub category object
   * @param {Object}   mainCategory    productcategory main category object
   *
   */
  onChangeCheckbox = (e, category, mainCategory) => {
    const { checked } = e.target;
    const { selectedCategory, productcategoryFilterArr } = this.state;
    const { id } = category;
    const { productcategoryId, productcategoryName } = mainCategory;
    const index = selectedCategory.findIndex(
      (v) => v.productcategoryId === productcategoryId
    );
    let newCategoryArr = [];
    let newProductCategoryFilterArr = [];
    if (index === -1) {
      if (checked) {
        newCategoryArr = [
          ...newCategoryArr,
          { productcategoryId, productcategoryName, productlines: [category] },
        ];
        newProductCategoryFilterArr = [...newProductCategoryFilterArr, id];
      }
    } else {
      newCategoryArr = [...selectedCategory];
      newProductCategoryFilterArr = [...productcategoryFilterArr];
      if (checked) {
        newCategoryArr[index].productlines = [
          ...newCategoryArr[index].productlines,
          category,
        ];
        newProductCategoryFilterArr = [...newProductCategoryFilterArr, id];
      } else {
        newCategoryArr[index].productlines = newCategoryArr[
          index
        ].productlines.filter((v) => v.id !== id);
        if (!newCategoryArr[index].productlines.length) {
          newCategoryArr = [];
        }
        newProductCategoryFilterArr = newProductCategoryFilterArr.filter(
          (v) => v !== id
        );
      }
    }

    this.setState({
      selectedCategory: newCategoryArr,
      productcategoryFilterArr: newProductCategoryFilterArr,
    });

    const { onSetProductCategory } = this.props;
    onSetProductCategory(newProductCategoryFilterArr);
  };

  render() {
    const {
      open,
      productcategoryList,
      currentId,
      selectedCategory,
      productcategoryFilterArr,
      productSearch,
    } = this.state;

    return (
      <>
        <div
          className="search_field productcategory_select"
          onClick={this.productcategoryOpen}
          role="presentation"
          ref={this.myRef1}
          data-repcard-test="popup"
        >
          {productcategoryFilterArr.length ? (
            <span className="productcategory_placeholder selected_productcategory">
              {selectedCategory[0].productcategoryName} -{' '}
              {productcategoryFilterArr.length === 1
                ? selectedCategory[0].productlines[0].name
                : `${productcategoryFilterArr.length} Product Lines`}
            </span>
          ) : (
            <span className="productcategory_placeholder">
              Click here to select Product Category + Product Line
            </span>
          )}
        </div>
        {open ? (
          <div className="productcategory_sub_list" ref={this.myRef}>
            <ul className="search_list_dtl">
              <li>
                <MDBInput
                  type="text"
                  placeholder="Begin typing here for search"
                  maxLength="50"
                  className="d-inline-block"
                  hint="enter search text here"
                  onChange={this.updateProductSearch}
                />
              </li>
              {productcategoryList.map((v) => {
                let { productlines } = v;
                if (productSearch) {
                  productlines = productlines.filter((item) => {
                    return item.name.toLowerCase().includes(productSearch);
                  });
                }
                const isSearchMatch = productSearch
                  ? productlines.length > 0
                  : false;

                const isSelected = productSearch
                  ? isSearchMatch
                  : currentId === v.productcategoryId;

                if (productSearch && !isSearchMatch) {
                  return null;
                }

                return (
                  <li
                    key={v.productcategoryId}
                    onClick={() => {
                      this.onClick(v.productcategoryId);
                    }}
                    data-repcard-test="productcategory"
                    role="presentation"
                  >
                    {v.productcategoryName}
                    {isSelected || isSearchMatch ? (
                      <ul>
                        {productlines.map((item) => {
                          return (
                            <li key={item.id}>
                              <MDBInput
                                label={item.name}
                                filled
                                type="checkbox"
                                id={`productcategoryFilter${item.id}`}
                                checked={
                                  productcategoryFilterArr.indexOf(item.id) !==
                                  -1
                                }
                                onChange={(e) =>
                                  this.onChangeCheckbox(e, item, v)
                                }
                              />
                            </li>
                          );
                        })}
                      </ul>
                    ) : (
                      ''
                    )}
                  </li>
                );
              })}
            </ul>
          </div>
        ) : (
          ''
        )}
      </>
    );
  }
}

export default SearchProductCategoryList;
