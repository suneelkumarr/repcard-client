/**
 *
 * Description. Filters
 *
 * @link   URL
 * @file   Filters for Rep's search by city/state, Account and Product line
           (whatever is available in search results for displaying city/state,
            Account and Product line)
           User can do the filtering by choosing any of these things.
 * @since  1.0.0
 */
import React, { Component } from 'react';
import uniq from 'lodash/uniq';
import isEmpty from 'lodash/isEmpty';
import { SearchFilterList } from './SearchFilterList';
import FilterButtons from '../Search/FilterButtons';
import { axiosApi } from '../../apis/axiosApiCall';
import getCancelToken from '../../apis/getCancelToken';
import scrollCheck from '../../utils/scrollCheck';
import app from '../../helpers/appGlobal';

class Filters extends Component {
  constructor(props) {
    super(props);
    // By default selected Arr if available
    const { productcategoryFilterArr, cityArr, hospitalArr } = this.props;
    let isSelected = '';
    if (cityArr && cityArr.length) {
      isSelected = 'city';
    } else if (hospitalArr && hospitalArr.length) {
      isSelected = 'account';
    } else if (productcategoryFilterArr && productcategoryFilterArr.length) {
      isSelected = 'isProductCategory';
    }
    this.state = {
      filterArr: [
        { key: 'city' },
        { key: 'account' },
        { key: 'isProductCategory' },
      ],
      city: {
        limit: 10,
        offset: 0,
        selectedArr: cityArr || [],
        arrlist: [],
        isAPICalled: false,
        apiOnScroll: false,
        disPlayStr: 'City/State',
        urlname: '/searchColleagues/searchRepByNameCityFilter',
      },
      account: {
        limit: 10,
        offset: 0,
        selectedArr: hospitalArr || [],
        arrlist: [],
        isAPICalled: false,
        apiOnScroll: false,
        disPlayStr: 'Account',
        urlname: '/searchColleagues/searchRepByNameHospitalFilter',
      },
      isProductCategory: {
        limit: 10,
        offset: 0,
        selectedArr: productcategoryFilterArr || [],
        arrlist: [],
        isAPICalled: false,
        apiOnScroll: false,
        disPlayStr: 'Product Line',
        urlname: '/searchColleagues/searchRepByNameProductLineFilter',
      },
      isSelected,
    };
  }

  componentDidMount() {
    // Call all three apis
    this.callApi('city');
    this.callApi('account');
    this.callApi('isProductCategory');
  }

  componentWillUnmount() {
    this.cancelAPIreq(); // Cancel API req if api is in progress
  }

  /**
   *  To cancel Api reuqest
   */
  cancelAPIreq() {
    const { filterArr } = this.state;
    const stateVal = this.state;
    filterArr.forEach((item) => {
      const { source } = stateVal[item.key];
      if (source) {
        source.cancel('API request canceled.');
      }
    });
  }

  /**
   * Summary. filter checkbox onchange event
   *
   * Description. Set/Reset city, account and product line filters
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Object}   e               event object
   * @param {Object}   item            filter object
   * @param {string}   name            key value
   *
   */
  handleCheckboxChange = (e, item, name) => {
    const { checked } = e.target;
    const { id } = item;
    if (checked) {
      this.setState((prevState) => ({
        [name]: {
          ...prevState[name],
          selectedArr: uniq([...prevState[name].selectedArr, id]),
        },
      }));
    } else {
      this.setState((prevState) => ({
        [name]: {
          ...prevState[name],
          selectedArr: prevState[name].selectedArr.filter((v) => v !== id),
        },
      }));
    }
  };

  /**
   * Summary. Call city, hospital and product line filter API
   *
   * Description. To retrive all the list as per the API's
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   name            key value
   */
  callApi = (name) => {
    const stateVal = this.state;
    const currentKey = stateVal[name];
    const source = getCancelToken();
    this.setState((prevState) => ({
      [name]: {
        ...prevState[name],
        isAPICalled: true,
        source,
      },
    }));

    const { limit, offset, urlname } = currentKey;
    const { text, companyId } = this.props;

    axiosApi(
      `${urlname}?name=${text}&limit=${limit}&offset=${offset}&companyId=${companyId}&repId=${app.user.id}`,
      'GET',
      '',
      (res) => {
        if (!isEmpty(res.data)) {
          const resObj = res.data.items;
          if (offset === 0) {
            this.setState((prevState) => ({
              [name]: {
                ...prevState[name],
                arrlist: resObj,
              },
            }));
          } else {
            this.setState((prevState) => ({
              [name]: {
                ...prevState[name],
                arrlist: [...prevState[name].arrlist, ...resObj],
              },
            }));
          }
          if (res.data.isMore) {
            this.setState((prevState) => ({
              [name]: {
                ...prevState[name],
                offset: offset + limit,
              },
            }));
          } else {
            this.setState((prevState) => ({
              [name]: {
                ...prevState[name],
                offset: 0,
              },
            }));
          }
        }
        this.setState((prevState) => ({
          [name]: {
            ...prevState[name],
            isAPICalled: false,
            apiOnScroll: false,
            source: '',
          },
        }));
      },
      source.token
    );
  };

  /**
   * Summary. On scroll event
   *
   * Description. Load more filter list on scroll
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param  {Object}   e      event object
   * @param  {string}   keyVal key value (selected filter)
   */
  onScroll = (e, keyVal) => {
    const stateVal = this.state;
    const currentKey = stateVal[keyVal];
    const { offset, apiOnScroll } = currentKey;
    if (scrollCheck(e, offset, apiOnScroll)) {
      this.setState((prevState) => ({
        [keyVal]: {
          ...prevState[keyVal],
          apiOnScroll: false,
        },
      }));
      this.callApi(keyVal);
    }
  };

  /**
   * Summary. Change filter name
   *
   * Description. Change the filter either city, account or product line
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}       name             name of the filter
   *
   */
  onChangeFilter = (name) => {
    this.setState({
      isSelected: name,
    });
  };

  /**
   *  Returns the selected filter array list
   */
  getAllFilterSelectedArr = () => {
    const { filterArr } = this.state;
    const stateVal = this.state;
    let cityArr = [];
    let hospitalArr = [];
    let productcategoryFilterArr = [];
    filterArr.forEach((item) => {
      const { selectedArr } = stateVal[item.key];
      if (item.key === 'city') {
        cityArr = selectedArr;
      } else if (item.key === 'account') {
        hospitalArr = selectedArr;
      } else if (item.key === 'isProductCategory') {
        productcategoryFilterArr = selectedArr;
      }
    });
    return {
      cityArr,
      hospitalArr,
      productcategoryFilterArr,
    };
  };

  /**
   *  Apply filter btn click event
   */
  onFilterClick = () => {
    const {
      cityArr,
      hospitalArr,
      productcategoryFilterArr,
    } = this.getAllFilterSelectedArr();
    if (
      cityArr.length ||
      hospitalArr.length ||
      productcategoryFilterArr.length
    ) {
      const { onFilterClick } = this.props;
      onFilterClick(cityArr, hospitalArr, productcategoryFilterArr);
    } else {
      alert('Please select any company or product line');
    }
  };

  /**
   *  Reset btn click event
   */
  onResetClick = () => {
    const { onResetClick } = this.props;
    onResetClick();
  };

  render() {
    const { masterStateList, onStateChange, selectedStates } = this.props;
    const { isSelected, filterArr } = this.state;
    const stateVal = this.state;

    const {
      cityArr,
      hospitalArr,
      productcategoryFilterArr,
    } = this.getAllFilterSelectedArr();

    return (
      <div className="filter-list-wrap" style={{ right: '-24px' }}>
        <div className={`product-wrap ${isSelected ? 'height_add' : ''}`}>
          <div className="wid-50">
            <ul className="filter-list">
              {filterArr.map((v) => {
                return (
                  <li
                    role="presentation"
                    onClick={() => {
                      this.onChangeFilter(v.key);
                    }}
                    className={isSelected === v.key ? 'selected' : ''}
                    data-repcard-test={v.key}
                    key={v.key}
                  >
                    {stateVal[v.key].disPlayStr} (
                    <span>{stateVal[v.key].selectedArr.length}</span>)
                  </li>
                );
              })}
            </ul>
            {isSelected ? (
              <div className="filter-btn">
                <FilterButtons
                  onFilterClick={this.onFilterClick}
                  onResetClick={this.onResetClick}
                  isBtnEnable={
                    productcategoryFilterArr.length ||
                    cityArr.length ||
                    hospitalArr.length
                  }
                />
              </div>
            ) : (
              ''
            )}
          </div>
          {isSelected ? (
            <div className="wid-50 selected">
              <SearchFilterList
                filterList={stateVal[isSelected].arrlist}
                filterArr={stateVal[isSelected].selectedArr}
                onScroll={(e) => {
                  this.onScroll(e, isSelected);
                }}
                onChange={(e, item) => {
                  this.handleCheckboxChange(e, item, isSelected);
                }}
                onStateChange={(e, item) => {
                  onStateChange(e, item);
                }}
                isAPICalled={stateVal[isSelected].isAPICalled}
                isSelected={isSelected}
                masterStateList={masterStateList}
                selectedStates={selectedStates}
              />
            </div>
          ) : (
            ''
          )}
        </div>
      </div>
    );
  }
}

export default Filters;
