/**
 *
 * Description. Rep's search grid
 *
 * @link   URL
 * @file   Display Rep's information
 * @since  1.0.0
 */
import React, { Component } from 'react';
import { MDBInput } from 'mdbreact';

/**
 * Summary. Rep Html
 *
 * Description. Returns Rep search grid with radio button
 *
 * @since      1.0
 * @deprecated No //x.x.x Use new_function_name() instead.
 * @access     export public
 *
 * @param {Object}   item           Rep Object
 * @param {string}   selectedRep    selected rep info
 * @param {function} onRadioClick   Callback function for radio btn click
 *
 */
class SearchRepRow extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    const { item, selectedRep, onRadioClick } = this.props;
    const selectedId = selectedRep ? selectedRep.id : '';
    return (
      <li>
        <span>
          {item.firstName} {item.lastName}
        </span>
        <div className="d-inline-block radio-fix">
          <MDBInput
            gap
            onClick={() => {
              onRadioClick(item);
            }}
            label=" "
            checked={item.id === selectedId}
            type="radio"
            id={`radio${item.id}`}
          />
        </div>
      </li>
    );
  }
}

export default SearchRepRow;
