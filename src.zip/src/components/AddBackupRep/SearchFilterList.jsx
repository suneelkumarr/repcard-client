import React from 'react';
import { MDBInput } from 'mdbreact';
/**
 * Summary. Search filter list
 *
 * Description. Retruns html of right hand side filter section
 *
 * @since      1.0
 * @deprecated No //x.x.x Use new_function_name() instead.
 * @access     export public
 *
 * @param  {Array}      filterList     list of filters
 * @param  {Array}      filterArr      selected filters array
 * @param  {function}   onScroll       callback function of scroll
 * @param  {function}   onChange       callback function of checkbox change
 * @param  {boolean}    isAPICalled    flag for wait for an api
 */
// eslint-disable-next-line
export const SearchFilterList = ({
  filterList,
  filterArr,
  onScroll,
  onChange,
  isAPICalled,
  isSelected,
  masterStateList,
  onStateChange,
  selectedStates,
}) => {
  if (isAPICalled && !filterList.length) {
    return 'Please wait';
  }

  if (isSelected === 'city') {
    const allStateIds = filterList.map((city) => city.stateId);
    const newStateList = masterStateList
      .filter((state) => {
        return allStateIds.includes(state.id);
      })
      .map((state) => {
        return {
          ...state,
          cities: filterList.filter((city) => city.stateId === state.id),
        };
      });
    return (
      <ul className="filter-list overflow-lists" onScroll={onScroll}>
        {newStateList.map((state) => {
          return (
            <li key={state.id}>
              <MDBInput
                label={state.state}
                onChange={(e) => {
                  onStateChange(e, state);
                }}
                checked={selectedStates.includes(state.id)}
                filled
                type="checkbox"
                id={`filter${state.id}`}
              />
              {selectedStates.indexOf(state.id) !== -1 ? (
                <ul className="filter-list ml-3">
                  {state.cities.map((city) => {
                    return (
                      <li key={city.id}>
                        <MDBInput
                          label={city.city}
                          onChange={(e) => {
                            onChange(e, city);
                          }}
                          checked={filterArr.includes(city.id)}
                          filled
                          type="checkbox"
                          id={`filtersubcat${city.id}`}
                        />
                      </li>
                    );
                  })}
                </ul>
              ) : (
                ''
              )}
            </li>
          );
        })}
      </ul>
    );
  }

  return (
    <ul className="filter-list overflow-lists" onScroll={onScroll}>
      {filterList.map((v) => {
        return (
          <li key={v.id}>
            <MDBInput
              label={v.city || v.name}
              onChange={(e) => {
                onChange(e, v);
              }}
              checked={filterArr.indexOf(v.id) !== -1}
              filled
              type="checkbox"
              id={`filter${v.id}`}
            />
          </li>
        );
      })}
    </ul>
  );
};
