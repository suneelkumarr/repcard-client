/**
 *
 * Description.  Rep Invite
 *
 * @link   URL
 * @file   Any Rep user can invite another rep using below component
 * @since  1.0.0
 */
import React, { Component } from 'react';
import { MDBInput, MDBRow, MDBCol, MDBIcon } from 'mdbreact';
import validateObj from '../../validations/repprofile/repfront.js';
import { axiosApi } from '../../apis/axiosApiCall';
import getCancelToken from '../../apis/getCancelToken';
import app from '../../helpers/appGlobal';

class InviteRep extends Component {
  constructor(props) {
    super(props);
    this.state = {
      profileRes: {},
      openInvite: false,
      inputClass: {},
      errorObj: {},
    };
  }

  componentDidMount() {}

  componentWillUnmount() {
    this.cancelAPIreq(); // Cancel API req if api is in progress
  }

  /**
   *  To cancel Api reuqest
   */
  cancelAPIreq() {
    const { source } = this.state;
    if (source) {
      source.cancel('API request canceled.');
    }
  }

  /**
   * Summary. Form validation
   *
   * Description. Validate form on submit click
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @return {boolean} false if not valid else true
   */
  validate() {
    const { profileRes } = this.state;
    const { firstName, lastName, email, profileurl } = profileRes;
    let isValid = true;
    let error;

    error = this.validateInput('firstName', firstName);
    if (error) {
      isValid = false;
    }

    error = this.validateInput('usernname', profileurl);
    if (error) {
      isValid = false;
    }

    error = this.validateInput('lastName', lastName);
    if (error) {
      isValid = false;
    }

    error = this.validateInput('email', email);
    if (error) {
      isValid = false;
    }

    return isValid;
  }

  /**
   * Summary. Validate Input
   *
   * Description. Sets the error to errorObj and className to inputClass object
   *              if any validation error found.
   *              errorObj is used for displaying the errors for particular input
   *              inputClas is used for Adding error classNames for particular input
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   name           Input element name
   * @param {string}   value          Input element value
   * @param {string}   value1         additional value
   *
   * @return {String} Error if any else null
   */
  validateInput(name, value, value1) {
    if (validateObj[name]) {
      let error = '';
      let className = 'error-border';
      error = validateObj[name](value, value1);
      if (!error) {
        className = '';
      }

      this.setState((prevState) => ({
        errorObj: {
          ...prevState.errorObj,
          [name]: error,
        },
        inputClass: {
          ...prevState.inputClass,
          [name]: className,
        },
      }));

      return error;
    }
    return '';
  }

  /**
   * Summary. Set input values
   *
   * Description. Update All the input values to state
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   name           name of the input
   * @param {string}   value          value of the input
   *
   */
  setValue = (name, value) => {
    this.setState((prevState) => ({
      profileRes: {
        ...prevState.profileRes,
        [name]: value,
      },
    }));
  };

  /**
   * Summary. OnChange event
   *
   * Description. Input Change method for all input
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   e           Input element event object
   *
   */
  onChange = (e) => {
    const { name, value } = e.target;
    this.setValue(name, value);
  };

  /**
   * Summary. OnBlur event
   *
   * Description. Blur method for all input
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   e           Input element event object
   *
   */
  onBlur = (e) => {
    const { name } = e.target;
    const { profileRes } = this.state;
    this.validateInput(name, profileRes[name]);
  };

  /**
   * Summary. Rep Invite API
   *
   * Description. Send an email to invite a Rep
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  inviteRepApiCall = () => {
    const { profileRes } = this.state;
    const { firstName, lastName, email, profileurl } = profileRes;
    const source = getCancelToken();
    this.setState({
      isAPICalled: true,
      apiErrorMessage: '',
      source,
    });

    const reqObj = {
      firstName,
      lastName,
      email,
      profileurl,
      inviterName: `${app.user.firstName} ${app.user.lastName}`,
    };

    axiosApi(
      '/searchColleagues/inviteRep',
      'POST',
      reqObj,
      (res) => {
        this.setState({
          isAPICalled: false,
          source: '',
        });
        if (res.error) {
          this.setState({
            apiErrorMessage: res.message,
          });
        } else {
          this.setState({
            isEmailSent: true,
          });
        }
      },
      source.token
    );
  };

  /**
   * Summary. Form submit
   *
   * Description. Validate the form and call the api
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param  {object}      e       event object
   */
  onBtnClick = (e) => {
    e.preventDefault();
    const isValid = this.validate();
    if (isValid) {
      this.inviteRepApiCall();
    }
  };

  /**
   * Toggle invite box
   */
  toggle = () => {
    this.setState((prevState) => ({
      openInvite: !prevState.openInvite,
    }));
  };

  render() {
    const {
      profileRes,
      errorObj,
      inputClass,
      isAPICalled,
      openInvite,
      apiErrorMessage,
      isEmailSent,
    } = this.state;
    const { firstName, lastName, email } = profileRes;

    return (
      <div className="find_rep mt-3">
        <p
          className={`find_rep_txt ${openInvite ? 'active' : ''}`}
          onClick={this.toggle}
          role="presentation"
          data-repcard-test="toggle"
        >
          <MDBIcon icon="caret-down" /> Didn’t find the person you looking for?
        </p>
        {openInvite ? (
          <div className="invite_rep">
            <div
              className="invite_close"
              onClick={this.toggle}
              role="presentation"
            />
            <form onSubmit={this.onBtnClick} noValidate>
              <MDBRow>
                <MDBCol lg="12">
                  <p className="invite_txt">
                    Invite My Colleague to Join REPCARDz
                  </p>
                </MDBCol>
                {isEmailSent ? (
                  <MDBCol lg="12">
                    <p className="text-center green-text">
                      An Invite has been sent.
                    </p>
                  </MDBCol>
                ) : (
                  <>
                    <MDBCol lg="4">
                      <div className={`input-field ${inputClass.firstName}`}>
                        <MDBInput
                          type="text"
                          value={firstName}
                          name="firstName"
                          onChange={this.onChange}
                          onBlur={this.onBlur}
                          label="First Name"
                        />
                        {errorObj.firstName ? (
                          <span className="error-message">
                            {errorObj.firstName}
                          </span>
                        ) : (
                          ''
                        )}
                      </div>
                    </MDBCol>
                    <MDBCol lg="4">
                      <div className={`input-field ${inputClass.lastName}`}>
                        <MDBInput
                          type="text"
                          value={lastName}
                          name="lastName"
                          onChange={this.onChange}
                          onBlur={this.onBlur}
                          label="Last Name"
                        />
                        {errorObj.lastName ? (
                          <span className="error-message">
                            {errorObj.lastName}
                          </span>
                        ) : (
                          ''
                        )}
                      </div>
                    </MDBCol>
                    <MDBCol lg="4">
                      <div className={`input-field ${inputClass.email}`}>
                        <MDBInput
                          type="email"
                          value={email}
                          onBlur={this.onBlur}
                          name="email"
                          onChange={this.onChange}
                          label="Company Email"
                        />
                        {errorObj.email ? (
                          <span className="error-message">
                            {errorObj.email}
                          </span>
                        ) : (
                          ''
                        )}
                      </div>
                    </MDBCol>
                    <MDBCol lg="12">
                      <div className="text-center">
                        <button
                          type="submit"
                          className="fill-orange-btn"
                          disabled={isAPICalled}
                        >
                          {isAPICalled ? (
                            <span className="spinner-border spinner-border-sm" />
                          ) : (
                            ''
                          )}
                          Invite
                        </button>
                        {apiErrorMessage ? (
                          <p className="error-message1">{apiErrorMessage}</p>
                        ) : (
                          ''
                        )}
                      </div>
                    </MDBCol>
                  </>
                )}
              </MDBRow>
            </form>
          </div>
        ) : (
          ''
        )}
      </div>
    );
  }
}

export default InviteRep;
