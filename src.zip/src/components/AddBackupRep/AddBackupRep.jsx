/**
 *
 * Description. Adding Backup Rep for vacation
 *
 * @link   URL
 * @file   When user is on vacation the user need to set backup rep using this component
 * @since  1.0.0
 */
import React, { Component } from 'react';
import isEmpty from 'lodash/isEmpty';
import { MDBModalBody, MDBInput } from 'mdbreact';
import uniq from 'lodash/uniq';
import Filters from './Filters';
import ProfileHeading from '../Common/ProfileHeading';
import SearchRepRow from './SearchRepRow.jsx';
import InviteRep from './InviteRep.jsx';
import { axiosApi } from '../../apis/axiosApiCall';
import isEnterKeyPressed from '../../utils/checkEnterKeyPressed';
import scrollCheck from '../../utils/scrollCheck';
import app from '../../helpers/appGlobal';
import { getMasterStatesDataWithCities } from '../../utils/masterProductCategoryData';

import './AddBackupRep.scss';

class AddBackupRep extends Component {
  constructor(props) {
    super(props);
    this.state = {
      limit: 10,
      offset: 0,
      text: '',
      searchResults: [],
      isAPICalled: false,
      apiOnScroll: false,
      filterOpen: false,
      productcategoryFilterArr: [],
      cityArr: [],
      hospitalArr: [],
      currentSearchName: '',
      selectedRep: '',
      masterStateList: [],
      selectedStates: [],
    };
  }

  getStatesData = () => {
    getMasterStatesDataWithCities((dataArr) => {
      if (!isEmpty(dataArr)) {
        this.setState({
          masterStateList: dataArr,
        });
      }
    });
  };

  /**
   *  Toggle filter menu
   */
  filterSelectOpen = () => {
    this.setState((prevState) => ({
      filterOpen: !prevState.filterOpen,
      selectedStates: prevState.filterOpen ? [] : prevState.selectedStates,
    }));
  };

  /**
   * Summary. Apply filter click event
   *
   * Description. Call search API with city, hospital and productcategory filters
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Array}   cityArr              array list of cities
   * @param {Array}   hospitalArr          list of hospitals
   * @param {Array}   productcategoryFilterArr  list of productcategories
   *
   */
  onFilterClick = (cityArr, hospitalArr, productcategoryFilterArr) => {
    this.setState(
      {
        offset: 0,
        searchResults: [],
        isAPICalled: false,
        apiOnScroll: false,
        filterOpen: false,
        cityArr,
        hospitalArr,
        productcategoryFilterArr,
      },
      () => {
        this.callSearchApi();
      }
    );
  };

  /**
   *  Reset btn click - Remove All the filters and call search API
   */
  onResetClick = () => {
    this.setState(
      {
        offset: 0,
        searchResults: [],
        isAPICalled: false,
        apiOnScroll: false,
        filterOpen: false,
        productcategoryFilterArr: [],
        cityArr: [],
        hospitalArr: [],
        selectedStates: [],
      },
      () => {
        this.callSearchApi();
      }
    );
  };

  componentDidMount() {
    this.getStatesData();
  }

  /**
   *  Rep Selection click
   */
  onRadioClick = (rep) => {
    this.setState({
      selectedRep: rep,
    });
  };

  /**
   * Summary. Provider Search API
   *
   * Description. To retrive all the search results using api call with city
   *              and hospital and productcategory filters along with limit and offset
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  callSearchApi = () => {
    this.setState({
      isAPICalled: true,
    });
    const { companyId } = this.props;
    const {
      limit,
      offset,
      text,
      productcategoryFilterArr,
      cityArr,
      hospitalArr,
    } = this.state;
    const reqObj = {
      filters: {},
    };

    if (productcategoryFilterArr.length) {
      reqObj.filters.productcategory = productcategoryFilterArr;
    }

    if (cityArr.length) {
      reqObj.filters.city = cityArr;
    }

    if (hospitalArr.length) {
      reqObj.filters.account = hospitalArr;
    }

    axiosApi(
      `/searchColleagues/searchColleaguesByName?type=name&name=${text}&limit=${limit}&offset=${offset}&companyId=${companyId}&repId=${app.user.id}`,
      'POST',
      reqObj,
      (res) => {
        if (res.data) {
          const resObj = res.data.items;
          if (offset === 0) {
            this.setState({
              searchResults: resObj,
            });
          } else {
            this.setState((prevState) => ({
              searchResults: [...prevState.searchResults, ...resObj],
            }));
          }

          if (res.data.isMore) {
            this.setState({
              offset: offset + limit,
            });
          } else {
            this.setState({
              offset: 0,
            });
          }
        }
        this.setState({
          isAPICalled: false,
          apiOnScroll: false,
          currentSearchName: text,
        });
      }
    );
  };

  handleStateCheckboxChange = (e, item) => {
    const { checked } = e.target;
    const { id } = item;
    const { selectedStates } = this.state;
    if (checked) {
      this.setState({
        selectedStates: uniq([...selectedStates, id]),
      });
    } else {
      this.setState({
        selectedStates: selectedStates.filter((v) => v !== id),
      });
    }
  };

  /**
   * Summary. Search API call
   *
   * Description. Call the search API as per the text
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  onSearch = () => {
    const { text } = this.state;
    if (text.length < 3) {
      alert('minimum 3 characters');
    } else {
      this.setState(
        {
          offset: 0,
          searchResults: [],
          isAPICalled: false,
          apiOnScroll: false,
          filterOpen: false,
          productcategoryFilterArr: [],
          cityArr: [],
          hospitalArr: [],
        },
        () => {
          this.callSearchApi();
        }
      );
    }
  };

  /**
   * Summary. Clear results click event
   *
   * Description. Remove and clear all the results with filters
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  clearResults = () => {
    this.setState({
      offset: 0,
      searchResults: [],
      isAPICalled: false,
      apiOnScroll: false,
      filterOpen: false,
      productcategoryFilterArr: [],
      cityArr: [],
      hospitalArr: [],
      text: '',
      currentSearchName: '',
    });
  };

  /**
   * Summary. Search input
   *
   * Description. Input Change method for search input
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   e           Input element event object
   *
   */
  onChange = (e) => {
    const { value } = e.target;
    this.setState({
      text: value,
      filterOpen: false,
    });
  };

  /**
   * Summary. On scroll event
   *
   * Description. Load more search results on scroll
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param  {Object}   e      event object
   */
  onScroll = (e) => {
    const { offset, apiOnScroll } = this.state;
    if (scrollCheck(e, offset, apiOnScroll)) {
      this.setState({
        apiOnScroll: true,
      });
      this.callSearchApi();
    }
  };

  /**
   * Summary. On keyDown event
   *
   * Description. Check if enter key pressed and call search api if true
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param  {Object}   e      event object
   */
  onKeyDown = (e) => {
    if (isEnterKeyPressed(e)) {
      this.onSearch();
    }
  };

  onSaveBackupRep = () => {
    const { selectedRep } = this.state;
    const { onSaveBackupRep } = this.props;
    onSaveBackupRep(selectedRep);
  };

  render() {
    const {
      filterOpen,
      text,
      isAPICalled,
      searchResults,
      selectedRep,
      currentSearchName,
      cityArr,
      hospitalArr,
      productcategoryFilterArr,
      masterStateList,
      selectedStates,
    } = this.state;
    const { companyId } = this.props;

    let isFilterDisable = false;
    if (currentSearchName !== text) {
      isFilterDisable = true;
    }

    return (
      <MDBModalBody>
        <div className="d-inline-block">
          <ProfileHeading headingtxt="Add Backup Rep" />
        </div>
        <div className="d-block">
          <div className="select_panel d-inline-block">
            <MDBInput
              type="search"
              hint="Type Name"
              onChange={this.onChange}
              name="textSearch"
              value={text}
              disabled={false}
              autoComplete="off"
              onKeyDown={this.onKeyDown}
              className="search_name"
              placeholder="Name"
            />
          </div>
          <button
            type="button"
            className={`search_btn ${
              isAPICalled || text.length < 3 ? 'noEvents' : ''
            }`}
            onClick={this.onSearch}
            disabled={isAPICalled || text.length < 3}
            data-repcard-test="search"
          >
            {isAPICalled ? (
              <span className="spinner-border spinner-border-sm" />
            ) : (
              'Search'
            )}
          </button>
          <span
            className={`clear_btn ${
              searchResults.length || currentSearchName || text
                ? 'cursor'
                : 'noEvents disable_text'
            }`}
            onClick={this.clearResults}
            role="presentation"
            data-repcard-test="clear"
          >
            Clear Results
          </span>
          {searchResults.length ? (
            <div
              className={`filter-panel account_filter_panel ${
                isFilterDisable ? 'noEvents' : ''
              }`}
            >
              <div
                className={`filter-list-name ${filterOpen ? 'active' : ''}`}
                onClick={this.filterSelectOpen}
                role="presentation"
                data-repcard-test="filter"
              >
                <span className="shape mr-1" />
                Filter
              </div>
              {filterOpen ? (
                <Filters
                  text={text}
                  companyId={companyId}
                  onFilterClick={this.onFilterClick}
                  onResetClick={this.onResetClick}
                  productcategoryFilterArr={productcategoryFilterArr}
                  cityArr={cityArr}
                  hospitalArr={hospitalArr}
                  masterStateList={masterStateList}
                  selectedStates={selectedStates}
                  onStateChange={this.handleStateCheckboxChange}
                />
              ) : (
                ''
              )}
            </div>
          ) : (
            ''
          )}
        </div>

        {searchResults.length ? (
          <div className="backuprep_list mt-2">
            <ul className="repList" onScroll={this.onScroll}>
              {searchResults.map((v) => {
                return (
                  <SearchRepRow
                    item={v}
                    key={v.id}
                    selectedRep={selectedRep}
                    onRadioClick={this.onRadioClick}
                  />
                );
              })}
            </ul>
          </div>
        ) : (
          <div className="no_result_txt">
            {currentSearchName && !isAPICalled
              ? 'There are no results for your search. Please try again.'
              : ''}
          </div>
        )}

        <InviteRep />

        <div className="text-center">
          <button
            type="button"
            className="fill-orange-btn"
            disabled={!selectedRep}
            onClick={this.onSaveBackupRep}
            data-repcard-test="saveRep"
          >
            Save
          </button>
        </div>
      </MDBModalBody>
    );
  }
}

export default AddBackupRep;
