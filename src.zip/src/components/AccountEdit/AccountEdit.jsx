/**
 *
 * Description. Account Edit functionality
 *
 * @link   URL
 * @file   User can update the password from Rep/Provider Dashboard Page
 * @since  1.0.0
 */

import React, { Component } from 'react';
import { MDBContainer, MDBRow, MDBCol, MDBInput, Fa } from 'mdbreact';
import ProfileHeading from '../Common/ProfileHeading';
import app from '../../helpers/appGlobal';
import { axiosApi } from '../../apis/axiosApiCall';
import validateObj from '../../validations/repprofile/repfront.js';

class AccountEdit extends Component {
  constructor(props) {
    super(props);
    this.state = {
      inputClass: {},
      errorObj: {},
      password: '',
    };
  }

  componentDidMount() {}

  /**
   * Summary. Validate Input
   *
   * Description. Sets the error to errorObj and className to inputClass object
   *              if any validation error found.
   *              errorObj is used for displaying the errors for particular input
   *              inputClas is used for Adding error classNames for particular input
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   name           Input element name
   * @param {string}   value          Input element value
   * @param {string}   value1         Input element Addtional value
   *
   * @return {String} Error if any else null
   */
  validateInput(name, value, value1) {
    if (validateObj[name]) {
      let error = '';
      let className = 'error-border';
      error = validateObj[name](value, value1);
      if (!error) {
        className = '';
      }

      this.setState((prevState) => ({
        errorObj: {
          ...prevState.errorObj,
          [name]: error,
        },
        inputClass: {
          ...prevState.inputClass,
          [name]: className,
        },
      }));

      return error;
    }
    return '';
  }

  /**
   * Summary. OnChange event
   *
   * Description. Input Change method for all input
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   e           Input element event object
   *
   */
  onChange = (e) => {
    const { name, value } = e.target;
    this.setState({
      [name]: value,
    });
  };

  /**
   * Summary. OnBlur event
   *
   * Description. Blur method for all input
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   e           Input element event object
   *
   */
  onBlur = (e) => {
    const { password } = this.state;
    const { name, value } = e.target;
    this.validateInput(name, value, password);
  };

  /**
   * Summary. Form validation
   *
   * Description. Validate form on submit click
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @return {boolean} false if not valid else true
   */
  validate() {
    const { password, confirmpass } = this.state;
    let isValid = true;
    let error;

    error = this.validateInput('password', password);
    if (error) {
      isValid = false;
    }

    error = this.validateInput('confirmpass', confirmpass, password);
    if (error) {
      isValid = false;
    }

    return isValid;
  }

  /**
   * Summary. Update Password API Call
   *
   * Description. Calls the update password API and redirected to dashboard on
   *              success otherwise display error
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  updatePasswordApiCall = () => {
    const { password } = this.state;
    const reqObj = {
      password,
      userid: app.user.id,
      userType: app.user.userType,
    };

    this.setState({
      isAPICalled: true,
      apiErrorMessage: '',
    });
    axiosApi('/resetpwd/updatePasswordWithoutToken', 'POST', reqObj, (res) => {
      this.setState({
        isAPICalled: false,
      });
      if (res.error) {
        this.setState({
          apiErrorMessage: res.message,
        });
      } else {
        const { goBackToDashboardAndSave } = this.props;
        goBackToDashboardAndSave();
      }
    });
  };

  /**
   * Summary. Form submit
   *
   * Description. Validate the form and call the api
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param  {object}      e       event object
   */
  onBtnClick = (e) => {
    e.preventDefault();
    const isValid = this.validate();
    if (isValid) {
      this.updatePasswordApiCall();
    }
  };

  /**
   * Summary. Password Toggle
   *
   * Description. Toggle password on click of eye icon
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   e           Input element event object
   * @param {String}   name        name of the inout field
   */
  handleClickShowPassword = (e, name) => {
    e.preventDefault();
    this.setState((prevState) => ({
      [name]: !prevState[name],
    }));
  };

  // onFocus method to remove readOnly field if there
  onFocus = (e) => {
    const node = e.target;
    // This is used for prevent autofill passwords on the input
    if (node.hasAttribute('readonly')) {
      node.removeAttribute('readonly');
      // fix for mobile safari to show virtual keyboard
      // node.blur();
      // node.focus();
    }
  };

  render() {
    const {
      errorObj,
      inputClass,
      password,
      confirmpass,
      apiErrorMessage,
      isAPICalled,
      showPassword,
      showPassword1,
    } = this.state;
    const { goBackToDashboard } = this.props;
    const isBtnDisable = !(password && confirmpass) || isAPICalled;
    return (
      <MDBContainer>
        <MDBRow>
          <MDBCol lg="8" className="my-5">
            <div className="heading_section">
              <span
                className="left_icon cursor"
                role="presentation"
                onClick={goBackToDashboard}
                data-repcard-test="back"
              />
              <ProfileHeading headingtxt="Account Credentials" />
            </div>
            <form onSubmit={this.onBtnClick} noValidate>
              <MDBRow>
                <MDBCol lg="12">
                  <div className="input-field noEvents">
                    <MDBInput
                      type="text"
                      value={app.user.email}
                      name="email"
                      label="Email"
                      disabled
                    />
                  </div>
                </MDBCol>
                <MDBCol lg="6">
                  <div
                    className={`input-field ${
                      errorObj.password && errorObj.password.length > 100
                        ? 'password_field'
                        : ''
                    } ${inputClass.password}`}
                  >
                    <MDBInput
                      label="Password"
                      name="password"
                      readOnly
                      onFocus={this.onFocus}
                      onChange={this.onChange}
                      type={showPassword ? 'text' : 'password'}
                      required
                      value={password}
                      onBlur={this.onBlur}
                    />
                    <div
                      className="p-0 password-icon"
                      onClick={(e) => {
                        this.handleClickShowPassword(e, 'showPassword');
                      }}
                      onMouseDown={(e) => e.preventDefault()}
                      role="presentation"
                      data-repcard-test="pass-icon"
                    >
                      <Fa far icon={showPassword ? 'eye' : 'eye-slash'} />
                    </div>
                    {errorObj.password ? (
                      <span className="error-message">{errorObj.password}</span>
                    ) : (
                      ''
                    )}
                  </div>
                </MDBCol>
                <MDBCol lg="6">
                  <div className={`input-field ${inputClass.confirmpass}`}>
                    <MDBInput
                      label="Confirm Password"
                      name="confirmpass"
                      readOnly
                      onFocus={this.onFocus}
                      onChange={this.onChange}
                      type={showPassword1 ? 'text' : 'password'}
                      required
                      value={confirmpass}
                      onBlur={this.onBlur}
                      onContextMenu={(e) => {
                        e.preventDefault();
                      }}
                      onPaste={(e) => {
                        e.preventDefault();
                      }}
                    />
                    <div
                      className="p-0 password-icon"
                      onClick={(e) => {
                        this.handleClickShowPassword(e, 'showPassword1');
                      }}
                      onMouseDown={(e) => e.preventDefault()}
                      role="presentation"
                      data-repcard-test="pass-icon1"
                    >
                      <Fa far icon={showPassword1 ? 'eye' : 'eye-slash'} />
                    </div>
                    {errorObj.confirmpass ? (
                      <span className="error-message">
                        {errorObj.confirmpass}
                      </span>
                    ) : (
                      ''
                    )}
                  </div>
                </MDBCol>
              </MDBRow>
              <div className="btn_panel mt-4">
                <button
                  type="submit"
                  className="fill-orange-btn"
                  disabled={isBtnDisable}
                >
                  {isAPICalled ? (
                    <span className="spinner-border spinner-border-sm" />
                  ) : (
                    ''
                  )}
                  Save
                </button>
                <button
                  type="submit"
                  className="outline-btn"
                  onClick={goBackToDashboard}
                >
                  Cancel
                </button>
                {apiErrorMessage ? (
                  <p className="error-message1">{apiErrorMessage}</p>
                ) : (
                  ''
                )}
              </div>
            </form>
          </MDBCol>
        </MDBRow>
      </MDBContainer>
    );
  }
}

export default AccountEdit;
