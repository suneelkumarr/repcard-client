import React, { Component } from 'react';
import { MDBModal, MDBModalBody, MDBModalHeader } from 'mdbreact';

class Share extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isCopySuccess: false,
    };
  }

  copyToClipbord = (Profileurl) => {
    const textArea = document.createElement('textarea');
    textArea.value = Profileurl;

    // Avoid scrolling to bottom
    textArea.style.top = '0';
    textArea.style.left = '0';
    textArea.style.position = 'fixed';

    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();

    try {
      const successful = document.execCommand('copy');
      if (successful) {
        this.setState(
          {
            isCopySuccess: true,
          },
          () => {
            setTimeout(() => {
              this.setState({ isCopySuccess: false });
            }, 3000);
          }
        );
      } else alert('Oops, unable to copy');
    } catch (err) {
      alert('Oops, unable to copy');
    }

    document.body.removeChild(textArea);
  };

  render() {
    const { isCopySuccess } = this.state;
    const { profileurl, open, toggle } = this.props;
    const shareUrl = `${window.location.origin}/r/${profileurl}`;
    return (
      <MDBModal isOpen={open} toggle={toggle}>
        <MDBModalHeader toggle={toggle}>Share profile</MDBModalHeader>
        <MDBModalBody>
          <p>
            {shareUrl}{' '}
            <span
              className="txt_orange cursor"
              onClick={() => this.copyToClipbord(shareUrl)}
            >
              {isCopySuccess ? 'Copied' : 'Copy'}
            </span>
          </p>
        </MDBModalBody>
      </MDBModal>
    );
  }
}

export default Share;
