/**
 *
 * Description. Utility function for header
 *
 * @link   URL
 * @file   Return header html with edit button
 * @since  1.0.0
 */
import React from 'react';
import { MDBBtn, MDBIcon } from 'mdbreact';

/**
 * Summary. Profile Header html
 *
 * Description. Profile Header html
 *
 * @since      1.0
 * @deprecated No //x.x.x Use new_function_name() instead.
 * @access     export public
 *
 * @param {string}    headingtxt      header text to display
 * @param {boolean}   buttonenable    flag for showing edit button
 * @param {function}  onClick         Callback function for edit button click
 *
 */
const ProfileHeading = ({ headingtxt, buttonenable, onClick }) => {
  return (
    <>
      {headingtxt ? (
        <h5 className="heading-h5 mr-2 d-md-inline-block d-xl-inline-block">
          {headingtxt}
        </h5>
      ) : (
        ''
      )}
      {buttonenable ? (
        <MDBBtn outline className="border-orange edit-btn" onClick={onClick}>
          <MDBIcon icon="aa" className="edit_icon" /> Edit
        </MDBBtn>
      ) : (
        ' '
      )}
    </>
  );
};

export default ProfileHeading;
