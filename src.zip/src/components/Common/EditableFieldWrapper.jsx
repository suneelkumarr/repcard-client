import React, { useState, useEffect, useRef } from 'react';
import { MDBInput } from 'mdbreact';
import { element, func, string, bool } from 'prop-types';

import RepNumberFormat from '../../utils/RepNumberFormat.jsx';
import isValidateMobile from '../../utils/isValidateMobile';

const EditableFieldWrapper = ({
  children,
  onSave,
  onCancel,
  value,
  type,
  disabled,
  name,
}) => {
  const [edit, setEdit] = useState(false);
  const [text, setText] = useState(value);
  const [error, setError] = useState('');
  const inputRef = useRef();
  useEffect(() => {
    setTimeout(() => {
      if (inputRef && inputRef.current && inputRef.current.focus) {
        inputRef.current.focus();
      }
    }, 1000);
  }, []);
  useEffect(() => {
    setText(value);
  }, [value]);
  const handleSave = () => {
    if (text) {
      if (type === 'number' && isValidateMobile(text)) {
        setError(isValidateMobile(text));
        return;
      }
      onSave(text);
      setEdit(false);
    }
  };
  const keyUp = (e) => {
    if (e.keyCode === 13) {
      handleSave();
    }
    if (e.keyCode === 27) {
      setEdit(false);
    }
  };
  const inputField = (
    <>
      {type === 'number' ? (
        <RepNumberFormat
          className="form-control"
          name={name}
          format="XXX.XXX.XXXX"
          value={text}
          onChange={(values, _name, apiValue) => setText(apiValue)}
          // onBlur={e => setText(e.target.value)}
          ref={inputRef}
          onKeyUp={keyUp}
        />
      ) : (
        <MDBInput
          onKeyUp={keyUp}
          value={text}
          onChange={(e) => setText(e.target.value)}
          ref={inputRef}
        />
      )}
      <div>{error}</div>
    </>
  );
  if (disabled) return <>{children}</>;
  return (
    <>
      {edit ? (
        <>
          {inputField}
          <i
            className="fa fa-check m-2"
            style={{ cursor: 'pointer' }}
            onClick={() => {
              handleSave();
            }}
          />
          <i
            className="fa fa-times m-2"
            style={{ cursor: 'pointer' }}
            onClick={() => {
              setEdit(false);
              onCancel();
            }}
          />
        </>
      ) : (
        <>
          {children}
          <i
            className="fa fa-pencil-alt ml-2"
            style={{ cursor: 'pointer' }}
            onClick={() => setEdit(true)}
          />
        </>
      )}
    </>
  );
};

EditableFieldWrapper.defaultProps = {
  onCancel: () => true,
  name: 'phone',
};

EditableFieldWrapper.propTypes = {
  children: element.isRequired,
  onSave: func.isRequired,
  onCancel: func,
  type: string.isRequired,
  value: string.isRequired,
  disabled: bool.isRequired,
  name: string,
};

export default EditableFieldWrapper;
