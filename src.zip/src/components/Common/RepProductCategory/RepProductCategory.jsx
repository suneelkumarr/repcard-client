/**
 *
 * Description. Rep's Specialites
 *
 * @link   URL
 * @file   It display Rep's Specialites information
 * @since  1.0.0
 */
import React from 'react';
import './productcategories.scss';

/**
 * Summary. Rep ProductCategory View Html (back part)
 *
 * Description. Return ProductCategory view html details for Rep
 *
 * @since      1.0
 * @deprecated No //x.x.x Use new_function_name() instead.
 * @access     export public
 *
 * @param {Array}    productcategoryRes    ProductCategory Response data
 * @param {string}   boxclass         main div class for shadow
 * @param {string}   changehight      extra class for height
 * @param {boolean}  flipicondisable  flag for enable/disable flip icon
 * @param {boolean}  isNameRemove     flag for not displaying name details
 * @param {Object}   profileRes       My Account Response data
 * @param {function} onClick          Callback function for flip icon click
 *
 */
const RepProductCategory = ({
  productcategoryRes,
  boxclass,
  changehight,
  flipicondisable,
  isNameRemove,
  profileRes = {},
  onClick,
  setProductCategoryFlag,
}) => {
  const noProductCategoryClass =
    flipicondisable && !productcategoryRes.length ? 'no-productcategory' : '';

  return (
    <div
      className={`rep-profile-card-view m-0 ${noProductCategoryClass} ${boxclass} ${changehight}`}
    >
      <div className="productcategories_list">
        {flipicondisable ? (
          onClick ? (
            <div
              className="flip-icon"
              onClick={() => {
                onClick('productcategory');
              }}
              role="presentation"
            />
          ) : (
            <div className="flip-icon">
              <div className="info-tooltip">Flip disabled</div>
            </div>
          )
        ) : null}
        {isNameRemove ? (
          <p className="productcategory-avatar-name">
            {profileRes.firstName} {profileRes.lastName}
          </p>
        ) : (
          ''
        )}
        <span
          className={`txt_productcategories ${
            setProductCategoryFlag && 'cursor'
          }`}
          onClick={setProductCategoryFlag}
        >
          My Product Lines
        </span>
        {productcategoryRes.map((v) => {
          if (v.productlines.length === 0) {
            return null;
          }

          return (
            <div
              className="productcategories_list_dtl"
              key={v.productcategoryId}
            >
              <p className="txt_spec_name">{v.productcategoryName}</p>
              <ul>
                {v.productlines.map((v1) => {
                  return (
                    <li key={v1.id}>
                      <div className="">
                        <span className="spciality_popover">{v1.info}</span>
                      </div>
                      <span>{v1.name}</span>
                    </li>
                  );
                })}
              </ul>
            </div>
          );
        })}
        {productcategoryRes.length ? (
          ''
        ) : (
          <p className="no-specility-text">No Product Lines selected</p>
        )}
      </div>
    </div>
  );
};

export default RepProductCategory;
