/**
 *
 * Description. Login Api call
 *
 * @link   URL
 * @file   Calls login API and set relevant data into localstorage
 * @since  1.0.0
 */
import isEmpty from 'lodash/isEmpty';
import { axiosApi, axiosApiNew } from '../../apis/axiosApiCall';
import { messageBroadcast } from '../../helpers/broadcastMessage';
import { setResData, setToStorage } from '../../utils/editUpdateStorage';
import { encrypt } from '../../config/encrypt-decrypt';

/**
 * Summary. Login API Call
 *
 * Description. Calls the Login API and and redirected to appropriate page on success
 *
 * @since      1.0
 * @deprecated No //x.x.x Use new_function_name() instead.
 * @access     export public
 *
 * @param {string}   email           User Email Value
 * @param {string}   password        User Password value
 * @param {function} cb              Callback function
 *
 */
const loginApi = (email, password, cb) => {
  const reqObj = {
    email: encrypt(email),
    password: encrypt(password),
  };
  console.log('CALLING LOGIN API');
  axiosApi(`/login`, 'POST', reqObj, (res) => {
    console.log('CALLING axiosApi');
    if (!isEmpty(res.data)) {
      console.log(`LOGIN SUCCESS`);
      console.dir(res.data);
      setToStorage(res.data); // Set to localstorage
      setResData(res.data); // Set to app global variable
      // To reload other tabs in the browser if its open
      messageBroadcast({
        command: 'reload',
        uid: new Date().getTime() + Math.random(),
      });
      const { userType } = res.data;
      let redirectURL = '';
      if (userType === 'rep') {
        redirectURL = '/RepDashboard';
      } else {
        redirectURL = '/SearchRep';
      }
      const newRes = {
        redirectURL,
      };
      cb(false, newRes);
    } else {
      console.log(`LOGIN FAIL`);
      console.dir(res);
      cb(res, '');
    }
  });
};

const loginApiNew = async (email, password) => {
  const reqObj = {
    email: encrypt(email),
    password: encrypt(password),
  };

  console.log('CALLING axiosApiNew');
  const res = await axiosApiNew('/login', 'POST', reqObj).catch((error) => {
    console.log(`ERROR : loginApiNew : axiosApiNew`);
    console.dir(error);
  });

  if (!isEmpty(res.data)) {
    console.log(`LOGIN SUCCESS`);
    let redirectURL = '';
    const { isOtpVerified, otpToken, userType } = res.data;
    console.log(`USER TYPE: ${userType}`);
    if (userType === 'rep') {
      redirectURL =
        isOtpVerified || !otpToken ? '/RepDashboard' : `/VerifyOTP/${otpToken}`;
    } else {
      redirectURL = '/SearchRep';
    }
    if (
      ((isOtpVerified || !otpToken) && userType === 'rep') ||
      userType !== 'rep'
    ) {
      console.dir(res.data);
      setToStorage(res.data); // Set to localstorage
      setResData(res.data); // Set to app global variable
      console.log('DATA STORED');
      // To reload other tabs in the browser if its open
      messageBroadcast({
        command: 'reload',
        uid: new Date().getTime() + Math.random(),
      });
    }
    const newRes = {
      redirectURL,
    };
    return newRes;
  }
  console.log(`LOGIN FAIL`);
  console.dir(res);
  return res;

  // axiosApi(`/login`, 'POST', reqObj, res => {
  //   console.log('CALLING axiosApi');
  //   if (!isEmpty(res.data)) {
  //     console.log(`LOGIN SUCCESS`);
  //     console.dir(res.data);
  //     setToStorage(res.data); // Set to localstorage
  //     setResData(res.data); // Set to app global variable
  //     // To reload other tabs in the browser if its open
  //     messageBroadcast({
  //       command: 'reload',
  //       uid: new Date().getTime() + Math.random()
  //     });
  //     const { userType } = res.data;
  //     let redirectURL = '';
  //     if (userType === 'rep') {
  //       redirectURL = '/RepDashboard';
  //     } else {
  //       redirectURL = '/SearchRep';
  //     }
  //     const newRes = {
  //       redirectURL
  //     };
  //     return newRes;
  //   } else {
  //     console.log(`LOGIN FAIL`);
  //     console.dir(res);
  //     return res;
  //   }
  // });
};

export { loginApi, loginApiNew };
