/* eslint-disable react/no-unescaped-entities */
import React, { Component } from 'react';
import { MDBInput, MDBModal } from 'mdbreact';
import ProfileHeading from './ProfileHeading';
import validateObj from '../../validations/repprofile/repfront';
import app from '../../helpers/appGlobal';
import { axiosApi } from '../../apis/axiosApiCall';

class InvitePopup extends Component {
  constructor(props) {
    super(props);
    this.state = {
      emails: {
        first: '',
        second: '',
        third: '',
      },
      errorObj: {
        first: '',
        second: '',
        third: '',
      },
      inviteSent: false,
    };
  }

  setEmail(name, e) {
    const { value } = e.target;
    this.setState((prevState) => ({
      emails: {
        ...prevState.emails,
        [name]: value,
      },
    }));
  }

  toggle = () => {
    const { toggle } = this.props;
    if (toggle) {
      toggle();
      this.setState({
        emails: {
          first: '',
          second: '',
          third: '',
        },
        errorObj: {
          first: '',
          second: '',
          third: '',
        },
        inviteSent: false,
      });
    }
  };

  validateInput(name, value, value1) {
    if (validateObj.email) {
      let error = '';
      if (name === 'first' || value) {
        error = validateObj.email(value, value1);
      }

      this.setState((prevState) => ({
        errorObj: {
          ...prevState.errorObj,
          [name]: error,
        },
      }));

      return error;
    }
    return '';
  }

  validate = () => {
    const { emails } = this.state;
    let error;
    let isValid = true;
    Object.keys(emails).forEach((name) => {
      error = this.validateInput(name, emails[name]);
      if (error) {
        isValid = false;
      }
    });
    return isValid;
  };

  sendInvite = () => {
    if (this.validate()) {
      this.setState({
        isAPICalled: true,
        apiErrorMessage: '',
      });
      const { emails } = this.state;
      const { id, userType } = app.user;
      const reqObj = {
        inviteBy: id,
        userType,
        emails: Object.values(emails).filter((e) => {
          return e;
        }),
      };

      axiosApi('/invite', 'POST', reqObj, (res) => {
        this.setState({
          isAPICalled: false,
        });
        if (res.error) {
          this.setState({
            apiErrorMessage: res.message,
          });
        } else {
          this.setState({ inviteSent: true }, () => {
            setTimeout(() => {
              this.toggle();
            }, 3000);
          });
        }
      });
    }
  };

  render() {
    const {
      emails,
      errorObj,
      isAPICalled,
      apiErrorMessage,
      inviteSent,
    } = this.state;
    const { open } = this.props;

    return (
      <MDBModal md="10" isOpen={open} toggle={this.toggle}>
        <div className="p-lg-3 p-md-2 p-sm-2 mt-3">
          <ProfileHeading headingtxt="Give A Month, Get A Month" />
          <p>
            Invite any healthcare rep or provider to join REPCARDz, and you’ll
            get a month of Premium, too. All members must complete their
            REPCARDz profile to be eligible.
            <br className="d-none d-lg-inline-block d-md-display-none" />{' '}
          </p>
          <ProfileHeading headingtxt="Special Pilot Program Bonus" />
          <p>
            As a thank you for being our first REPCARDz members and helping us
            grow, you'll be entered to win one of three $500 VISA gift cards for
            every 3 reps or providers you refer to REPCARDz. All members must
            complete their REPCARDz profile to be eligible. Offer ends May 31st
            at midnight CST.
            <br className="d-none d-lg-inline-block d-md-display-none" />{' '}
          </p>
          {Object.keys(emails).map((name) => {
            return (
              <div className="input-field text-left" key={name}>
                <MDBInput
                  value={emails[name]}
                  onChange={(e) => this.setEmail(name, e)}
                  label="Add colleagues email address"
                />
                {errorObj[name] && (
                  <span className="error-message">{errorObj[name]}</span>
                )}
              </div>
            );
          })}
          <div className="btn-panel mt-2">
            <button
              type="button"
              className="fill-orange-btn"
              onClick={this.sendInvite}
              disabled={isAPICalled}
            >
              {isAPICalled ? (
                <span className="spinner-border spinner-border-sm" />
              ) : (
                ''
              )}
              Submit Invite
            </button>
            {apiErrorMessage ? (
              <p className="error-message1 mt-2">{apiErrorMessage}</p>
            ) : (
              ''
            )}
            {inviteSent && (
              <p className="txt_orange mt-2">
                Thank you for sharing REPCARDz with your colleagues and
                customers. They will receive an invitation email shortly to
                become a member of REPCARDz. Keep sharing the good word and keep
                getting rewarded. No limitations apply.
              </p>
            )}
          </div>
        </div>

        <div
          role="presentation"
          onClick={this.toggle}
          className="close_auth_popup"
        >
          X close
        </div>
      </MDBModal>
    );
  }
}

export default InvitePopup;
