/**
 *
 * Description. Get Vacation details Information
 *
 * @link   URL
 * @file   Return Vacation string using fromDate and toDate
 * @since  1.0.0
 */
import moment from 'moment';

/**
 * Summary. Vacation details information
 *
 * Description. Return vacation details string using from and to date
 *
 * @since      1.0
 * @deprecated No //x.x.x Use new_function_name() instead.
 * @access     export public
 *
 * @param {string}   fromDate        from Date value
 * @param {string}   toDate          to Date Value
 *
 * @return {String} Available or Unavailable till {date}
 */
const getAvailableStr = (fromDate, toDate) => {
  if (fromDate && toDate) {
    const currentDate = moment().format('YYYY-MM-DD');
    const fromDate1 = moment(fromDate.split('T')[0]).format('YYYY-MM-DD');
    const toDate1 = moment(toDate.split('T')[0]).format('YYYY-MM-DD');

    if (currentDate >= fromDate1 && currentDate <= toDate1) {
      const str = moment(toDate1).format('dddd MMM DD');
      return `Unavailable till ${str}`;
    }
  }
  return 'Available';
};

export default getAvailableStr;
