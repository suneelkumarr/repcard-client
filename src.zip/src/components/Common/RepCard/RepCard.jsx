/* eslint-disable react/destructuring-assignment */
/**
 *
 * Description. Rep's My Account Details
 *
 * @link   URL
 * @file   It display Rep's My Account Details such as phone, email, firstName, lastName,
          company details, vacation details
 * @since  1.0.0
 */
import React, { Component } from 'react';
import { Link, Redirect } from 'react-router-dom';
import { MDBIcon } from 'mdbreact';
import isEmpty from 'lodash/isEmpty';
import ProfilePhoto from '../ProfilePhoto';
import phoneFormat from '../../../utils/getPhoneFormat.js';
import app from '../../../helpers/appGlobal';
import { getBasicPlanNew } from '../../../utils/getPlanInfo';
import { axiosApi } from '../../../apis/axiosApiCall';
import getAvailableStr from './getAvailableStr';
import EditableFieldWrapper from '../EditableFieldWrapper';

/**
 *  website url regex test
 */
const isHttpURL = (website) => {
  const protocolRegex = new RegExp('^(?:[a-z]+:)?//', 'i');
  return protocolRegex.test(website);
};

/**
 * Summary. Rep My Account View Html (Front part)
 *
 * Description. Return My Account view html details for Rep
 *
 * @since      1.0
 * @deprecated No //x.x.x Use new_function_name() instead.
 * @access     export public
 *
 * @param {Object}   profileRes       My Account Response data
 * @param {string}   boxclass         main div class for shadow
 * @param {string}   shadows          classes for profile photo shadow
 * @param {boolean}  flipicondisable  flag for enable/disable flip icon
 * @param {boolean}  isFavourite      flag for enable/disable favourite icon
 * @param {boolean}  isChat           flag for enable/disable chat icon
 * @param {function} onClick          Callback function for flip icon click
 * @param {function} onFavouriteClick Callback function for favoutrite icon click
 * @param {boolean}  isFavouriteAPI   Flag for disabling favourite icon on API called
 * @param {boolean}  showInlineAvailable Flag for showing inline backup contact
 *
 */
class RepCard extends Component {
  constructor(props) {
    super(props);
    this.state = {
      phone: '',
      customerServicePhone: '',
    };
  }

  componentDidMount() {
    const { profileRes } = this.props;
    const {
      fromDate,
      toDate,
      backupRepId,
      phone,
      customerServicePhone,
    } = profileRes;
    this.setState({ phone, customerServicePhone });
    if (fromDate && toDate && backupRepId) {
      this.getBackupRepApi(backupRepId);
    }
  }

  /**
   * Summary. Get Backuo Rep Information
   *
   * Description. Call API for Rep's to get phone and email data
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  getBackupRepApi = (backupRepId) => {
    axiosApi(
      `/repProfile/getMyAccountRepProfile/${backupRepId}`,
      'GET',
      '',
      (res) => {
        if (!isEmpty(res.data)) {
          this.setState({
            backupRepData: res.data,
          });
          const { setBackupRep } = this.props;
          if (setBackupRep) {
            setBackupRep(res.data);
          }
        }
      }
    );
  };

  render() {
    const {
      profileRes = {},
      boxclass,
      shadows,
      flipicondisable,
      isFavourite,
      isChat,
      onClick,
      onFavouriteClick,
      isFavouriteAPI,
      showInlineAvailable,
      onChange,
      showFullProfileLink,
      id,
    } = this.props;

    const { redirectToReferrer, phone, customerServicePhone } = this.state;
    const titleOnClick =
      app.user.isPremiumFreeTrial &&
      !profileRes.title &&
      window.location.pathname === '/RepDashboard';
    if (redirectToReferrer && titleOnClick) {
      const from = { pathname: redirectToReferrer };
      return <Redirect push to={from} />;
    }

    const { website } = profileRes;
    let websiteLink = '';
    if (website) {
      websiteLink = website;
      if (!isHttpURL(website)) {
        websiteLink = `//${website}`;
      }
    }

    const isBasicPlan = getBasicPlanNew();
    const { photoUrl } = profileRes;
    let newPhotoUrl = photoUrl;
    if (isBasicPlan && id === app.user.id) {
      newPhotoUrl = '';
    }

    const dateStr = getAvailableStr(profileRes.fromDate, profileRes.toDate);
    const { backupRepDetails } = profileRes;
    const { backupRepData } = this.state;
    const newBackupData = backupRepDetails || backupRepData;

    return (
      <div className={`rep-profile-card-view ${boxclass}`}>
        {flipicondisable ? (
          <div className="flip-icon-panel">
            {onClick ? (
              <div
                className="flip-icon"
                onClick={() => {
                  onClick('profile');
                }}
                role="presentation"
              />
            ) : (
              <div className="flip-icon">
                <div className="info-tooltip">Flip disabled</div>
              </div>
            )}
          </div>
        ) : null}
        <div className="d-block">
          <ProfilePhoto
            shadows={shadows}
            photoUrl={
              newPhotoUrl
                ? `${newPhotoUrl}?dummy=${new Date().getTime()}`
                : newPhotoUrl
            }
            addProfile="card_prfl_pic d-inline-block"
          />
          <div className="avatar_avl_dtl">
            <span className="d-block card_rep_name">
              {profileRes.firstName} {profileRes.lastName}
            </span>
            <span className="status_red">{dateStr}</span>
            {showFullProfileLink && (
              <Link className="txt_orange" to={`/FullProfile/${profileRes.id}`}>
                View Full Profile
              </Link>
            )}
            {dateStr !== 'Available' && showInlineAvailable ? (
              <div className="backup_rep_contact">
                <div className="rep-icon" />
                Backup Contact:{' '}
                {newBackupData ? (
                  <span className="backup_rep_name">
                    {newBackupData.firstName} {newBackupData.lastName}
                  </span>
                ) : (
                  ''
                )}
              </div>
            ) : (
              ''
            )}
          </div>
        </div>
        <div className="rep_dtl py-3">
          <div className="d-block mb-3">
            <MDBIcon icon="aa" className="rep_icon title_icon mr-3" />
            <div
              className={`d-inline-block repcard-title-text ${
                titleOnClick ? 'title-text-onclick' : ''
              }`}
              onClick={
                titleOnClick
                  ? () => {
                      app.ProfileEdit = true;
                      this.setState({
                        redirectToReferrer: '/Dashboard',
                      });
                    }
                  : null
              }
            >
              <span className="d-block card_prfl_name">Title</span>
              <span className="card_prfl_designation">
                {profileRes.title && typeof profileRes.title.value === 'string'
                  ? profileRes.title.value
                  : profileRes.title}
              </span>
            </div>
          </div>
          <div className="d-block mb-3">
            <MDBIcon icon="aa" className="rep_icon company_icon mr-3" />
            <div className="d-inline-block">
              <span className="d-block card_prfl_name">Company</span>
              <span className="card_prfl_designation">
                <div className="txt_orange">
                  {websiteLink ? (
                    <a
                      target="_blank"
                      rel="noopener noreferrer"
                      href={`${websiteLink}`}
                      style={{ textDecoration: 'underline' }}
                    >
                      {profileRes.companyName}
                    </a>
                  ) : (
                    profileRes.companyName
                  )}
                </div>
              </span>
            </div>
          </div>
          {dateStr === 'Available' || showInlineAvailable ? (
            ''
          ) : (
            <div className="position-relative">
              <div className="backup_contact">
                {newBackupData ? (
                  <div
                    className="d-flex justify-content-center flex-column align-items-center"
                    style={{ height: '100%' }}
                  >
                    <div className="backup_info">
                      <div className="rep-icon" />
                      <div>
                        Backup Contact:
                        <div className="backup_name">
                          {newBackupData.firstName} {newBackupData.lastName}
                        </div>
                      </div>
                    </div>
                    <div className="backup_info my-3">
                      <div className="rep-icon" />
                      <div>
                        Mobile
                        <div className="backup_name">
                          {newBackupData.subscriptionId &&
                          newBackupData.phone ? (
                            <a
                              style={{ textDecoration: 'underline' }}
                              href={`tel: ${phoneFormat(newBackupData.phone)}`}
                            >
                              {phoneFormat(newBackupData.phone)}
                            </a>
                          ) : (
                            'XXX-XXX-XXXX'
                          )}
                        </div>
                      </div>
                    </div>
                    <div className="backup_info">
                      <div className="rep-icon" />
                      <div>
                        Email
                        <div className="backup_name">
                          <a
                            style={{ textDecoration: 'underline' }}
                            href={`mailto:${newBackupData.email}`}
                          >
                            {newBackupData.email}
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  ''
                )}
              </div>
            </div>
          )}
          <div className="d-block mb-3">
            <MDBIcon icon="aa" className="rep_icon mobile_icon mr-3" />
            <div className="d-inline-block">
              <span className="d-block card_prfl_name">My Mobile</span>
              <span className="txt_orange">
                <EditableFieldWrapper
                  type="number"
                  value={phone || ''}
                  disabled={id !== app.user.id}
                  onSave={(value) => {
                    axiosApi(
                      `/repProfile/createRep`,
                      'POST',
                      { phone: value, id: app.user.id },
                      (res) => {
                        if (res.error) {
                          alert(res.message);
                        } else {
                          this.setState({
                            phone: value,
                          });
                        }
                        if (onChange) onChange({}, 'phone', value);
                      }
                    );
                  }}
                >
                  {phone ? (
                    <a
                      style={{ textDecoration: 'underline' }}
                      href={`tel: ${phoneFormat(phone)}`}
                    >
                      {phoneFormat(phone)}
                    </a>
                  ) : isBasicPlan ? (
                    'XXX-XXX-XXXX'
                  ) : (
                    'XXX-XXX-XXXX'
                  )}
                </EditableFieldWrapper>
              </span>
              <div className="mt-2">
                <span className="d-block card_prfl_name">Customer Service</span>
                <span className="txt_orange">
                  <EditableFieldWrapper
                    name="customerServicePhone"
                    type="number"
                    value={customerServicePhone || ''}
                    disabled={id !== app.user.id}
                    onSave={(value) => {
                      axiosApi(
                        `/repProfile/createRep`,
                        'POST',
                        { customerServicePhone: value, id: app.user.id },
                        (res) => {
                          if (res.error) {
                            alert(res.message);
                          } else {
                            this.setState({
                              customerServicePhone: value,
                            });
                          }
                          if (onChange)
                            onChange({}, 'customerServicePhone', value);
                        }
                      );
                    }}
                  >
                    {customerServicePhone ? (
                      <a
                        style={{ textDecoration: 'underline' }}
                        href={`tel: ${phoneFormat(customerServicePhone)}`}
                      >
                        {phoneFormat(customerServicePhone)}
                      </a>
                    ) : isBasicPlan ? (
                      'XXX-XXX-XXXX'
                    ) : (
                      'XXX-XXX-XXXX'
                    )}
                  </EditableFieldWrapper>
                </span>
              </div>
            </div>
          </div>
          <div className="d-block">
            <MDBIcon icon="aa" className="rep_icon email_icon mr-3" />
            <div className="d-inline-block">
              <span className="d-block card_prfl_name">My Email</span>
              <span className="txt_orange">
                <a
                  style={{ textDecoration: 'underline' }}
                  href={`mailto:${profileRes.email}`}
                >
                  {profileRes.email}
                </a>
              </span>
            </div>
          </div>
          {app.user.userType === 'provider' && (isFavourite || isChat) ? (
            <div className="d-block mt-4">
              {isFavourite ? (
                <button
                  type="button"
                  className="outline-btn"
                  onClick={onFavouriteClick}
                  disabled={isFavouriteAPI || isBasicPlan}
                >
                  <span
                    className={
                      profileRes.isFavourite
                        ? 'favorite_icon_1'
                        : 'favorite_icon'
                    }
                  />{' '}
                  Favorite
                </button>
              ) : (
                ''
              )}
              {isChat ? (
                <button type="button" className="fill-orange-btn" disabled>
                  <span className="open-chat-icon" />
                  Chat
                </button>
              ) : (
                ''
              )}
            </div>
          ) : (
            ''
          )}
        </div>
      </div>
    );
  }
}

export default RepCard;
