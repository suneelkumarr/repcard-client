/**
 *
 * Description. Profile Photo
 *
 * @link   URL
 * @file   Profile photo html
 * @since  1.0.0
 */
import React from 'react';

/**
 * Summary. Profile photo html
 *
 * Description. Profile photo html
 *
 * @since      1.0
 * @deprecated No //x.x.x Use new_function_name() instead.
 * @access     export public
 *
 * @param {string}    addProfile      classes for photo main div
 * @param {string}    rounded         class for round image
 * @param {string}    shadows         classes for profile photo shadow
 * @param {string}    photoUrl        profile pic url
 *
 */
const ProfilePhoto = ({ addProfile, rounded, shadows, photoUrl }) => {
  return (
    <div className={`avatar-photo ${addProfile} ${shadows || ''}`}>
      <img
        src={
          photoUrl || `${process.env.PUBLIC_URL}/images/icons/Profilebig.svg`
        }
        alt="Profile pic"
        className={`img-fluid ${rounded || ''}`}
      />
    </div>
  );
};

export default ProfilePhoto;
