/**
 *
 * Description. Rep's Account details information
 *
 * @link   URL
 * @file   It display Rep's Account details Information such as email, password
           and Plan details
 * @since  1.0.0
 */
import React, { Component } from 'react';
import ProfileHeading from '../ProfileHeading';
// import { repPlanObj } from '../../PremiumPlan/planDetails';
import { getCustomerId } from '../../../utils/getPlanInfo';
import app from '../../../helpers/appGlobal';
import { getCustomerPaymentAPI } from '../../../utils/stripeApis';

import '../../PremiumPlan/premiumplan.scss';

class RepAccountCard extends Component {
  constructor(props) {
    super(props);
    this.state = {
      last4Digit: '',
      isAPICalled: true,
    };
  }

  /**
   * Summary. stripe payment method API
   *
   * Description. Load the credit card details information via calling below API
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  getCustomerPaymentAPI = () => {
    const customerId = getCustomerId();
    const { planDetails } = this.props;
    if (planDetails && customerId) {
      getCustomerPaymentAPI(customerId, (res) => {
        if (res) {
          this.setState({
            last4Digit: res.card.last4,
          });
        }
        this.setState({
          isAPICalled: false,
        });
      });
    } else {
      this.setState({
        isAPICalled: false,
      });
    }
  };

  componentDidMount() {
    this.getCustomerPaymentAPI();
  }

  render() {
    const { last4Digit, isAPICalled } = this.state;
    const { onPlanClick, onAccountEditClick, planDetails } = this.props;
    const customerId = getCustomerId();
    return (
      <>
        <div className="rep-card-panel">
          <div className="mt-2">
            <ProfileHeading headingtxt="My Account" buttonenable={false} />
          </div>
          <div className="mt-4">
            <div className="rep-profile-card-view pt-2 no-bg">
              <div className="d-block acc-info-panel mb-4">
                <p className="clearfix m-0">
                  <span className="float-left mt-2 txt_productcategories">
                    Account Credentials
                  </span>
                  <span className="float-right">
                    <ProfileHeading buttonenable onClick={onAccountEditClick} />
                  </span>
                </p>
                <div className="d-block mb-3">
                  <div className="d-inline-block mt-2">
                    <span className="d-block card_prfl_name">
                      Account Email
                    </span>
                    <span className="card_prfl_designation">
                      {app.user.email}
                    </span>
                  </div>
                </div>
                <div className="d-block mb-3">
                  <div className="d-inline-block">
                    <span className="d-block card_prfl_name">Password</span>
                    <span className="card_prfl_designation">***********</span>
                  </div>
                </div>
              </div>
              {isAPICalled ? (
                ''
              ) : (
                <div className="d-block acc-info-panel">
                  <p className="clearfix m-0">
                    <span className="float-left mt-2 txt_productcategories">
                      Current Plan
                    </span>
                    <span className="float-right">
                      <ProfileHeading buttonenable onClick={onPlanClick} />
                    </span>
                  </p>
                  {planDetails && customerId ? (
                    <>
                      <div className="d-block mt-3 mb-3 plan-info-txt">
                        REPCARDz - Premium
                      </div>
                      <div className="d-block mb-3">
                        <div className="d-inline-block">
                          <span className="d-block card_prfl_name">
                            Payment
                          </span>
                          <span className="card_prfl_designation">
                            {app.user.paymentMethod
                              ? `Credit Card ending ${last4Digit}`
                              : 'Free Trial'}
                          </span>
                        </div>
                      </div>
                    </>
                  ) : (
                    <div className="d-block mt-3 plan-info-txt">
                      REPCARDz - Basic Plan Complimentary
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </>
    );
  }
}

export default RepAccountCard;
