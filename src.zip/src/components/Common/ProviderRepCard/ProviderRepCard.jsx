/**
 *
 * Description. Provider's My Account Details
 *
 * @link   URL
 * @file   It display Provider's My Account Details such as phone, firstName, lastName,
           hospital details
 * @since  1.0.0
 */
import React from 'react';
import { MDBIcon } from 'mdbreact';
import ProfilePhoto from '../ProfilePhoto';
import phoneFormat from '../../../utils/getPhoneFormat.js';

/**
 * Summary. Provider My Account View Html
 *
 * Description. Return My Account view html details
 *
 * @since      1.0
 * @deprecated No //x.x.x Use new_function_name() instead.
 * @access     export public
 *
 * @param {Object}   profileRes       My Account Response data
 * @param {string}   boxclass         main div class for shadow
 * @param {string}   shadows          classes for profile photo shadow
 * @param {string}   changehight      extra class for height
 *
 */
const ProviderRepCard = ({
  profileRes = {},
  boxclass,
  shadows,
  changehight,
}) => {
  const { hospital, title } = profileRes;

  return (
    <div className={`rep-profile-card-view ${boxclass} ${changehight}`}>
      <div className="d-block">
        <ProfilePhoto
          shadows={shadows}
          photoUrl={profileRes.photoUrl}
          addProfile="card_prfl_pic d-inline-block"
        />
        <div className="avatar_avl_dtl">
          <span className="d-block card_rep_name">
            {profileRes.firstName} {profileRes.lastName}
          </span>
        </div>
      </div>
      <div className="rep_dtl py-2">
        <div className="d-block mb-4">
          <MDBIcon icon="aa" className="rep_icon mobile_icon mr-3" />
          <div className="d-inline-block">
            <span className="d-block card_prfl_name">Phone Number</span>
            <span className="txt_orange">
              {profileRes.phone
                ? phoneFormat(profileRes.phone)
                : 'XXX-XXX-XXXX'}
            </span>
          </div>
        </div>
        <div className="d-block mb-3">
          <MDBIcon icon="aa" className="rep_icon company_icon mr-3" />
          <div className="d-inline-block">
            <span className="d-block card_prfl_name">Hospital/Practice</span>
            <span className="card_prfl_designation">
              <div className="txt_orange">{hospital || 'Not Available'}</div>
            </span>
            <div className="mt-3">
              <span className="d-block card_prfl_name">Title</span>
              <span className="txt_orange">
                {title && title.title ? title.title : 'Not Available'}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProviderRepCard;
