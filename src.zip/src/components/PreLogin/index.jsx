/**
 *
 * Description. PreLogin component
 *
 * @link   URL
 * @file   This component is common for all login, signup and forgot password page.
           User can go to specific page as per the URL (pathname)
 * @since  1.0.0
 */
import React, { Component, lazy, Suspense } from 'react';
import Header from '../NavHeader/PreloginHeader/Header';
import Footer from '../Footer/Footer';
import './SignUp.scss';

const ForgotPassword = lazy(() =>
  import('../ForgotPassword/ForgotPassword.jsx')
);
const ResetPassword = lazy(() => import('../ForgotPassword/ResetPassword.jsx'));
const Verify = lazy(() => import('../Verification/Verify.jsx'));
const Signup = lazy(() => import('../SignUp/SignUp.jsx'));
const Login = lazy(() => import('../Login/Login.jsx'));
const ClaimAccount = lazy(() => import('../SignUp/ClaimAccount.jsx'));
const Loading = () => <div>Loading...</div>;

class PreLogin extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isVerified: false,
    };
  }

  componentDidMount() {
    const { history } = this.props;

    history.listen((newLocation, action) => {
      if (
        action === 'POP' &&
        newLocation.pathname.indexOf('VerifyOTP') !== -1
      ) {
        history.go(1);
      }
    });
  }

  setVerify(isVerified) {
    this.setState({
      isVerified,
    });
  }

  render() {
    const { isVerified } = this.state;
    const { location } = this.props;
    const { pathname } = location;
    const isLoginPage = pathname === '/Login';
    const isClaimAccountPage = pathname === '/ClaimAccount';
    const isOTPPage = pathname.startsWith('/VerifyOTP');
    return (
      <>
        <Header
          isLoginPage={isLoginPage}
          isOTPPage={isOTPPage}
          isVerified={isVerified}
        />
        <div className="preLogin">
          <Suspense fallback={<Loading />}>
            {pathname === '/Signup' ? <Signup {...this.props} /> : ''}
            {pathname === '/ForgotPassword' ? (
              <ForgotPassword {...this.props} />
            ) : (
              ''
            )}
            {pathname.startsWith('/ResetPassword') ? (
              <ResetPassword {...this.props} />
            ) : (
              ''
            )}
            {isOTPPage ? (
              <Verify
                {...this.props}
                setVerify={(status) => this.setVerify(status)}
              />
            ) : (
              ''
            )}
            {isLoginPage ? <Login {...this.props} /> : ''}
            {isClaimAccountPage ? <ClaimAccount {...this.props} /> : ''}
          </Suspense>
        </div>
        <Footer />
      </>
    );
  }
}

export default PreLogin;
