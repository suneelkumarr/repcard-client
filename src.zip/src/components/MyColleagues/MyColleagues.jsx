/**
 *
 * Description. My Colleagues component
 *
 * @link   URL
 * @file   Reps can search for other Reps in the same company
 * @since  1.0.0
 */
import React, { Component, lazy, Suspense } from 'react';
import isEmpty from 'lodash/isEmpty';
import {
  MDBContainer,
  MDBRow,
  MDBCol,
  MDBSelect,
  MDBSelectInput,
  MDBSelectOptions,
  MDBSelectOption,
  MDBInput,
} from 'mdbreact';
import { axiosApi } from '../../apis/axiosApiCall';
import ProfileHeading from '../Common/ProfileHeading';
import SearchRow from '../Search/SearchRow';
import FiltersMyColleagues from '../Search/FiltersMyColleagues.jsx';
import RecentSearch from '../Search/RecentSearch.jsx';
import app from '../../helpers/appGlobal';
import isEnterKeyPressed from '../../utils/checkEnterKeyPressed';
import scrollCheck from '../../utils/scrollCheck';
import { getMasterStatesDataWithCities } from '../../utils/masterProductCategoryData';
import { getBasicPlanNew } from '../../utils/getPlanInfo';

import '../Search/search.scss';
import InvitePopup from '../Common/InvitePopup';

const Loading = () => <div>Loading...</div>;
const SearchProductCategoryList = lazy(() =>
  import('../Search/SearchProductCategoryList')
);
const SearchCityList = lazy(() => import('../Search/SearchCityList'));
const SearchHospitalList = lazy(() => import('../Search/SearchHospitalList'));

class Search extends Component {
  constructor(props) {
    super(props);
    this.state = {
      limit: 10,
      offset: 0,
      searchby: '',
      text: '',
      searchResults: [],
      isAPICalled: false,
      apiOnScroll: false,
      filterOpen: false,
      masterStateList: [],
      hospitalArr: [],
      productcategoryFilterArr: [],
      cityFilterArr: [],
      tagHospitalList: [],
      tagCityArr: [],
      tagProductCategoryArr: [],
      currentSearchName: '',
      keyVal: 1,
      updateSearchKey: 1,
      optionsObj: {
        name: 'Name',
        productcategory: 'Product Line',
        hospital: 'Account',
        city: 'City/State',
        product: 'Product',
      },
      invitePopupOpen: false,
    };
  }

  filterSelectOpen = () => {
    this.setState((prevState) => ({
      filterOpen: !prevState.filterOpen,
    }));
  };

  onClickAway = () => {
    this.setState({ filterOpen: false });
  };

  /**
   * Summary. Provider Search API
   *
   * Description. To retrive all the search results using api call with company
   *              and productcategory filters along with limit and offset
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  callSearchApi = () => {
    this.setState({
      isAPICalled: true,
    });
    const {
      limit,
      offset,
      text,
      searchby,
      hospitalArr,
      productcategoryFilterArr,
      cityFilterArr,
    } = this.state;
    const reqObj = {
      filters: {},
    };

    if (hospitalArr.length) {
      reqObj.filters.account = hospitalArr;
    }
    if (productcategoryFilterArr.length) {
      reqObj.filters.productcategory = productcategoryFilterArr;
    }
    if (cityFilterArr.length) {
      reqObj.filters.city = cityFilterArr;
    }

    axiosApi(
      `/searchColleagues/searchColleaguesByName?type=${searchby}&name=${text}&limit=${limit}&offset=${offset}&repId=${app.user.id}&companyId=${app.user.companyId}`,
      'POST',
      reqObj,
      (res) => {
        if (res.data) {
          const resObj = res.data.items;
          if (offset === 0) {
            this.setState({
              searchResults: resObj,
            });
          } else {
            this.setState((prevState) => ({
              searchResults: [...prevState.searchResults, ...resObj],
            }));
          }

          if (res.data.isMore) {
            this.setState({
              offset: offset + limit,
            });
          } else {
            this.setState({
              offset: 0,
            });
          }
        }
        this.setState({
          isAPICalled: false,
          apiOnScroll: false,
          currentSearchName:
            searchby === 'productcategory'
              ? productcategoryFilterArr.join(',')
              : searchby === 'city'
              ? cityFilterArr.join(',')
              : text,
        });
      }
    );
  };

  /**
   *  Load master states with cities array data and set to state
   */
  getStatesData = () => {
    getMasterStatesDataWithCities((dataArr) => {
      if (!isEmpty(dataArr)) {
        this.setState({
          masterStateList: dataArr,
        });
      }
    });
  };

  componentDidMount() {
    this.getStatesData();
  }

  /**
   * Summary. Select search parameter
   *
   * Description. Select search by name, company or productcategory
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Array}   val       select value (name, company or productcategory)
   *
   */
  searchVal = (val) => {
    const { searchby } = this.state;
    const newSearchVal = val.toString();
    if (searchby !== newSearchVal) {
      this.clearResults();
      this.setState({
        searchby: newSearchVal,
      });
    }
  };

  /**
   * Summary. Search input
   *
   * Description. Input Change method for search input
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   e           Input element event object
   * @param {function} cb          Callback function
   *
   */
  onChange = (e, cb) => {
    const { value } = e.target;
    this.setState(
      {
        text: value,
        filterOpen: false,
      },
      () => {
        if (cb) {
          cb();
        }
      }
    );
  };

  /**
   * Summary. On company select event
   *
   * Description. Set company and call the search API to get the new data
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   e           Input element event object
   *
   */
  onHospitalSelect = (e) => {
    this.setState({
      text: e.target.value,
    });
  };

  /**
   * Summary. On specialiy search event
   *
   * Description. Call the search API as per the productcategory filters
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  onProductCategorySearch = () => {
    const { productcategoryFilterArr } = this.state;
    if (productcategoryFilterArr.length <= 0) {
      alert('Select any product line first');
    } else {
      this.setState(
        {
          offset: 0,
          searchResults: [],
          isAPICalled: false,
          apiOnScroll: false,
          filterOpen: false,
          hospitalArr: [],
          tagHospitalList: [],
          tagProductCategoryArr: [],
        },
        () => {
          this.callSearchApi();
        }
      );
    }
  };

  /**
   * Summary. On city search event
   *
   * Description. Call the search API as per the city filters
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  onCitySearch = () => {
    const { cityFilterArr } = this.state;
    if (cityFilterArr.length <= 0) {
      alert('Select any city first');
    } else {
      this.setState(
        {
          offset: 0,
          searchResults: [],
          isAPICalled: false,
          apiOnScroll: false,
          filterOpen: false,
          hospitalArr: [],
          tagHospitalList: [],
          tagProductCategoryArr: [],
        },
        () => {
          this.callSearchApi();
        }
      );
    }
  };

  /**
   * Summary. Search API call
   *
   * Description. Call the search API as per the text
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  onSearch = () => {
    const { text } = this.state;
    if (text.length < 3) {
      alert('minimum 3 characters');
    } else {
      this.setState(
        {
          offset: 0,
          searchResults: [],
          isAPICalled: false,
          apiOnScroll: false,
          filterOpen: false,
          hospitalArr: [],
          productcategoryFilterArr: [],
          cityFilterArr: [],
          tagHospitalList: [],
          tagProductCategoryArr: [],
          tagCityArr: [],
        },
        () => {
          this.callSearchApi();
        }
      );
    }
  };

  /**
   * Summary. Recent search click
   *
   * Description. Call the search API as per the recent search click details
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   str           text input of search
   * @param {string}   type          can be name, company
   */
  onRecentSearchClick = (str, type) => {
    const { keyVal } = this.state;
    this.setState(
      {
        searchby: type,
        text: str,
        keyVal: keyVal + 1,
      },
      () => {
        this.onSearch();
      }
    );
  };

  /**
   * Summary. Recent search - search by productcategory click
   *
   * Description. Set spe filter details and call the search API to get the new data
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Array}   productcategoryArr           array object of productcategories
   * @param {string}  type                    productcategory type
   *
   */
  onSearchProductCategory = (productcategoryArr, type) => {
    const { keyVal } = this.state;
    this.setState(
      {
        searchby: type,
        text: '',
        productcategoryFilterArr: productcategoryArr,
        keyVal: keyVal + 1,
      },
      () => {
        this.onProductCategorySearch();
      }
    );
  };

  /**
   * Summary. Recent search - search by city click
   *
   * Description. Set city filter details and call the search API to get the new data
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Array}   cityArr          array object of productcategories
   * @param {string}  type                    productcategory type
   *
   */
  onSearchCity = (cityArr, type) => {
    const { keyVal } = this.state;
    this.setState(
      {
        searchby: type,
        text: '',
        cityFilterArr: cityArr,
        keyVal: keyVal + 1,
      },
      () => {
        this.onCitySearch();
      }
    );
  };

  /**
   * Summary. Recent search - search by city click
   *
   * Description. Set city filter details and call the search API to get the new data
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Array}   speclialityArr          array object of cities
   * @param {string}  type                    city type
   *
   */
  onSearchCity = (cityArr, type) => {
    const { keyVal } = this.state;
    this.setState(
      {
        searchby: type,
        text: '',
        cityFilterArr: cityArr,
        keyVal: keyVal + 1,
      },
      () => {
        this.onCitySearch();
      }
    );
  };

  /**
   * Summary. Apply filter click event
   *
   * Description. Call search API with company and productcategory filters
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Array}   hospitalArr           array list of companies
   * @param {Array}   productcategoryFilterArr  list of productcategories
   * @param {Array}   tagHospitalList       array list of companies with more info
   * @param {Array}   tagProductCategoryArr     array list of productcategories with more info
   *
   */
  onFilterClick = (
    hospitalArr,
    productcategoryFilterArr,
    cityFilterArr,
    tagHospitalList,
    tagProductCategoryArr,
    tagCityArr
  ) => {
    this.setState(
      {
        offset: 0,
        searchResults: [],
        isAPICalled: false,
        apiOnScroll: false,
        filterOpen: false,
        hospitalArr,
        productcategoryFilterArr,
        cityFilterArr,
        tagHospitalList,
        tagProductCategoryArr,
        tagCityArr,
      },
      () => {
        this.callSearchApi();
      }
    );
  };

  /**
   *  Reset btn click - Remove All the filters and call search API
   */
  onResetClick = () => {
    const { searchby } = this.state;
    if (searchby === 'productcategory') {
      this.setState(
        {
          offset: 0,
          searchResults: [],
          isAPICalled: false,
          apiOnScroll: false,
          filterOpen: false,
          hospitalArr: [],
          tagHospitalList: [],
          tagProductCategoryArr: [],
        },
        () => {
          this.callSearchApi();
        }
      );
    } else if (searchby === 'city') {
      this.setState(
        {
          offset: 0,
          searchResults: [],
          isAPICalled: false,
          apiOnScroll: false,
          filterOpen: false,
          hospitalArr: [],
          productcategoryFilterArr: [],
          tagHospitalList: [],
          tagProductCategoryArr: [],
        },
        () => {
          this.callSearchApi();
        }
      );
    } else {
      this.setState(
        {
          offset: 0,
          searchResults: [],
          isAPICalled: false,
          apiOnScroll: false,
          filterOpen: false,
          hospitalArr: [],
          productcategoryFilterArr: [],
          cityFilterArr: [],
          tagHospitalList: [],
          tagProductCategoryArr: [],
        },
        () => {
          this.callSearchApi();
        }
      );
    }
  };

  /**
   * Summary. Set productcategory filters
   *
   * Description. Set productcategory filters on select
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Array}   productcategoryFilterArr  list of productcategories
   *
   */
  onSetProductCategory = (productcategoryFilterArr) => {
    this.setState({
      productcategoryFilterArr,
    });
  };

  /**
   * Summary. Set city filters
   *
   * Description. Set city filters on select
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Array}   cityFilterArr  list of cities
   *
   */
  onSetCity = (cityFilterArr) => {
    this.setState({
      cityFilterArr,
    });
  };

  /**
   * Summary. Clear results click event
   *
   * Description. Remove and clear all the results with filters
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  clearResults = () => {
    const { keyVal } = this.state;
    this.setState({
      offset: 0,
      searchResults: [],
      isAPICalled: false,
      apiOnScroll: false,
      filterOpen: false,
      hospitalArr: [],
      productcategoryFilterArr: [],
      cityFilterArr: [],
      tagHospitalList: [],
      tagProductCategoryArr: [],
      text: '',
      currentSearchName: '',
      keyVal: keyVal + 1,
    });
  };

  /**
   * Summary. Remove company from tags
   *
   * Description. Remove the company from company list and call search API
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   id  company id
   *
   */
  removeHospital = (id) => {
    this.setState(
      (prevState) => ({
        hospitalArr: prevState.hospitalArr.filter((h) => h !== id),
        tagHospitalList: prevState.tagHospitalList.filter((h) => h.id !== id),
        offset: 0,
        searchResults: [],
        isAPICalled: false,
        apiOnScroll: false,
        filterOpen: false,
      }),
      () => {
        this.callSearchApi();
      }
    );
  };

  /**
   * Summary. Remove productcategory from tags
   *
   * Description. Remove the productcategory from productcategory list and call search API
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   productcategoryId       productcategory id
   *
   */
  removeProductCategory = (productcategoryId) => {
    const { productcategoryFilterArr, tagProductCategoryArr } = this.state;
    const index = tagProductCategoryArr.findIndex(
      (v) => v.productcategoryId === productcategoryId
    );
    let newproductcategoryFilterArr = [...productcategoryFilterArr];
    if (index !== -1) {
      tagProductCategoryArr[index].productlines.forEach((item) => {
        newproductcategoryFilterArr = newproductcategoryFilterArr.filter(
          (v) => v !== item.id
        );
      });
    }

    this.setState(
      (prevState) => ({
        productcategoryFilterArr: newproductcategoryFilterArr,
        tagProductCategoryArr: prevState.tagProductCategoryArr.filter(
          (v) => v.productcategoryId !== productcategoryId
        ),
        offset: 0,
        searchResults: [],
        isAPICalled: false,
        apiOnScroll: false,
        filterOpen: false,
      }),
      () => {
        this.callSearchApi();
      }
    );
  };

  /**
   * Summary. Remove city from tags
   *
   * Description. Remove the city from city list and call search API
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   stateId       state id
   *
   */
  removeCity = (stateId) => {
    const { cityFilterArr, tagCityArr } = this.state;
    const index = tagCityArr.findIndex((s) => s.id === stateId);
    let newCityFilterArr = [...cityFilterArr];
    if (index !== -1) {
      tagCityArr[index].cities.forEach((item) => {
        item.checked = false; // eslint-disable-line
        newCityFilterArr = newCityFilterArr.filter((c) => c !== item.id);
      });
    }

    this.setState(
      (prevState) => ({
        cityFilterArr: newCityFilterArr,
        tagCityArr: prevState.tagCityArr.filter((s) => s.id !== stateId),
        offset: 0,
        searchResults: [],
        isAPICalled: false,
        apiOnScroll: false,
        filterOpen: false,
      }),
      () => {
        this.callSearchApi();
      }
    );
  };

  /**
   * Summary. On scroll event
   *
   * Description. Load more search results on scroll
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param  {Object}   e      event object
   */
  onScroll = (e) => {
    const { offset, apiOnScroll } = this.state;
    if (scrollCheck(e, offset, apiOnScroll)) {
      this.setState({
        apiOnScroll: true,
      });
      this.callSearchApi();
    }
  };

  /**
   * Summary. On keyDown event
   *
   * Description. Check if enter key pressed and call search api if true
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param  {Object}   e      event object
   */
  onKeyDown = (e) => {
    if (isEnterKeyPressed(e)) {
      this.onSearch();
    }
  };

  /**
   * Summary. Update favourite details
   *
   * Description. Update favourite flag details of search results
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param  {integer}   id     Rep's user id
   */
  updateSearchFavourites = (id) => {
    const { searchResults, updateSearchKey } = this.state;
    const arrIndex = searchResults.findIndex((v) => v.id === id);
    if (arrIndex !== -1) {
      const newSearchResults = [...searchResults];
      newSearchResults[arrIndex].isFavourite = false;
      this.setState({
        searchResults: newSearchResults,
        updateSearchKey: updateSearchKey + 1,
      });
    }
  };

  toggleInvitePopupOpen = () => {
    this.setState((prevState) => ({
      invitePopupOpen: !prevState.invitePopupOpen,
    }));
  };

  render() {
    const {
      optionsObj,
      searchby,
      text,
      isAPICalled,
      searchResults,
      filterOpen,
      hospitalArr,
      masterStateList,
      productcategoryFilterArr,
      cityFilterArr,
      tagHospitalList,
      tagProductCategoryArr,
      tagCityArr,
      currentSearchName,
      keyVal,
      updateSearchKey,
      invitePopupOpen,
    } = this.state;
    const isBasicPlan = getBasicPlanNew();

    const { updateFavourites } = this.props;

    let isFilterDisable = false;
    let newSearchText = text;
    if (searchby === 'productcategory') {
      newSearchText = productcategoryFilterArr.join(',');
    }
    if (searchby === 'city') {
      newSearchText = cityFilterArr.join(',');
    }
    if (currentSearchName !== newSearchText) {
      isFilterDisable = true;
    }

    return (
      <MDBContainer
        className="preLogin position-relative"
        id="my-colleagues-container"
      >
        <MDBRow>
          <MDBCol lg="12" className="my-5">
            <div className="search-right-panel">
              <div className="clearfix text-right">
                <div className="heading-txt">
                  <ProfileHeading headingtxt="My Colleagues" />
                </div>
                <RecentSearch
                  stateList={masterStateList}
                  onRecentSearchClick={this.onRecentSearchClick}
                  onSearchProductCategory={this.onSearchProductCategory}
                  onSearchCity={this.onSearchCity}
                />
                <span
                  className={`clear_btn ${
                    searchResults.length || currentSearchName || newSearchText
                      ? 'cursor'
                      : 'noEvents disable_text'
                  }`}
                  onClick={this.clearResults}
                  role="presentation"
                >
                  Clear Results
                </span>
              </div>
              <div className="provider_search_panel">
                <div className="provider_select">
                  <MDBSelect getValue={this.searchVal} key={keyVal}>
                    <MDBSelectInput
                      selected={searchby ? optionsObj[searchby] : 'Search By'}
                    />
                    <MDBSelectOptions>
                      {/* <MDBSelectOption disabled>
                                  Search By
                                </MDBSelectOption> */}
                      {Object.keys(optionsObj).map((v) => {
                        if (isBasicPlan && v === 'product') {
                          return '';
                        }
                        return (
                          <MDBSelectOption key={v} value={v}>
                            {optionsObj[v]}
                          </MDBSelectOption>
                        );
                      })}
                    </MDBSelectOptions>
                  </MDBSelect>
                </div>
                <div className="provider_search_bar">
                  <div className="search_bar_panel">
                    <div className="search_bar">
                      <div className="position-relative">
                        <Suspense fallback={<Loading />}>
                          {searchby === 'hospital' ? (
                            <SearchHospitalList
                              onChange={this.onChange}
                              onHospitalSelect={this.onHospitalSelect}
                              masterStateList={masterStateList}
                              onKeyDown={this.onKeyDown}
                              selectedHospital={text}
                              key={keyVal}
                            />
                          ) : searchby === 'productcategory' ? (
                            <SearchProductCategoryList
                              onSetProductCategory={this.onSetProductCategory}
                              productcategoryFilterArr={
                                productcategoryFilterArr
                              }
                              key={keyVal}
                            />
                          ) : searchby === 'city' ? (
                            <SearchCityList
                              onSetCity={this.onSetCity}
                              masterStateList={masterStateList}
                              cityFilterArr={cityFilterArr}
                              key={keyVal}
                            />
                          ) : (
                            <MDBInput
                              type="search"
                              className="search_field"
                              maxLength="50"
                              placeholder={
                                searchby
                                  ? searchby === 'product'
                                    ? 'Begin typing product name here'
                                    : 'Begin typing colleague’s name here'
                                  : ''
                              }
                              onChange={this.onChange}
                              name="textSearch"
                              value={text}
                              disabled={!searchby}
                              autoComplete="off"
                              onKeyDown={this.onKeyDown}
                            />
                          )}
                        </Suspense>
                      </div>
                    </div>

                    {searchby === 'city' ? (
                      <button
                        type="button"
                        className={`search_btn ${
                          isAPICalled || cityFilterArr.length <= 0
                            ? 'noEvents'
                            : ''
                        }`}
                        onClick={this.onCitySearch}
                        disabled={
                          searchby && (isAPICalled || cityFilterArr.length <= 0)
                        }
                        data-repcard-test="search"
                      >
                        {isAPICalled ? (
                          <span className="spinner-border spinner-border-sm" />
                        ) : (
                          'Search'
                        )}
                      </button>
                    ) : searchby === 'productcategory' ? (
                      <button
                        type="button"
                        className={`search_btn ${
                          isAPICalled || productcategoryFilterArr.length <= 0
                            ? 'noEvents'
                            : ''
                        }`}
                        onClick={this.onProductCategorySearch}
                        disabled={
                          searchby &&
                          (isAPICalled || productcategoryFilterArr.length <= 0)
                        }
                        data-repcard-test="search"
                      >
                        {isAPICalled ? (
                          <span className="spinner-border spinner-border-sm" />
                        ) : (
                          'Search'
                        )}
                      </button>
                    ) : (
                      <button
                        type="button"
                        className={`search_btn ${
                          isAPICalled || text.length < 3 ? 'noEvents' : ''
                        }`}
                        onClick={this.onSearch}
                        disabled={searchby && (isAPICalled || text.length < 3)}
                        data-repcard-test="search"
                      >
                        {isAPICalled ? (
                          <span className="spinner-border spinner-border-sm" />
                        ) : (
                          'Search'
                        )}
                      </button>
                    )}
                  </div>
                </div>
              </div>
              {searchResults.length ||
              tagHospitalList.length ||
              tagCityArr.length ||
              tagProductCategoryArr.length ? (
                <div
                  className={`filter-panel mt-1 ${
                    isFilterDisable ? 'noEvents' : ''
                  }`}
                >
                  <div
                    className={`filter-list-name ${filterOpen ? 'active' : ''}`}
                    onClick={this.filterSelectOpen}
                    role="presentation"
                    data-repcard-test="filter"
                  >
                    <span className="shape mr-1" />
                    Filter
                  </div>
                  {filterOpen ? (
                    <FiltersMyColleagues
                      text={text}
                      onClickAway={this.onClickAway}
                      onFilterClick={this.onFilterClick}
                      onResetClick={this.onResetClick}
                      hospitalArr={hospitalArr}
                      productcategoryFilterArr={productcategoryFilterArr}
                      cityFilterArr={cityFilterArr}
                      masterStateList={masterStateList}
                      tagHospitalList={tagHospitalList}
                      tagProductCategoryArr={tagProductCategoryArr}
                      tagCityArr={tagCityArr}
                      searchby={searchby}
                    />
                  ) : (
                    ''
                  )}
                </div>
              ) : (
                ''
              )}

              <div className="tagPanel">
                {tagHospitalList.map((v) => {
                  return (
                    <p className="tags" key={v.id}>
                      {v.name}
                      <span
                        className="close_tag"
                        onClick={() => {
                          this.removeHospital(v.id);
                        }}
                        role="presentation"
                        data-repcard-test="removeHospital"
                      />
                    </p>
                  );
                })}
                {tagProductCategoryArr.map((v) => {
                  return (
                    <p className="tags" key={v.productcategoryId}>
                      {v.productcategoryName} -{' '}
                      {v.productlines.map((item, i) => {
                        if (i === v.productlines.length - 1) {
                          return item.name;
                        }
                        return `${item.name}, `;
                      })}
                      <span
                        className="close_tag"
                        onClick={() => {
                          this.removeProductCategory(v.productcategoryId);
                        }}
                        role="presentation"
                        data-repcard-test="removeProductCategory"
                      />
                    </p>
                  );
                })}
                {tagCityArr.map((s) => {
                  return (
                    <p className="tags" key={s.id}>
                      {s.state} -{' '}
                      {s.cities.map((c, i) => {
                        if (i === s.cities.length - 1) {
                          return c.city;
                        }
                        return `${c.city}, `;
                      })}
                      <span
                        className="close_tag"
                        onClick={() => {
                          this.removeCity(s.id);
                        }}
                        role="presentation"
                        data-repcard-test="removeCity"
                      />
                    </p>
                  );
                })}
              </div>

              {searchResults.length ? (
                <div className="provider_table" onScroll={this.onScroll}>
                  <div className="provider_search_list" key={updateSearchKey}>
                    <div className="tr d-md-inline-block d-sm-none">
                      <div className="th" />
                      <div className="active_in_mobile">
                        <div className="th">Rep Name</div>
                        <div className="th">Company</div>
                        <div className="th">Product Lines</div>
                        <div className="th">Email</div>
                        <div className="th">Phone</div>
                      </div>
                    </div>
                    {searchResults.map((v) => {
                      return (
                        <SearchRow
                          item={v}
                          key={v.id}
                          updateFavourites={updateFavourites}
                        />
                      );
                    })}
                  </div>
                </div>
              ) : (
                <div className="no_result_txt">
                  {currentSearchName && !isAPICalled ? (
                    <>
                      {searchby === 'name' ? (
                        <>
                          <p>
                            Sorry. We can&apos;t find any rep by that name at
                            your company.
                          </p>

                          <p>
                            Please try an alternate search or try again at a
                            later date. Thank you.
                          </p>
                        </>
                      ) : searchby === 'productcategory' ? (
                        <>
                          <p>
                            Sorry. We can&apos;t find any rep associated with
                            that product line at your company.
                          </p>
                          <p>
                            Please try an alternate search or try again at a
                            later date. Thank you.
                          </p>
                        </>
                      ) : searchby === 'hospital' ? (
                        <>
                          <p>
                            Sorry. We can&apos;t find any rep associated with
                            that account at your company.
                          </p>
                          <p>
                            Please try an alternate search or try again at a
                            later date. Thank you.
                          </p>
                        </>
                      ) : searchby === 'city' ? (
                        <>
                          <p>
                            Sorry. We can&apos;t find any rep associated with
                            {cityFilterArr.length > 1
                              ? ' those cities '
                              : ' that city '}
                            or state at your company.
                          </p>
                          <p>
                            Please try an alternate search or try again at a
                            later date. Thank you.
                          </p>
                        </>
                      ) : searchby === 'product' ? (
                        <>
                          <p>
                            Sorry. We can&apos;t find any rep associated with
                            that product at your company.
                          </p>
                          <p>
                            Please try an alternate search or try again at a
                            later date. Thank you.
                          </p>
                        </>
                      ) : (
                        ''
                      )}
                      <br />
                    </>
                  ) : (
                    ''
                  )}
                </div>
              )}
            </div>
            <InvitePopup
              open={invitePopupOpen}
              toggle={this.toggleInvitePopupOpen}
            />
          </MDBCol>
        </MDBRow>
      </MDBContainer>
    );
  }
}

export default Search;
