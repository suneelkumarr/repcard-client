/**
 *
 * Description. PreMyColleagues Page
 *
 * @link   URL
 * @file   Redirect to my products page with header and footer
 * @since  1.0.0
 */
import React, { Component } from 'react';
import Header from '../NavHeader/RepHeader/Header';
import Footer from '../Footer/Footer';
import MyAccount from './MyColleagues.jsx';

class PreMyColleagues extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  componentDidMount() {}

  render() {
    return (
      <>
        <Header isMyColleagues {...this.props} showClaimBtn />
        <MyAccount />
        <Footer />
      </>
    );
  }
}

export default PreMyColleagues;
