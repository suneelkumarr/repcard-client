/**
 *
 * Description. Add hospitals from city and state
 *
 * @link   URL
 * @file   Seacrh hospitals from state dropdown and add it to the account.
           Also search hospitals using city filter.
 * @since  1.0.0
 */

import React, { Component } from 'react';
import isEmpty from 'lodash/isEmpty';
import {
  MDBModalBody,
  MDBInput,
  MDBSelect,
  MDBCol,
  MDBRow,
  MDBSelectInput,
  MDBSelectOptions,
  MDBSelectOption,
} from 'mdbreact';
import uniqBy from 'lodash/uniqBy';
import { axiosApi } from '../../apis/axiosApiCall';
import app from '../../helpers/appGlobal';
import Filters from './Filters';
import ProfileHeading from '../Common/ProfileHeading';
import {
  getMasterStatesData,
  getMasterHospitalsData,
} from '../../utils/masterProductCategoryData';
import './addaccount.scss';

class AddAccount extends Component {
  constructor(props) {
    super(props);
    this.state = {
      searchVal: '',
      cityList: [],
      cityArr: [],
      filterHospitalList: [],
      selectedArr: [],
      statesArr: [],
    };
  }

  /**
   *  Load master state array data and set to state
   */
  getMasterStateData = () => {
    getMasterStatesData((dataArr) => {
      if (!isEmpty(dataArr)) {
        this.setState({
          statesArr: dataArr,
        });
      }
    });
  };

  /**
   * Summary. Hospital Data API
   *
   * Description. To retrive hospital list using state
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export public
   *
   * @param {string}   abbr       state abbr name
   *
   */
  getMasterHospitalData = (abbr) => {
    const id = this.findStateIdByAbbr(abbr);
    getMasterHospitalsData(id, (dataArr) => {
      if (!isEmpty(dataArr)) {
        const hospitalList = dataArr.cities;
        this.setState({
          hospitalList,
          filterHospitalList: hospitalList,
          cityList: uniqBy(hospitalList, 'city'),
        });
      }
    });
  };

  /**
   * Summary. Find state Id
   *
   * Description. To retrive state details using state abbr
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export public
   *
   * @param {string}   abbr       state abbr name
   *
   */
  findStateIdByAbbr = (abbr) => {
    const { statesArr } = this.state;
    const index = statesArr.findIndex((v) => v.abbr === abbr);
    return statesArr[index].id;
  };

  /**
   * Summary. Select search parameter
   *
   * Description. Select state from dropdown
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Array}   val       select value
   *
   */
  searchVal = (val) => {
    this.setState(
      {
        searchVal: val.toString(),
        hospitalList: [],
        filterHospitalList: [],
        cityList: [],
        cityArr: [],
        selectedArr: [],
        filterOpen: false,
      },
      () => {
        this.getMasterHospitalData(val.toString());
      }
    );
  };

  /**
   * Summary. filter tab
   *
   * Description. Toggle filter html
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  filterSelectOpen = () => {
    this.setState((prevState) => ({
      filterOpen: !prevState.filterOpen,
    }));
  };

  /**
   * Summary. Apply filter click
   *
   * Description. Set cities and hospital list
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  onFilterClick = (cityArr) => {
    const { hospitalList } = this.state;
    let newHospitalList = [];
    cityArr.forEach((city) => {
      const value = hospitalList.filter((x) => x.city === city);
      newHospitalList = [...newHospitalList, ...value];
    });

    this.setState({
      cityArr,
      filterHospitalList: newHospitalList,
      filterOpen: false,
    });
  };

  /**
   * Summary. Reset btn click
   *
   * Description. Remove All the filters and research
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  onResetClick = () => {
    const { searchVal } = this.state;
    this.searchVal([searchVal]);
  };

  /**
   * Summary. Add button click
   *
   * Description. Toggle hospitals on Add button click
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   hospitalId      id of the hospital
   *
   */
  onAddClick = (hospitalId) => {
    const { selectedArr } = this.state;
    const index = selectedArr.findIndex((v) => v === hospitalId);
    if (index === -1) {
      this.setState((prevState) => ({
        selectedArr: [...prevState.selectedArr, hospitalId],
      }));
    } else {
      this.setState((prevState) => ({
        selectedArr: prevState.selectedArr.filter((v) => v !== hospitalId),
        isSelectAll: false,
      }));
    }
  };

  /**
   * Summary. Select All checkbox click
   *
   * Description. Add all the hospitals to the array
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Object}   e      event object
   *
   */
  onSelectAll = (e) => {
    const { checked } = e.target;
    const { filterHospitalList } = this.state;
    let selectedArr = [];
    if (checked) {
      filterHospitalList.forEach((v) => {
        selectedArr = [...selectedArr, v.id];
      });
    }
    this.setState({
      isSelectAll: checked,
      selectedArr,
    });
  };

  /**
   * Summary. Add hospitals API
   *
   * Description. Save hospital array list via calling an API
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  onSaveClick = () => {
    const { selectedArr } = this.state;
    const { id } = app.user;
    this.setState({
      isAPICalled: true,
    });
    const reqObj = {
      repId: id,
      hospitalIds: selectedArr,
    };
    axiosApi(`/repProfile/addRepHospitals`, 'POST', reqObj, (res) => {
      this.setState({
        isAPICalled: false,
      });
      if (res.error) {
        this.setState({
          apiErrorMessage: res.message,
        });
      } else {
        const { onAddSuccess } = this.props;
        onAddSuccess();
      }
    });
  };

  componentDidMount() {
    this.getMasterStateData();
  }

  render() {
    const {
      searchVal,
      cityList,
      filterHospitalList,
      filterOpen,
      cityArr,
      selectedArr,
      isSelectAll,
      isAPICalled,
      apiErrorMessage,
      statesArr,
    } = this.state;

    return (
      <MDBModalBody>
        <div className="d-block">
          <ProfileHeading headingtxt="Add Accounts" />
        </div>
        {statesArr.length ? (
          <>
            <MDBRow>
              <MDBCol lg="9">
                <div className="select_panel arrow-list">
                  <MDBSelect getValue={this.searchVal}>
                    <MDBSelectInput selected={searchVal || 'Select State'} />
                    <MDBSelectOptions>
                      {/* <MDBSelectOption disabled>
                    Search By
                  </MDBSelectOption> */}
                      {statesArr.map((v) => {
                        return (
                          <MDBSelectOption key={v.id} value={v.abbr}>
                            {v.state}
                          </MDBSelectOption>
                        );
                      })}
                    </MDBSelectOptions>
                  </MDBSelect>
                </div>
              </MDBCol>
              {searchVal ? (
                <MDBCol lg="3">
                  <div className="filter-panel account_filter_panel orange_bg add-account">
                    <div
                      className={`filter-list-name ${
                        filterOpen ? 'active' : ''
                      }`}
                      onClick={this.filterSelectOpen}
                      role="presentation"
                      data-repcard-test="filter"
                    >
                      <span className="shape mr-1" />
                      Filter by City
                    </div>
                    {filterOpen ? (
                      <Filters
                        state={searchVal}
                        onFilterClick={this.onFilterClick}
                        onResetClick={this.onResetClick}
                        cityList={cityList}
                        cityArr={cityArr}
                      />
                    ) : (
                      ''
                    )}
                  </div>
                </MDBCol>
              ) : (
                ''
              )}
            </MDBRow>
            {filterHospitalList.length ? (
              <div className="account_name_list">
                <div className="account_info_txt clearfix">
                  Account Name{' '}
                  <span>
                    (Use the Add Button to add multiple accounts to My Account
                    list)
                  </span>
                  <div className="float-right">
                    <MDBInput
                      label="Add All"
                      filled
                      type="checkbox"
                      id="checkboxAddAll"
                      checked={isSelectAll}
                      onChange={this.onSelectAll}
                    />
                  </div>
                </div>
                <ul>
                  {filterHospitalList.map((v) => {
                    const { city, hospital, id } = v;
                    return (
                      <li key={id}>
                        <div className="center_name">{hospital}</div>
                        <div className="city_name">
                          {city}, {searchVal}
                        </div>
                        <div className="mobile-block">
                          <button
                            type="button"
                            className={`add_btn ${
                              selectedArr.indexOf(id) !== -1 ? 'active' : ''
                            }`}
                            onClick={() => {
                              this.onAddClick(id);
                            }}
                            data-repcard-test="add"
                          >
                            Add
                          </button>
                        </div>
                      </li>
                    );
                  })}
                </ul>
                <div className="text-center account_name_btn">
                  <button
                    type="button"
                    className="fill-orange-btn"
                    disabled={!selectedArr.length || isAPICalled}
                    onClick={this.onSaveClick}
                    data-repcard-test="save"
                  >
                    {isAPICalled ? (
                      <span className="spinner-border spinner-border-sm" />
                    ) : (
                      ''
                    )}
                    Save
                  </button>
                  {apiErrorMessage ? (
                    <p className="error-message1">{apiErrorMessage}</p>
                  ) : (
                    ''
                  )}
                </div>
              </div>
            ) : (
              ''
            )}
          </>
        ) : (
          'Please wait...'
        )}
      </MDBModalBody>
    );
  }
}

export default AddAccount;
