/**
 *
 * Description. Filters section for hospitals
 *
 * @link   URL
 * @file   Filter the hospital list by choosing the city filter
 * @since  1.0.0
 */
import React, { Component } from 'react';
import { MDBInput } from 'mdbreact';
import uniq from 'lodash/uniq';
import FilterButtons from '../Search/FilterButtons';

class Filters extends Component {
  constructor(props) {
    super(props);
    const { cityArr } = this.props;
    this.state = {
      cityArr: cityArr || [],
    };
  }

  componentDidMount() {}

  componentWillUnmount() {}

  /**
   * Summary. Checkbox change event
   *
   * Description. Set/Reset city to cityArray
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Object}   e               event object
   * @param {Object}   item            City object
   *
   */
  onCheckboxChange = (e, item) => {
    const { checked } = e.target;
    const { city } = item;
    const id = city;
    if (checked) {
      this.setState((prevState) => ({
        cityArr: uniq([...prevState.cityArr, id]),
      }));
    } else {
      this.setState((prevState) => ({
        cityArr: prevState.cityArr.filter((v) => v !== id),
      }));
    }
  };

  /**
   *  Apply filter btn click event
   */
  onFilterClick = () => {
    const { cityArr } = this.state;
    if (cityArr.length) {
      const { onFilterClick } = this.props;
      onFilterClick(cityArr);
    }
  };

  /**
   *  Reset btn click event
   */
  onResetClick = () => {
    const { onResetClick } = this.props;
    onResetClick();
  };

  render() {
    const { cityArr } = this.state;
    const { cityList } = this.props;

    return (
      <div className="filter-list-wrap" style={{ right: '-55px' }}>
        <div className="product-wrap height_add">
          <div className="wid-50">
            <ul className="filter-list">
              <li role="presentation" className="selected">
                Select city
              </li>
            </ul>
            <div className="filter-btn">
              <FilterButtons
                onFilterClick={this.onFilterClick}
                onResetClick={this.onResetClick}
                isBtnEnable={!!cityArr.length}
              />
            </div>
          </div>
          <div className="wid-50 selected">
            <ul className="filter-list overflow-lists">
              {cityList.map((v) => {
                const { city } = v;
                const id = city;
                return (
                  <li key={id}>
                    <MDBInput
                      label={v.city}
                      filled
                      type="checkbox"
                      checked={cityArr.indexOf(id) !== -1}
                      id={`filtermain${id}`}
                      onChange={(e) => {
                        this.onCheckboxChange(e, v);
                      }}
                    />
                  </li>
                );
              })}
            </ul>
          </div>
        </div>
      </div>
    );
  }
}

export default Filters;
