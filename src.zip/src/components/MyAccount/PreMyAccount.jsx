/**
 *
 * Description. PreMyAccount Page
 *
 * @link   URL
 * @file   Redirect to my account page with header and footer
 * @since  1.0.0
 */
import React, { Component } from 'react';
import Header from '../NavHeader/RepHeader/Header';
import Footer from '../Footer/Footer';
import MyAccount from './MyAccount.jsx';

class PreMyAccount extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  componentDidMount() {}

  render() {
    return (
      <>
        <Header isMyAccount {...this.props} />
        <MyAccount />
        <Footer />
      </>
    );
  }
}

export default PreMyAccount;
