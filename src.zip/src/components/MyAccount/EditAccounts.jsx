/**
 *
 * Description. Edit hospitals
 *
 * @link   URL
 * @file   Remove Already added hospitals (By select all or by selecting multiple checkboxes)
           This is also used to display the Already added hospitals.
 * @since  1.0.0
 */
import React, { Component } from 'react';
import { Redirect } from 'react-router-dom';
import { MDBInput, MDBModal, MDBModalBody } from 'mdbreact';
import { axiosApi } from '../../apis/axiosApiCall';
import app from '../../helpers/appGlobal';
import ProfileHeading from '../Common/ProfileHeading';

class EditAccount extends Component {
  constructor(props) {
    super(props);
    this.state = {
      modal: false,
      deleteIdArr: [],
      deletedCityList: [],
      isSelectAll: false,
      hospitalKey: 'hospitalId',
      redirectToReferrer: '',
    };
  }

  componentDidMount() {}

  /**
   *  Minimum 1 hospital needs to be there
   */
  isValidate = () => {
    const { totalCount } = this.props;
    const { deleteIdArr } = this.state;
    if (deleteIdArr.length < totalCount) {
      return true;
    }
    return false;
  };

  /**
   * Summary. Modal Open
   *
   * Description. Toggle Modal for removing hospitals
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  toggle = () => {
    const isValid = this.isValidate();
    if (isValid) {
      this.setState((prevState) => ({
        modal: !prevState.modal,
      }));
    } else {
      alert('You must have at least one account associated with your profile.');
    }
  };

  /**
   *  Set default react state parameters
   */
  setDefaultStates = () => {
    this.setState({
      deleteIdArr: [],
      deletedCityList: [],
      isSelectAll: false,
      modal: false,
    });
  };

  /**
   *  Cancel click event, Remove all the selected hospitals
   */
  onCancel = () => {
    const { onCancelClick } = this.props;
    this.setDefaultStates();
    onCancelClick();
  };

  /**
   * Summary. Remove hospital API
   *
   * Description. API call for removing hospital list
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  onRemoveClick = () => {
    const { deleteIdArr } = this.state;
    const { id } = app.user;
    this.setState({
      isAPICalled: true,
    });
    const reqObj = {
      repId: id,
      hospitalIds: deleteIdArr,
    };
    axiosApi(`/repProfile/removeRepHospitals/`, 'POST', reqObj, (res) => {
      this.setState({
        isAPICalled: false,
      });
      if (res.error) {
        this.setState({
          apiErrorMessage: res.message,
        });
      } else {
        this.setDefaultStates();
        const { onRemove } = this.props;
        onRemove(deleteIdArr);
      }
    });
  };

  /**
   * Summary. Checkbox change event
   *
   * Description. Set/Reset deleted hospitals and cityObj to state
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Object}   e               event object
   * @param {string}   hospitalId      id of the hospital
   * @param {Object}   cityObj         city object for deleted hospital
   *
   */
  onChangeCheckbox = (e, hospitalId, cityObj) => {
    const { checked } = e.target;
    const { hospitalKey } = this.state;
    if (checked) {
      this.setState((prevState) => ({
        deleteIdArr: [...prevState.deleteIdArr, hospitalId],
        deletedCityList: [...prevState.deletedCityList, cityObj],
      }));
    } else {
      this.setState((prevState) => ({
        deleteIdArr: prevState.deleteIdArr.filter((v) => v !== hospitalId),
        deletedCityList: prevState.deletedCityList.filter(
          (v) => v[hospitalKey] !== hospitalId
        ),
        isSelectAll: false,
      }));
    }
  };

  /**
   * Summary. Select All checkbox
   *
   * Description. Set All the deleted hospitals and cityObj to state
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Object}   e               event object
   *
   */
  onSelectAll = (e) => {
    const { checked } = e.target;
    const { hospitalArr, keyname } = this.props;
    const { hospitalKey } = this.state;
    let deleteIdArr = [];
    let deletedCityList = [];
    if (checked) {
      hospitalArr.forEach((item) => {
        item[keyname].forEach((v) => {
          deleteIdArr = [...deleteIdArr, v[hospitalKey]];
          deletedCityList = [...deletedCityList, v];
        });
      });
    }
    this.setState({
      isSelectAll: checked,
      deleteIdArr,
      deletedCityList,
    });
  };

  /**
   *  Redirect to REpDashboard Page
   */
  redirectToPage = () => {
    this.setState({
      redirectToReferrer: '/RepDashboard',
    });
  };

  render() {
    const {
      modal,
      deleteIdArr,
      isSelectAll,
      deletedCityList,
      isAPICalled,
      apiErrorMessage,
      hospitalKey,
      redirectToReferrer,
    } = this.state;
    const {
      isEdit,
      hospitalArr,
      tagcityArr,
      removeTags,
      onScroll,
      keyname,
      isDoneBtnShow,
    } = this.props;

    if (redirectToReferrer) {
      const from = { pathname: redirectToReferrer };
      return <Redirect to={from} />;
    }

    return (
      <>
        <div className="account_name_list edit_list">
          {isEdit ? (
            ''
          ) : (
            <div className="tagPanel">
              {tagcityArr &&
                tagcityArr.map((v) => {
                  return (
                    <div className="tags" key={v.city}>
                      {v.state} - {v.city}{' '}
                      <span
                        className="close_tag"
                        role="presentation"
                        onClick={() => {
                          removeTags(v.city);
                        }}
                      />
                    </div>
                  );
                })}
            </div>
          )}
          <ul onScroll={onScroll}>
            <li>
              <div className="hospital_name selectall">
                {isEdit ? (
                  <MDBInput
                    label="Select All"
                    filled
                    type="checkbox"
                    id="checkboxSelectAll"
                    className="selectall"
                    checked={isSelectAll}
                    onChange={this.onSelectAll}
                  />
                ) : (
                  <>Account Name</>
                )}
              </div>
              <div className="city_name">Location</div>
            </li>
            {hospitalArr.map((item) => {
              return item[keyname].map((v) => {
                const { city, hospital } = v;
                const hospitalId = v[hospitalKey];
                return (
                  <li key={hospitalId}>
                    <div className="hospital_name">
                      {isEdit ? (
                        <MDBInput
                          label={hospital}
                          filled
                          type="checkbox"
                          id={`editCheck${hospitalId}`}
                          checked={deleteIdArr.indexOf(hospitalId) !== -1}
                          onChange={(e) => {
                            this.onChangeCheckbox(e, hospitalId, v);
                          }}
                        />
                      ) : (
                        <div>{hospital}</div>
                      )}
                    </div>
                    <div className="city_name">
                      {city}, {item.abbr}
                    </div>
                  </li>
                );
              });
            })}
          </ul>
          {isEdit || !hospitalArr.length ? (
            ''
          ) : isDoneBtnShow ? (
            <div className="text-right account_name_btn">
              {/* <button
                type="button"
                className="fill-orange-btn mr-3"
                onClick={this.redirectToPage}
                data-repcard-test="done"
              >
                Done
              </button> */}
            </div>
          ) : (
            ''
          )}

          {isEdit ? (
            <div className="text-right account_name_btn">
              <button
                type="button"
                className="fill-orange-btn mr-3"
                onClick={this.toggle}
                disabled={!deleteIdArr.length}
                data-repcard-test="modal"
              >
                Remove
              </button>
              <button
                type="button"
                className="fill-orange-btn"
                onClick={this.onCancel}
                data-repcard-test="cancel"
              >
                Cancel
              </button>
            </div>
          ) : (
            ''
          )}
        </div>

        <MDBModal
          className="add_account_popup"
          centered
          isOpen={modal}
          toggle={this.toggle}
        >
          <MDBModalBody className="p-5">
            <div className="d-block">
              <ProfileHeading headingtxt="Remove Account" />
            </div>
            <div className="remove_txt mb-5">
              Are you sure you want to remove{' '}
              {deletedCityList.map((item, i) => {
                if (i === deletedCityList.length - 1) {
                  return (
                    <span key={item[hospitalKey]}>
                      “{item.hospital} of {item.city}”
                    </span>
                  );
                }
                return (
                  <span key={item[hospitalKey]}>
                    <span>
                      “{item.hospital} of {item.city}”
                    </span>
                    {i === deletedCityList.length - 2 ? ' and ' : ', '}
                  </span>
                );
              })}{' '}
              ?
            </div>
            <div className="text-center mt-3">
              <button
                type="button"
                className="fill-orange-btn"
                onClick={this.onRemoveClick}
                disabled={isAPICalled}
                data-repcard-test="remove"
              >
                {isAPICalled ? (
                  <span className="spinner-border spinner-border-sm" />
                ) : (
                  ''
                )}
                Ok
              </button>
              {apiErrorMessage ? (
                <p className="error-message1">{apiErrorMessage}</p>
              ) : (
                ''
              )}
            </div>
          </MDBModalBody>
        </MDBModal>
      </>
    );
  }
}

export default EditAccount;
