/**
 *
 * Description. Main component for hospitals
 *
 * @link   URL
 * @file   Used for add, edit and remove hospitals with filters.
           Redirect to specific components for above functionality
 * @since  1.0.0
 */
import React, { Component } from 'react';
import { MDBContainer, MDBCol, MDBRow, MDBModal } from 'mdbreact';
import ProfileHeading from '../Common/ProfileHeading';
import AddAccount from './AddAccount.jsx';
import { axiosApi } from '../../apis/axiosApiCall';
import app from '../../helpers/appGlobal';
import scrollCheck from '../../utils/scrollCheck';
import EditAccounts from './EditAccounts';
import RowFilters from './RowFilters';

import './myaccount.scss';

class MyAccount extends Component {
  constructor(props) {
    super(props);
    this.state = {
      limit: 1000,
      totalCount: 0,
      offset: 0,
      apiOnScroll: false,
      modal: false,
      filterOpen: false,
      isAPICalled: true,
      isRemove: false,
      tagcityArr: [],
      keyname: 'cities',
    };
  }

  /**
   * Summary. Toggle remove
   *
   * Description. Toggle isRemove flag (edit)
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  onRemoveToggle = () => {
    this.setState((prevState) => ({
      isRemove: !prevState.isRemove,
    }));
  };

  /**
   *  Cancel click event form edit view
   */
  onCancelClick = () => {
    this.onRemoveToggle();
  };

  /**
   *  Remove All the filters
   */
  onRemoveClick = () => {
    this.removeAllFilter();
  };

  /**
   * Summary. Apply filter click
   *
   * Description. Set data to state and get new hospital list as per the filter
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Array}       tagcityArr             city Array list
   */
  onFilterClick = (tagcityArr) => {
    this.setState(
      {
        offset: 0,
        apiResponse: [],
        tagcityArr,
        filterOpen: false,
      },
      () => {
        this.getHospitalsList();
      }
    );
  };

  /**
   * Summary. Remove tags click
   *
   * Description. Remove the city from tagCityArr and reload the hospital list
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}       city             id/name of the city
   */
  removeTags = (city) => {
    this.setState(
      (prevState) => ({
        offset: 0,
        apiResponse: [],
        tagcityArr: prevState.tagcityArr.filter((v) => v.city !== city),
        filterOpen: false,
      }),
      () => {
        this.getHospitalsList();
      }
    );
  };

  /**
   *  Remove all the filters on reset click and refresh the hospital list
   */
  onResetClick = () => {
    this.setState(
      {
        offset: 0,
        tagcityArr: [],
        apiResponse: [],
        filterOpen: false,
      },
      () => {
        this.getHospitalsList();
      }
    );
  };

  /**
   *  Remove all the applied filters whenever required
   */
  removeAllFilter = () => {
    this.setState(
      {
        offset: 0,
        tagcityArr: [],
        apiResponse: [],
        filterOpen: false,
        modal: false,
        isRemove: false,
      },
      () => {
        this.getHospitalsList();
      }
    );
  };

  /**
   *  Toggle filter view
   */
  filterSelectOpen = () => {
    this.setState((prevState) => ({
      filterOpen: !prevState.filterOpen,
    }));
  };

  /**
   *  Open/close modal popup for adding new hospital
   */
  toggle = () => {
    this.setState((prevState) => ({
      modal: !prevState.modal,
    }));
  };

  /**
   * Summary. Get hospitals API
   *
   * Description. To retrive all the hospitals using get API with filter parameters
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {boolean}  isFlag      Flag for showing done btn
   */
  getHospitalsList = (isFlag) => {
    const { id } = app.user;
    this.setState({
      isAPICalled: true,
    });
    const { limit, offset, tagcityArr } = this.state;

    let urlname = `/repProfile/getRepHospitals/?repId=${id}&filterFlag=true&limit=${limit}&offset=${offset}`;
    if (tagcityArr && tagcityArr.length) {
      let cityArrFilter = [];
      tagcityArr.forEach((item) => {
        cityArrFilter = [...cityArrFilter, item.cityId || item.id];
      });
      urlname += `&filterCity=${cityArrFilter.join(',')}`;
    }

    axiosApi(urlname, 'GET', '', (res) => {
      if (res.error) {
        console.log(res.message);
      } else if (res.data) {
        const resObj = res.data.table_data;
        if (offset === 0) {
          this.setState({
            apiResponse: resObj,
            filterCities: res.data.filter_data,
          });
        } else {
          this.setState((prevState) => ({
            apiResponse: [...prevState.apiResponse, ...resObj],
          }));
        }

        if (!(tagcityArr && tagcityArr.length)) {
          this.setState({
            totalCount: res.data.totalCount,
          });
        }

        if (isFlag) {
          this.setState({
            isDoneBtnShow: !resObj.length,
          });
        }

        if (res.data.isMore) {
          this.setState({
            offset: offset + limit,
          });
        } else {
          this.setState({
            offset: 0,
          });
        }
      }
      this.setState({
        isAPICalled: false,
        apiOnScroll: false,
      });
    });
  };

  /**
   * Summary. On scroll event
   *
   * Description. Load more hospital list on scroll
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param  {Object}   e      event object
   */
  onScroll = (e) => {
    const { offset, apiOnScroll } = this.state;
    if (scrollCheck(e, offset, apiOnScroll)) {
      this.setState({
        apiOnScroll: true,
      });
      this.getHospitalsList();
    }
  };

  /**
   *  Remove All the applied filters after Adding new hospitals
   */
  onAddSuccess = () => {
    this.removeAllFilter();
  };

  componentDidMount() {
    this.getHospitalsList(true);
  }

  render() {
    const {
      modal,
      filterOpen,
      apiResponse,
      isAPICalled,
      isRemove,
      tagcityArr,
      keyname,
      filterCities,
      isDoneBtnShow,
      totalCount,
    } = this.state;

    return (
      <MDBContainer className="preLogin position-relative">
        <MDBRow>
          <MDBCol lg="12" className="my-5">
            {isAPICalled ? (
              <div className="clearfix">
                <ProfileHeading headingtxt="My Accounts" />
                <div>Please wait...</div>
              </div>
            ) : (
              <>
                <div className="clearfix">
                  <ProfileHeading headingtxt="My Accounts" />
                  {apiResponse && apiResponse.length && !isRemove ? (
                    <div className="float-right">
                      <div className="filter-section">
                        <div className="filter-panel">
                          <div
                            className={`filter-list-name ${
                              filterOpen ? 'active' : ''
                            }`}
                            onClick={this.filterSelectOpen}
                            role="presentation"
                            data-repcard-test="filter"
                          >
                            <span className="shape mr-1" />
                            Filter
                          </div>
                          {filterOpen ? (
                            <RowFilters
                              onFilterClick={this.onFilterClick}
                              onResetClick={this.onResetClick}
                              hospitalArr={filterCities}
                              tagcityArr={tagcityArr}
                              keyname={keyname}
                            />
                          ) : (
                            ''
                          )}
                        </div>
                      </div>
                      <div
                        className="add_remove_sec"
                        role="presentation"
                        onClick={this.onRemoveToggle}
                        data-repcard-test="remove"
                      >
                        <i className="remove_icon" /> Remove
                      </div>
                      <div
                        className="add_remove_sec ml-4"
                        role="presentation"
                        onClick={this.toggle}
                        data-repcard-test="modal"
                      >
                        <i className="add_account_icon" /> Add Account
                      </div>
                    </div>
                  ) : (
                    ''
                  )}
                </div>
                {apiResponse && apiResponse.length ? (
                  <EditAccounts
                    hospitalArr={apiResponse}
                    isEdit={isRemove}
                    onCancelClick={this.onCancelClick}
                    onRemove={this.onRemoveClick}
                    tagcityArr={tagcityArr}
                    removeTags={this.removeTags}
                    onScroll={this.onScroll}
                    keyname={keyname}
                    isDoneBtnShow={isDoneBtnShow}
                    totalCount={totalCount}
                  />
                ) : (
                  <div className="add_acc_btnpanel">
                    <button
                      type="button"
                      className="add_acc_btn"
                      onClick={this.toggle}
                      data-repcard-test="modal"
                    >
                      <span className="add_icon" /> Add Accounts
                    </button>
                    <p>
                      No Accounts added yet
                      <span className="add_acc_txt">
                        You must have at least one account associated with your
                        profile. Add one now before proceeding.
                      </span>
                    </p>
                  </div>
                )}
                <MDBModal
                  className="add_account_popup"
                  contentClassName="add-min-height"
                  isOpen={modal}
                  toggle={this.toggle}
                >
                  <div
                    role="presentation"
                    onClick={this.toggle}
                    className="close_auth_popup close"
                  >
                    X close
                  </div>
                  {modal ? <AddAccount onAddSuccess={this.onAddSuccess} /> : ''}
                </MDBModal>
              </>
            )}
          </MDBCol>
        </MDBRow>
      </MDBContainer>
    );
  }
}

export default MyAccount;
