/**
 *
 * Description. Filter for Already added hospital section
 *
 * @link   URL
 * @file   Display list of states (whatever is available) and display cities
           accordingly by choosing state option. Apply or Reset filter by choosing
           cities. The list of hospitals get filtered accordingly
 * @since  1.0.0
 */
import React, { Component } from 'react';
import { MDBInput } from 'mdbreact';
import FilterButtons from '../Search/FilterButtons';
import ClickAwayListner from '../Common/ClickAwayListner';

class RowFilters extends Component {
  constructor(props) {
    super(props);
    const { tagcityArr, hospitalArr } = this.props;
    this.state = {
      tagcityArr: tagcityArr || [],
      newCityList: hospitalArr,
      isSelected: hospitalArr[0].id,
    };
  }

  componentDidMount() {}

  componentWillUnmount() {}

  /**
   * Summary. Checkbox change event
   *
   * Description. Set/Reset city to tagcityArr list
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Object}       e               event object
   * @param {string}       id              City Id
   * @param {Object}       item            City object
   * @param {Object}       stateObj        State object for current city
   *
   */
  onCheckboxChange = (e, id, item, stateObj) => {
    const { checked } = e.target;
    if (checked) {
      const newItem = { ...item, state: stateObj.state };
      this.setState((prevState) => ({
        tagcityArr: [...prevState.tagcityArr, newItem],
      }));
    } else {
      this.setState((prevState) => ({
        tagcityArr: prevState.tagcityArr.filter((v) => v.city !== id),
      }));
    }
  };

  /**
   *  Apply filter btn click event
   */
  onFilterClick = () => {
    const { tagcityArr } = this.state;
    if (tagcityArr.length) {
      const { onFilterClick } = this.props;
      onFilterClick(tagcityArr);
    }
  };

  /**
   *  Reset btn click event
   */
  onResetClick = () => {
    const { onResetClick } = this.props;
    onResetClick();
  };

  /**
   * Summary. Change State filter
   *
   * Description. Change state filter
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}       id             state id
   *
   */
  onChangeFilter = (id) => {
    this.setState({
      isSelected: id,
    });
  };

  render() {
    const { tagcityArr, newCityList, isSelected } = this.state;
    const { hospitalArr, keyname } = this.props;

    const index = hospitalArr.findIndex((v) => v.id === isSelected);

    return (
      <ClickAwayListner handleClickAway={() => this.onResetClick()}>
        <div className="filter-list-wrap" style={{ right: '-55px' }}>
          <div className="product-wrap height_add">
            <div className="wid-50">
              <ul className="filter-list">
                {hospitalArr.map((v) => {
                  const { id } = v;
                  return (
                    <li
                      key={id}
                      role="presentation"
                      onClick={() => {
                        this.onChangeFilter(id);
                      }}
                      className={isSelected === id ? 'selected' : ''}
                      data-repcard-test="state"
                    >
                      {v.state}
                    </li>
                  );
                })}
              </ul>
              <div className="filter-btn">
                <FilterButtons
                  onFilterClick={this.onFilterClick}
                  onResetClick={this.onResetClick}
                  isBtnEnable={!!tagcityArr.length}
                />
              </div>
            </div>
            <div className="wid-50 selected">
              <ul className="filter-list overflow-lists">
                {newCityList[index][keyname].map((v) => {
                  const { city } = v;
                  const id1 = city;
                  return (
                    <li key={id1}>
                      <MDBInput
                        label={city}
                        filled
                        type="checkbox"
                        checked={
                          tagcityArr.findIndex((v1) => v1.city === id1) !== -1
                        }
                        id={`filtermain${id1}`}
                        onChange={(e) => {
                          this.onCheckboxChange(e, id1, v, newCityList[index]);
                        }}
                      />
                    </li>
                  );
                })}
              </ul>
            </div>
          </div>
        </div>
      </ClickAwayListner>
    );
  }
}

export default RowFilters;
