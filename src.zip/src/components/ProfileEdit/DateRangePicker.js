/**
 *
 * Description. Date Range Picker
 *
 * @link   URL
 * @file   Display and set the start and end date for vacation details
 * @since  1.0.0
 */
import React, { useState } from 'react';
import { MDBCol } from 'mdbreact';
import moment from 'moment';
import DatePicker from 'react-datepicker';
import MaskedInput from 'react-maskedinput';
import 'react-datepicker/dist/react-datepicker.css';

const getDateObj = (dateObj) => {
  if (dateObj) {
    // Remove timezone offset by adding 00:00
    return new Date(`${dateObj.split('T')[0]} 00:00`);
  }
  return '';
};

/**
 * Summary. Date Range Picker
 *
 * Description. Return from date and to date html details for Rep
 *
 * @since      1.0
 * @deprecated No //x.x.x Use new_function_name() instead.
 * @access     export public
 *
 * @param {function} onChangeCallBack Callback function when date changes
 * @param {string}   fromDate         from date value
 * @param {string}   toDate           to date value
 * @param {Object}   errorObj         error details for from and to date if available
 * @param {Object}   inputClass       error classnames for input
 *
 */
const DateRangePicker = ({
  onChangeCallBack,
  fromDate,
  toDate,
  errorObj,
  inputClass,
}) => {
  const initialFromDate = getDateObj(fromDate);
  const initialToDate = getDateObj(toDate);
  const [startDate, setStartDate] = useState(initialFromDate);
  const [endDate, setEndDate] = useState(initialToDate);

  return (
    <>
      <MDBCol lg="3">
        <div className={`input-field datepicker-label ${inputClass.fromDate}`}>
          <label className="field_label">From</label>
          <DatePicker
            selected={startDate}
            onChange={(date) => {
              if (date) {
                setStartDate(date);
                onChangeCallBack('fromDate', moment(date).format('YYYY-MM-DD'));
              }
            }}
            selectsStart
            startDate={startDate}
            endDate={endDate}
            minDate={new Date()}
            dateFormat="yyyy-MM-dd"
            placeholderText="YYYY-MM-DD"
            customInput={<MaskedInput mask="1111-11-11" />}
          />
          {errorObj.fromDate ? (
            <p className="error-message">
              <span /> {errorObj.fromDate}
            </p>
          ) : (
            ''
          )}
        </div>
      </MDBCol>
      <MDBCol lg="3">
        <div className={`input-field datepicker-label ${inputClass.toDate}`}>
          <label className="field_label">To</label>
          <DatePicker
            selected={endDate}
            onChange={(date) => {
              if (date) {
                setEndDate(date);
                onChangeCallBack('toDate', moment(date).format('YYYY-MM-DD'));
              }
            }}
            selectsEnd
            startDate={startDate}
            endDate={endDate}
            minDate={startDate}
            dateFormat="yyyy-MM-dd"
            placeholderText="YYYY-MM-DD"
            customInput={<MaskedInput mask="1111-11-11" />}
          />
          {errorObj.toDate ? (
            <p className="error-message">
              <span /> {errorObj.toDate}
            </p>
          ) : (
            ''
          )}
        </div>
      </MDBCol>
    </>
  );
};

export default DateRangePicker;
