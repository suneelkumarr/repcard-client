/* eslint-disable no-restricted-syntax */
/**
 *
 * Description. Rep  ProductCategory Edit
 *
 * @link   URL
 * @file   Rep's productcategory Edit, change and remove section
 * @since  1.0.0
 */
import React, { Component } from 'react';
import { MDBRow, MDBCol, MDBContainer, MDBInput, MDBModal } from 'mdbreact';
import * as _ from 'lodash';
import RepAutocomplete from '../../utils/RepAutocomplete.jsx';
import {
  matchStateToTermCustom,
  sortItemsCustom,
} from '../../utils/autoCompleteUtils';
import ProfileHeading from '../Common/ProfileHeading';
import { axiosApi } from '../../apis/axiosApiCall';
import RepProductCategory from '../Common/RepProductCategory/RepProductCategory';
import RepProductsRow from './RepProductsRow.jsx';
// import DeleteModalPopup from './DeleteModalPopup.jsx';
import app from '../../helpers/appGlobal';
import './ProfileEdit.scss';

/**
 *  Generate main and sub category array from master product line data
 */
const getCategoryArr = (arr, productcategoryRes) => {
  let mainCategoryArr = [];
  const subCategoryArr = {};
  arr.forEach((v) => {
    mainCategoryArr = [
      ...mainCategoryArr,
      {
        productcategoryName: v.productcategoryName,
        productcategoryId: v.productcategoryId,
      },
    ];
    const productlines = v.productlines.map((p) => {
      const index = productcategoryRes.findIndex(
        (x) => x.productcategoryId === v.productcategoryId
      );
      if (index !== -1) {
        const productLineIndex = productcategoryRes[
          index
        ].productlines.findIndex((x) => x.id === p.id);
        if (
          productLineIndex !== -1 &&
          p.id === productcategoryRes[index].productlines[productLineIndex].id
        ) {
          return {
            ...p,
            checked: true,
          };
        }
      }
      return {
        ...p,
        checked: false,
      };
    });
    subCategoryArr[v.productcategoryId] = productlines;
  });

  return { mainCategoryArr, subCategoryArr };
};

class RepProfileEditBack extends Component {
  constructor(props) {
    super(props);
    const { productcategoryRes } = this.props;
    const { mainCategoryArr, subCategoryArr } = getCategoryArr(
      app.user.productcategories,
      productcategoryRes
    );
    this.state = {
      productcategoryRes,
      mainCategoryArr,
      subCategoryArr,
      maxCategoryLen: 10,
      isDisabled: true,
      showDesc: false,
    };

    this.timeout = null;
  }

  componentDidMount() {
    const { productcategoryRes } = this.props;
    const newRes = [...productcategoryRes];
    newRes.forEach((v) => {
      v.child = React.createRef(); // eslint-disable-line
    });
    this.setState({
      productcategoryRes: newRes,
    });
    this.addProductCategory();
  }

  /**
   * Summary. Find index from an array
   *
   * Description. Find and return the product line index
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   item    product line object
   *
   */
  getArrIndex = (item) => {
    const { productcategoryRes } = this.state;
    const index = productcategoryRes.findIndex(
      (x) => x.productcategoryId === item.productcategoryId
    );
    return index;
  };

  /**
   * Summary. Set ProductCategory info to state
   *
   * Description. Set the productcategory details to state
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   name    product line name
   * @param {string}   value   product line value
   * @param {object}   item    product line object
   *
   */
  setProductCategory = (name, value, item) => {
    const { productcategoryRes } = this.state;
    let newRes = [...productcategoryRes];
    newRes = [
      { ...item, productlines: [], child: React.createRef() },
      ...newRes,
    ];
    this.setState({
      productcategoryRes: newRes,
      isAdd: false,
      productcategory: '',
      isFocus: false,
    });
  };

  /**
   *  Set main product line value
   */
  setProductCategoryValue = (value) => {
    clearTimeout(this.timeout);
    this.timeout = setTimeout(() => {
      this.setState({
        productcategory: value,
      });
    }, 250);
  };

  /*
   *
   * Set isFocus flag to true on focus of autocomplete input
   */
  onFocusAutocomplete = () => {
    this.setState({
      isFocus: true,
    });
  };

  /*
   *
   * Set isFocus flag to false on blur event of autocomplete input if no value is filled
   */
  onBlurAutocomplete = () => {
    const { productcategory } = this.state;
    if (!productcategory) {
      this.setState({
        isFocus: false,
      });
    }
  };

  /**
   * Summary. Update Product categories
   *
   * Description. update the product line details to state
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Array}   arr            product line array
   * @param {string}  productcategoryId   id of the main product line
   *
   */
  updateArr = (arr, productcategoryId) => {
    const { productcategoryRes } = this.state;
    const index = productcategoryRes.findIndex(
      (x) => x.productcategoryId === productcategoryId
    );

    if (index !== -1) {
      const newRes = [...productcategoryRes];
      newRes[index].productlines = arr;
      this.setState(
        {
          productcategoryRes: newRes,
        },
        () => {
          this.setState(getCategoryArr(app.user.productcategories, newRes));
        }
      );
    }
  };

  addNewProductLines = () => {
    const { productcategoryRes, mainCategoryArr } = this.state;
    const { productcategoryRes: productcategoryResProps } = this.props;

    const selectedCategories = mainCategoryArr.filter((c) => c.checked);
    const toRemoveSaved = productcategoryRes
      .filter((c) => c.checked)
      .filter(
        (c) =>
          !selectedCategories.find(
            (cat) => cat.productcategoryId === c.productcategoryId
          )
      );

    let newRes = [...productcategoryRes].filter(
      (c) =>
        !toRemoveSaved.find(
          (cat) => cat.productcategoryId === c.productcategoryId
        )
    );

    Object.values(selectedCategories).forEach((category) => {
      const addedCategory = newRes.find(
        (c) => c.productcategoryId === category.productcategoryId
      );
      const selectedLines = this.getCurrentProductLines(
        category.productcategoryId
      ).filter((p) => p.checked);

      // category is already in state
      if (addedCategory) {
        // productlines add
        if (addedCategory.productlines.length > 0) {
          const selectedLinesUniq = selectedLines.filter((p) => {
            return !addedCategory.productlines.find((p1) => p1.id === p.id);
          });

          newRes = newRes.map((c) => {
            if (c === addedCategory) {
              return {
                ...c,
                productlines: [...c.productlines, ...selectedLinesUniq],
              };
            }
            return c;
          });
          // remove category
        } else {
          const removeIndex = newRes.findIndex(
            (x) => x.productcategoryId === addedCategory.productcategoryId
          );
          if (removeIndex > -1) {
            newRes.splice(removeIndex, 1);
          }
        }
        // category is not in state
      } else {
        newRes.unshift({
          ...category,
          child: React.createRef(),
          productlines: selectedLines,
        });
      }
    });

    this.setState({
      productcategoryRes: newRes,
      isDisabled: _.isEqual(newRes, productcategoryResProps),
    });
  };

  /**
   * Summary. Delete product line
   *
   * Description. Delete particuar product line and remove from the array
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}  productcategoryId   id of the main product line
   *
   */
  deleteProductCategory = (productcategoryId) => {
    this.setState((prevState) => ({
      productcategoryRes: prevState.productcategoryRes.filter(
        (item) => item.productcategoryId !== productcategoryId
      ),
    }));
  };

  /**
   *  Get product line list using sub category id
   */
  getCurrentProductLines = (id) => {
    const { subCategoryArr } = this.state;
    return subCategoryArr[id];
  };

  /**
   *  Flag set for Add productcategory - open productcategory dropdown html
   */
  addProductCategory = () => {
    this.setState({
      isAdd: true,
    });
  };

  /**
   * Summary. Rep's ProductCategory save
   *
   * Description. Create/update the Rep's productcategory information using API.
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Object}   reqObj      API req object
   */
  callApi = (reqObj) => {
    this.setState({
      isAPICalled: true,
    });
    axiosApi(
      `/repProfile/createRepProductCategories`,
      'POST',
      reqObj,
      (res) => {
        this.setState({ isAPICalled: false });
        if (res.error) {
          alert(res.message);
        } else {
          const { onEditSuccess } = this.props;
          const results = reqObj.results.filter(
            (c) => c.productlines.length > 0
          );
          onEditSuccess(results, 'back');
        }
      }
    );
  };

  /**
   * Summary. Form submit
   *
   * Description. Validate the form and call the API to save Rep's product line data
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  onButtonClick = () => {
    const { productcategoryRes } = this.state;
    let newArr = [];
    productcategoryRes.forEach((v) => {
      newArr = [
        ...newArr,
        {
          productcategoryId: v.productcategoryId,
          productcategoryName: v.productcategoryName,
          productlines: v.productlines || [],
        },
      ];
    });

    if (newArr.filter((p) => p.productlines.length > 0).length === 0) {
      alert(
        'You must have at least one product line associated with your profile to populate in search results.'
      );
    } else {
      const reqObj = {
        results: newArr,
        id: app.user.id,
      };
      this.callApi(reqObj);
    }
  };

  toggleDesc = () => {
    this.setState((prevState) => ({
      showDesc: !prevState.showDesc,
    }));
  };

  selectProductCategory = (e, category) => {
    e.stopPropagation();

    const { mainCategoryArr, productcategory } = this.state;
    const { productcategoryId } = category;

    if (productcategory) {
      // don't select category while filtering
      return;
    }

    const newMainCategoryArr = mainCategoryArr.map((cat) => {
      if (cat.productcategoryId === productcategoryId) {
        return {
          ...cat,
          isSelected: !cat.isSelected,
        };
      }
      return cat;
    });

    this.setState({
      mainCategoryArr: newMainCategoryArr,
    });
  };

  onChangeCheckbox = (e, category, productLine) => {
    e.stopPropagation();
    const { productcategoryId } = category;
    const {
      mainCategoryArr,
      subCategoryArr,
      productcategoryRes,
      maxCategoryLen,
    } = this.state;

    let newMainCategoryArr = [...mainCategoryArr];
    let newSubCategoryArr = { ...subCategoryArr };
    let newProductcategoryRes = [...productcategoryRes];

    const productLines = this.getCurrentProductLines(productcategoryId);

    newSubCategoryArr = {
      ...newSubCategoryArr,
      [productcategoryId]: productLines.map((p) => {
        if (p.id === productLine.id) {
          return {
            ...p,
            checked: !p.checked,
          };
        }
        return p;
      }),
    };

    const checkedLines = newSubCategoryArr[productcategoryId].filter(
      (p) => p.checked
    );

    if (!category.checked) {
      newMainCategoryArr = newMainCategoryArr.map((cat) => {
        if (cat.productcategoryId === productcategoryId) {
          return {
            ...cat,
            checked: true,
          };
        }
        return cat;
      });
    } else if (category.checked && checkedLines.length === 0) {
      newMainCategoryArr = newMainCategoryArr.map((cat) => {
        if (cat.productcategoryId === productcategoryId) {
          return {
            ...cat,
            checked: false,
          };
        }
        return cat;
      });
    }

    newProductcategoryRes = newProductcategoryRes.map((cat) => {
      if (cat.productcategoryId === productcategoryId) {
        return {
          ...cat,
          productlines: checkedLines,
        };
      }
      return cat;
    });
    if (newProductcategoryRes.length < maxCategoryLen || productLine.checked) {
      this.setState(
        {
          mainCategoryArr: newMainCategoryArr,
          subCategoryArr: newSubCategoryArr,
          productcategoryRes: newProductcategoryRes,
        },
        () => {
          this.addNewProductLines();
        }
      );
    }
  };

  render() {
    const {
      productcategoryRes,
      isAPICalled,
      isAdd,
      mainCategoryArr,
      maxCategoryLen,
      isFocus,
      productcategory,
      isDisabled,
      showDesc,
    } = this.state;
    const { onCancel, profileRes } = this.props;

    return (
      <MDBContainer>
        <div className="whitebg-wrapper my-6">
          <MDBRow>
            <MDBCol lg="12" md="12">
              <div className="edit-wrapper m-auto">
                <MDBRow>
                  <MDBCol lg="8">
                    <ProfileHeading headingtxt="My REPCARD (Back)" />
                    <div className="edit-profile-fields">
                      {productcategoryRes &&
                      productcategoryRes.length < maxCategoryLen ? (
                        ''
                      ) : (
                        <p className="error-message2">
                          You have max category of product line associated with
                          your profile.
                        </p>
                      )}

                      <MDBRow>
                        <MDBCol
                          lg="12"
                          md="12"
                          className="d-flex justify-content-md-end justify-content-lg-end btn-mt-2"
                        >
                          <button
                            type="button"
                            className="float-right fill-orange-btn"
                            onClick={this.onButtonClick}
                            disabled={isAPICalled || isDisabled}
                            data-repcard-test="saveBtn"
                          >
                            {isAPICalled ? (
                              <span className="spinner-border spinner-border-sm" />
                            ) : (
                              ''
                            )}
                            Save
                          </button>
                          <button
                            type="button"
                            className="float-right outline-btn"
                            onClick={onCancel}
                            data-repcard-test="cancel"
                          >
                            Cancel
                          </button>
                        </MDBCol>
                      </MDBRow>
                      <MDBRow>
                        <MDBCol className="mt-2">
                          <span
                            className="badge badge-pill badge-orange ml-2"
                            onClick={this.toggleDesc}
                          >
                            i
                          </span>
                        </MDBCol>
                      </MDBRow>
                      <MDBModal
                        centered
                        isOpen={showDesc}
                        toggle={this.toggleDesc}
                      >
                        <div className="product-desc-pop d-flex flex-column mt-3 ml-3 mr-3">
                          <p>
                            Help healthcare providers connect with you when
                            searching for additional or alternative vendors for
                            a product, by selecting all the product lines that
                            apply or may apply to your products.{' '}
                          </p>
                          <p>
                            Examples of product line searches include generic
                            search terms like “glove” or “balloon” or
                            “instrument”.{' '}
                          </p>
                          <p>
                            Alternatively, to ensure you’ve selected all
                            applicable product lines, you may search a product
                            category, such as “Implantable Devices” or “Surgical
                            Services” to view all the product lines available
                            for selection in that category.
                          </p>
                        </div>
                      </MDBModal>

                      <div className="edit-fields-panel mt-1">
                        <MDBRow>
                          {isAdd ? (
                            <MDBCol lg="12" className="mb-2">
                              <div className="input-field">
                                <RepAutocomplete
                                  inputName="productcategory"
                                  inputClass=""
                                  placeholder=""
                                  onFocus={() => {
                                    this.onFocusAutocomplete();
                                  }}
                                  onBlur={() => {
                                    this.onBlurAutocomplete();
                                  }}
                                  getItemValue={(item) =>
                                    item.productcategoryName
                                  }
                                  shouldItemRender={(state, value) => {
                                    return (
                                      matchStateToTermCustom(
                                        state.productcategoryName,
                                        value
                                      ) ||
                                      this.getCurrentProductLines(
                                        state.productcategoryId
                                      ).find((productLine) =>
                                        matchStateToTermCustom(
                                          productLine.name,
                                          value
                                        )
                                      )
                                    );
                                  }}
                                  sortItems={(a, b, value) =>
                                    sortItemsCustom(
                                      a.productcategoryName,
                                      b.productcategoryName,
                                      value
                                    )
                                  }
                                  renderInput={(props) => [
                                    <input key="1" {...props} />,
                                    <label
                                      className={
                                        isFocus || productcategory
                                          ? 'active'
                                          : ''
                                      }
                                      style={{ pointerEvents: 'none' }}
                                      data-error=""
                                      key="2"
                                    >
                                      Product Line
                                    </label>,
                                  ]}
                                  items={mainCategoryArr}
                                  renderItem={(item) => {
                                    const productLines = this.getCurrentProductLines(
                                      item.productcategoryId
                                    );

                                    return (
                                      <React.Fragment
                                        key={item.productcategoryId}
                                      >
                                        <li>
                                          <span
                                            onClick={(e) => {
                                              this.selectProductCategory(
                                                e,
                                                item
                                              );
                                            }}
                                          >
                                            {item.productcategoryName}
                                          </span>
                                        </li>

                                        {(item.isSelected ||
                                          productcategory) && (
                                          // eslint-disable-next-line jsx-a11y/no-noninteractive-element-interactions
                                          <ul
                                            className="rep-add-productline"
                                            onClick={(e) => e.stopPropagation()}
                                          >
                                            {productLines
                                              .filter((v) => {
                                                return matchStateToTermCustom(
                                                  v.name,
                                                  productcategory || ''
                                                );
                                              })
                                              .map((v) => {
                                                return (
                                                  <li
                                                    key={v.id}
                                                    className="rep-product-select"
                                                  >
                                                    <MDBInput
                                                      label={v.name}
                                                      filled
                                                      checked={v.checked}
                                                      type="checkbox"
                                                      id={`${v.id}id`}
                                                      onChange={(e) => {
                                                        this.onChangeCheckbox(
                                                          e,
                                                          item,
                                                          v
                                                        );
                                                      }}
                                                    />
                                                    {v.info && (
                                                      <div className="info_icon">
                                                        <span className="spciality_popover">
                                                          {v.info}
                                                        </span>
                                                      </div>
                                                    )}
                                                  </li>
                                                );
                                              })}
                                          </ul>
                                        )}
                                      </React.Fragment>
                                    );
                                  }}
                                  value=""
                                  onChange={(event, value) => {
                                    this.setProductCategoryValue(value);
                                  }}
                                  autoHighlight={false}
                                />
                              </div>
                            </MDBCol>
                          ) : (
                            ''
                          )}
                          {productcategoryRes
                            .sort((a, b) => {
                              if (
                                a.productcategoryName < b.productcategoryName
                              ) {
                                return -1;
                              }
                              if (
                                a.productcategoryName > b.productcategoryName
                              ) {
                                return 1;
                              }
                              return 0;
                            })
                            .map((v) => {
                              return (
                                <MDBCol
                                  lg="12"
                                  className="mb-2"
                                  key={v.productcategoryId}
                                >
                                  {/* <DeleteModalPopup
                                  item={v}
                                  deleteProductCategory={this.deleteProductCategory}
                                /> */}
                                  {v.productlines && v.productlines.length > 0 && (
                                    <RepProductsRow
                                      productcategoryName={
                                        v.productcategoryName
                                      }
                                      list={v.productlines}
                                      masterList={this.getCurrentProductLines(
                                        v.productcategoryId
                                      )}
                                      updateArr={(arr) => {
                                        this.setState({ isDisabled: false });
                                        this.updateArr(
                                          arr,
                                          v.productcategoryId
                                        );
                                      }}
                                      ref={v.child}
                                    />
                                  )}
                                </MDBCol>
                              );
                            })}
                        </MDBRow>
                      </div>
                    </div>
                  </MDBCol>
                  <MDBCol lg="4">
                    <ProfileHeading headingtxt="My REPCARD" />
                    <RepProductCategory
                      flipicondisable
                      isNameRemove
                      productcategoryRes={productcategoryRes}
                      profileRes={profileRes}
                      boxclass="boxpanel"
                    />
                  </MDBCol>
                </MDBRow>
              </div>
            </MDBCol>
          </MDBRow>
        </div>
      </MDBContainer>
    );
  }
}

export default RepProfileEditBack;
