/**
 *
 * Description. Photo upload
 *
 * @link   URL
 * @file   Display, change and remove the Profile photo
 * @since  1.0.0
 */
import React, { Component } from 'react';
import { MDBModal, MDBModalHeader } from 'mdbreact';
import app from '../../helpers/appGlobal';
import CropPhoto from './CropPhoto.jsx';

class PhotoUpload extends Component {
  constructor(props) {
    super(props);
    const { photoUrl } = this.props;
    this.state = {
      modal: false,
      photoUrl,
    };
  }

  componentDidMount() {
    if (app.photoEdit) {
      // Open the profile pic upload modal
      app.photoEdit = false;
      const { isBasicPlan } = this.props;
      if (!isBasicPlan) {
        this.toggle();
      }
    }
  }

  /**
   * Summary. Photo upload
   *
   * Description. Set the photo url from file object and close the modal
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {file}   file              file paramaeter of profile pic
   * @param {string} croppedImageUrl   image url
   *
   */
  uploadPhoto = (file, croppedImageUrl) => {
    // const objectURL = URL.createObjectURL(file);
    const { onPhotoChange } = this.props;
    this.setState(
      {
        isAPICalled: true,
      },
      () => {
        onPhotoChange(file, croppedImageUrl, () => {
          this.setState({
            photoUrl: croppedImageUrl,
            modal: false,
            isAPICalled: false,
          });
        });
      }
    );
  };

  /**
   *  Toggle the modal popup
   */
  toggle = () => {
    this.setState((prevState) => ({
      modal: !prevState.modal,
    }));
  };

  /**
   *  Remove the photo on remove click
   */
  removePhoto = () => {
    alert('You are not allowed to remove profile pic');
    // const { onPhotoChange } = this.props;
    // onPhotoChange('', '', () => {
    //   this.setState({
    //     photoUrl: '',
    //   });
    // });
  };

  render() {
    const { modal, photoUrl, isAPICalled } = this.state;
    const { isBasicPlan, upgradeClick } = this.props;
    return (
      <div className="prfl-pic-center">
        <div className="edit-profile-pic">
          <div className={`${isBasicPlan ? 'hovertooltip' : ''}`}>
            {!isBasicPlan ? (
              <button
                type="button"
                className="edit_btn_transparent"
                onClick={this.toggle}
                data-repcard-test="photoedit"
              >
                Edit
              </button>
            ) : (
              ''
            )}
            <MDBModal
              isOpen={modal}
              toggle={this.toggle}
              className="edit-photo-popup"
            >
              <div className="heading_text">Add or edit your photo </div>
              <MDBModalHeader toggle={this.toggle}>
                <div
                  role="presentation"
                  onClick={this.toggle}
                  className="closepopup close"
                >
                  X close
                </div>
              </MDBModalHeader>
              <CropPhoto
                photoUrl={photoUrl}
                uploadPhoto={this.uploadPhoto}
                isAPICalled={isAPICalled}
              />
            </MDBModal>
            {photoUrl ? (
              <div
                className="edit-avatar-photo"
                style={{ backgroundImage: `url(${photoUrl})` }}
              />
            ) : (
              <div className="edit-avatar-photo" />
            )}
            {photoUrl ? (
              <button
                type="button"
                className="remove_photo"
                onClick={this.removePhoto}
                data-repcard-test="removephoto"
              >
                Remove Photo
              </button>
            ) : (
              ''
            )}
            {isBasicPlan ? (
              <div className="input-tooltip">
                <span
                  className="cursor"
                  onClick={upgradeClick}
                  role="presentation"
                >
                  Upgrade to Premium
                </span>{' '}
                to add your Profile pic to your REPCARD.
                <span className="triangle" />
              </div>
            ) : (
              ''
            )}
          </div>
        </div>
      </div>
    );
  }
}

export default PhotoUpload;
