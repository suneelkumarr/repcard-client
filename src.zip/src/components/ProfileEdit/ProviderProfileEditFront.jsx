/**
 *
 * Description. Provider My Account Edit
 *
 * @link   URL
 * @file   Edit All the Provider's My Account details such as firstName, lastname,
           phone, profile pic, hospital
 * @since  1.0.0
 */
import React, { Component } from 'react';
import { MDBRow, MDBCol, MDBContainer, MDBInput } from 'mdbreact';
import RepAutocomplete from '../../utils/RepAutocomplete.jsx';
import PhotoUpload from './PhotoUpload.jsx';
import { matchStateToTermCustom } from '../../utils/autoCompleteUtils';
import ProfileHeading from '../Common/ProfileHeading';
import RepNumberFormat from '../../utils/RepNumberFormat.jsx';
import validateObj from '../../validations/repprofile/repfront.js';
import { axiosApi } from '../../apis/axiosApiCall';
import fileUpload from '../../apis/fileUpload';
import app from '../../helpers/appGlobal';
import { getBasicPlan } from '../../utils/getPlanInfo';
import './ProfileEdit.scss';

class ProviderProfileEditFront extends Component {
  constructor(props) {
    super(props);
    const { profileRes } = this.props;
    this.state = {
      profileRes: {
        ...profileRes,
        hospital: {
          value: profileRes.hospital,
          id: profileRes.hospitalId,
        },
        title: {
          value: profileRes.title.title,
          id: profileRes.title.id,
        },
        specialty: {
          value: profileRes.providersspecialty.name,
          id: profileRes.providersspecialty.id,
        },
      },
      errorObj: {},
      inputClass: {},
      fileInput: '',
    };
  }

  componentDidMount() {}

  /**
   * Summary. Photo change event
   *
   * Description. Set the photo url and file object to state for an api call
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {file}   file       file paramaeter of profile pic
   * @param {string} photoUrl   profile pic url
   *
   */
  onPhotoChange = (file, photoUrl) => {
    this.setState({
      fileInput: file,
    });
    this.setValue('photoUrl', photoUrl);
  };

  /**
   * Summary. Input phone number change event
   *
   * Description. update phone number value to state
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   values         number object contains formatted value
   * @param {string}   name           name of the input
   * @param {string}   apiValue       value which needs to pass in API
   *
   */
  onDateChange = (values, name, apiValue) => {
    this.setValue(name, apiValue);
  };

  /**
   * Summary. OnChange event
   *
   * Description. Input Change method for all input
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   e           Input element event object
   *
   */
  onChange = (e) => {
    const { name, value } = e.target;
    this.setValue(name, value);
  };

  /**
   * Summary. OnBlur event
   *
   * Description. Blur method for all input
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   e           Input element event object
   *
   */
  onBlur = (e) => {
    const { name } = e.target;
    const { profileRes } = this.state;
    this.validateInput(name, profileRes[name]);
  };

  /**
   * Summary. Set Autocomplete data
   *
   * Description. Set company/hospital autocomplete data values to state
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   name           name of the input
   * @param {string}   value          autocomplete value
   * @param {string}   id             id of the company/hospital
   *
   */
  setProfileValue = (name, value, id) => {
    this.setState(
      (prevState) => ({
        profileRes: {
          ...prevState.profileRes,
          [name]: {
            value,
            id,
          },
        },
      }),
      () => {
        if (id) {
          this.validateInput(name, value, id);
        }
      }
    );
  };

  /*
   *
   * Set isFocus flag to true on focus of autocomplete input
   */
  onFocusAutocomplete = (fieldName) => {
    this.setState({
      [`isFocus${fieldName}`]: true,
    });
  };

  /*
   *
   * Set isFocus flag to false on blur event of autocomplete input if no value is filled
   */
  onBlurAutocomplete = (fieldName) => {
    const { profileRes } = this.state;
    const fieldObj = profileRes[fieldName];
    this.validateInput(fieldName, fieldObj.value, fieldObj.id);
    if (!fieldObj.value) {
      this.setState({
        [`isFocus${fieldName}`]: false,
      });
    }
  };

  /**
   * Summary. Set input values
   *
   * Description. Update All the input values to state
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   name           name of the input
   * @param {string}   value          value of the input
   *
   */
  setValue = (name, value) => {
    this.setState((prevState) => ({
      profileRes: {
        ...prevState.profileRes,
        [name]: value,
      },
    }));
  };

  /**
   * Summary. Validate Input
   *
   * Description. Sets the error to errorObj and className to inputClass object
   *              if any validation error found.
   *              errorObj is used for displaying the errors for particular input
   *              inputClas is used for Adding error classNames for particular input
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   name           Input element name
   * @param {string}   value          Input element value
   * @param {string}   value1         additional value
   *
   * @return {String} Error if any else null
   */
  validateInput(name, value, value1) {
    if (validateObj[name]) {
      let error = '';
      let className = 'error-border';
      error = validateObj[name](value, value1);
      if (!error) {
        className = '';
      }

      this.setState((prevState) => ({
        errorObj: {
          ...prevState.errorObj,
          [name]: error,
        },
        inputClass: {
          ...prevState.inputClass,
          [name]: className,
        },
      }));

      return error;
    }
    return '';
  }

  /**
   * Summary. Form validation
   *
   * Description. Validate form on submit click
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @return {boolean} false if not valid else true
   */
  validate() {
    const { profileRes } = this.state;
    const {
      firstName,
      lastName,
      phone,
      title,
      hospital,
      specialty,
    } = profileRes;
    let isValid = true;
    let error;

    error = this.validateInput('firstName', firstName);
    if (error) {
      isValid = false;
    }

    error = this.validateInput('lastName', lastName);
    if (error) {
      isValid = false;
    }

    error = this.validateInput('phone', phone);
    if (error) {
      isValid = false;
    }

    error = this.validateInput('specialty', specialty.value, specialty.id);
    if (error) {
      isValid = false;
    }

    error = this.validateInput('title', title.value, title.id);
    if (error) {
      isValid = false;
    }

    error = this.validateInput('hospital', hospital.value, hospital.id);
    if (error) {
      isValid = false;
    }

    return isValid;
  }

  /**
   * Summary. Provider create/update
   *
   * Description. Create/update the provider my account information using API.
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Object}   reqObj      API req object
   */
  callApi = (reqObj) => {
    axiosApi(`/providerProfile/createProvider`, 'POST', reqObj, (res) => {
      this.setState({ isAPICalled: false });
      if (res.error) {
        alert(res.message);
      } else {
        const { onEditSuccess } = this.props;
        onEditSuccess(reqObj, 'front');
      }
    });
  };

  /**
   * Summary. Form submit
   *
   * Description. Validate the form and call the API to save provider data
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  onButtonClick = () => {
    const isValid = this.validate();
    if (isValid) {
      this.setState({ isAPICalled: true });
      const { profileRes } = this.state;
      const {
        firstName,
        lastName,
        phone,
        hospital,
        title,
        photoUrl,
        specialty,
      } = profileRes;
      const { planDetails } = this.props;
      const isBasicPlan = getBasicPlan(planDetails);

      const reqObj = {
        id: app.user.id,
        firstName,
        lastName,
        hospital: hospital.value,
        hospitalId: hospital.id,
        title: {
          title: title.value,
          id: title.id,
        },
        titleId: title.id,
        photoUrl,
        phone,
        providersspecialty: {
          name: specialty.value,
          id: specialty.id,
        },
        specialtyId: specialty.id,
      };

      // if (!isBasicPlan) {
      //   reqObj.photoUrl = photoUrl;
      //   reqObj.phone = phone;
      // }

      const { fileInput } = this.state;
      if (fileInput && !isBasicPlan) {
        fileUpload(
          fileInput,
          '',
          '',
          (res) => {
            if (res.Location) {
              this.setValue('photoUrl', res.Location);
              this.setState({
                fileInput: '',
              });
              // query string is used for remove image caching
              reqObj.photoUrl = `${res.Location}?dummy=${new Date().getTime()}`;
              this.callApi(reqObj);
            }
          },
          { userId: app.user.id }
        );
      } else {
        this.callApi(reqObj);
      }
    }
  };

  render() {
    const {
      profileRes,
      errorObj,
      inputClass,
      isAPICalled,
      isFocushospital,
      isFocustitle,
    } = this.state;
    const { onCancel, planDetails, upgradeClick } = this.props;
    const { title, hospital, specialty } = profileRes;
    const isBasicPlan = getBasicPlan(planDetails);

    return (
      <MDBContainer>
        <div className="whitebg-wrapper my-6">
          <MDBRow>
            <MDBCol lg="12" md="12">
              <div className="edit-wrapper m-auto">
                <MDBRow>
                  <MDBCol lg="8">
                    <ProfileHeading headingtxt="My Profile Information" />
                    <div className="edit-profile-fields">
                      <PhotoUpload
                        photoUrl={isBasicPlan ? '' : profileRes.photoUrl}
                        onPhotoChange={this.onPhotoChange}
                        isBasicPlan={isBasicPlan}
                        upgradeClick={upgradeClick}
                      />
                      <div className="edit-fields-panel mt-4">
                        <MDBRow>
                          <MDBCol lg="6" md="6">
                            <div
                              className={`input-field ${inputClass.firstName}`}
                            >
                              <MDBInput
                                type="text"
                                value={profileRes.firstName}
                                name="firstName"
                                onChange={this.onChange}
                                onBlur={this.onBlur}
                                label="First Name"
                              />
                              {errorObj.firstName ? (
                                <p className="error-message">
                                  <span /> {errorObj.firstName}
                                </p>
                              ) : (
                                ''
                              )}
                            </div>
                          </MDBCol>
                          <MDBCol lg="6" md="6">
                            <div
                              className={`input-field ${inputClass.lastName}`}
                            >
                              <MDBInput
                                type="text"
                                value={profileRes.lastName}
                                name="lastName"
                                onChange={this.onChange}
                                onBlur={this.onBlur}
                                label="Last Name"
                              />
                              {errorObj.lastName ? (
                                <p className="error-message">
                                  <span /> {errorObj.lastName}
                                </p>
                              ) : (
                                ''
                              )}
                            </div>
                          </MDBCol>
                          <MDBCol lg="6" md="6">
                            <div
                              className={`${isBasicPlan ? 'hovertooltip' : ''}`}
                            >
                              <div
                                className={`input-field fixed-field ${inputClass.phone}`}
                              >
                                <label className="field_label">
                                  Mobile Number
                                </label>
                                <RepNumberFormat
                                  onChange={this.onDateChange}
                                  onBlur={this.onBlur}
                                  value={profileRes.phone}
                                  className="form-control"
                                  name="phone"
                                  format="XXX.XXX.XXXX"
                                />
                                {errorObj.phone ? (
                                  <p className="error-message">
                                    <span /> {errorObj.phone}
                                  </p>
                                ) : (
                                  ''
                                )}
                              </div>
                            </div>
                          </MDBCol>
                          <MDBCol lg="6" md="6">
                            <div
                              className={`signup_form_panel input-field ${inputClass.specialty}`}
                            >
                              <RepAutocomplete
                                inputName="specialty"
                                inputClass={inputClass.specialty}
                                placeholder=""
                                onFocus={() => {
                                  this.onFocusAutocomplete('specialty');
                                }}
                                onBlur={() => {
                                  this.onBlurAutocomplete('specialty');
                                }}
                                getItemValue={(item) => item.name}
                                shouldItemRender={(state, value) =>
                                  matchStateToTermCustom(state.name, value)
                                }
                                sortItems={() => 1}
                                renderInput={(props) => [
                                  <input key="1" {...props} />,
                                  <label
                                    className={specialty.value ? 'active' : ''}
                                    style={{ pointerEvents: 'none' }}
                                    key="2"
                                  >
                                    Specialty
                                  </label>,
                                ]}
                                apiurl="/providersSpecialties"
                                renderItem={(item, isHighlighted) => {
                                  return (
                                    <li
                                      style={{
                                        background: isHighlighted
                                          ? '#eeeeee'
                                          : '',
                                      }}
                                      key={item.id}
                                    >
                                      {item.name}
                                    </li>
                                  );
                                }}
                                value={specialty.value}
                                onChange={(event, value) => {
                                  this.setProfileValue('specialty', value, '');
                                }}
                                minChar={0}
                                onSelect={(value, item) => {
                                  this.setProfileValue(
                                    'specialty',
                                    value,
                                    item.id
                                  );
                                }}
                              />
                              {errorObj.specialty ? (
                                <span className="error-message">
                                  {errorObj.specialty}
                                </span>
                              ) : (
                                ''
                              )}
                            </div>
                          </MDBCol>
                          <MDBCol lg="12">
                            <div
                              className={`input-field ${inputClass.hospital}`}
                            >
                              <RepAutocomplete
                                inputName="hospital"
                                inputClass={inputClass.hospital}
                                placeholder=""
                                onFocus={() => {
                                  this.onFocusAutocomplete('hospital');
                                }}
                                onBlur={() => {
                                  this.onBlurAutocomplete('hospital');
                                }}
                                getItemValue={(item) => item.hospital}
                                shouldItemRender={(state, value) =>
                                  matchStateToTermCustom(state.hospital, value)
                                }
                                sortItems={() => 1}
                                renderInput={(props) => [
                                  <input key="1" {...props} />,
                                  <label
                                    className={
                                      isFocushospital || profileRes.hospital
                                        ? 'active'
                                        : ''
                                    }
                                    style={{ pointerEvents: 'none' }}
                                    key="2"
                                  >
                                    Medical Facility
                                  </label>,
                                ]}
                                apiurl="/hospitalsbyname"
                                renderItem={(item, isHighlighted) => {
                                  return (
                                    <li
                                      style={{
                                        background: isHighlighted
                                          ? '#eeeeee'
                                          : '',
                                      }}
                                      key={item.id}
                                    >
                                      {item.hospital}
                                    </li>
                                  );
                                }}
                                value={hospital.value}
                                onChange={(event, value) => {
                                  this.setProfileValue('hospital', value, '');
                                }}
                                minChar={0}
                                onSelect={(value, item) => {
                                  this.setProfileValue(
                                    'hospital',
                                    value,
                                    item.id
                                  );
                                }}
                              />
                              {errorObj.hospital ? (
                                <p className="error-message">
                                  <span /> {errorObj.hospital}
                                </p>
                              ) : (
                                ''
                              )}
                            </div>
                          </MDBCol>
                          <MDBCol lg="12">
                            <div className={`input-field ${inputClass.title}`}>
                              <RepAutocomplete
                                inputName="title"
                                inputClass={inputClass.title}
                                placeholder=""
                                onFocus={() => {
                                  this.onFocusAutocomplete('title');
                                }}
                                onBlur={() => {
                                  this.onBlurAutocomplete('title');
                                }}
                                getItemValue={(item) => item.title}
                                shouldItemRender={(state, value) =>
                                  matchStateToTermCustom(state.title, value)
                                }
                                sortItems={() => 1}
                                renderInput={(props) => [
                                  <input key="1" {...props} />,
                                  <label
                                    className={
                                      isFocustitle || title.value
                                        ? 'active'
                                        : ''
                                    }
                                    style={{ pointerEvents: 'none' }}
                                    key="2"
                                  >
                                    Title
                                  </label>,
                                ]}
                                apiurl="/titles/getAllProviderTitles"
                                renderItem={(item, isHighlighted) => {
                                  return (
                                    <li
                                      style={{
                                        background: isHighlighted
                                          ? '#eeeeee'
                                          : '',
                                      }}
                                      key={item.id}
                                    >
                                      {item.title}
                                    </li>
                                  );
                                }}
                                value={title.value}
                                onChange={(event, value) => {
                                  this.setProfileValue('title', value, '');
                                }}
                                minChar={0}
                                onSelect={(value, item) => {
                                  this.setProfileValue('title', value, item.id);
                                }}
                              />
                              {errorObj.title ? (
                                <span className="error-message">
                                  {errorObj.title}
                                </span>
                              ) : (
                                ''
                              )}
                            </div>
                          </MDBCol>
                          <MDBCol className="mt-4">
                            <button
                              type="button"
                              className="float-left fill-orange-btn"
                              onClick={this.onButtonClick}
                              disabled={isAPICalled}
                              data-repcard-test="saveBtn"
                            >
                              {isAPICalled ? (
                                <span className="spinner-border spinner-border-sm" />
                              ) : (
                                ''
                              )}
                              Save
                            </button>
                            <button
                              type="button"
                              className="float-left outline-btn"
                              onClick={onCancel}
                              data-repcard-test="cancelBtn"
                            >
                              Cancel
                            </button>
                          </MDBCol>
                        </MDBRow>
                      </div>
                    </div>
                  </MDBCol>
                </MDBRow>
              </div>
            </MDBCol>
          </MDBRow>
        </div>
      </MDBContainer>
    );
  }
}

export default ProviderProfileEditFront;
