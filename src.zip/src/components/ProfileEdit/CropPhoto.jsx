/**
 *
 * Description. Crop photo
 *
 * @link   URL
 * @file   Crop the profile pic using react-image-crop component
 * @since  1.0.0
 */
import React, { Component } from 'react';
import ReactCrop from 'react-image-crop';
import { MDBModalBody, MDBRow, MDBCol } from 'mdbreact';
import 'react-image-crop/dist/ReactCrop.css';
import dataURLtoFile from '../../utils/dataURLtoFile';
import { axiosApi } from '../../apis/axiosApiCall';
import fileRead from '../../utils/fileRead';

class CropPhoto extends Component {
  constructor(props) {
    super(props);
    this.state = {
      apiErrorMessage: '',
      src: '',
      crop: {
        // unit: 'px',
        // width: 500,
        // height: 500,
        unit: '%',
        width: 100,
        aspect: 1 / 1,
      },
    };
  }

  /**
   *  Set default crop state on new file select
   */
  setDefaultURLState = () => {
    this.setState({
      src: '',
      crop: {
        unit: '%',
        width: 100,
        aspect: 1 / 1,
      },
    });
  };

  /**
   *  Set existing photo url to state
   */
  setPhotoURL = (url) => {
    this.setState({
      src: url,
    });
  };

  /**
   *  Api call for getting image data as bas64 url
   */
  getImageData = (photoUrl) => {
    const reqObj = {
      imageURL: photoUrl,
    };
    axiosApi('/uploadDocs/getImageAsBase64', 'POST', reqObj, (res) => {
      if (!res.error) {
        this.setPhotoURL(res.url);
      }
    });
  };

  /**
   *  Api call for getting image data as bas64 url from client fetch
   */
  getImageDataClient = (photoUrl) => {
    fetch(photoUrl, { cache: 'no-cache' })
      .then((res) => res.blob())
      .then((blob) => {
        const blobURL = URL.createObjectURL(blob);
        this.setPhotoURL(blobURL);
      })
      .catch((err) => {
        console.log(err);
        this.getImageData(photoUrl);
      });
  };

  componentDidMount() {
    const { photoUrl } = this.props;
    if (photoUrl) {
      if (photoUrl.search('blob:') === -1) {
        this.getImageDataClient(photoUrl);
      } else {
        this.setPhotoURL(photoUrl);
      }
    }
  }

  // If you setState the crop in here you should return false.
  onImageLoaded = (image) => {
    this.imageRef = image;
  };

  /*
   * Crop complete handler
   */
  onCropComplete = (crop) => {
    this.makeClientCrop(crop);
  };

  /*
   * Crop change handler
   */
  onCropChange = (crop) => {
    // You could also use percentCrop:
    // this.setState({ crop: percentCrop });
    // console.log(percentCrop);
    this.setState({ crop });
  };

  /**
   *  Get cropped image url and set to state
   */
  makeClientCrop = async (crop) => {
    if (this.imageRef && crop.width && crop.height) {
      const croppedImageUrl = await this.getCroppedImg(
        this.imageRef,
        crop,
        'newFile.jpg'
      );
      this.setState({ croppedImageUrl });
    }
  };

  setBlobParams = (blob, fileName, cb) => {
    if (!blob) {
      // reject(new Error('Canvas is empty'));
      console.error('Canvas is empty');
      return;
    }
    blob.name = fileName; // eslint-disable-line
    // window.URL.revokeObjectURL(this.fileUrl);
    // this.fileUrl = window.URL.createObjectURL(blob);
    const fileUrl = window.URL.createObjectURL(blob);
    this.setState({
      blob,
    });
    cb(fileUrl);
  };

  /**
   *  Get cropped image url using canvas
   */
  getCroppedImg(image, crop, fileName) {
    const canvas = document.createElement('canvas');
    const scaleX = image.naturalWidth / image.width;
    const scaleY = image.naturalHeight / image.height;
    canvas.width = crop.width;
    canvas.height = crop.height;
    const ctx = canvas.getContext('2d');

    ctx.drawImage(
      image,
      crop.x * scaleX,
      crop.y * scaleY,
      crop.width * scaleX,
      crop.height * scaleY,
      0,
      0,
      crop.width,
      crop.height
    );

    return new Promise((resolve) => {
      const type = 'image/jpeg';
      if (!HTMLCanvasElement.prototype.toBlob) {
        const binStr = atob(canvas.toDataURL(type).split(',')[1]);
        const len = binStr.length;
        const arr = new Uint8Array(len);

        for (let i = 0; i < len; i += 1) {
          arr[i] = binStr.charCodeAt(i);
        }
        const blob = new Blob([arr], { type });
        this.setBlobParams(blob, fileName, (url) => {
          resolve(url);
        });
      } else {
        canvas.toBlob((blob) => {
          this.setBlobParams(blob, fileName, (url) => {
            resolve(url);
          });
        }, type);
      }
    });
  }

  /**
   *  Returns file object of photo url for API save
   */
  getFileObj = (cb) => {
    const { blob } = this.state;
    /*
    const fileObj = new File([blob], 'cropped.jpg', {
      lastModifiedDate: new Date(),
      lastModified: new Date().getTime(),
      type: blob.type
    });
    cb(fileObj);
    */
    fileRead(blob, (result) => {
      const fileObj = dataURLtoFile(result, 'cropped.jpg');
      cb(fileObj);
    });
  };

  /**
   *  Save btn click handler
   */
  onSaveClick = () => {
    const { croppedImageUrl } = this.state;
    this.getFileObj((file) => {
      const { uploadPhoto } = this.props;
      uploadPhoto(file, croppedImageUrl);
    });
  };

  /**
   *  File upload change handler
   */
  uploadPhoto = (file) => {
    fileRead(file, (result) => {
      this.setState({ src: result });
    });
  };

  /**
   * Summary. Image upload
   *
   * Description. Check and validate the file input
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}  e   event object
   *
   */
  uploadImage = (e) => {
    e.preventDefault();
    this.setState({
      apiErrorMessage: '',
    });

    const { files } = e.target;
    if (files[0]) {
      const fileType = files[0].type;
      const fileSize = files[0].size;
      const sizeLimit = 1024 * 1024 * 5; // 5MB limit
      const allowedFileType = ['image/png', 'image/jpeg', 'image/jpg'];
      if (allowedFileType.indexOf(fileType) !== -1) {
        if (fileSize < sizeLimit) {
          this.setDefaultURLState();
          this.uploadPhoto(files[0]);
        } else {
          this.setState({
            apiErrorMessage: 'Upto 5MB size image is supported',
          });
        }
      } else {
        this.setState({
          apiErrorMessage: 'Only png, jpg and jpeg images are allowed',
        });
      }
    }
  };

  render() {
    const { crop, src, apiErrorMessage } = this.state;
    const { isAPICalled } = this.props;

    return (
      <>
        <MDBModalBody className="text-center">
          {src ? (
            <div className="App">
              <ReactCrop
                src={src}
                crop={crop}
                ruleOfThirds
                onImageLoaded={this.onImageLoaded}
                onComplete={this.onCropComplete}
                onChange={this.onCropChange}
              />
            </div>
          ) : (
            <div className="edit-avatar-photo" />
          )}
          <div className="text-center my-3 photo-copy">
            Adding a photo is optional. If you choose to add it, your profile
            photo is used as the icon for your account. For best results, please
            upload your profile photo in the JPEG or PNG format. Maximum file
            size is 5 MB.
          </div>
        </MDBModalBody>

        <MDBRow className="align-items-center">
          <MDBCol size="12" lg="8" md="9" className="mt-3 p-0">
            <div className="input-group photo-upload">
              <div className="input-group-prepend">
                <span className="input-group-text" id="inputGroupFileAddon01">
                  <input
                    type="file"
                    className="custom-file-input"
                    id="inputGroupFile01"
                    aria-describedby="inputGroupFileAddon01"
                    accept=".png, .jpeg, .jpg"
                    onChange={this.uploadImage}
                    ref={(ref) => {
                      this.uploadInput = ref;
                    }}
                  />
                  <label
                    className="custom-file-label"
                    htmlFor="inputGroupFile01"
                  >
                    Choose file
                  </label>
                </span>
              </div>
            </div>
          </MDBCol>
          <MDBCol size="12" lg="4" md="3" className="text-center mt-3 p-0">
            <button
              type="button"
              className="fill-orange-btn"
              onClick={this.onSaveClick}
              disabled={!src || isAPICalled}
              data-repcard-test="save"
            >
              {isAPICalled ? (
                <span className="spinner-border spinner-border-sm" />
              ) : (
                'Save'
              )}
            </button>
          </MDBCol>
        </MDBRow>
        {apiErrorMessage ? (
          <p className="error-message1 text-center my-2">{apiErrorMessage}</p>
        ) : (
          ''
        )}
      </>
    );
  }
}

export default CropPhoto;
