/**
 *
 * Description. Delete ProductCategory
 *
 * @link   URL
 * @file   Delete Rep's productcategory by confirming user using modal popup
 * @since  1.0.0
 */
import React, { Component } from 'react';
import { MDBModal, MDBModalBody } from 'mdbreact';

class DeleteModalPopup extends Component {
  constructor(props) {
    super(props);
    this.state = {
      modal: false,
    };
  }

  /**
   * Toggle productcategory modal
   */
  toggle = () => {
    this.setState((prevState) => ({
      modal: !prevState.modal,
    }));
  };

  render() {
    const { modal } = this.state;
    const { item, deleteProductCategory } = this.props;
    const { productcategoryName, productcategoryId } = item;
    return (
      <div className="input-field fixed-field">
        <label className="field_label">Product Category</label>
        <div className="form-control">{productcategoryName}</div>
        <div
          className="remove-productcategory"
          onClick={this.toggle}
          role="presentation"
          data-repcard-test="modal"
        >
          <div className="info-tooltip">Click to delete</div>
        </div>
        <MDBModal
          isOpen={modal}
          toggle={this.toggle}
          className="edit-photo-popup"
        >
          <div className="heading_text">Confim to Delete</div>
          <div
            role="presentation"
            onClick={this.toggle}
            className="closepopup close"
          >
            X
          </div>

          <MDBModalBody className="text-center">
            <div className="text-center my-3 photo-copy">
              Are you sure you want to delete ‘{productcategoryName}’ Product
              Category
            </div>
            <div className="d-inline-block">
              <button
                type="button"
                className="outline-btn"
                data-repcard-test="delete"
                onClick={() => {
                  this.toggle();
                  deleteProductCategory(productcategoryId);
                }}
              >
                Confirm
              </button>
            </div>
          </MDBModalBody>
        </MDBModal>
      </div>
    );
  }
}

export default DeleteModalPopup;
