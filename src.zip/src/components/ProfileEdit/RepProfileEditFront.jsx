/**
 *
 * Description. Rep  My Account Edit
 *
 * @link   URL
 * @file   Edit All the Rep's My Account details such as firstName, lastname,
           phone, profile pic, company and vacation details
 * @since  1.0.0
 */
import React, { Component, lazy, Suspense } from 'react';
import {
  MDBRow,
  MDBCol,
  MDBContainer,
  MDBInput,
  MDBModal,
  MDBInputGroup,
} from 'mdbreact';
import * as _ from 'lodash';

import PhotoUpload from './PhotoUpload.jsx';
import RepCard from '../Common/RepCard/RepCard';
import RepAutocomplete from '../../utils/RepAutocomplete.jsx';
import ProfileHeading from '../Common/ProfileHeading';
import RepNumberFormat from '../../utils/RepNumberFormat.jsx';
import AddBackupRep from '../AddBackupRep/AddBackupRep.jsx';
import { matchStateToTermCustom } from '../../utils/autoCompleteUtils';
import { getBasicPlan } from '../../utils/getPlanInfo';
import validateObj from '../../validations/repprofile/repfront.js';
import { axiosApi } from '../../apis/axiosApiCall';
import fileUpload from '../../apis/fileUpload';
import app from '../../helpers/appGlobal';
import './ProfileEdit.scss';

const Loading = () => <div>Loading...</div>;
const DateRangePicker = lazy(() => import('./DateRangePicker'));

class RepProfileEditFront extends Component {
  constructor(props) {
    super(props);
    const { profileRes } = this.props;
    const { fromDate, toDate } = profileRes;
    const newProfileRes = !(fromDate && toDate)
      ? this.getNewProfileRes(profileRes)
      : profileRes;

    this.state = {
      profileRes: {
        ...newProfileRes,
        title: {
          value:
            profileRes.title && profileRes.title.value
              ? profileRes.title.value
              : (profileRes.title || {}).title || '',
          id: _.get(profileRes, 'title.id', ''),
        },
        company: {
          value: profileRes.companyName
            ? profileRes.companyName
            : (profileRes.companyName || {}).companyName || '',

          id: _.get(profileRes, 'companyId', ''),
        },
      },
      errorObj: {},
      inputClass: {},
      switch1: fromDate && toDate,
      fileInput: '',
      modal: false,
      keyVal: 1,
      isProfileurlEdit: false,
      isCopySuccess: false,
    };
  }

  componentDidMount() {}

  // Toggle backrep modal popup
  toggle = () => {
    this.setState((prevState) => ({
      modal: !prevState.modal,
    }));
  };

  /**
   * Summary. Photo change event
   *
   * Description. Set the photo url and file object to state for an api call
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {file}   file       file paramaeter of profile pic
   * @param {string} photoUrl   profile pic url
   *
   */
  onPhotoChange = (file, photoUrl, cb) => {
    const { planDetails } = this.props;
    const isBasicPlan = getBasicPlan(planDetails);
    this.setState(
      {
        fileInput: file,
        isAPICalled2: true,
      },
      () => {
        const { fileInput } = this.state;
        if (fileInput && !isBasicPlan) {
          fileUpload(
            fileInput,
            '',
            '',
            (res) => {
              if (res.Location) {
                // this.setValue('photoUrl', res.Location);
                this.updateImage(res.Location, cb);
              }
            },
            { userId: app.user.id }
          );
        } else {
          this.updateImage(photoUrl, cb);
        }
      }
    );

    // this.setValue('photoUrl', photoUrl);
  };

  updateImage(photoUrl, cb) {
    this.setState({
      fileInput: '',
    });
    axiosApi(
      `/repProfile/postPhotoUrl`,
      'POST',
      {
        repId: app.user.id,
        photoUrl: photoUrl ? `${photoUrl}?dummy=${new Date().getTime()}` : '',
      },
      (res1) => {
        if (res1.error) {
          alert(res1.message);
        } else {
          this.setState({ isAPICalled2: false });
          const { onEditSuccess } = this.props;
          onEditSuccess(res1.data, 'front', false);
          this.setValue('photoUrl', photoUrl);
          cb();
        }
      }
    );
  }

  /**
   *  Remove old vacation data if user is available
   */
  getNewProfileRes = (newProfileRes) => {
    const profileRes = { ...newProfileRes };
    profileRes.fromDate = null;
    profileRes.toDate = null;
    profileRes.backupRepId = null;
    profileRes.backupRepDetails = '';
    return profileRes;
  };

  /**
   * Summary. Switch input on/off event
   *
   * Description. update the switch input data to state
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   nr         number value of switch
   *
   */
  handleSwitchChange = (nr) => {
    const switchNumber = `switch${nr}`;
    this.setState(
      (prevState) => ({
        [switchNumber]: !prevState[switchNumber],
      }),
      () => {
        const { switch1 } = this.state;
        if (!switch1) {
          const { profileRes } = this.state;
          // Remove old vaction data
          this.setState((prevState) => ({
            profileRes: this.getNewProfileRes(profileRes),
            keyVal: prevState.keyVal + 1,
          }));
        }
      }
    );
  };

  /**
   * Summary. Input phone number change event
   *
   * Description. update phone number value to state
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   values         number object contains formatted value
   * @param {string}   name           name of the input
   * @param {string}   apiValue       value which needs to pass in API
   *
   */
  onDateChange = (values, name, apiValue) => {
    this.setValue(name, apiValue);
  };

  /**
   * Summary. OnChange event
   *
   * Description. Input Change method for all input
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   e           Input element event object
   *
   */
  onChange = (e) => {
    const { name, value } = e.target;
    this.setValue(name, value);
  };

  /**
   * Summary. OnBlur event
   *
   * Description. Blur method for all input
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   e           Input element event object
   *
   */
  onBlur = (e) => {
    const { name } = e.target;
    const { profileRes } = this.state;
    this.validateInput(name, profileRes[name]);
  };

  /**
   * Summary. Set input values
   *
   * Description. Update All the input values to state
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   name           name of the input
   * @param {string}   value          value of the input
   *
   */
  setValue = (name, value) => {
    this.setState((prevState) => ({
      profileRes: {
        ...prevState.profileRes,
        [name]: value,
      },
    }));
  };

  /**
   * Summary. Set Autocomplete data
   *
   * Description. Set company/hospital autocomplete data values to state
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   name           name of the input
   * @param {string}   value          autocomplete value
   * @param {string}   id             id of the company/hospital
   *
   */
  setProfileValue = (name, value, id) => {
    this.setState(
      (prevState) => ({
        profileRes: {
          ...prevState.profileRes,
          [name]: {
            value,
            id,
          },
        },
      }),
      () => {
        if (id) {
          this.validateInput(name, value, id);
        }
      }
    );
  };

  /*
   *
   * Set isFocus flag to true on focus of autocomplete input
   */
  onFocusAutocomplete = (fieldName) => {
    this.setState({
      [`isFocus${fieldName}`]: true,
    });
  };

  /*
   *
   * Set isFocus flag to false on blur event of autocomplete input if no value is filled
   */
  onBlurAutocomplete = (fieldName) => {
    const { profileRes } = this.state;
    const fieldObj = profileRes[fieldName];
    this.validateInput(fieldName, fieldObj.value, fieldObj.id);
    if (!fieldObj.value) {
      this.setState({
        [`isFocus${fieldName}`]: false,
      });
    }
  };

  /**
   * Summary. DatePicker Value
   *
   * Description. Update from and to date values to the state
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   name           name of the input
   * @param {string}   value          value of the input
   *
   */
  onChangeDatePicker = (name, value) => {
    this.setState(
      (prevState) => ({
        profileRes: {
          ...prevState.profileRes,
          [name]: value,
        },
      }),
      () => {
        const { profileRes, errorObj } = this.state;
        const { fromDate, toDate } = profileRes;
        if (errorObj.fromDate || errorObj.toDate) {
          this.validateInput('fromDate', fromDate);
          this.validateInput('toDate', toDate, fromDate);
        }
      }
    );
  };

  /**
   * Summary. Validate Input
   *
   * Description. Sets the error to errorObj and className to inputClass object
   *              if any validation error found.
   *              errorObj is used for displaying the errors for particular input
   *              inputClas is used for Adding error classNames for particular input
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   name           Input element name
   * @param {string}   value          Input element value
   * @param {string}   value1         additional value
   *
   * @return {String} Error if any else null
   */
  validateInput(name, value, value1) {
    if (validateObj[name]) {
      let error = '';
      let className = 'error-border';
      error = validateObj[name](value, value1);
      if (!error) {
        className = '';
      }

      this.setState((prevState) => ({
        errorObj: {
          ...prevState.errorObj,
          [name]: error,
        },
        inputClass: {
          ...prevState.inputClass,
          [name]: className,
        },
      }));

      return error;
    }
    return '';
  }

  /**
   * Summary. Form validation
   *
   * Description. Validate form on submit click
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @return {boolean} false if not valid else true
   */

  validate() {
    const { profileRes, switch1 } = this.state;
    const {
      firstName,
      lastName,
      profileurl,
      phone,
      title,
      customerServicePhone,
      fromDate,
      toDate,
      backupRepId,
      companyName,
      companyId,
      company,
    } = profileRes;
    let isValid = true;
    let error;

    error = this.validateInput('firstName', firstName);
    if (error) {
      isValid = false;
    }

    error = this.validateInput('lastName', lastName);
    if (error) {
      isValid = false;
    }

    error = this.validateInput('profileurl', profileurl);
    if (error) {
      isValid = false;
    }

    const { planDetails } = this.props;
    const isBasicPlan = getBasicPlan(planDetails);
    if (!isBasicPlan) {
      error = this.validateInput('phone', phone);
      if (error) {
        isValid = false;
      }

      error = this.validateInput('customerServicePhone', customerServicePhone);
      if (error) {
        isValid = false;
      }
    }

    error = this.validateInput('title', title.value, title.id);
    if (error) {
      isValid = false;
    }

    error = this.validateInput('companyName', companyName, companyId);
    if (error) {
      isValid = false;
    }

    error = this.validateInput('company', company.value, company.id);
    if (error) {
      isValid = false;
    }

    if (switch1) {
      error = this.validateInput('fromDate', fromDate);
      if (error) {
        isValid = false;
      }

      error = this.validateInput('toDate', toDate, fromDate);
      if (error) {
        isValid = false;
      }

      error = this.validateInput('backupRep', backupRepId);
      if (error) {
        isValid = false;
      }
    }

    return isValid;
  }

  /**
   * Summary. Rep's create/update
   *
   * Description. Create/update the Rep's my account information using API.
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Object}   reqObj      API req object
   */
  callApi = (reqObj) => {
    axiosApi(`/repProfile/createRep`, 'POST', reqObj, (res) => {
      this.setState({ isAPICalled: false });
      if (res.error) {
        alert(res.message);
      } else {
        const { onEditSuccess } = this.props;
        onEditSuccess(reqObj, 'front');
      }
    });
  };

  /**
   * Summary. Form submit
   *
   * Description. Validate the form and call the API to save Rep's my account data
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */

  onButtonClick = () => {
    const isValid = this.validate();
    if (isValid) {
      this.setState({ isAPICalled: true });
      const { profileRes, switch1 } = this.state;
      const {
        firstName,
        lastName,
        phone,
        title,
        customerServicePhone,
        website,
        fromDate,
        toDate,
        companyName,
        companyId,
        company,
        photoUrl,
        email,
        profileurl,
        backupRepId,
      } = profileRes;
      // const { planDetails } = this.props;
      // const isBasicPlan = getBasicPlan(planDetails);

      const reqObj = {
        id: app.user.id,
        firstName,
        lastName,
        website,
        companyName: company.value || companyName,
        titleId: title.id,
        title,
        fromDate,
        toDate,
        backupRepId,
        companyId: company.id || companyId,
        email,
        company,
        profileurl,
        photoUrl,
        phone,
        customerServicePhone,
      };

      // if (!isBasicPlan) {
      //   reqObj.photoUrl = photoUrl;
      //   reqObj.phone = phone;
      //   reqObj.customerServicePhone = customerServicePhone;
      // }

      if (!switch1) {
        reqObj.fromDate = null;
        reqObj.toDate = null;
        reqObj.backupRepId = null;
      }

      this.callApi(reqObj);
    }
  };

  /**
   *  Save backup Rep information on select from dropwndown
   */
  onSaveBackupRep = async (rep) => {
    const { profileRes } = this.state;
    const { firstName: colleagueName } = profileRes;
    let hasAddedProducts = false;
    const urlname = `/repProfile/getProductsForRep?repId=${rep.id}`;
    const reqBody = {
      filters: { company: [] },
    };

    axiosApi(urlname, 'POST', reqBody, (res) => {
      if (res && res.data && res.data.length > 0) {
        hasAddedProducts = true;
      }

      const {
        isOtpVerified,
        isProductcategorySelected,
        isAccountSelected,
        photoUrl,
        phone,
      } = rep;

      if (
        isOtpVerified &&
        isProductcategorySelected &&
        isAccountSelected &&
        photoUrl &&
        phone &&
        hasAddedProducts
      ) {
        this.setValue('backupRepDetails', rep);
        this.setValue('backupRepId', rep.id);
        this.validateInput('backupRep', rep.id);
        this.toggle();
      } else {
        const urlname1 = `/repProfile/sentMailCompleteProfile`;
        const { email, firstName, lastName } = rep;
        const reqBody1 = {
          email,
          firstName,
          lastName,
          colleagueName,
        };
        axiosApi(urlname1, 'POST', reqBody1, () => {});
        alert('Please complete profile first');
      }
    });
  };

  /**
   *  Save backup Rep information from API call
   */
  setBackupRepData = (rep) => {
    this.setValue('backupRepDetails', rep);
  };

  onProfileSave = () => {
    const { profileRes } = this.state;
    const { profileurl } = profileRes;
    this.setState({ isAPICalled3: true }, () => {
      axiosApi(
        `/repProfile/postProfileUrl`,
        'POST',
        {
          id: app.user.id,
          profileurl,
        },
        (res) => {
          this.setState({ isAPICalled3: false });
          if (res.error) {
            alert(res.message);
          } else {
            this.setState({ isProfileurlEdit: false });
            const { onEditSuccess } = this.props;
            onEditSuccess(profileRes, 'front', false);
          }
        }
      );
    });
  };

  copyToClipbord = (Profileurl) => {
    const textArea = document.createElement('textarea');
    textArea.value = Profileurl;

    // Avoid scrolling to bottom
    textArea.style.top = '0';
    textArea.style.left = '0';
    textArea.style.position = 'fixed';

    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();

    try {
      const successful = document.execCommand('copy');
      if (successful) {
        this.setState(
          {
            isCopySuccess: true,
          },
          () => {
            setTimeout(() => {
              this.setState({ isCopySuccess: false });
            }, 3000);
          }
        );
      } else alert('Oops, unable to copy');
    } catch (err) {
      alert('Oops, unable to copy');
    }

    document.body.removeChild(textArea);
  };

  render() {
    const {
      profileRes,
      switch1,
      errorObj,
      inputClass,
      isAPICalled,
      isAPICalled3,
      modal,
      keyVal,
      isFocustitle,
      isFocuscompany,
      isProfileurlEdit,
      isCopySuccess,
    } = this.state;
    const { onCancel, planDetails, upgradeClick } = this.props;
    const isBasicPlan = getBasicPlan(planDetails);

    const { backupRepId, backupRepDetails, title, company } = profileRes;

    const Profileurl = `${window.location.origin}/r/${profileRes.profileurl}`;

    const backupRepVal =
      backupRepId && backupRepDetails
        ? `${backupRepDetails.firstName} ${backupRepDetails.lastName}`
        : '';

    return (
      <MDBContainer>
        <div className="whitebg-wrapper my-6">
          <MDBRow>
            <MDBCol lg="12" md="12">
              <div className="edit-wrapper m-auto">
                <MDBRow>
                  <MDBCol lg="8">
                    <ProfileHeading headingtxt="My Repcard (Front)" />
                    <div className="edit-profile-fields">
                      <PhotoUpload
                        photoUrl={isBasicPlan ? '' : profileRes.photoUrl}
                        onPhotoChange={this.onPhotoChange}
                        isBasicPlan={isBasicPlan}
                        upgradeClick={upgradeClick}
                      />
                      <div className="edit-fields-panel mt-4">
                        <MDBRow>
                          <MDBCol lg="6">
                            <div
                              className={`input-field ${inputClass.firstName}`}
                            >
                              <MDBInput
                                type="text"
                                value={profileRes.firstName}
                                name="firstName"
                                onChange={this.onChange}
                                onBlur={this.onBlur}
                                label="First Name"
                              />
                              {errorObj.firstName ? (
                                <p className="error-message">
                                  <span /> {errorObj.firstName}
                                </p>
                              ) : (
                                ''
                              )}
                            </div>
                          </MDBCol>
                          <MDBCol lg="6">
                            <div
                              className={`input-field ${inputClass.lastName}`}
                            >
                              <MDBInput
                                type="text"
                                value={profileRes.lastName}
                                name="lastName"
                                onChange={this.onChange}
                                onBlur={this.onBlur}
                                label="Last Name"
                              />
                              {errorObj.lastName ? (
                                <p className="error-message">
                                  <span /> {errorObj.lastName}
                                </p>
                              ) : (
                                ''
                              )}
                            </div>
                          </MDBCol>
                          <MDBCol lg="4">
                            <div
                              className={`${isBasicPlan ? 'hovertooltip' : ''}`}
                            >
                              <div
                                className={`input-field fixed-field ${inputClass.phone}`}
                              >
                                <label className="field_label">
                                  Mobile Number
                                </label>
                                <RepNumberFormat
                                  onChange={this.onDateChange}
                                  onBlur={this.onBlur}
                                  value={profileRes.phone}
                                  className="form-control"
                                  name="phone"
                                  format="XXX.XXX.XXXX"
                                />
                                {errorObj.phone ? (
                                  <p className="error-message">
                                    <span /> {errorObj.phone}
                                  </p>
                                ) : (
                                  ''
                                )}
                              </div>
                            </div>
                          </MDBCol>
                          <MDBCol lg="8">
                            <div className="input-field disabled noEvents">
                              <MDBInput
                                type="email"
                                disabled
                                value={profileRes.email}
                                label="Email"
                              />
                            </div>
                          </MDBCol>

                          <MDBCol lg="12">
                            {!isProfileurlEdit ? (
                              <div className="input-field url-field">
                                <label className="field_label">
                                  Custom Profile URL for Sharing
                                </label>
                                <div className="input-group justify-content-between">
                                  <div className="input-group-prepend">
                                    <span className="input-group-text">
                                      {Profileurl}
                                    </span>
                                  </div>
                                  <div className="input-group-append">
                                    <button
                                      type="button"
                                      className="fill-orange-btn mr-1"
                                      onClick={() =>
                                        this.copyToClipbord(Profileurl)
                                      }
                                      data-repcard-test="copyBtn"
                                    >
                                      {isCopySuccess ? 'Copied' : 'Copy'}
                                    </button>{' '}
                                    <button
                                      type="button"
                                      className="fill-orange-btn"
                                      onClick={() =>
                                        this.setState({
                                          isProfileurlEdit: true,
                                        })
                                      }
                                      data-repcard-test="editBtn"
                                    >
                                      Edit
                                    </button>
                                  </div>
                                </div>
                              </div>
                            ) : (
                              <div
                                className={`input-field url-field ${inputClass.profileurl}`}
                              >
                                <MDBInputGroup
                                  label="Custom Profile URL for Sharing"
                                  labelClassName="field_label"
                                  prepend={`${window.location.origin}/r/`}
                                  append={
                                    <button
                                      type="button"
                                      className="fill-orange-btn"
                                      onClick={this.onProfileSave}
                                      disabled={isAPICalled3}
                                      data-repcard-test="saveBtn"
                                    >
                                      {isAPICalled3 ? (
                                        <span className="spinner-border spinner-border-sm" />
                                      ) : (
                                        'Save'
                                      )}
                                    </button>
                                  }
                                  value={profileRes.profileurl}
                                  name="profileurl"
                                  onChange={(e) =>
                                    this.setValue('profileurl', e.target.value)
                                  }
                                  onBlur={this.onBlur}
                                />
                                {errorObj.profileurl ? (
                                  <p className="error-message">
                                    <span /> {errorObj.profileurl}
                                  </p>
                                ) : (
                                  ''
                                )}
                              </div>
                            )}
                          </MDBCol>

                          <MDBCol lg="12">
                            <div className="custom-control custom-switch">
                              <input
                                type="checkbox"
                                className="custom-control-input"
                                id="customSwitches"
                                checked={switch1}
                                onChange={() => {
                                  this.handleSwitchChange(1);
                                }}
                              />
                              <label
                                className="custom-control-label"
                                htmlFor="customSwitches"
                              >
                                Set Out of Office Notice
                              </label>
                            </div>
                          </MDBCol>
                          {switch1 ? (
                            <Suspense fallback={<Loading />}>
                              <DateRangePicker
                                fromDate={profileRes.fromDate}
                                toDate={profileRes.toDate}
                                errorObj={errorObj}
                                inputClass={inputClass}
                                onChangeCallBack={this.onChangeDatePicker}
                              />
                              <MDBCol lg="12">
                                <div
                                  className={`input-field ${inputClass.backupRep}`}
                                >
                                  <MDBInput
                                    type="text"
                                    value={backupRepVal}
                                    disabled
                                    label="Backup Rep"
                                  />
                                  <div
                                    onClick={this.toggle}
                                    role="presentation"
                                    className="plus_icon addBackRep"
                                  />
                                  {errorObj.backupRep ? (
                                    <p className="error-message">
                                      <span /> {errorObj.backupRep}
                                    </p>
                                  ) : (
                                    ''
                                  )}
                                </div>
                                <MDBModal
                                  className="backuprep_popup"
                                  isOpen={modal}
                                  toggle={this.toggle}
                                >
                                  <div
                                    role="presentation"
                                    onClick={this.toggle}
                                    className="close_auth_popup close"
                                  >
                                    X close
                                  </div>
                                  <AddBackupRep
                                    companyId={profileRes.companyId}
                                    onSaveBackupRep={this.onSaveBackupRep}
                                  />
                                </MDBModal>
                              </MDBCol>
                            </Suspense>
                          ) : (
                            ''
                          )}
                          <MDBCol lg="12">
                            <div
                              className={`input-field ${inputClass.company}`}
                            >
                              <RepAutocomplete
                                inputName="company"
                                inputClass={inputClass.company}
                                placeholder=""
                                onFocus={() => {
                                  this.onFocusAutocomplete('company');
                                }}
                                onBlur={() => {
                                  this.onBlurAutocomplete('company');
                                }}
                                getItemValue={(item) => item.companyName}
                                shouldItemRender={(state, value) =>
                                  matchStateToTermCustom(
                                    state.companyName,
                                    value
                                  )
                                }
                                sortItems={() => 1}
                                renderInput={(props) => [
                                  <input key="1" {...props} />,
                                  <label
                                    className={
                                      isFocuscompany || company.value
                                        ? 'active'
                                        : ''
                                    }
                                    style={{ pointerEvents: 'none' }}
                                    key="2"
                                  >
                                    Company Name
                                  </label>,
                                ]}
                                apiurl="/manufacturers"
                                renderItem={(item, isHighlighted) => {
                                  return (
                                    <li
                                      style={{
                                        background: isHighlighted
                                          ? '#eeeeee'
                                          : '',
                                      }}
                                      key={item.companyId}
                                    >
                                      {item.companyName}
                                    </li>
                                  );
                                }}
                                value={company.value}
                                onChange={(event, value) => {
                                  this.setProfileValue('company', value, '');
                                }}
                                minChar={0}
                                onSelect={(value, item) => {
                                  this.setProfileValue(
                                    'company',
                                    value,
                                    item.companyId
                                  );
                                  this.setValue('website', item.website);
                                }}
                              />

                              {errorObj.company ? (
                                <span className="error-message">
                                  {errorObj.company}
                                </span>
                              ) : (
                                ''
                              )}
                            </div>
                          </MDBCol>
                          <MDBCol lg="12">
                            <div className={`input-field ${inputClass.title}`}>
                              <RepAutocomplete
                                inputName="title"
                                inputClass={inputClass.title}
                                placeholder=""
                                onFocus={() => {
                                  this.onFocusAutocomplete('title');
                                }}
                                onBlur={() => {
                                  this.onBlurAutocomplete('title');
                                }}
                                getItemValue={(item) => item.title}
                                shouldItemRender={(state, value) =>
                                  matchStateToTermCustom(state.title, value)
                                }
                                sortItems={() => 1}
                                renderInput={(props) => [
                                  <input key="1" {...props} />,
                                  <label
                                    className={
                                      isFocustitle || title.value
                                        ? 'active'
                                        : ''
                                    }
                                    style={{ pointerEvents: 'none' }}
                                    key="2"
                                  >
                                    Title
                                  </label>,
                                ]}
                                apiurl="/titles/getAllRepTitles"
                                renderItem={(item, isHighlighted) => {
                                  return (
                                    <li
                                      style={{
                                        background: isHighlighted
                                          ? '#eeeeee'
                                          : '',
                                      }}
                                      key={item.id}
                                    >
                                      {item.title}
                                    </li>
                                  );
                                }}
                                value={title.value}
                                onChange={(event, value) => {
                                  this.setProfileValue('title', value, '');
                                }}
                                minChar={0}
                                onSelect={(value, item) => {
                                  this.setProfileValue('title', value, item.id);
                                }}
                              />
                              {errorObj.title ? (
                                <span className="error-message">
                                  {errorObj.title}
                                </span>
                              ) : (
                                ''
                              )}
                            </div>
                          </MDBCol>
                          <MDBCol lg="4">
                            <div
                              className={`${isBasicPlan ? 'hovertooltip' : ''}`}
                            >
                              <div
                                className={`input-field fixed-field ${inputClass.customerServicePhone}`}
                              >
                                <label className="field_label">
                                  Customer Service Phone
                                </label>
                                <RepNumberFormat
                                  onChange={this.onDateChange}
                                  value={profileRes.customerServicePhone}
                                  onBlur={this.onBlur}
                                  className="form-control"
                                  name="customerServicePhone"
                                  format="XXX.XXX.XXXX"
                                />
                                {errorObj.customerServicePhone ? (
                                  <p className="error-message">
                                    <span /> {errorObj.customerServicePhone}
                                  </p>
                                ) : (
                                  ''
                                )}
                              </div>
                            </div>
                          </MDBCol>
                          <MDBCol lg="8">
                            <div className="input-field disabled noEvents">
                              <MDBInput
                                type="text"
                                disabled
                                value={profileRes.website}
                                label="Company Website"
                              />
                            </div>
                          </MDBCol>
                          <MDBCol className="mt-4">
                            <button
                              type="button"
                              className="float-left fill-orange-btn"
                              onClick={this.onButtonClick}
                              disabled={isAPICalled}
                              data-repcard-test="saveBtn"
                            >
                              {isAPICalled ? (
                                <span className="spinner-border spinner-border-sm" />
                              ) : (
                                ''
                              )}
                              Save
                            </button>
                            <button
                              type="button"
                              className="float-left outline-btn"
                              onClick={onCancel}
                              data-repcard-test="cancelBtn"
                            >
                              Cancel
                            </button>
                          </MDBCol>
                        </MDBRow>
                      </div>
                    </div>
                  </MDBCol>
                  <MDBCol lg="4">
                    <ProfileHeading headingtxt="My Repcard" />
                    <RepCard
                      flipicondisable
                      profileRes={profileRes}
                      shadows="shadows"
                      boxclass="boxpanel"
                      key={keyVal}
                      setBackupRep={this.setBackupRepData}
                      onChange={this.onDateChange}
                    />
                  </MDBCol>
                </MDBRow>
              </div>
            </MDBCol>
          </MDBRow>
        </div>
      </MDBContainer>
    );
  }
}

export default RepProfileEditFront;
