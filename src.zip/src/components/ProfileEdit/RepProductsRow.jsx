/**
 *
 * Description. ProductCategory
 *
 * @link   URL
 * @file   Display All the productcategory with its sub categories in popup
 * @since  1.0.0
 */
import React, { Component } from 'react';
import { MDBInput } from 'mdbreact';
import PublishSubscribe from 'publish-subscribe-js';
import PUB_SUB from '../../constants/events.constant';

class RepProductsRow extends Component {
  constructor(props) {
    super(props);
    const { masterList, list } = this.props;

    const newMasterList = masterList.map((p) => ({ ...p }));

    newMasterList.forEach((v) => {
      v.checked = false; // eslint-disable-line
    });

    if (list) {
      list.forEach((v) => {
        const newIndex = newMasterList.findIndex((x) => x.id === v.id);
        if (newIndex !== -1) {
          newMasterList[newIndex].checked = true;
        }
      });
    }

    this.state = {
      isOpen: false,
      masterList: newMasterList,
    };
    this.mousedownSubKey = 0;
  }

  /**
   *  Validate the payload
   */
  validatePayload = () => {
    const arr = this.getNewListArr();
    if (arr.length) {
      return true;
    }
    this.setState({
      errorMsg: 'Please choose a product line',
    });

    return false;
  };

  /**
   * Summary. Open product list
   *
   * Description. Open product list in dropdown
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}    e     event object
   */
  openProductList = (e) => {
    e.preventDefault();
    this.setState({
      isOpen: true,
    });
  };

  /**
   * Summary. Outside click event
   *
   * Description. Check if click event is occured not in the html part and closes
                  the popup on outside click
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   eventObj   click event object
   *
   */
  handleClickOutside = (eventObj) => {
    const { isOpen } = this.state;
    if (
      isOpen &&
      this.wrapperRef &&
      !this.wrapperRef.contains(eventObj.event.target)
    ) {
      this.setState({
        isOpen: false,
      });
    }
  };

  /**
   *   Set Ref for product categories dropdown
   */
  setWrapperRef = (node) => {
    this.wrapperRef = node;
  };

  /**
   *   Set Ref for mainDiv
   */
  setCurrentElementNode = (node) => {
    this.currentElem = node;
  };

  componentDidMount() {
    // mouse down event subscribe for outside click
    this.mousedownSubKey = PublishSubscribe.subscribe(
      PUB_SUB.MOUSEDOWN,
      this.handleClickOutside
    );
  }

  componentWillUnmount() {
    // PublishSubscribe.unsubscribe(PUB_SUB.MOUSEDOWN, this.mousedownSubKey);
  }

  /**
   *   Generate product categories info using checked flag
   */
  getNewListArr = () => {
    const { masterList } = this.state;
    let arr = [];
    masterList.forEach((v) => {
      if (v.checked) {
        arr = [...arr, { id: v.id, name: v.name, info: v.info }];
      }
    });
    return arr;
  };

  /**
   * Summary. Checkbox change event
   *
   * Description. Product category checkbox change event - Add check falg to the
                  object whichever is checked
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {object}   e       event object
   * @param {object}   item    product line object
   *
   */
  onChangeCheckbox = (e, item) => {
    const { masterList } = this.state;
    const { checked } = e.target;
    const newIndex = masterList.findIndex((x) => x.id === item.id);
    masterList[newIndex].checked = checked;
    this.setState(
      {
        masterList,
        errorMsg: '',
      },
      () => {
        const newArr = this.getNewListArr();
        const { updateArr } = this.props;
        updateArr(newArr);
      }
    );
  };

  /**
   *   Get All Product category names whichever is checked
   */
  getNamesList = () => {
    const { masterList } = this.state;
    let str = [];
    masterList.forEach((v) => {
      if (v.checked) {
        str = [...str, v.name];
      }
    });
    return str.join(', ');
  };

  render() {
    const { isOpen, masterList, errorMsg } = this.state;
    const { productcategoryName, list } = this.props;
    const namesList = list.map((p) => p.name).join(', ');

    return (
      <div
        className="input-field fixed-field product-label arrow-list"
        ref={this.setCurrentElementNode}
      >
        <label
          className={
            isOpen || namesList ? 'field_label labelActive' : 'field_label'
          }
        >
          {productcategoryName}
        </label>
        <div
          onClick={this.openProductList}
          role="presentation"
          className="product-list"
          data-repcard-test="openproduct"
        >
          <div>
            <div className="form-control">{namesList}</div>
          </div>
        </div>
        {errorMsg && (
          <p className="error-message">
            <span /> {errorMsg}
          </p>
        )}
        {isOpen ? (
          <div className="multiple-product">
            <div className="product-wrap" ref={this.setWrapperRef}>
              <ul>
                {masterList.map((v) => {
                  return (
                    <li key={v.id}>
                      <MDBInput
                        label={v.name}
                        filled
                        checked={v.checked}
                        type="checkbox"
                        id={`${v.id}id`}
                        onChange={(e) => {
                          this.onChangeCheckbox(e, v);
                        }}
                      />
                      {v.info && (
                        <div className="info_icon">
                          <span className="spciality_popover">{v.info}</span>
                        </div>
                      )}
                    </li>
                  );
                })}
              </ul>
            </div>
          </div>
        ) : null}
      </div>
    );
  }
}

export default RepProductsRow;
