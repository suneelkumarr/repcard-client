/**
 *
 * Description. Rep/Provider Dashboard
 *
 * @link   URL
 * @file   Common Dashboard page for viewing Rep's My Account, productcategory, Account information, plan details
            And provider's My Account, Account information and plan details
 * @since  1.0.0
 */

import React, { Component, lazy, Suspense } from 'react';
import { MDBContainer, MDBRow, MDBCol } from 'mdbreact';
import Footer from '../Footer/Footer';
import ProfileHeading from '../Common/ProfileHeading';
import { axiosApi } from '../../apis/axiosApiCall';
import { getMasterProductCategoryData } from '../../utils/masterProductCategoryData';
import { getProductCategoryApi } from '../../utils/getProductCategoryApi';
import { getSubscriptionApi } from '../../utils/stripeApis';
import app from '../../helpers/appGlobal';

import './dashboard.scss';

const Loading = () => <div>Loading...</div>;
const RepProfileEditFront = lazy(() =>
  import('../ProfileEdit/RepProfileEditFront.jsx')
);
const ProviderProfileEditFront = lazy(() =>
  import('../ProfileEdit/ProviderProfileEditFront.jsx')
);

const RepProfileEditBack = lazy(() =>
  import('../ProfileEdit/RepProfileEditBack.jsx')
);

const Plans = lazy(() => import('../PremiumPlan/index.jsx'));

const RepHeader = lazy(() => import('../NavHeader/RepHeader/Header'));
const ProviderHeader = lazy(() => import('../NavHeader/ProviderHeader/Header'));

const RepCard = lazy(() => import('../Common/RepCard/RepCard'));
const ProviderRepCard = lazy(() =>
  import('../Common/ProviderRepCard/ProviderRepCard')
);

const RepAccountCard = lazy(() =>
  import('../Common/AccountCard/RepAccountCard')
);
const ProviderAccountCard = lazy(() =>
  import('../Common/AccountCard/ProviderAccountCard')
);

const RepProductCategory = lazy(() =>
  import('../Common/RepProductCategory/RepProductCategory')
);

const AccountEdit = lazy(() => import('../AccountEdit/AccountEdit.jsx'));

class CommonDashboard extends Component {
  constructor(props) {
    super(props);
    const initialLimit = 20;
    this.state = {
      profileRes: {},
      totalRes: [],
      productcategoryRes: [],
      initialLimit,
      limit: initialLimit,
      totalLength: 0,
      masterAPICalled: true,
      isAPICalled1: true,
      isAPICalled: true,
      isCustomerAPI: true,
    };
  }

  /**
   * Summary. Filter productcategory response
   *
   * Description. Set productcategory response and display the productcategories
   *              as per the limit
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Array}    data      List of Array of objects
   * @param {Integer}  limit     Display limit
   *
   * @return {Object} TotalLength and new productcategory Arr
   */
  filterDataAsperLimit = (data, limit) => {
    let newArr = [];
    let totalLength = 0;
    data.forEach((v) => {
      const obj1 = {
        productcategoryId: v.productcategoryId,
        productcategoryName: v.productcategoryName,
        productlines: [],
      };
      let arr1 = [];
      v.productlines.forEach((v1, i) => {
        if (totalLength < limit) {
          if (i === 0) {
            newArr = [...newArr, obj1];
          }
          arr1 = [...arr1, v1];
          obj1.productlines = arr1;
        }
        totalLength += 1;
      });
    });
    return {
      totalLength,
      newArr,
    };
  };

  /**
   * Summary. Set ProductCategory Response
   *
   * Description. Set productcategory response and display the productcategories
   *              as per the limit
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Array}  results      List of Array of objects
   */
  setProductCategorySuccessRes = (results) => {
    if (results && results.length) {
      const { initialLimit } = this.state;
      const { totalLength, newArr } = this.filterDataAsperLimit(
        results,
        initialLimit
      );
      this.setState(
        {
          totalRes: results,
          productcategoryRes: newArr,
          totalLength,
        },
        () => {
          if (app.productLineEdit) {
            // Open directly productline
            this.onEditClick('back');
          }
          app.productLineEdit = false;
        }
      );
    } else {
      this.setState(
        {
          totalRes: [],
          productcategoryRes: [],
          totalLength: 0,
        },
        () => {
          if (app.productLineEdit) {
            // Open directly productline
            this.onEditClick('back');
          }
          app.productLineEdit = false;
        }
      );
    }
  };

  /**
   * Summary. Rep's ProductCategory
   *
   * Description. To Retrive all the Rep's productcategories information
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  getProductCategoryApi = () => {
    this.setState({
      isAPICalled1: true,
    });
    getProductCategoryApi(app.user.id, (results) => {
      this.setProductCategorySuccessRes(results);
      this.setState({
        isAPICalled1: false,
      });
    });
  };

  /**
   * Summary. Payment API
   *
   * Description. To retrive all the payment related info (plan details)
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {string}   subscriptionId        Plan subscription id
   *
   */
  getPaymentInfoAPI = (subscriptionId) => {
    if (subscriptionId) {
      this.setState({
        isCustomerAPI: true,
      });
      getSubscriptionApi(subscriptionId, (plan) => {
        if (plan) {
          this.setState({
            planDetails: plan,
          });
        }
        this.setState({
          isCustomerAPI: false,
        });
      });
    } else {
      this.setState({
        isCustomerAPI: false,
      });
    }
  };

  /**
   * Summary. Get My Account Information
   *
   * Description. Call API for Rep/Provider to get my account data
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  getMyAccountApi = () => {
    this.setState({
      isAPICalled: true,
    });
    let urlname = `/providerProfile/getMyAccountProfile/${app.user.id}`;
    if (app.user.userType === 'rep') {
      urlname = `/repProfile/getMyAccountRepProfile/${app.user.id}`;
    }
    axiosApi(urlname, 'GET', '', (res) => {
      if (res.error) {
        if (res.code === 'REP01') {
          this.setState({
            profileRes: {
              email: app.user.email,
            },
          });
        }
        this.getPaymentInfoAPI(''); // This is used for removing flag
      } else if (res.data) {
        this.setState({
          profileRes: res.data,
        });
        // Call the payment API to get plan info
        this.getPaymentInfoAPI(res.data.subscriptionId);
      }
      this.setState({
        isAPICalled: false,
      });
    });
  };

  /**
   * Summary. Load Master ProductCategory Data
   *
   * Description. Call API for Master data of productcategory
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   */
  getMasterProductCategoryData = () => {
    this.setState({
      masterAPICalled: true,
    });
    getMasterProductCategoryData((flag) => {
      if (flag) {
        this.setState({
          masterAPICalled: false,
        });
      }
    });
  };

  componentDidMount() {
    this.getMyAccountApi();
    if (app.user.userType === 'rep') {
      this.getProductCategoryApi();
    }
    this.getMasterProductCategoryData();
    if (app.isUpgrade) {
      // Open directly plan page if this flag is set
      this.setState({
        isUpgrade: true,
      });
    } else if (app.ProfileEdit) {
      // Open directly edit page of front part for Rep/Provider
      this.onEditClick('front');
    }
    app.isUpgrade = false;
    app.ProfileEdit = false;
  }

  /**
   *
   * ProductCategory more click handling. Display more data as per the limit
   */
  moreClick = () => {
    const { limit, totalRes, initialLimit } = this.state;
    const newLimit = limit + initialLimit;
    const { newArr } = this.filterDataAsperLimit(totalRes, newLimit);
    this.setState({
      productcategoryRes: newArr,
      limit: newLimit,
    });
  };

  /**
   *
   * My Account Front/Back page edit click
   */
  onEditClick = (screenName) => {
    this.setState({
      isEdit: screenName,
      isEditComplete: false,
    });
  };

  /**
   * Summary. On Edit success handling
   *
   * Description. Set the response after edit of my account front/back page
   *
   * @since      1.0
   * @deprecated No //x.x.x Use new_function_name() instead.
   * @access     export private
   *
   * @param {Object}   res        Object in case of front page, Array
   *                              in case of back page(speciaity)
   * @param {String}   from       From where this is called (front/back)
   */
  onEditSuccess = (res, from, isEditComplete = true) => {
    if (from === 'front') {
      this.setState({
        profileRes: res,
      });
    } else if (from === 'back') {
      this.setProductCategorySuccessRes(res);
    }
    if (isEditComplete) {
      this.setState({
        isEdit: '',
        isEditComplete: true,
      });
    }
  };

  /**
   *
   * My Account Front/Back page cancel btn click event
   */
  onCancel = () => {
    this.setState({
      isEdit: '',
    });
  };

  /**
   *
   * Current plan edit click event
   */
  onPlanClick = () => {
    this.setState({
      isUpgrade: true,
      isEditComplete: false,
    });
  };

  /**
   *
   * Set current plan edit flag to false and go to view mode
   */
  goBackToDashboard = () => {
    this.setState({
      isUpgrade: false,
      isAccountEdit: false,
    });
  };

  /**
   *
   * Set current plan edit flag to false and show the success message
   */
  goBackToDashboardAndSave = () => {
    this.setState({
      isUpgrade: false,
      isAccountEdit: false,
      isEditComplete: true,
    });
  };

  /**
   *
   * Account credentials edit click event
   */
  onAccountEditClick = () => {
    this.setState({
      isAccountEdit: true,
      isEditComplete: false,
    });
  };

  upgradeClick = () => {
    this.onCancel();
    this.onPlanClick();
  };

  render() {
    const {
      profileRes,
      productcategoryRes,
      totalLength,
      totalRes,
      limit,
      isEdit,
      isEditComplete,
      isAPICalled,
      isAPICalled1,
      masterAPICalled,
      isCustomerAPI,
      isUpgrade,
      planDetails,
      isAccountEdit,
    } = this.state;

    return (
      <>
        <Suspense fallback={<Loading />}>
          {app.user.userType === 'rep' ? (
            <RepHeader profileRes={profileRes} isAPINotNeeded {...this.props} />
          ) : (
            <ProviderHeader
              profileRes={profileRes}
              isAPINotNeeded
              {...this.props}
            />
          )}
        </Suspense>
        {isAccountEdit ? (
          <Suspense fallback={<Loading />}>
            <AccountEdit
              goBackToDashboard={this.goBackToDashboard}
              goBackToDashboardAndSave={this.goBackToDashboardAndSave}
            />
          </Suspense>
        ) : isUpgrade ? (
          <Suspense fallback={<Loading />}>
            {isCustomerAPI ? (
              ''
            ) : (
              <Plans
                goBackToDashboard={this.goBackToDashboard}
                goBackToDashboardAndSave={this.goBackToDashboardAndSave}
                isRep={app.user.userType === 'rep'}
              />
            )}
          </Suspense>
        ) : isEdit === 'front' ? (
          <Suspense fallback={<Loading />}>
            {isCustomerAPI || isAPICalled || masterAPICalled ? (
              ''
            ) : app.user.userType === 'rep' ? (
              <RepProfileEditFront
                onEditSuccess={this.onEditSuccess}
                onCancel={this.onCancel}
                profileRes={profileRes}
                productcategoryRes={totalRes}
                planDetails={planDetails}
                upgradeClick={this.upgradeClick}
              />
            ) : (
              <ProviderProfileEditFront
                onEditSuccess={this.onEditSuccess}
                onCancel={this.onCancel}
                profileRes={profileRes}
                planDetails={planDetails}
                upgradeClick={this.upgradeClick}
              />
            )}
          </Suspense>
        ) : isEdit === 'back' ? (
          <Suspense fallback={<Loading />}>
            <RepProfileEditBack
              onEditSuccess={this.onEditSuccess}
              onCancel={this.onCancel}
              profileRes={profileRes}
              productcategoryRes={totalRes}
            />
          </Suspense>
        ) : (
          <Suspense fallback={<Loading />}>
            <MDBContainer>
              <MDBRow
                className={
                  app.user.userType === 'rep'
                    ? ''
                    : 'd-flex justify-content-center'
                }
              >
                {isEditComplete ? (
                  <p className="text-center success-notification">
                    <span className="success_pr_icon" />
                    Your changes have been saved successfully.
                  </p>
                ) : (
                  ''
                )}
                <MDBCol
                  lg={app.user.userType === 'rep' ? '12' : '9'}
                  className="my-6"
                >
                  <MDBRow>
                    {!(isAPICalled || masterAPICalled) ? (
                      <MDBCol
                        lg={app.user.userType === 'rep' ? '4' : '6'}
                        md="6"
                      >
                        <div className="rep-card-panel">
                          <div>
                            <ProfileHeading
                              headingtxt={
                                app.user.userType === 'rep'
                                  ? 'My Repcard (Front)'
                                  : 'My Profile Information'
                              }
                              buttonenable
                              onClick={() => {
                                this.onEditClick('front');
                              }}
                            />
                          </div>
                          <div className="mt-4">
                            {app.user.userType === 'rep' ? (
                              <RepCard
                                profileRes={profileRes}
                                flipicondisable={false}
                                showInlineAvailable
                              />
                            ) : (
                              <ProviderRepCard
                                profileRes={profileRes}
                                changehight="pdheightreduce"
                              />
                            )}
                          </div>
                        </div>
                      </MDBCol>
                    ) : (
                      ''
                    )}

                    {!(isAPICalled1 || masterAPICalled) ? (
                      app.user.userType === 'rep' ? (
                        <MDBCol lg="4" md="6">
                          <div className="rep-card-panel">
                            <div>
                              <ProfileHeading
                                headingtxt="My Repcard (Back)"
                                buttonenable
                                onClick={() => {
                                  this.onEditClick('back');
                                }}
                              />
                            </div>
                            <div className="mt-4">
                              <RepProductCategory
                                isNameRemove={false}
                                flipicondisable={false}
                                productcategoryRes={productcategoryRes}
                                photoUrl={profileRes.photoUrl}
                                changehight=""
                              />
                              {totalLength > limit ? (
                                <div
                                  role="presentation"
                                  className="more-list"
                                  onClick={this.moreClick}
                                >
                                  more
                                </div>
                              ) : (
                                ''
                              )}
                            </div>
                          </div>
                        </MDBCol>
                      ) : (
                        ''
                      )
                    ) : (
                      ''
                    )}

                    {!(isAPICalled || isCustomerAPI) ? (
                      app.user.userType === 'rep' ? (
                        <MDBCol lg="4">
                          <RepAccountCard
                            planDetails={planDetails}
                            onPlanClick={this.onPlanClick}
                            onAccountEditClick={this.onAccountEditClick}
                          />
                        </MDBCol>
                      ) : (
                        <MDBCol lg="6" md="6">
                          <ProviderAccountCard
                            planDetails={planDetails}
                            onPlanClick={this.onPlanClick}
                            onAccountEditClick={this.onAccountEditClick}
                          />
                        </MDBCol>
                      )
                    ) : (
                      ''
                    )}
                  </MDBRow>
                </MDBCol>
              </MDBRow>
            </MDBContainer>
          </Suspense>
        )}

        <Footer />
      </>
    );
  }
}

export default CommonDashboard;
