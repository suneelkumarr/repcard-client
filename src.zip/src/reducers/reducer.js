// Combine All the reducers over here
import { combineReducers } from 'redux';

import dashboardReducer from './dashboardReducer';

const repCardzApp = combineReducers({ dashboardReducer });

export default repCardzApp;
